# IDB Schema 快照 (v2.3.2.6 部署後, IDB→SoT 升級前)

## Database: LearningProgressDB v4
## 升級到 Source-of-Truth 前的最後狀態

### 12 Object Stores (per disk-db.js)

| Store | KeyPath | 用途 | 同步狀態 |
|-------|---------|------|---------|
| units | _legacyUnitId (e.g., id_xxx) | 教材 unit 細節 | 一次性 snapshot, runtime 不更新 |
| masters | id | 教材主檔 | 一次性 snapshot |
| ... | ... | (其他 10 個 store) | 待盤點 |

### units store 結構 (10 fields)
```
{
  typeName: string,         // '複習' U+7FD2
  instanceName: string,
  vol: string,
  unitName: string,
  _legacyUnitId: string,    // 'id_xxx' ← 注意：沒有 id 欄位
  subject: string,
  cat: string,
  start: number,
  end: number,
  createdAt: ISO8601
}
```

### 已知單位總數
- 697 units total
- 國文 進度式 = 21 units (在 localStorage 是 0 units → IDB 是權威)

### 字串分歧
| 來源 | 用途 | 字串 |
|------|------|------|
| UI button | user-facing | 複習 (習 U+7FD2) |
| IDB units.typeName | database | 複習 (習 U+7FD2) |
| localStorage multiData | runtime legacy | 複試 (試 U+8A66) |

### Bug 鏈 (記錄用)
1. _collectSubjectUnits line 4805 `if (u && u.id)` → IDB unit 無 id → 跳過
2. findUnitContext line 2730 `if (!unitId) return null` → u.id 為 undefined → null
3. getUnitTotalCount line 2611 → page count 當 unit count

