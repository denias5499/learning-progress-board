import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

old_within = '''                        // 2. v1.6.169: 強健 within-match remap
                        // 保留 v1.6.64 的 within-match (page range 為主) + exact-match (type+instance 為主)
                        // 加上 v1.6.169 強化: cross-vol 同名 unit 用 typeName+instanceName+vol 鎖,
                        // 避免被錯指到頁範圍剛好覆蓋的另一 vol unit
                        var masterEntry = (user.masters[t.cat] || {})[t.subject];
                        if (!masterEntry) return;
                        var allUnits = _collectSubjectUnits(masterEntry);
                        var match = null;
                        // v1.6.64: within-match (page range 涵蓋, 但 v1.6.169 加 type+instance+vol 鎖避免跨 vol 誤判)
                        var withinMatch = allUnits.find(function(u) {
                            if (u.name !== t.unitName) return false;
                            // v1.6.169: type+instance 鎖 (避免跨 instance 同名 unit 誤判, 例如 麻辣甲 vs 大滿貫)
                            if (t.typeName && u._typeName !== t.typeName) return false;
                            if (t.instanceName && u._instanceName !== t.instanceName) return false;
                            // v1.6.168: vol 鎖 (避免跨 vol 同名 unit 誤判, 例如 大滿貫 第二冊 L1~2 vs 第三冊 L1~2)
                            if (u.vol != null && t.vol && u.vol !== t.vol) return false;
                            if (t.startPage != null && t.endPage != null &&
                                u.start != null && u.end != null) {
                                return u.start <= t.startPage && u.end >= t.endPage;
                            }
                            return true;
                        });
                        if (t.typeName && t.instanceName) {
                            // 精確比對: name + typeName + instanceName + vol (v1.6.168 加 vol 保險)
                            match = allUnits.find(function(u) {
                                return u.name === t.unitName &&
                                       u._typeName === t.typeName &&
                                       u._instanceName === t.instanceName &&
                                       (u.vol == null || !t.vol || u.vol === t.vol);
                            });
                            // v1.6.64: 如果精確比對的 unit 頁範圍不涵蓋 task (例如 麻辣甲 P.1 vs task P.39-42),
                            // 但有 within-match 的 unit 涵蓋, 用 within-match
                            if (match && withinMatch && match.id !== withinMatch.id) {
                                var matchCovers = match.start <= t.startPage && match.end >= t.endPage;
                                if (!matchCovers) {
                                    match = withinMatch;
                                }
                            } else if (!match) {
                                // exact match 找不到 (舊資料沒 typeName/instanceName 設對), 用 within-match
                                match = withinMatch;
                            }
                        } else {
                            match = withinMatch;
                        }'''

new_within = '''                        // 2. v1.6.169: 強健 within-match remap
                        // - within-match 用 page range + vol 鎖 (不加 type/instance, 才能跨 instance disambiguate)
                        // - exact-match 用 type+instance+vol (鎖定同一個教材實例)
                        // - page range fixup: exact 不涵蓋時 fallback 到 within-match
                        // - 沒 type/instance 時 fallback 找當前 unitId (ground truth)
                        var masterEntry = (user.masters[t.cat] || {})[t.subject];
                        if (!masterEntry) return;
                        var allUnits = _collectSubjectUnits(masterEntry);
                        var match = null;
                        // within-match: page range 為主, 只加 vol 鎖 (不加 type/instance 才能跨 instance disambiguate)
                        var withinMatch = allUnits.find(function(u) {
                            if (u.name !== t.unitName) return false;
                            // v1.6.168: vol 鎖 (避免跨 vol 同名 unit 誤判)
                            if (u.vol != null && t.vol && u.vol !== t.vol) return false;
                            if (t.startPage != null && t.endPage != null &&
                                u.start != null && u.end != null) {
                                return u.start <= t.startPage && u.end >= t.endPage;
                            }
                            return true;
                        });
                        if (t.typeName && t.instanceName) {
                            // 精確比對: name + typeName + instanceName + vol
                            match = allUnits.find(function(u) {
                                return u.name === t.unitName &&
                                       u._typeName === t.typeName &&
                                       u._instanceName === t.instanceName &&
                                       (u.vol == null || !t.vol || u.vol === t.vol);
                            });
                            // v1.6.64: 如果精確比對的 unit 頁範圍不涵蓋 task (例如 麻辣甲 P.1 vs task P.39-42),
                            // 但有 within-match 的 unit 涵蓋, 用 within-match
                            if (match && withinMatch && match.id !== withinMatch.id) {
                                var matchCovers = match.start <= t.startPage && match.end >= t.endPage;
                                if (!matchCovers) {
                                    match = withinMatch;
                                }
                            } else if (!match) {
                                match = withinMatch;
                            }
                        } else {
                            // v1.6.169: 沒 type/instance — fallback 找當前 unitId 是否在 master (ground truth)
                            match = allUnits.find(function(u) { return u.id === t.unitId; });
                            if (!match) match = withinMatch;
                        }'''

if old_within not in content:
    print("❌ 找不到 v1.6.169 v2 within-match block, 不替換")
    import sys
    sys.exit(1)

content = content.replace(old_within, new_within, 1)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ v1.6.169 v3 patch applied")
