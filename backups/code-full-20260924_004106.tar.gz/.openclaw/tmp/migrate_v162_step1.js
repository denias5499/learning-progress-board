// v1.6.162 最終版 — 用最簡單的 for 迴圈 (避免 forEach / arrow / 任何可能 syntax 炸的)
// Step 1: 先做診斷,不要寫入。印出將會做什麼給你看。
(function() {
    var KEY = 'StudyMap_AccuracyRecords_V158_config';
    var raw = localStorage.getItem(KEY);
    if (!raw) { console.log('NO_KEY'); return; }
    var data = JSON.parse(raw);
    var records = (data && data.records) || [];
    console.log('records=' + records.length);

    if (typeof appMaster === 'undefined') { console.log('NO_MASTER'); return; }

    // 找某個 unitName 出現在 (sub, tn, insName) 裡的 vols
    function findVols(unitName, sub, tn, insName) {
        var out = [];
        var ms = appMaster[sub];
        if (!ms || !ms.materials) return out;
        var t = ms.materials[tn];
        if (!t || !t.instances) return out;
        for (var i = 0; i < t.instances.length; i++) {
            var ins = t.instances[i];
            if (ins.type !== 'volume' || !ins.vols) continue;
            if ((ins.alias || ins.name) !== insName) continue;
            var vols = ins.vols;
            var volKeys = Object.keys(vols);
            for (var k = 0; k < volKeys.length; k++) {
                var v = volKeys[k];
                var arr = vols[v];
                for (var j = 0; j < arr.length; j++) {
                    if (arr[j].name === unitName) out.push(v);
                }
            }
        }
        return out;
    }

    var auto = 0, manual = 0, kept = 0;
    var preview = [];

    for (var i = 0; i < records.length; i++) {
        var r = records[i];
        if (!r.wrongUnits || !Array.isArray(r.wrongUnits)) continue;

        var hasNew = false;
        for (var j = 0; j < r.wrongUnits.length; j++) {
            if (r.wrongUnits[j].indexOf('|') > 0) { hasNew = true; break; }
        }
        if (hasNew) continue;

        // 手動修
        var isManual = (r.id === 'acc_id_sl3l8t3oz') ||
            (r.subject === '英文' && r.instanceName === '大滿貫甲' &&
             r.date === '2026-09-15' && r.wrongUnits.indexOf('L1~2') >= 0);
        if (isManual) {
            manual++;
            preview.push('[M] ' + r.subject + '/' + r.instanceName + '/' + r.date + ' L1~2 -> 第三冊|L1~2');
            continue;
        }

        // 自動標註
        var nu = [];
        var changed = false;
        for (var k2 = 0; k2 < r.wrongUnits.length; k2++) {
            var wu = r.wrongUnits[k2];
            if (wu.indexOf('|') > 0) { nu.push(wu); continue; }
            var vols = findVols(wu, r.subject, r.typeName, r.instanceName);
            if (vols.length === 1) {
                nu.push(vols[0] + '|' + wu);
                auto++;
                changed = true;
            } else {
                nu.push(wu);
                kept++;
            }
        }
        if (changed) {
            preview.push('[A] ' + r.subject + '/' + r.instanceName + '/' + r.date + ' ' + JSON.stringify(r.wrongUnits) + ' -> ' + JSON.stringify(nu));
        }
    }

    console.log('PREVIEW (不會寫入):');
    for (var p = 0; p < preview.length; p++) {
        console.log('  ' + preview[p]);
    }
    console.log('SUMMARY auto=' + auto + ' manual=' + manual + ' kept=' + kept);
})();