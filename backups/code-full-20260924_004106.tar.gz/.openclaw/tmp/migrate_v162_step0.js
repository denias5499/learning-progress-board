// v1.6.162 Step 0 — Sanity test
// 確認 page 已 reload v1.6.162 + 環境 OK
(function() {
    console.log('=== v1.6.162 Sanity Test ===');
    console.log('1. typeof appMaster = ' + typeof appMaster);
    if (typeof appMaster !== 'undefined') {
        var keys = Object.keys(appMaster);
        console.log('   appMaster subs = ' + JSON.stringify(keys));
    }
    console.log('2. typeof loadAccuracyRecords = ' + typeof loadAccuracyRecords);
    console.log('3. typeof getUnitAccuracyRate = ' + typeof getUnitAccuracyRate);
    if (typeof getUnitAccuracyRate === 'function') {
        // 檢查函數 arity (新版應該是 5)
        console.log('   getUnitAccuracyRate.length = ' + getUnitAccuracyRate.length + ' (expected 5)');
    }
    var KEY = 'StudyMap_AccuracyRecords_V158_config';
    var raw = localStorage.getItem(KEY);
    console.log('4. localStorage records key exists = ' + (raw !== null));
    if (raw) {
        try {
            var data = JSON.parse(raw);
            var recs = (data && data.records) || data || [];
            console.log('   records count = ' + (Array.isArray(recs) ? recs.length : 'not array'));
        } catch (e) {
            console.log('   parse failed: ' + e.message);
        }
    }
    console.log('5. document.title = ' + document.title);
    console.log('=== Done ===');
})();