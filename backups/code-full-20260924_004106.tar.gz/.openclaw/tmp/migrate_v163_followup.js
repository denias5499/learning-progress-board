// v1.6.163-followup migration
// 修 5 筆 missing vol + 修大滿貫甲「第3八」typo
(function(){
  var KEY='StudyMap_AccuracyRecords_V158_config';
  var raw=localStorage.getItem(KEY);
  if(!raw){console.error('NO KEY');return;}
  var data=JSON.parse(raw);
  var records=(data&&data.records)||[];
  
  // vol 對照表 — 根據 Denias 口頭指定
  var fixes = [
    {date:'2026-07-08',sub:'英文',tn:'複習卷',ins:'龐辣甲',wu:'L1~L3',newVol:'第一冊'},
    {date:'2026-07-15',sub:'英文',tn:'複習卷',ins:'龐辣甲',wu:'L4~L6',newVol:'第一冊'},
    {date:'2026-07-22',sub:'英文',tn:'複習卷',ins:'龐辣甲',wu:'L1~L2',newVol:'第二冊'},
    {date:'2026-07-29',sub:'英文',tn:'複習卷',ins:'龐辣甲',wu:'L3~L4',newVol:'第二冊'},
    {date:'2026-09-15',sub:'英文',tn:'複習講義',ins:'大滿貫甲',wu:'L1~2',newVol:'第三冊',fixTypo:true}
  ];
  
  var hits=0, typo=0;
  fixes.forEach(function(f){
    var found=false;
    records.forEach(function(r){
      if(r.subject!==f.sub)return;
      if(r.typeName!==f.tn)return;
      if(r.instanceName!==f.ins)return;
      if(r.date!==f.date)return;
      if(!Array.isArray(r.wrongUnits))return;
      
      var newUnits=[];
      r.wrongUnits.forEach(function(wu){
        var base=wu;
        var i=wu.indexOf('|');
        if(i>0)base=wu.substring(i+1);
        
        if(f.fixTypo && wu.indexOf('第3八|')===0){
          // 修「第3八|L1~2」→「第三冊|L1~2」
          newUnits.push('第三冊|'+base);
          typo++;
          found=true;
        } else if(base===f.wu){
          newUnits.push(f.newVol+'|'+base);
          hits++;
          found=true;
        } else {
          newUnits.push(wu);
        }
      });
      
      if(found){
        r.wrongUnits=newUnits;
      }
    });
    
    if(!found){
      console.log('NOT FOUND: '+JSON.stringify(f));
    }
  });
  
  console.log('=== v1.6.163-followup: 套用 vol=' + hits + ', 修 typo=' + typo + ' ===');
  
  // 寫回
  if(data&&Array.isArray(data.records)){
    data.records=records;
  } else {
    data=records;
  }
  localStorage.setItem(KEY,JSON.stringify(data));
  console.log('✅ written, records.length=' + records.length);
  
  // 驗證
  console.log('--- verify 5 records ---');
  fixes.forEach(function(f){
    records.forEach(function(r){
      if(r.subject===f.sub&&r.typeName===f.tn&&r.instanceName===f.ins&&r.date===f.date){
        console.log('  '+r.date+' '+r.instanceName+' wrongUnits='+JSON.stringify(r.wrongUnits)+' correct='+r.correct+'/'+r.total);
      }
    });
  });
})();
