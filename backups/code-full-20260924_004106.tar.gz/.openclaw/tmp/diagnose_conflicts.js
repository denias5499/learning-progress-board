// 在 DevTools Console 執行的診斷腳本
console.clear();
console.log("🔍 衝突單元分析診斷 v1.6.160");

// 1. 檢查當前的記錄
function analyzeCurrentConflicts() {
    console.log("📊 步驟 1: 分析當前記錄中的衝突...");
    
    if (!window._accuracyRecords) {
        console.error("錯誤: 找不到 _accuracyRecords，請先執行 loadAccuracyRecords()");
        return;
    }
    
    var conflicts = {};
    var totalRecords = 0;
    var multiVolUnits = 0;
    
    // 檢查每個 subject 的 master 定義
    for (var subject in appMaster) {
        var s = appMaster[subject];
        if (!s.materials) continue;
        
        for (var typeName in s.materials) {
            var instances = s.materials[typeName].instances || [];
            for (var i = 0; i < instances.length; i++) {
                var inst = instances[i];
                var alias = inst.alias || inst.name;
                
                // 只檢查麻辣甲/大滿貫甲
                if (!alias || !alias.includes('麻辣') && !alias.includes('大滿貫')) continue;
                
                // 檢查每個 vol 的單元
                var volUnits = {};
                for (var vol in inst.vols || {}) {
                    var units = inst.vols[vol] || [];
                    for (var j = 0; j < units.length; j++) {
                        var unitName = units[j].name;
                        if (!volUnits[unitName]) volUnits[unitName] = [];
                        volUnits[unitName].push(vol);
                    }
                }
                
                // 找出出現在多個 vol 的單元
                for (var unitName in volUnits) {
                    if (volUnits[unitName].length > 1) {
                        var key = subject + '/' + alias + '/' + unitName;
                        if (!conflicts[key]) {
                            conflicts[key] = {
                                subject: subject,
                                instance: alias,
                                unit: unitName,
                                vols: volUnits[unitName],
                                records: []
                            };
                            multiVolUnits++;
                        }
                    }
                }
            }
        }
    }
    
    console.log("  發現", multiVolUnits, "個可能衝突的單元（同名單元出現在多個冊）");
    
    // 2. 檢查哪些記錄受到影響
    console.log("📊 步驟 2: 檢查哪些記錄使用這些單元...");
    
    for (var i = 0; i < window._accuracyRecords.length; i++) {
        var r = window._accuracyRecords[i];
        if (!r.wrongUnits || r.wrongUnits.length === 0) continue;
        
        // 只檢查麻辣/大滿貫 instances
        if (!r.instanceName || (!r.instanceName.includes('麻辣') && !r.instanceName.includes('大滿貫'))) continue;
        
        for (var j = 0; j < r.wrongUnits.length; j++) {
            var unit = r.wrongUnits[j];
            var key = r.subject + '/' + r.instanceName + '/' + unit;
            
            if (conflicts[key]) {
                conflicts[key].records.push({
                    date: r.date,
                    correct: r.correct,
                    total: r.total,
                    rate: (r.total > 0 ? (r.correct / r.total * 100).toFixed(1) + '%' : 'N/A')
                });
                totalRecords++;
            }
        }
    }
    
    console.log("  影響記錄數:", totalRecords, "筆");
    
    // 3. 輸出詳細資訊
    console.log("📋 詳細衝突清單:");
    console.log("=".repeat(80));
    
    var count = 0;
    for (var key in conflicts) {
        var c = conflicts[key];
        if (c.records.length === 0) continue;
        
        count++;
        console.log(
            "%c" + count + ". " + c.subject + "/" + c.instance + ": " + c.unit,
            "color: #ff6b6b; font-weight: bold;"
        );
        console.log("   所在冊次:", c.vols.join(", "));
        console.log("   影響記錄:", c.records.length, "筆");
        
        // 只顯示前 3 筆記錄
        for (var k = 0; k < Math.min(c.records.length, 3); k++) {
            var rec = c.records[k];
            console.log("     •", rec.date, "→", rec.rate);
        }
        if (c.records.length > 3) {
            console.log("     ...還有", c.records.length - 3, "筆");
        }
        console.log();
    }
    
    if (count === 0) {
        console.log("✅ 未發現有衝突的單元，但請檢查其他可能的問題。");
    }
    
    return conflicts;
}

// 4. 檢查你的截圖問題：大滿貫甲 L1~L2
function checkReportedIssue() {
    console.log("🚨 檢查 Denias 回報的問題: 大滿貫甲 L1~L2");
    console.log("-".repeat(80));
    
    // 找大滿貫甲 records
    var targetRecords = [];
    for (var i = 0; i < window._accuracyRecords.length; i++) {
        var r = window._accuracyRecords[i];
        if (r.instanceName && 
            (r.instanceName.includes('大滿貫') || r.instanceName === '大滿貫甲') &&
            r.wrongUnits && r.wrongUnits.some(function(wu) {
                return wu && wu.includes('L1~L2');
            })) {
            targetRecords.push(r);
        }
    }
    
    if (targetRecords.length === 0) {
        console.log("❌ 未找到任何大滿貫甲 L1~L2 記錄");
        console.log("   請確認是否有執行 loadAccuracyRecords()");
        return;
    }
    
    console.log("找到", targetRecords.length, "筆大滿貫甲 L1~L2 記錄:");
    for (var i = 0; i < targetRecords.length; i++) {
        var r = targetRecords[i];
        var l1l2Units = r.wrongUnits.filter(function(wu) {
            return wu && wu.includes('L1~L2');
        });
        
        console.log(
            "%c" + (i+1) + ". " + r.date + " " + r.subject + "/" + r.instanceName,
            "color: #3498db;"
        );
        console.log("   單元:", l1l2Units[0]);
        console.log("   答對率:", r.correct + "/" + r.total + " (" + 
                   (r.total > 0 ? (r.correct / r.total * 100).toFixed(1) + "%" : "N/A") + ")");
        
        // 檢查 master 中這個單元在哪幾個 vol
        if (appMaster && appMaster[r.subject] && appMaster[r.subject].materials) {
            var materials = appMaster[r.subject].materials;
            for (var typeName in materials) {
                var instances = materials[typeName].instances || [];
                for (var j = 0; j < instances.length; j++) {
                    var inst = instances[j];
                    var alias = inst.alias || inst.name;
                    if (alias !== r.instanceName) continue;
                    
                    // 檢查每個 vol
                    var foundInVols = [];
                    for (var vol in inst.vols || {}) {
                        var units = inst.vols[vol] || [];
                        if (units.some(function(u) {
                            return u.name === l1l2Units[0];
                        })) {
                            foundInVols.push(vol);
                        }
                    }
                    
                    if (foundInVols.length > 0) {
                        console.log("   在 master 中出現在:", foundInVols.join(", "));
                        if (foundInVols.length > 1) {
                            console.log("   ⚠️ 注意: 這個單元在多個冊次中出現！");
                        }
                    }
                }
            }
        }
        
        console.log();
    }
}

// 執行分析
console.log("要執行分析，請在 Console 輸入以下任一命令:");
console.log("1. analyzeCurrentConflicts() - 分析所有衝突單元");
console.log("2. checkReportedIssue() - 檢查大滿貫甲 L1~L2 問題");
console.log("3. 或直接執行完整診斷:");
console.log("   loadAccuracyRecords();");
console.log("   analyzeCurrentConflicts();");
console.log("   checkReportedIssue();");

// 如果已載入 records，自動執行
if (window._accuracyRecords && window._accuracyRecords.length > 0) {
    console.log("\\n📦 偵測到已有 _accuracyRecords，自動執行診斷...\\n");
    analyzeCurrentConflicts();
    checkReportedIssue();
}
