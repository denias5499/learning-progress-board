import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# Revert v1.6.169 to v1.6.168 base, then add v1.6.169 enhancement
# v1.6.168 base (within-match first + exact-match with vol + page range fixup)
# v1.6.169 enhancement: even if t.vol is undefined, exact-match candidates with same typeName+instanceName+unitName must have same vol (cross-vol disambiguation via type+instance)

old_within = '''                        // 2. v1.6.169: 強健 within-match remap (處理 t.vol 未設 / vol 錯的情況)
                        var masterEntry = (user.masters[t.cat] || {})[t.subject];
                        if (!masterEntry) return;
                        var allUnits = _collectSubjectUnits(masterEntry);
                        var match = null;
                        // v1.6.169: 先收集所有 name+type+instance 匹配候選
                        var candidates = allUnits.filter(function(u) {
                            if (u.name !== t.unitName) return false;
                            if (t.typeName && u._typeName !== t.typeName) return false;
                            if (t.instanceName && u._instanceName !== t.instanceName) return false;
                            return true;
                        });
                        // v1.6.169: 候選 ≤1 直接用; 多個 (跨 vol 同名) 用 vol 鎖
                        if (candidates.length === 1) {
                            match = candidates[0];
                        } else if (candidates.length > 1) {
                            // 優先用 task.vol 鎖
                            if (t.vol) {
                                match = candidates.find(function(u) { return u.vol === t.vol; });
                            }
                            // 否則用當前 unitId (如果有對應候選, 表示原本是對的只是 vol 沒設)
                            if (!match) {
                                match = candidates.find(function(u) { return u.id === t.unitId; });
                            }
                            // 最後退到第一個
                            if (!match) match = candidates[0];
                        } else {
                            // 沒 type/instance (舊資料) 或全沒匹配 — 用 name+vol 找
                            match = allUnits.find(function(u) {
                                if (u.name !== t.unitName) return false;
                                if (t.vol && u.vol !== t.vol) return false;
                                return true;
                            });
                        }
                        // v1.6.64: 套用 page range 邏輯 — match 必須涵蓋 task 的頁範圍
                        if (match && t.startPage != null && t.endPage != null &&
                            match.start != null && match.end != null) {
                            var matchCovers = match.start <= t.startPage && match.end >= t.endPage;
                            if (!matchCovers) {
                                // 找候選裡有涵蓋的 (優先 vol 鎖)
                                var covering = null;
                                if (t.vol) covering = candidates.find(function(u) {
                                    return u.start <= t.startPage && u.end >= t.endPage && u.vol === t.vol;
                                });
                                if (!covering) covering = candidates.find(function(u) {
                                    return u.start <= t.startPage && u.end >= t.endPage;
                                });
                                if (covering) match = covering;
                            }
                        }
                        if (match && match.id !== t.unitId) {
                            t.unitId = match.id;
                            if (match._typeName) t.typeName = match._typeName;
                            if (match._instanceName) t.instanceName = match._instanceName;
                            remapCount++;
                        }'''

# v1.6.169 v2: restore v1.6.64's within-match logic (page range primary),
# but ADD vol filter to within-match, AND for cross-vol candidates with same type+instance, use page range to disambiguate
new_within = '''                        // 2. v1.6.169: 強健 within-match remap
                        // 保留 v1.6.64 的 within-match (page range 為主) + exact-match (type+instance 為主)
                        // 加上 v1.6.169 強化: cross-vol 同名 unit 用 typeName+instanceName+vol 鎖,
                        // 避免被錯指到頁範圍剛好覆蓋的另一 vol unit
                        var masterEntry = (user.masters[t.cat] || {})[t.subject];
                        if (!masterEntry) return;
                        var allUnits = _collectSubjectUnits(masterEntry);
                        var match = null;
                        // v1.6.64: within-match (page range 涵蓋, 但 v1.6.169 加 type+instance+vol 鎖避免跨 vol 誤判)
                        var withinMatch = allUnits.find(function(u) {
                            if (u.name !== t.unitName) return false;
                            // v1.6.169: type+instance 鎖 (避免跨 instance 同名 unit 誤判, 例如 麻辣甲 vs 大滿貫)
                            if (t.typeName && u._typeName !== t.typeName) return false;
                            if (t.instanceName && u._instanceName !== t.instanceName) return false;
                            // v1.6.168: vol 鎖 (避免跨 vol 同名 unit 誤判, 例如 大滿貫 第二冊 L1~2 vs 第三冊 L1~2)
                            if (u.vol != null && t.vol && u.vol !== t.vol) return false;
                            if (t.startPage != null && t.endPage != null &&
                                u.start != null && u.end != null) {
                                return u.start <= t.startPage && u.end >= t.endPage;
                            }
                            return true;
                        });
                        if (t.typeName && t.instanceName) {
                            // 精確比對: name + typeName + instanceName + vol (v1.6.168 加 vol 保險)
                            match = allUnits.find(function(u) {
                                return u.name === t.unitName &&
                                       u._typeName === t.typeName &&
                                       u._instanceName === t.instanceName &&
                                       (u.vol == null || !t.vol || u.vol === t.vol);
                            });
                            // v1.6.64: 如果精確比對的 unit 頁範圍不涵蓋 task (例如 麻辣甲 P.1 vs task P.39-42),
                            // 但有 within-match 的 unit 涵蓋, 用 within-match
                            if (match && withinMatch && match.id !== withinMatch.id) {
                                var matchCovers = match.start <= t.startPage && match.end >= t.endPage;
                                if (!matchCovers) {
                                    match = withinMatch;
                                }
                            } else if (!match) {
                                // exact match 找不到 (舊資料沒 typeName/instanceName 設對), 用 within-match
                                match = withinMatch;
                            }
                        } else {
                            match = withinMatch;
                        }
                        if (match && match.id !== t.unitId) {
                            t.unitId = match.id;
                            if (match._typeName) t.typeName = match._typeName;
                            if (match._instanceName) t.instanceName = match._instanceName;
                            remapCount++;
                        }'''

if old_within not in content:
    print("❌ 找不到 v1.6.169 within-match block, 不替換")
    import sys
    sys.exit(1)

content = content.replace(old_within, new_within, 1)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ v1.6.169 v2 patch applied")
