import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 找到 v1.6.170 mission fix 之後加上 v1.6.172 migration
pat = r"console\.log\('v1\\.6\\.170: ✅ fix missions\\.會考複習\\.二模\\[35\\] = id_j7l5x7jdz \\(第三冊 L1~2\\)'\);\s*}\s*}"
found = re.search(pat, content, re.DOTALL)
if found:
    after = found.end()
    patch = '''                console.log('v1.6.170: ✅ fix missions.會考複習.二模[35] = id_j7l5x7jdz (第三冊 L1~2)');
            }
        }
        // v1.6.172: 修正 plan.grid L1~2 tasks 跨 vol 匹配錯誤 (排程天數對應錯誤)
        if (user && user.plans) {
            user.plans.forEach(function(plan, pi){
                if (!plan.grid) return;
                Object.keys(plan.grid).forEach(function(dateStr){
                    var tasks = plan.grid[dateStr] || [];
                    tasks.forEach(function(t, i){
                        if (!t || !t.unitName || (t.unitName !== 'L1~2' && t.unitName !== 'L1~L2')) return;
                        var cat = t.cat || '會考複習';
                        var sub = t.subject || '英文';
                        var masterEntry = (((user.masters||{})[cat])||{})[sub];
                        if (!masterEntry) return;
                        var allUnits = _collectSubjectUnits(masterEntry);
                        var match = allUnits.find(function(u){
                            return u.name === t.unitName && u._typeName === t.typeName && u._instanceName === t.instanceName && u.vol === t.vol;
                        });
                        if (match && match.id !== t.unitId) t.unitId = match.id;
                    });
                });
            });
        }'''
    content = content[:found.start()] + patch + content[after:]

# 更新 title v1.6.171 -> v1.6.172
content = content.replace(
    '<title>2026 學習進度看板 (列印月曆版) [v1.6.171]</title>',
    '<title>2026 學習進度看板 (列印月曆版) [v1.6.172]</title>'
)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print('v1.6.172 migration added, title updated')
