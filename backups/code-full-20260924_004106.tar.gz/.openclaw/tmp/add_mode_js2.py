import sys

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 找到 setWizardScheduleMode 整個函數
target_start = 'function setWizardScheduleMode(mode) {'
if target_start not in content:
    print("函數未找到")
    sys.exit(1)

start_idx = content.find(target_start)
brace_count = 1
current_idx = start_idx + len(target_start)
while brace_count > 0 and current_idx < len(content):
    if content[current_idx] == '{':
        brace_count += 1
    elif content[current_idx] == '}':
        brace_count -= 1
    current_idx += 1

function_body = content[start_idx:current_idx]

# 改寫函數
new_function = '''function setWizardScheduleMode(mode) {
    // mode = 'hours' | 'units'
    if (typeof wizardSubjects !== 'undefined') {
        wizardSubjects.forEach(function(ws) {
            ws.scheduleMode = mode;
            // 模式 B 補預設值 (不覆蓋 user 已設定)
            if (mode === 'units' && !ws.daysPerUnit) ws.daysPerUnit = 3;
        });
        saveWizardPrefs();
    }
    
    var hoursCard = el('wz-mode-hours-card');
    var unitsCard = el('wz-mode-units-card');
    var desc = el('wz-schedule-mode-desc');
    var globalHoursCard = el('global-mode-hours-card');
    var globalUnitsCard = el('global-mode-units-card');
    
    if (mode === 'hours') {
        if (hoursCard) {
            hoursCard.style.border = '2px solid #0ea5e9';
            hoursCard.style.background = '#e0f2fe';
            hoursCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio = hoursCard.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        }
        if (unitsCard) {
            unitsCard.style.border = '2px solid #cbd5e1';
            unitsCard.style.background = 'white';
            unitsCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (globalHoursCard) {
            globalHoursCard.style.border = '2px solid #0ea5e9';
            globalHoursCard.style.background = '#e0f2fe';
            globalHoursCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio2 = globalHoursCard.querySelector('input[type="radio"]');
            if (radio2) radio2.checked = true;
        }
        if (globalUnitsCard) {
            globalUnitsCard.style.border = '2px solid #cbd5e1';
            globalUnitsCard.style.background = 'white';
            globalUnitsCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (desc) desc.innerHTML = '⏱️ <b>時數模式</b>：每 unit 切成 0.5hr chunks，平均塞進每天時數內';
    } else {
        if (hoursCard) {
            hoursCard.style.border = '2px solid #cbd5e1';
            hoursCard.style.background = 'white';
            hoursCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (unitsCard) {
            unitsCard.style.border = '2px solid #0ea5e9';
            unitsCard.style.background = '#e0f2fe';
            unitsCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio = unitsCard.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        }
        if (globalHoursCard) {
            globalHoursCard.style.border = '2px solid #cbd5e1';
            globalHoursCard.style.background = 'white';
            globalHoursCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (globalUnitsCard) {
            globalUnitsCard.style.border = '2px solid #0ea5e9';
            globalUnitsCard.style.background = '#e0f2fe';
            globalUnitsCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio2 = globalUnitsCard.querySelector('input[type="radio"]');
            if (radio2) radio2.checked = true;
        }
        if (desc) desc.innerHTML = '📅 <b>單元模式</b>：每 unit 分 N 天讀，每天一個時段 (hrs÷N 小時)';
    }
    
    // 儲存到偏好設定
    if (window.preferences) {
        window.preferences.scheduleMode = mode;
        window.saveWizardPrefs();
    }
}

// v1.6.173: 全局模式切換初始化
function initGlobalScheduleMode() {
    var globalHoursCard = el('global-mode-hours-card');
    var globalUnitsCard = el('global-mode-units-card');
    if (globalHoursCard && globalUnitsCard) {
        // 綁定 click 事件
        globalHoursCard.addEventListener('click', function(e) {
            if (e.target.type !== 'radio') {
                setWizardScheduleMode('hours');
            }
        });
        globalUnitsCard.addEventListener('click', function(e) {
            if (e.target.type !== 'radio') {
                setWizardScheduleMode('units');
            }
        });
        // 同步 radio 狀態
        var globalRadioHours = globalHoursCard.querySelector('input[type="radio"]');
        var globalRadioUnits = globalUnitsCard.querySelector('input[type="radio"]');
        if (globalRadioHours && globalRadioUnits) {
            globalRadioHours.addEventListener('change', function() {
                if (this.checked) setWizardScheduleMode('hours');
            });
            globalRadioUnits.addEventListener('change', function() {
                if (this.checked) setWizardScheduleMode('units');
            });
        }
    }
}
'''

new_content = content[:start_idx] + new_function + content[current_idx:]

# 在 init 之後呼叫 initGlobalScheduleMode
init_call = '/* DOM 載入後初始化全局模式切換 */'
if init_call in new_content:
    new_content = new_content.replace(init_call, init_call + '\n          initGlobalScheduleMode();')
else:
    # 找適當位置插入
    init_pos = new_content.find('document.addEventListener("DOMContentLoaded", function() {')
    if init_pos > 0:
        end_pos = new_content.find('});', init_pos)
        insert_idx = end_pos - 1
        new_content = new_content[:insert_idx] + '          initGlobalScheduleMode();\n' + new_content[insert_idx:]

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("已更新函數並加入初始化")
