// v1.6.163 診斷 — 找 5 筆英文 records 實際位置
(function(){
  console.log('=== ALL localStorage keys ===');
  var keys = [];
  for (var i = 0; i < localStorage.length; i++) {
    keys.push(localStorage.key(i));
  }
  console.log('total keys: ' + keys.length);
  keys.forEach(function(k){ console.log('  ['+i+'] '+k); });
  
  console.log('=== key 1 ===');
  var k1 = localStorage.key(1);
  console.log('key(1)='+k1);
  if (k1) {
    var v1 = localStorage.getItem(k1);
    console.log('value length: ' + v1.length);
    console.log('value preview: ' + v1.substring(0, 200));
    
    var d1;
    try { d1 = JSON.parse(v1); } catch(e) { console.log('JSON parse fail: '+e.message); return; }
    
    console.log('typeof: ' + typeof d1);
    console.log('isArray: ' + Array.isArray(d1));
    if (d1 && typeof d1 === 'object') {
      console.log('keys: ' + Object.keys(d1).join(','));
    }
    if (Array.isArray(d1)) {
      console.log('length: ' + d1.length);
      if (d1.length > 0) {
        console.log('first record: ' + JSON.stringify(d1[0]));
      }
    }
  }
  
  // 找英文 records
  console.log('=== search 英文/複習卷/龐辣甲 across all keys ===');
  keys.forEach(function(k){
    var v = localStorage.getItem(k);
    if (!v) return;
    try {
      var d = JSON.parse(v);
      var arr = Array.isArray(d) ? d : (d && Array.isArray(d.records) ? d.records : null);
      if (!arr) return;
      var hits = arr.filter(function(r){
        return r && r.subject === '英文' && (r.typeName === '複習卷' || r.typeName === '複習講義');
      });
      if (hits.length > 0) {
        console.log('  KEY: '+k+' → '+hits.length+' eng records');
        hits.forEach(function(r){
          console.log('    '+r.date+' '+r.instanceName+' '+r.typeName+' wrongUnits='+JSON.stringify(r.wrongUnits)+' correct='+r.correct+'/'+r.total);
        });
      }
    } catch(e) {}
  });
})();
