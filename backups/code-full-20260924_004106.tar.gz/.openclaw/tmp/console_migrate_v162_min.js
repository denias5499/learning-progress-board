// v1.6.162 簡化版 migration (避免 SyntaxError 風險)
// 只做三件事:
//   1. 自動標註「master 唯一 vol」records
//   2. 手動修 acc_id_sl3l8t3oz (英文/大滿貫甲/L1~2)
//   3. 寫回 localStorage

(function() {
    var KEY = 'StudyMap_AccuracyRecords_V158_config';
    var raw = localStorage.getItem(KEY);
    if (!raw) { console.error('no localStorage'); return; }
    var data = JSON.parse(raw);
    var records = (data && data.records) || [];

    if (typeof appMaster === 'undefined') { console.error('no appMaster'); return; }

    // 找某個 unitName 出現在哪些 (sub, instanceName, vol)
    function findVols(unitName) {
        var out = [];
        var ms = appMaster;
        Object.keys(ms).forEach(function(sub) {
            if (!ms[sub] || !ms[sub].materials) return;
            Object.keys(ms[sub].materials).forEach(function(tn) {
                var t = ms[sub].materials[tn];
                if (!t || !t.instances) return;
                t.instances.forEach(function(ins) {
                    var vols = ins.vols;
                    if (ins.type === 'volume' && vols) {
                        Object.keys(vols).forEach(function(v) {
                            var arr = vols[v] || [];
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i].name === unitName) {
                                    out.push({ sub: sub, tn: tn, insName: ins.alias || ins.name, vol: v });
                                }
                            }
                        });
                    }
                });
            });
        });
        return out;
    }

    var auto = 0, manual = 0, kept = 0, modified = false;

    records.forEach(function(r) {
        if (!r.wrongUnits || !Array.isArray(r.wrongUnits)) return;

        // 跳過已標註的
        var hasNew = false;
        for (var i = 0; i < r.wrongUnits.length; i++) {
            if (r.wrongUnits[i].indexOf('|') > 0) { hasNew = true; break; }
        }
        if (hasNew) return;

        // 手動修: 大滿貫甲 L1~2 (2026-09-15)
        if (r.id === 'acc_id_sl3l8t3oz') {
            r.wrongUnits = ['第三冊|L1~2'];
            manual++;
            modified = true;
            return;
        }
        if (r.subject === '英文' && r.instanceName === '大滿貫甲' &&
            r.date === '2026-09-15' && r.wrongUnits.indexOf('L1~2') >= 0) {
            r.wrongUnits = ['第三冊|L1~2'];
            manual++;
            modified = true;
            return;
        }

        // 自動標註
        var changed = false;
        var nu = [];
        for (var j = 0; j < r.wrongUnits.length; j++) {
            var wu = r.wrongUnits[j];
            if (wu.indexOf('|') > 0) { nu.push(wu); continue; }
            var vols = findVols(wu);
            // 過濾: 只算 (sub, tn, insName) 完全相符的 vols
            var matched = vols.filter(function(v) {
                return v.sub === r.subject && v.tn === r.typeName && v.insName === r.instanceName;
            });
            if (matched.length === 1 && matched[0].vol) {
                nu.push(matched[0].vol + '|' + wu);
                auto++;
                changed = true;
            } else {
                nu.push(wu);
                kept++;
            }
        }
        if (changed) {
            r.wrongUnits = nu;
            modified = true;
        }
    });

    if (modified) {
        if (data && Array.isArray(data.records)) {
            data.records = records;
        } else {
            data = records;
        }
        localStorage.setItem(KEY, JSON.stringify(data));
        console.log('OK written');
    } else {
        console.log('no change');
    }
    console.log('auto=' + auto + ' manual=' + manual + ' kept=' + kept);
})();