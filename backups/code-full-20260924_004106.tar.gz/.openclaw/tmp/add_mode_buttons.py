import sys

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 找到 global-filter-selectors div 的結尾位置
target = '<select id="filter-mission" onchange="renderDashboard(); renderTreeView(); renderMonthlyAnalysis();"></select>'
if target not in content:
    print("目標字串未找到")
    sys.exit(1)

# 構建插入內容
insert_html = '''
</select>
            <!-- v1.6.173: 加入時數/單元模式切換 -->
            <div style="margin-left: 20px; display: flex; gap: 8px; align-items: center;">
                <label id="global-mode-hours-card" style="cursor: pointer; display: inline-table; padding: 6px 12px; border-radius: 8px; border: 2px solid #0ea5e9; background: #e0f2fe; font-size: 13px; white-space: nowrap; box-sizing: border-box;">
                    <span style="display: table-cell; vertical-align: middle; padding-right: 8px;"><input type="radio" name="global-schedule-mode" value="hours" checked style="margin: 0; cursor: pointer;"></span><span style="display: table-cell; vertical-align: middle; font-size: 14px;">⏱️</span><span style="display: table-cell; vertical-align: middle; color: #0369a1; font-weight: bold; padding-left: 4px;">時數模式</span>
                </label>
                <label id="global-mode-units-card" style="cursor: pointer; display: inline-table; padding: 6px 12px; border-radius: 8px; border: 2px solid #cbd5e1; background: white; font-size: 13px; white-space: nowrap; box-sizing: border-box;">
                    <span style="display: table-cell; vertical-align: middle; padding-right: 8px;"><input type="radio" name="global-schedule-mode" value="units" style="margin: 0; cursor: pointer;"></span><span style="display: table-cell; vertical-align: middle; font-size: 14px;">📅</span><span style="display: table-cell; vertical-align: middle; color: #475569; font-weight: bold; padding-left: 4px;">單元模式</span>
                </label>
                <span style="color: var(--secondary); font-size: 13px; padding: 4px 8px; background: #f8fafc; border-radius: 6px; border: 1px solid #e2e8f0;">影響精靈排程預設模式</span>
            </div>
'''

# 替換
new_content = content.replace(target + '</select>', insert_html)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("已加入模式切換按鈕")
