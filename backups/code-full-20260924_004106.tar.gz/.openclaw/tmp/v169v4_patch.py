import re

with open('index.html', 'r', encoding='utf-8') as f:
    content = f.read()

old_exact = '''                        if (t.typeName && t.instanceName) {
                            // 精確比對: name + typeName + instanceName + vol
                            match = allUnits.find(function(u) {
                                return u.name === t.unitName &&
                                       u._typeName === t.typeName &&
                                       u._instanceName === t.instanceName &&
                                       (u.vol == null || !t.vol || u.vol === t.vol);
                            });'''

new_exact = '''                        if (t.typeName && t.instanceName) {
                            // v1.6.169: 先收集 name+type+instance 候選
                            var tiCandidates = allUnits.filter(function(u) {
                                return u.name === t.unitName &&
                                       u._typeName === t.typeName &&
                                       u._instanceName === t.instanceName;
                            });
                            // 精確比對: name + typeName + instanceName + vol
                            match = tiCandidates.find(function(u) {
                                return (u.vol == null || !t.vol || u.vol === t.vol);
                            });
                            // v1.6.169: t.vol 缺失時, 優先保留當前 unitId (ground truth)
                            if (!t.vol) {
                                var currentInCandidates = tiCandidates.find(function(u) { return u.id === t.unitId; });
                                if (currentInCandidates) match = currentInCandidates;
                            }'''

if old_exact not in content:
    print("❌ 找不到 exact match block, 不替換")
    import sys
    sys.exit(1)

content = content.replace(old_exact, new_exact, 1)

with open('index.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ v1.6.169 v4 patch applied")
