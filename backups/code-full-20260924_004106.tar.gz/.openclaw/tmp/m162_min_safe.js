// v1.6.162 SUPER MINIMAL migration
// 完全不用 regex, 完全沒動態 string
(function(){
    var KEY = 'StudyMap_AccuracyRecords_V158_config';
    var raw = localStorage.getItem(KEY);
    if(!raw){ console.log('NO_KEY'); return; }
    var data; try{ data = JSON.parse(raw); }catch(e){ console.log('BAD_JSON'); return; }
    var records = (data && data.records) || data || [];
    if(!Array.isArray(records)){ console.log('NOT_ARRAY'); return; }
    if(typeof appMaster==='undefined'){ console.log('NO_MASTER'); return; }
    console.log('records=' + records.length);

    var auto=0, manual=0, kept=0, modified=false;

    for(var i=0;i<records.length;i++){
        var r = records[i];
        if(!r || !r.wrongUnits || !Array.isArray(r.wrongUnits)) continue;
        var hasNew = false;
        for(var j=0;j<r.wrongUnits.length;j++) if(r.wrongUnits[j].indexOf('|')>0){hasNew=true;break;}
        if(hasNew) continue;
        if(r.id==='acc_id_sl3l8t3oz' || (r.subject==='英文' && r.instanceName==='大滿貫甲' && r.date==='2026-09-15' && r.wrongUnits.indexOf('L1~2')>=0)){
            r.wrongUnits = ['第三冊|L1~2'];
            manual++; modified=true; continue;
        }
        var nu = [];
        var changed = false;
        for(var k=0;k<r.wrongUnits.length;k++){
            var wu = r.wrongUnits[k];
            if(wu.indexOf('|')>0){ nu.push(wu); continue; }
            var sub = appMaster[r.subject];
            if(!sub || !sub.materials) { nu.push(wu); kept++; continue; }
            var t = sub.materials[r.typeName];
            if(!t || !t.instances) { nu.push(wu); kept++; continue; }
            var foundVol = null;
            var multiVol = false;
            for(var a=0;a<t.instances.length;a++){
                var ins = t.instances[a];
                if((ins.alias||ins.name)!==r.instanceName) continue;
                if(ins.type!=='volume' || !ins.vols) continue;
                var volKeys = Object.keys(ins.vols);
                for(var b=0;b<volKeys.length;b++){
                    var arr = ins.vols[volKeys[b]] || [];
                    for(var c=0;c<arr.length;c++){
                        if(arr[c].name===wu){
                            if(foundVol===null) foundVol = volKeys[b];
                            else if(foundVol!==volKeys[b]) multiVol = true;
                        }
                    }
                }
            }
            if(foundVol && !multiVol){
                nu.push(foundVol+'|'+wu);
                auto++; changed=true;
            } else {
                nu.push(wu);
                kept++;
            }
        }
        if(changed){ r.wrongUnits = nu; modified=true; }
    }

    if(modified){
        if(data && Array.isArray(data.records)) data.records = records;
        else data = records;
        localStorage.setItem(KEY, JSON.stringify(data));
        console.log('WRITTEN');
    } else {
        console.log('NO_CHANGE');
    }
    console.log('auto=' + auto + ' manual=' + manual + ' kept=' + kept);
})();