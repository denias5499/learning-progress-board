// ============================================================
// v1.6.162 Console Migration Script
// ============================================================
// 用法: 在答對率頁開啟 DevTools Console, 貼上執行
// 結果:
//   - 自動標註「master 唯一 vol」的 records (新格式 vol|name)
//   - 手動標註大滿貫甲 L1~2 (2026-09-15, acc_id_sl3l8t3oz) → 第三冊|L1~2
//   - 其他多 vol records 保持舊格式 (向後相容)
// ============================================================

(function autoAnnotateV162() {
    console.log('=== v1.6.162 自動標註 開始 ===');

    // 1. 讀 records (用 page 的 loadAccuracyRecords)
    var KEY = 'StudyMap_AccuracyRecords_V158_config';
    var raw = localStorage.getItem(KEY);
    if (!raw) {
        console.error('找不到 localStorage key: ' + KEY);
        return;
    }
    var data;
    try { data = JSON.parse(raw); }
    catch (e) {
        console.error('parse 失敗: ' + e.message);
        return;
    }
    var records = (data && data.records) || [];
    console.log('總共 ' + records.length + ' 筆 records');

    if (typeof appMaster === 'undefined') {
        console.error('appMaster 未定義 — 請先開到主頁讓 master 載入');
        return;
    }

    // 2. 建立 unit → vols 索引
    //    unitName (全域) → [{sub, typeName, instanceId, vol}, ...]
    function findUnitVols(unitName) {
        var out = [];
        Object.keys(appMaster).forEach(function(sub) {
            var subj = appMaster[sub];
            if (!subj || !subj.materials) return;
            Object.keys(subj.materials).forEach(function(typeName) {
                var typeObj = subj.materials[typeName];
                if (!typeObj || !typeObj.instances) return;
                typeObj.instances.forEach(function(ins) {
                    if (ins.type === 'volume' && ins.vols) {
                        Object.keys(ins.vols).forEach(function(vol) {
                            (ins.vols[vol] || []).forEach(function(u) {
                                if (u.name === unitName) {
                                    out.push({ sub: sub, typeName: typeName, instanceId: ins.id, instanceName: ins.alias || ins.name, vol: vol });
                                }
                            });
                        });
                    } else if (ins.type === 'custom' && ins.units) {
                        ins.units.forEach(function(u) {
                            if (u.name === unitName) {
                                out.push({ sub: sub, typeName: typeName, instanceId: ins.id, instanceName: ins.alias || ins.name, vol: null });
                            }
                        });
                    }
                });
            });
        });
        return out;
    }

    // 3. 對每筆 record 做檢查
    var autoAnnotated = 0;  // 自動標註
    var keptLegacy = 0;     // 保留舊格式 (多 vol)
    var manualFixed = 0;    // 手動修
    var modified = false;

    records.forEach(function(r, idx) {
        if (!r.wrongUnits || !Array.isArray(r.wrongUnits)) return;

        // 跳過已標註的 (vol|name 格式)
        var hasNewFormat = r.wrongUnits.some(function(wu) { return wu.indexOf('|') > 0; });
        if (hasNewFormat) {
            // 已處理過
            return;
        }

        // 手動修: 英文/大滿貫甲/L1~2 (2026-09-15, acc_id_sl3l8t3oz)
        if (r.id === 'acc_id_sl3l8t3oz' ||
            (r.subject === '英文' && r.typeName === '複習卷' && r.instanceName === '大滿貫甲' &&
             r.wrongUnits.indexOf('L1~2') >= 0 && r.date === '2026-09-15')) {
            r.wrongUnits = ['第三冊|L1~2'];
            modified = true;
            manualFixed++;
            console.log('  ✓ [manual] ' + r.id + ' (英文/大滿貫甲/L1~2, ' + r.date + ') → 第三冊|L1~2');
            return;
        }

        // 對每個 wrongUnit 判斷
        var newWrongUnits = [];
        var recordChanged = false;
        r.wrongUnits.forEach(function(wu) {
            // 已經是 vol|name 格式 (理論上 should not happen due to skip above, 但保險)
            if (wu.indexOf('|') > 0) {
                newWrongUnits.push(wu);
                return;
            }
            var vols = findUnitVols(wu);
            if (vols.length === 0) {
                // 找不到 — custom 或孤兒 — 保留
                newWrongUnits.push(wu);
                keptLegacy++;
                return;
            }
            if (vols.length === 1 && vols[0].vol) {
                // 唯一 vol — 安全, 自動標註
                newWrongUnits.push(vols[0].vol + '|' + wu);
                autoAnnotated++;
                recordChanged = true;
                return;
            }
            // 多 vol (vols.length >= 2) 或 vol=null — 不安全, 保留
            newWrongUnits.push(wu);
            keptLegacy++;
        });

        if (recordChanged) {
            r.wrongUnits = newWrongUnits;
            modified = true;
        }
    });

    // 4. 寫回 localStorage (保持原本 storage 結構)
    if (modified) {
        if (data && Array.isArray(data.records)) {
            data.records = records;
        } else {
            data = records;  // 容錯: 若原本存的是 array
        }
        // 注意: 這裡直接寫進 raw 結構, saveAccuracyRecords() 內部會處理
        localStorage.setItem(KEY, JSON.stringify(data));
        console.log('\n✓ 已寫回 localStorage');
    } else {
        console.log('\n(無修改)');
    }

    console.log('\n=== 結果 ===');
    console.log('  自動標註: ' + autoAnnotated + ' 筆');
    console.log('  手動修正: ' + manualFixed + ' 筆');
    console.log('  保留舊格式: ' + keptLegacy + ' 筆');

    // 5. 顯示「修過的 records」摘要
    console.log('\n=== 修過的 records (新格式 vol|name) ===');
    records.forEach(function(r) {
        if (r.wrongUnits && r.wrongUnits.some(function(wu) { return wu.indexOf('|') > 0; })) {
            console.log('  ' + r.id + ' [' + r.subject + '/' + r.instanceName + '/' + r.date + ']');
            console.log('    wrongUnits: ' + JSON.stringify(r.wrongUnits));
        }
    });

    console.log('\n=== 完成 — 請重新整理頁面讓 UI 載入新 records ===');
})();