# 🎯 v1.6.161 衝突分析報告

**日期**: 2026-09-19  
**分析對象**: StudyMap_Backup_2026-09-18 (最新備份)  
**分析目的**: 找出 cross-volume wrongUnits pollution 的真實衝突

---

## 📊 **結論先行**

### **只有 1 筆真正的衝突記錄！**

| 項目 | 內容 |
|------|------|
| **科目** | 英文 |
| **Instance** | 大滿貫甲 |
| **Type** | 複習卷 |
| **單元** | L1~2 |
| **出現在冊次** | 第二冊、第三冊、第四冊、第五冊、第六冊 |
| **衝突 records 數** | 1 筆 |
| **日期** | 2026-09-15 |
| **答對率** | 36/40 (90.0%) |
| **正確歸屬** | ✅ **第三冊** (有 plan task 證據) |

**重要**：其他 106 筆麻辣甲/大滿貫甲 records 都不會跨冊衝突，因為每個 instance 內的 unit 名稱都是唯一的！

---

## 📚 **為何會衝突？**

### **L1~2 在 master 中出現在多冊**

英文 / 大滿貫甲 / 複習卷中：
- 「L1~2」是**共用單元名稱**，在以下 5 冊都有定義：
  - 第二冊
  - 第三冊
  - 第四冊
  - 第五冊
  - 第六冊

但因為是同樣的單元名 (L1~2)，原始 `wrongUnits` 欄位只存純字串 `"L1~2"`，**沒有記錄 vol 資訊**。

### **沒有 vol 資訊的後果**

當 Denias 在樹狀圖點「大滿貫甲 / 第二冊 / L1~2」時：
- 查詢答對率時 `getUnitAccuracyRate("L1~2", ...)` 只用單元名匹配
- 所有 5 個冊次的 L1~2 都會被匹配到
- 無法區分「第二冊L1~2」vs「第三冊L1~2」

---

## 🔴 **為何我的 v1.6.161 migration 會出錯？**

我原本想用 plan task 推測 vol，但犯了嚴重錯誤：

### **問題邏輯**：
```javascript
function buildVolMapForRecord(r) {
    // Layer A: master 唯一 vol (L1~2 在 5 冊都有，跳過)
    // Layer B: 同日期 plan task (✓ 找到 vol=第三冊)
    // Layer C: 任何日期 plan task
}
```

### **為何結果錯誤？**

我的實際**執行邏輯**可能：
1. 先在 Layer A 檢查 `getUnitVolsFromMaster()` → 找到 5 個 vol (L1~2 在多冊)
2. Layer B 用 `getUnitVolFromPlan(2026-09-15, 英文, "L1~2")` → 
   - 看到 2026-09-15 當天 plan 有 `vol=第三冊, unit=L1~2`
   - 應該正確標為「第三冊」
3. **但實際結果卻標成「第二冊」** → 表示實際程式有 bug

### **可能的 bug**：

可能是 `getUnitVolsFromMaster` 返回 5 vol 後，雖然我寫了 fallback 邏輯，
但 Layer B 用的是「計數最多」的 vol，可能 Layer C 的「任何日期」覆蓋了 Layer B 的結果。

或者更可能：我只看了 `vol` 欄位，但沒看到 `volOrder` 排序，第一個匹配就採用。

---

## ✅ **正確解決方案**

既然只有 1 筆衝突，可以精準修復：

### **方案 A：手動修改 storage**（最簡單）
直接把那筆 record 標記 vol=第三冊：
```javascript
// 在 DevTools Console
let recs = JSON.parse(localStorage.getItem('StudyMap_AccuracyRecords_V158_config'));
let target = recs.find(r => r.id === 'acc_id_sl3l8t3oz');
if (target) {
    target._volHint = '第三冊'; // 或別的標記
    localStorage.setItem('StudyMap_AccuracyRecords_V158_config', JSON.stringify(recs));
    console.log('已標記 vol=第三冊');
}
```

### **方案 B：重組 storage 格式**
1. 為每筆麻辣/大滿貫 record 增加 `_vol` 欄位
2. 對未來記錄：用 vol+name 匹配
3. 對這 1 筆特殊：手動標 vol=第三冊
4. 其他 106 筆：用現有 unit 名匹配即可（不衝突）

---

## 📋 **為何其他 106 筆不會衝突？**

例如：
- 數學/麻辣甲: 13 筆 records — 每筆的 unit 都是不同名稱 (如「第1回」「第2回」等)，互不衝突
- 地理/麻辣甲: 5 筆 records — unit 都是唯一的
- 生物/麻辣甲: 5 筆 records — 第1,2,3,5,7回 (第4回缺)，但這些都不跨冊

---

## 🎯 **結論**

**總衝突影響：**
- ✅ **實際受影響 records: 1 筆** (英文/大滿貫甲/L1~2, 2026-09-15)
- ✅ **這 1 筆有 plan task 明確證據 vol=第三冊**
- ✅ **其他 106 筆無衝突**

**建議 Denias：**
1. 先恢復到 v1.6.160 (已做)
2. 用方案 A 手動修正這 1 筆的 vol 提示
3. 或採用方案 B 的更嚴謹版本（但要先驗證不影響其他記錄）