// 模擬 v1.6.138: Denias 點刪除「考古題」, marker 寫進, 然後重啟 (重新跑 init)
// 然後看 typeCount 還有沒有「考古題」
const idx = require('fs').readFileSync('index.html', 'utf8');
const re = /<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g;
const scripts = [];
let m; while((m=re.exec(idx))) scripts.push(m[1]);
const code = scripts[scripts.length-1];

const vm = require('vm');
const noop = () => ({});
const noopArr = () => [];

const STUBS = {
  'user-selector': { value:'Denias', textContent:'', innerHTML:'' }
};
const elStub = (id) => STUBS[id] || { value:'', textContent:'', innerHTML:'', style:{}, dataset:{}, options:[], addEventListener:noop, appendChild:noop, classList:{add:noop,remove:noop,contains:()=>false} };

// 模擬: Denias 已經 delete 過「考古題」, marker 寫進去
const DeniasState = {
  masters: {
    '會考複習': {
      '公民': {
        materials: {
          '複習講義': { id:'mt_1', name:'複習講義', instances:[{ name:'講義1', type:'volume', vols:{}, volOrder:[], units:[{id:'u-ky-1', name:'講義單元1', start:1, end:10}] }] },
          '複習卷': { id:'mt_2', name:'複習卷', instances:[{ name:'卷1', type:'volume', vols:{}, volOrder:[], units:[{id:'u-kj-1', name:'卷單元1', start:1, end:10}] }] },
          '數字題本': { id:'mt_3', name:'數字題本', instances:[] },
          '模擬題本': { id:'mt_4', name:'模擬題本', instances:[] },
          '考古題': { id:'mt_5', name:'考古題', instances:[{ name:'考古題1', type:'volume', vols:{}, volOrder:[], units:[{id:'u-kk-1', name:'考古單元1', start:1, end:10}] }] }  // 考古題有 unit
        }
      }
    }
  },
  missions: { '會考複習': { '會考練習': ['u-kk-1'] } }, // 引用考古題的單元
  logs: [], plans: [],
  _deletedTypes: { '會考複習': { '公民': [] } },  // 預設空 (還沒刪過)
  avatar: ''
};

const context = {
  console, Date, Math, JSON, Object, Array, String, Number, Boolean,
  setTimeout, clearTimeout, setInterval, clearInterval, WeakMap, Map, Set,
  Storage: function(){},
  alert: noop,
  confirm: () => true,
  document: { documentElement:{ setAttribute:noop, getAttribute:()=>'light' } },
  STORAGE_KEY_FAMILY: 'StudyMap_Family_Data_V20',
  STORAGE_KEY_CURRENT_USER: 'StudyMap_CurrentUserId_V20',
};
context.window = Object.assign(context, { addEventListener: noop });
context.document = Object.assign(context.document, {
  getElementById: elStub,
  querySelectorAll: noopArr,
  querySelector: () => null,
  addEventListener: noop,
  createElement: () => ({ style:{}, classList:{add:noop,remove:noop}, appendChild:noop }),
  body: { appendChild: noop },
  head: { appendChild: noop },
});
context.localStorage = {
  _store: { 'StudyMap_Family_Data_V20': JSON.stringify({ Denias: DeniasState }), 'StudyMap_CurrentUserId_V20': 'Denias' },
  getItem(k){ return this._store[k] || null; },
  setItem(k,v){ this._store[k] = v; },
  removeItem(k){ delete this._store[k]; }
};
vm.createContext(context);

console.log('=== T0: 載入 (考古題存在, 還沒被刪) ===');
vm.runInContext(code, context);
console.log('appMaster 公民 materials keys:', Object.keys(context.appMaster['公民'].materials));
const tree0 = context.buildMissionTree('會考複習', '會考練習');
console.log('tree:', JSON.stringify(tree0));

let subUnits0 = [];
Object.keys(tree0).forEach(sub => {
  const sTree = tree0[sub];
  Object.keys(sTree.items).forEach(vol => {
    sTree.items[vol].forEach(u => subUnits0.push({typeName: u._typeName||'(未分類)', name:u.name}));
  });
});
console.log('subUnits:', JSON.stringify(subUnits0, null, 2));

const typeCount0 = {};
subUnits0.forEach(x => { const t=x.typeName||'(未分類)'; typeCount0[t]=(typeCount0[t]||0)+1; });
console.log('typeCount (考古題應該 > 0):', typeCount0);

console.log('\n=== T1: Denias 點 deleteMaterialType("考古題") ===');
// 直接呼叫: delete subject.materials[typeName] + 寫 marker
const u = context.multiData['Denias'];
const sub = '公民', typeName = '考古題';
delete u.masters['會考複習'][sub].materials[typeName];
if (!u._deletedTypes) u._deletedTypes = {};
if (!u._deletedTypes['會考複習']) u._deletedTypes['會考複習'] = {};
if (!u._deletedTypes['會考複習'][sub]) u._deletedTypes['會考複習'][sub] = [];
u._deletedTypes['會考複習'][sub].push(typeName);
console.log('marker:', JSON.stringify(u._deletedTypes));

console.log('\n=== T2: 重啟 (重新載入程式) ===');
// 清掉 cache + 重新跑 buildMissionTree (模擬重啟邏輯)
context._collectSubjectUnitsCache = new context.WeakMap();
context.appMaster = context.multiData['Denias'].masters['會考複習'];

const tree1 = context.buildMissionTree('會考複習', '會考練習');
console.log('tree:', JSON.stringify(tree1));

let subUnits1 = [];
Object.keys(tree1).forEach(sub => {
  const sTree = tree1[sub];
  Object.keys(sTree.items).forEach(vol => {
    sTree.items[vol].forEach(u => subUnits1.push({typeName: u._typeName||'(未分類)', name:u.name}));
  });
});
console.log('subUnits:', JSON.stringify(subUnits1, null, 2));

const typeCount1 = {};
subUnits1.forEach(x => { const t=x.typeName||'(未分類)'; typeCount1[t]=(typeCount1[t]||0)+1; });
console.log('typeCount (考古題應該 = 0 或沒 key):', typeCount1);
console.log('orderedTypes 預期: 複習講義/複習卷/數字題本/模擬題本/考古題 (考古題在 defaultOrder 裡, 但 typeCount 沒它 → orderedTypes 還是有它, 但 onClick 不會 work 因為 typeCount=0 → 灰底)');
