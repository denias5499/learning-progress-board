// test syntax
    
        function genId() { return 'id_' + Math.random().toString(36).substr(2, 9); }
        // v1.6.64: 自動補 typeName/instanceName + 用 within-match 修 remap
        window._v164Migrate = function _v164Migrate(uid) {
            var user = multiData[uid];
            if (!user || !user.masters) return;
            // Build uid_map (unitId → [typeName, instanceName])
            var uidMap = {};
            Object.keys(user.masters).forEach(function(cat) {
                var subjects = user.masters[cat];
                if (typeof subjects !== 'object') return;
                Object.keys(subjects).forEach(function(sub) {
                    var subData = subjects[sub];
                    if (!subData || !subData.materials) return;
                    Object.keys(subData.materials).forEach(function(typeName) {
                        var typeObj = subData.materials[typeName];
                        if (!typeObj || !typeObj.instances) return;
                        typeObj.instances.forEach(function(ins) {
                            if (!ins) return;
                            var insName = ins.name || '';
                            (ins.units || []).forEach(function(u) {
                                if (u && u.id) uidMap[u.id] = [typeName, insName];
                            });
                            Object.keys(ins.vols || {}).forEach(function(vol) {
                                (ins.vols[vol] || []).forEach(function(u) {
                                    if (u && u.id) uidMap[u.id] = [typeName, insName];
                                });
                            });
                        });
                    });
                });
            });
            // Backfill typeName + instanceName for tasks that don't have them
            var bfCount = 0;
            // Also re-run remap with within-match to fix wrong unitIds
            var remapCount = 0;
            (user.plans || []).forEach(function(plan) {
                if (!plan.grid) return;
                Object.keys(plan.grid).forEach(function(dateStr) {
                    (plan.grid[dateStr] || []).forEach(function(t) {
                        if (!t || !t.unitName || !t.cat || !t.subject) return;
                        // 1. Backfill typeName/instanceName
                        if ((!t.typeName || !t.instanceName) && uidMap[t.unitId]) {
                            t.typeName = uidMap[t.unitId][0];
                            t.instanceName = uidMap[t.unitId][1];
                            bfCount++;
                        }
                        // 2. v1.6.169: 強健 within-match remap
                        // - within-match 用 page range + vol 鎖 (不加 type/instance, 才能跨 instance disambiguate)
                        // - exact-match 用 type+instance+vol (鎖定同一個教材實例)
                        // - page range fixup: exact 不涵蓋時 fallback 到 within-match
                        // - 沒 type/instance 時 fallback 找當前 unitId (ground truth)
                        var masterEntry = (user.masters[t.cat] || {})[t.subject];
                        if (!masterEntry) return;
                        var allUnits = _collectSubjectUnits(masterEntry);
                        var match = null;
                        // within-match: page range 為主, 只加 vol 鎖 (不加 type/instance 才能跨 instance disambiguate)
                        var withinMatch = allUnits.find(function(u) {
                            if (u.name !== t.unitName) return false;
                            // v1.6.168: vol 鎖 (避免跨 vol 同名 unit 誤判)
                            if (u.vol != null && t.vol && u.vol !== t.vol) return false;
                            if (t.startPage != null && t.endPage != null &&
                                u.start != null && u.end != null) {
                                return u.start <= t.startPage && u.end >= t.endPage;
                            }
                            return true;
                        });
                        if (t.typeName && t.instanceName) {
                            // v1.6.169: 先收集 name+type+instance 候選
                            var tiCandidates = allUnits.filter(function(u) {
                                return u.name === t.unitName &&
                                       u._typeName === t.typeName &&
                                       u._instanceName === t.instanceName;
                            });
                            // 精確比對: name + typeName + instanceName + vol
                            match = tiCandidates.find(function(u) {
                                return (u.vol == null || !t.vol || u.vol === t.vol);
                            });
                            // v1.6.169: t.vol 缺失時, 優先保留當前 unitId (ground truth)
                            if (!t.vol) {
                                var currentInCandidates = tiCandidates.find(function(u) { return u.id === t.unitId; });
                                if (currentInCandidates) match = currentInCandidates;
                            }
                            // v1.6.64: 如果精確比對的 unit 頁範圍不涵蓋 task (例如 麻辣甲 P.1 vs task P.39-42),
                            // 但有 within-match 的 unit 涵蓋, 用 within-match
                            if (match && withinMatch && match.id !== withinMatch.id) {
                                var matchCovers = match.start <= t.startPage && match.end >= t.endPage;
                                if (!matchCovers) {
                                    match = withinMatch;
                                }
                            } else if (!match) {
                                match = withinMatch;
                            }
                        } else {
                            // v1.6.169: 沒 type/instance — fallback 找當前 unitId 是否在 master (ground truth)
                            match = allUnits.find(function(u) { return u.id === t.unitId; });
                            if (!match) match = withinMatch;
                        }
                        if (match && match.id !== t.unitId) {
                            t.unitId = match.id;
                            if (match._typeName) t.typeName = match._typeName;
                            if (match._instanceName) t.instanceName = match._instanceName;
                            remapCount++;
                        }
                    });
                });
            });
            if (bfCount > 0) {
                console.log('v1.6.64: ✅ backfill ' + bfCount + ' 個 task 的 typeName/instanceName');
            } else {
                console.log('v1.6.64: 所有 task 都有 typeName/instanceName (無需 backfill)');
            }
            if (remapCount > 0) {
                console.log('v1.6.64: ✅ within-match remap 修了 ' + remapCount + ' 個 task 的 unitId');
            } else {
                console.log('v1.6.64: within-match remap 無需修正');
            }
            // v1.6.66: 清 _collectSubjectUnitsCache,確保 buildMissionTree 重新算
            if (typeof _collectSubjectUnitsCache !== 'undefined') {
                _collectSubjectUnitsCache = new WeakMap();
                console.log('v1.6.66: 清 _collectSubjectUnitsCache (避免 migration 後 cache 還用舊 reference)');
            }
            // v1.6.170: fix 9/15 mission template bug
            // 問題: missions['會考複習']['二模'][35] 指向 'id_us9n3e8wr' (第二冊 L1~2)
            //       但 Plan.grid[9/15] 的 task.unitName='L1~2' vol=第三冊, 應對應 'id_j7l5x7jdz' (第三冊 L1~2)
            // 症狀: tree 顯示綠點掛在第二冊 L1~2, 而不是第三冊 L1~2
            // 修法: idempotent guard — 如果 [35] 還是錯的就改成對的
            var m170 = user.missions && user.missions['會考複習'] && user.missions['會考複習']['二模'];
            if (Array.isArray(m170) && m170[35] === 'id_us9n3e8wr') {
                m170[35] = 'id_j7l5x7jdz';
                console.log('v1.6.170: ✅ fix missions.會考複習.二模[35] = id_j7l5x7jdz (第三冊 L1~2)');
                user._v170_mission_fix_applied = true;
            }
        };
        function el(id) { return document.getElementById(id); }
        function getLocalDateString(d) { var year = d.getFullYear(); var month = String(d.getMonth() + 1).padStart(2, '0'); var day = String(d.getDate()).padStart(2, '0'); return year + '-' + month + '-' + day; }
        // v1.5.144: Helper functions for unit-based materials
        function isUnitBasedType(typeObj) {
            return typeObj && typeObj.unitBased === true;
        }
        // v1.5.155: 從 unit 對象找 instance 的 alias
        function getInstanceAliasFromUnit(u) {
            if (!u || !u.instanceName) return '?';
            // v1.5.155: 從 instanceName 找 instance 對象
            for (var sub in appMaster) {
                var subj = appMaster[sub];
                if (!subj || !subj.materials) continue;
                for (var tName in subj.materials) {
                    var typeObj = subj.materials[tName];
                    if (!typeObj || !typeObj.instances) continue;
                    for (var i = 0; i < typeObj.instances.length; i++) {
                        if (typeObj.instances[i].name === u.instanceName && tName === u.typeName) {
                            return getInstanceAlias(typeObj.instances[i]);
                        }
                    }
                }
            }
            // v1.5.157: 找不到 instance 對象, fallback 用完整 instanceName
            return u.instanceName;
        }
        function getInstanceAlias(instance) {
            if (!instance) return '?';
            if (instance.alias) return instance.alias;
            // v1.5.157: fallback 到完整名稱
            if (instance.name) return instance.name;
            return '?';
        }
        // v1.5.146: Unit 進度計算 (支援 unit-based 跟 page-based)
        function getUnitTotalCount(unit, typeObj) {
            if (isUnitBasedType(typeObj)) {
                // Unit-based: 1 個 unit = 1 個單位
                return 1;
            }
            // Page-based: 用起註頁數
            if (unit && typeof unit.start === 'number' && typeof unit.end === 'number' && unit.end >= unit.start) {
                return unit.end - unit.start + 1;
            }
            return 1;
        }
        function getUnitDoneCount(unit, typeObj, filterCat, filterMis) {
            if (!appPlans || !unit) return 0;
            // v1.5.167: 過濾 mission filter (防止跨 mission 混算)
            if (filterCat && filterCat !== 'ALL' && !filterCat) return 0;
            // 計算 task 算進此 unit 的 pages
            var totalPages = 0;
            var isUnitBased = isUnitBasedType(typeObj);
            for (var i = 0; i < appPlans.length; i++) {
                var plan = appPlans[i];
                if (!plan.grid) continue;
                var dStrs = Object.keys(plan.grid);
                for (var j = 0; j < dStrs.length; j++) {
                    var tasks = plan.grid[dStrs[j]] || [];
                    for (var k = 0; k < tasks.length; k++) {
                        var t = tasks[k];
                        if (!t || !t.isDone || t.unitId !== unit.id) continue;
                        // v1.5.167: 按 mission filter 過濾
                        if (filterCat && filterCat !== 'ALL' && t.cat !== filterCat) continue;
                        if (filterMis && filterMis !== 'ALL' && t.mis !== filterMis) continue;
                        var pages = (t.endPage && t.startPage && t.endPage >= t.startPage) ? (t.endPage - t.startPage + 1) : 1;
                        if (isUnitBased) {
                            return 1;  // unit-based: 1 task done = 整個 unit done
                        }
                        totalPages += pages;
                    }
                }
            }
            return totalPages;
        }
        function findUnitContextByName(unitName) {
            if (!unitName || !appMaster) return null;
            for (var sub in appMaster) {
                var subj = appMaster[sub];
                if (!subj || !subj.materials) continue;
                for (var typeName in subj.materials) {
                    var typeObj = subj.materials[typeName];
                    if (!typeObj || !typeObj.instances) continue;
                    for (var i = 0; i < typeObj.instances.length; i++) {
                        var ins = typeObj.instances[i];
                        if (ins.type === 'volume' && ins.vols) {
                            for (var vol in ins.vols) {
                                var units = ins.vols[vol];
                                for (var j = 0; j < units.length; j++) {
                                    if (units[j].name === unitName) {
                                        return { sub: sub, typeName: typeName, typeObj: typeObj, instance: ins, unit: units[j], vol: vol };
                                    }
                                }
                            }
                        } else if (ins.type === 'custom' && ins.units) {
                            for (var j = 0; j < ins.units.length; j++) {
                                if (ins.units[j].name === unitName) {
                                    return { sub: sub, typeName: typeName, typeObj: typeObj, instance: ins, unit: ins.units[j], vol: null };
                                }
                            }
                        }
                    }
                }
            }
            return null;
        }
        // v1.5.219: 跨所有 category + 跨 current user 找 unit (處理 tree view 跨 category 但 appMaster 只有 current cat 的問題)
        function findUnitContextAnywhere(unitId, unitName) {
            // 先試 current appMaster
            var ctx = findUnitContext(unitId);
            if (ctx) return ctx;
            // 試其他 categories (multiData[currentUserId].masters)
            if (typeof multiData !== 'undefined' && multiData[currentUserId] && multiData[currentUserId].masters) {
                Object.keys(multiData[currentUserId].masters).forEach(function(cat) {
                    if (ctx) return;
                    var catMaster = multiData[currentUserId].masters[cat];
                    if (!catMaster) return;
                    Object.keys(catMaster).forEach(function(sub) {
                        if (ctx) return;
                        var subj = catMaster[sub];
                        if (!subj || !subj.materials) return;
                        Object.keys(subj.materials).forEach(function(typeName) {
                            if (ctx) return;
                            var typeObj = subj.materials[typeName];
                            if (!typeObj || !typeObj.instances) return;
                            typeObj.instances.forEach(function(ins) {
                                if (ctx) return;
                                if (ins.type === 'volume' && ins.vols) {
                                    Object.keys(ins.vols).forEach(function(vol) {
                                        if (ctx) return;
                                        (ins.vols[vol] || []).forEach(function(u) {
                                            if (!ctx && u.id === unitId) {
                                                ctx = { sub: sub, typeName: typeName, typeObj: typeObj, instance: ins, unit: u, vol: vol, fromCat: cat };
                                            }
                                        });
                                    });
                                } else if (ins.type === 'custom' && ins.units) {
                                    ins.units.forEach(function(u) {
                                        if (!ctx && u.id === unitId) {
                                            ctx = { sub: sub, typeName: typeName, typeObj: typeObj, instance: ins, unit: u, vol: null, fromCat: cat };
                                        }
                                    });
                                }
                            });
                        });
                    });
                });
            }
            if (ctx) return ctx;
            // fallback by name
            if (unitName) ctx = findUnitContextByName(unitName);
            return ctx;
        }
        function findUnitContext(unitId) {
            if (!unitId || !appMaster) return null;
            for (var sub in appMaster) {
                var subj = appMaster[sub];
                if (!subj || !subj.materials) continue;
                for (var typeName in subj.materials) {
                    var typeObj = subj.materials[typeName];
                    if (!typeObj || !typeObj.instances) continue;
                    for (var i = 0; i < typeObj.instances.length; i++) {
                        var ins = typeObj.instances[i];
                        if (ins.type === 'volume' && ins.vols) {
                            for (var vol in ins.vols) {
                                var units = ins.vols[vol];
                                for (var j = 0; j < units.length; j++) {
                                    if (units[j].id === unitId) {
                                        return { sub: sub, typeName: typeName, typeObj: typeObj, instance: ins, unit: units[j], vol: vol };
                                    }
                                }
                            }
                        } else if (ins.type === 'custom' && ins.units) {
                            for (var j = 0; j < ins.units.length; j++) {
                                if (ins.units[j].id === unitId) {
                                    return { sub: sub, typeName: typeName, typeObj: typeObj, instance: ins, unit: ins.units[j], vol: null };
                                }
                            }
                        }
                    }
                }
            }
            return null;
        }
        var STORAGE_KEY_FAMILY = 'StudyMap_Family_Data_V20';
        var STORAGE_KEY_CURRENT_USER = 'StudyMap_CurrentUserId_V20';
        var STORAGE_KEY_BOARD_TITLE = 'StudyMap_BoardTitle_V20';
        var STORAGE_KEY_BOARD_LOGO = 'StudyMap_BoardLogo_V20';
        var STORAGE_KEY_BOARD_EMOJI = 'StudyMap_BoardEmoji_V20';
        var STORAGE_KEY_BOARD_LOGO_HEIGHT = 'StudyMap_BoardLogoHeight_V20';
        var STORAGE_KEY_BOARD_LOGO_WIDTH = 'StudyMap_BoardLogoWidth_V20';
        var STORAGE_KEY_BOARD_LOGO_FIT = 'StudyMap_BoardLogoFit_V20';
        var STORAGE_KEY_WIZARD_PREFS = 'StudyMap_WizardPrefs_V20';
        var STORAGE_KEY_THEME = 'StudyMap_Theme_V21';
        
        var DEFAULT_AVATAR = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%2394a3b8'%3E%3Cpath d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z'/%3E%3C/svg%3E";
        var multiData = null;
        var currentUserId = null;
        var appMaster = {}; var appMissions = {}; var appLogs = []; var appPlans = []; var appCurrentCat = '';
        var currentViewDate = new Date(); 
        
        window.isMasterDirty = false;
        let lastMasterSub = "";
        window.aeSelectedItems = [];
        window.aeDisplayMode = 'D';  // v1.5.35: 手動新增顯示模式
        window.aeCollapsed = {};     // v1.5.35: 手動新增摺疊狀態
        window.aeSubjectType = {};  // v1.5.37: 每個科目目前選擇的教材類型 (sub → typeName)
        function applyPlannerButtonsColors() {
            const colors = ['#F3D2AC', '#F3B8B1'];
            document.querySelectorAll('.planner-action-btn').forEach((btn, index) => {
                btn.style.backgroundColor = colors[index % colors.length];
                btn.style.color = '#2c3e50'; 
            });
        }
        function showPage(pageId) {
            document.querySelectorAll('.page-view').forEach(p => p.style.display = 'none');
            el('dashboard-root').style.display = 'none';
            el('starmap-root').style.display = 'none';
            
            // v1.5.86: 離開月曆時清除 highlight
            if (pageId !== 'page-planner') {
                window._highlightUnitId = null;
            }
            
            // 修正：動態清除白底框,保留回首頁按鍵的透明背景
            
            // 修正：動態清除白底框，保留回首頁按鍵的透明背景
            if (pageId === 'page-settings' || pageId === 'page-planner') {
                el('global-filter-selectors').style.display = 'none';
                el('global-filter-bar').style.background = 'transparent';
                el('global-filter-bar').style.boxShadow = 'none';
                el('global-filter-bar').style.borderLeft = 'none';
            } else {
                el('global-filter-selectors').style.display = 'flex';
                el('global-filter-bar').style.background = '';
                el('global-filter-bar').style.boxShadow = '';
                el('global-filter-bar').style.borderLeft = '';
            }
            
            document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active-nav'));
            if(pageId) {
                el(pageId).style.display = 'block';
                if (pageId === 'page-settings' && el('nav-btn-settings')) el('nav-btn-settings').classList.add('active-nav');
                if (pageId === 'page-planner' && el('nav-btn-planner')) el('nav-btn-planner').classList.add('active-nav');
                // v1.5.57: page-history no longer has a top nav button
                // v1.5.57: page-daily no longer has a top nav button
                if (pageId === 'page-stats' && el('nav-btn-stats')) el('nav-btn-stats').classList.add('active-nav');
                if (pageId === 'page-wrongnotes' && el('nav-btn-wrongnotes')) el('nav-btn-wrongnotes').classList.add('active-nav');
            }
        }
        // v1.5.175: 樹狀圖 default 模式 — 顯示科目 summary cards
        function renderTreeSubjectSummary(root, treeSubjects) {
            var html = '';
            Object.keys(treeSubjects).forEach(function(key) {
                var info = treeSubjects[key];
                // 計算該科目的 unit / vol 統計
                var unitCount = 0, volCount = 0, typeCount = 0;
                if (info.subj && info.subj.materials) {
                    typeCount = Object.keys(info.subj.materials).length;
                    Object.values(info.subj.materials).forEach(function(t) {
                        if (t && t.instances) {
                            t.instances.forEach(function(inst) {
                                if (inst.vols) {
                                    Object.keys(inst.vols).forEach(function(v) {
                                        volCount++;
                                        unitCount += (inst.vols[v] || []).length;
                                    });
                                }
                            });
                        }
                    });
                }
                html += '<div class="tree-subject-summary" onclick="selectTreeSubject(\'' + key + '\')">' +
                    '<span class="tree-subject-summary-name">📘 ' + escapeHtml(info.name) + '</span>' +
                    '<span class="tree-subject-summary-stats">' + typeCount + ' 類別 · ' + volCount + ' 冊 · ' + unitCount + ' 單元</span>' +
                    '<span style="color: var(--secondary);">▶ 展開</span>' +
                    '</div>';
            });
            html += '<div style="text-align: center; padding: 15px; color: var(--secondary); font-size: 1.1em; font-weight: bold;">↑ 點擊科目展開詳細樹狀圖，或從上方 dropdowns 選擇</div>';
            root.innerHTML = html;
        }
        // v1.5.175: 點擊科目 summary card → 設成 selected 並重 render
        function selectTreeSubject(key) {
            var sel = el('tree-subject-filter');
            if (sel) {
                sel.value = key;
                renderTreeView();
            }
        }
        // v1.5.175: 重設所有樹狀圖 filter
        function resetTreeFilter() {
            var sels = ['tree-cat-filter', 'tree-subject-filter', 'tree-type-filter', 'tree-vol-filter'];
            sels.forEach(function(id) {
                var sel = el(id);
                if (sel) {
                    sel.value = (id === 'tree-cat-filter') ? 'ALL' : 'ALL';
                }
            });
            renderTreeView();
        }
        function returnToHome() {
            if (el('page-settings') && el('page-settings').style.display === 'block' && window.isMasterDirty) {
                if (confirm('警告：您在教材庫設定有尚未儲存的變更！\n按「確定」儲存變更，或按「取消」(否) 不儲存並離開。')) {
                    saveSettingsAndAlert(true); 
                    return;
                } else {
                    window.isMasterDirty = false;
                    switchUser(); 
                }
            }
            
            showPage(null);
            el('dashboard-root').style.display = 'block';
            el('starmap-root').style.display = 'none';
            el('dashboard-root').classList.add('active');
            el('starmap-root').classList.remove('active');
            document.querySelectorAll('.dash-tab').forEach(b => {
                if (b.getAttribute('data-view') === 'dashboard') b.classList.add('active');
                else b.classList.remove('active');
            });
            updateFilters();
            renderDashboard();
        }
        function loadWizardPrefs() {
            var prefs = localStorage.getItem(STORAGE_KEY_WIZARD_PREFS);
            var base = { hours: {}, subjects: {}, quickReadDiscount: 60, displayMode: 'D' };
            if (prefs) {
                try { 
                    var p = JSON.parse(prefs);
                    // v1.6.141: Migration — 補 scheduleMode/daysPerUnit 預設值
                    if (!p.scheduleMode) p.scheduleMode = 'hours';
                    if (!p.subjects) p.subjects = {};
                    Object.keys(p.subjects).forEach(function(k) {
                        var s = p.subjects[k];
                        if (!s.scheduleMode) s.scheduleMode = p.scheduleMode || 'hours';
                        if (!s.daysPerUnit) s.daysPerUnit = 2;
                    });
                    return p; 
                } catch(e){}
            }
            base.scheduleMode = 'hours';
            return base;
        }
        function saveWizardPrefs() {
            var prefs = { hours: {}, subjects: {}, quickReadDiscount: 60, displayMode: 'D' };
            for(let i=0; i<=6; i++) {
                let val = el('wz-hrs-' + i).value;
                if(val) prefs.hours[i] = val;
            }
            var qrDiscount = el('wz-quickread-discount') ? Number(el('wz-quickread-discount').value) : 60;
            prefs.quickReadDiscount = Math.max(10, Math.min(95, qrDiscount));
            // v1.6.141: 頁面級 scheduleMode
            var modeRadio = document.querySelector('input[name="wz-schedule-mode"]:checked');
            prefs.scheduleMode = modeRadio ? modeRadio.value : 'hours';
            if(typeof wizardSubjects !== 'undefined') {
                wizardSubjects.forEach(ws => {
                    // v1.5.112: 順便存 selectedUnitIds 供下次預設 (default 改為非全選後)
                    var selectedUnitIds = ws.selectedUnitIds || [];
                    prefs.subjects[ws.name] = {
                        progVal: ws.progVal,
                        hoursPerUnit: ws.hoursPerUnit,
                        displayMode: ws.displayMode || 'D',
                        scheduleMode: ws.scheduleMode || prefs.scheduleMode,
                        daysPerUnit: ws.daysPerUnit || 2,
                        selectedUnitIds: selectedUnitIds
                    };
                });
            }
            // 全域 displayMode (e.g. 所有科目統一)
            var globalDm = document.querySelector('input[name="wz-display-mode"]:checked');
            if (globalDm) prefs.globalDisplayMode = globalDm.value;
            localStorage.setItem(STORAGE_KEY_WIZARD_PREFS, JSON.stringify(prefs));
        }
        // v1.6.141: 切換智慧排程模式 (頁面級)
        function setWizardScheduleMode(mode) {
    // mode = 'hours' | 'units'
    if (typeof wizardSubjects !== 'undefined') {
        wizardSubjects.forEach(function(ws) {
            ws.scheduleMode = mode;
            // 模式 B 補預設值 (不覆蓋 user 已設定)
            if (mode === 'units' && !ws.daysPerUnit) ws.daysPerUnit = 3;
        });
        saveWizardPrefs();
    }
    
    var hoursCard = el('wz-mode-hours-card');
    var unitsCard = el('wz-mode-units-card');
    var desc = el('wz-schedule-mode-desc');
    var globalHoursCard = el('global-mode-hours-card');
    var globalUnitsCard = el('global-mode-units-card');
    
    if (mode === 'hours') {
        if (hoursCard) {
            hoursCard.style.border = '2px solid #0ea5e9';
            hoursCard.style.background = '#e0f2fe';
            hoursCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio = hoursCard.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        }
        if (unitsCard) {
            unitsCard.style.border = '2px solid #cbd5e1';
            unitsCard.style.background = 'white';
            unitsCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (globalHoursCard) {
            globalHoursCard.style.border = '2px solid #0ea5e9';
            globalHoursCard.style.background = '#e0f2fe';
            globalHoursCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio2 = globalHoursCard.querySelector('input[type="radio"]');
            if (radio2) radio2.checked = true;
        }
        if (globalUnitsCard) {
            globalUnitsCard.style.border = '2px solid #cbd5e1';
            globalUnitsCard.style.background = 'white';
            globalUnitsCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (desc) desc.innerHTML = '⏱️ <b>時數模式</b>：每 unit 切成 0.5hr chunks，平均塞進每天時數內';
    } else {
        if (hoursCard) {
            hoursCard.style.border = '2px solid #cbd5e1';
            hoursCard.style.background = 'white';
            hoursCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (unitsCard) {
            unitsCard.style.border = '2px solid #0ea5e9';
            unitsCard.style.background = '#e0f2fe';
            unitsCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio = unitsCard.querySelector('input[type="radio"]');
            if (radio) radio.checked = true;
        }
        if (globalHoursCard) {
            globalHoursCard.style.border = '2px solid #cbd5e1';
            globalHoursCard.style.background = 'white';
            globalHoursCard.querySelectorAll('span')[2].style.color = '#475569';
        }
        if (globalUnitsCard) {
            globalUnitsCard.style.border = '2px solid #0ea5e9';
            globalUnitsCard.style.background = '#e0f2fe';
            globalUnitsCard.querySelectorAll('span')[2].style.color = '#0369a1';
            var radio2 = globalUnitsCard.querySelector('input[type="radio"]');
            if (radio2) radio2.checked = true;
        }
        if (desc) desc.innerHTML = '📅 <b>單元模式</b>：每 unit 分 N 天讀，每天一個時段 (hrs÷N 小時)';
    }
    
    // 儲存到偏好設定
    if (window.preferences) {
        window.preferences.scheduleMode = mode;
        window.saveWizardPrefs();
    }
}
// v1.6.173: 全局模式切換初始化
function initGlobalScheduleMode() {
    var globalHoursCard = el('global-mode-hours-card');
    var globalUnitsCard = el('global-mode-units-card');
    if (globalHoursCard && globalUnitsCard) {
        // 綁定 click 事件
        globalHoursCard.addEventListener('click', function(e) {
            if (e.target.type !== 'radio') {
                setWizardScheduleMode('hours');
            }
        });
        globalUnitsCard.addEventListener('click', function(e) {
            if (e.target.type !== 'radio') {
                setWizardScheduleMode('units');
            }
        });
        // 同步 radio 狀態
        var globalRadioHours = globalHoursCard.querySelector('input[type="radio"]');
        var globalRadioUnits = globalUnitsCard.querySelector('input[type="radio"]');
        if (globalRadioHours && globalRadioUnits) {
            globalRadioHours.addEventListener('change', function() {
                if (this.checked) setWizardScheduleMode('hours');
            });
            globalRadioUnits.addEventListener('change', function() {
                if (this.checked) setWizardScheduleMode('units');
            });
        }
    }
}
        // === v1.5.112: 全域 App Prefs (三大任務預設時數) ===
        var STORAGE_KEY_APP_PREFS = 'StudyMap_AppPrefs_V112';
        function loadAppPrefs() {
            var p = localStorage.getItem(STORAGE_KEY_APP_PREFS);
            if (p) { try { return JSON.parse(p); } catch(e){} }
            return { taskHours: {} };
        }
        function saveAppPrefs(prefs) {
            if (!prefs) prefs = loadAppPrefs();
            // 從 DOM 讀取每個 cat 的時數
            if (document.querySelectorAll('[id^="apre-hours-"]').length > 0) {
                document.querySelectorAll('[id^="apre-hours-"]').forEach(function(inp) {
                    var cat = inp.id.replace('apre-hours-', '');
                    var val = Number(inp.value);
                    if (val > 0) prefs.taskHours[cat] = val;
                    else delete prefs.taskHours[cat];
                });
            }
            localStorage.setItem(STORAGE_KEY_APP_PREFS, JSON.stringify(prefs));
        }
        // === v1.5.112: plan.hourConfig 初始化 ===
        function ensurePlanHourConfig(plan) {
            if (!plan) return null;
            if (!plan.hourConfig) {
                plan.hourConfig = {
                    defaults: { 0: 4, 1: 2, 2: 2, 3: 2, 4: 2, 5: 2, 6: 4 },
                    taskHours: {},  // 該計畫自己的任務時數覆寫 (優先從 appPrefs 拉過來)
                    overrides: []   // 日期範圍 override (最高優先)
                };
            } else {
                if (!plan.hourConfig.defaults) plan.hourConfig.defaults = { 0: 4, 1: 2, 2: 2, 3: 2, 4: 2, 5: 2, 6: 4 };
                if (!plan.hourConfig.taskHours) plan.hourConfig.taskHours = {};
                if (!plan.hourConfig.overrides) plan.hourConfig.overrides = [];
            }
            return plan.hourConfig;
        }
        // === v1.5.112: 取得某天的時數 (優先序: override > taskHours > defaults) ===
        function getEffectiveDailyHours(dStr, dw, hourConfig, cat, plan) {
            if (!hourConfig) hourConfig = { defaults: {0:4,1:2,2:2,3:2,4:2,5:2,6:4}, taskHours: {}, overrides: [] };
            var overrides = hourConfig.overrides || [];
            // v1.5.164: 事件 (最高優先, 蓋過所有)
            if (plan && Array.isArray(plan.events)) {
                for (var ei = 0; ei < plan.events.length; ei++) {
                    var ev = plan.events[ei];
                    if (ev && ev.date === dStr && ev.hours !== undefined) {
                        return Math.max(0, Number(ev.hours) || 0);
                    }
                }
            }
            // v1.5.115: 先試特殊日期 (次高優先)
            for (var i = 0; i < overrides.length; i++) {
                var ov = overrides[i];
                if (ov.specialDates && ov.specialDates.length > 0) {
                    for (var j = 0; j < ov.specialDates.length; j++) {
                        var sd = ov.specialDates[j];
                        if (dStr === sd.date && sd.hours !== undefined) {
                            return Math.max(0, Number(sd.hours) || 0);
                        }
                    }
                }
            }
            // 1. 連續範圍 override
            for (var i = 0; i < overrides.length; i++) {
                var ov = overrides[i];
                if (ov.start && ov.end && dStr >= ov.start && dStr <= ov.end) {
                    if (ov.dailyHours && ov.dailyHours[dw] !== undefined && ov.dailyHours[dw] !== null) {
                        return Math.max(0, Number(ov.dailyHours[dw]) || 0);
                    }
                }
            }
            // 2. taskHours[cat] (計畫自己的)
            if (cat && hourConfig.taskHours && hourConfig.taskHours[cat] !== undefined) {
                return Math.max(0, Number(hourConfig.taskHours[cat]) || 0);
            }
            // 3. defaults[dw]
            var defaults = hourConfig.defaults || { 0:4,1:2,2:2,3:2,4:2,5:2,6:4 };
            return Math.max(0, Number(defaults[dw]) || 0);
        }
        // === v1.5.112: 任務預設時數 UI ===
        function renderAppPrefsCatHours() {
            var container = el('apre-cat-hours-container');
            if (!container) return;
            var cats = Object.keys(appMissions);
            if (cats.length === 0) {
                container.innerHTML = '<div style="color:#7f8c8d; font-size:0.85em;">(尚未設定任何進度大分類)</div>';
                return;
            }
            var prefs = loadAppPrefs();
            var html = '<div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap:10px;">';
            cats.forEach(function(cat) {
                var cur = (prefs.taskHours && prefs.taskHours[cat]) ? prefs.taskHours[cat] : 0;
                html += '<div style="display:flex; align-items:center; gap:8px; background:#fffbeb; padding:8px 12px; border-radius:6px; border:1px solid #fde68a;">';
                html += '<span style="flex:1; font-weight:bold; color:#92400e;">📚 ' + cat + '</span>';
                html += '<input type="number" id="apre-hours-' + cat + '" min="0" step="0.5" value="' + cur + '" style="width:70px; padding:5px; border-radius:4px; border:1px solid #ccc; text-align:center;">';
                html += '<span style="font-size:0.85em; color:var(--secondary);">小時/天</span>';
                html += '</div>';
            });
            html += '</div>';
            container.innerHTML = html;
        }
        function saveAppPrefsAndClose() {
            saveAppPrefs();
            // v1.5.114: 用 toast 取代 alert
            showAppPrefsToast('已儲存！下次開啟智慧排程時會自動套用。');
        }
        // v1.5.114: toast 提示 (右下角顯示 3 秒自動消失)
        var _appPrefsToastTimer = null;
        function showAppPrefsToast(msg) {
            var existing = document.getElementById('apre-toast');
            if (existing) existing.remove();
            var toast = document.createElement('div');
            toast.id = 'apre-toast';
            toast.innerHTML = '<span style="margin-right:6px;">✅</span>' + msg;
            toast.style.cssText = 'position:fixed; bottom:30px; right:30px; background:#10b981; color:white; padding:12px 20px; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,0.2); z-index:99999; font-weight:bold; font-size:0.95em;';
            document.body.appendChild(toast);
            if (_appPrefsToastTimer) clearTimeout(_appPrefsToastTimer);
            _appPrefsToastTimer = setTimeout(function() {
                if (toast.parentNode) toast.remove();
            }, 3000);
        }
        function getSortedSubjects(subjects) {
            var targetOrder = ['國文', '數學', '英文', '歷史', '地理', '公民', '理化', '生物'];
            return subjects.sort((a, b) => {
                var idxA = targetOrder.indexOf(a);
                var idxB = targetOrder.indexOf(b);
                if (idxA === -1) idxA = 999;
                if (idxB === -1) idxB = 999;
                if (idxA !== idxB) return idxA - idxB;
                return a.localeCompare(b);
            });
        }
        // ==========================================
        // 修正處 1：加入這個全新的 getUnitScheduleStatus 函數
        // 來取代原本陽春的 isUnitScheduled 函數
        // ==========================================
        function getUnitScheduleStatus(sub, unitName, volName, unitId, unitStart, unitEnd, targetCat, targetMis) {
            var pid = el('planner-selector') ? el('planner-selector').value : null;
            if(!pid && appPlans.length > 0) pid = appPlans[appPlans.length - 1].id;
            if(!pid) return { isFullyScheduled: false, maxEnd: 0, misMaxEnd: 0 };
            var plan = appPlans.find(p => p.id === pid);
            if(!plan || !plan.grid) return { isFullyScheduled: false, maxEnd: 0, misMaxEnd: 0 };
            let maxScheduledEnd = 0;    // 所有任務的 maxEnd → 控制 isFullyScheduled
            let misMaxEnd = 0;          // 只限當前任務的 maxEnd → 控制 adjU.start 起點調整
            let found = false;
            let misFound = false;
            for (let dateStr in plan.grid) {
                let tasks = plan.grid[dateStr];
                if (Array.isArray(tasks)) {
                    for (let t of tasks) {
                        if (t.subject === sub) {
                            // 判斷是否匹配此單元（不論 cat/mis）
                            let match = false;
                            if (unitId && t.unitId) {
                                if (t.unitId === unitId) match = true;
                            } else if (t.unitName === unitName && t.vol === (volName || '')) {
                                match = true;
                            } else if (!t.unitId && t.text) {
                                let matchText = volName ? `[${volName}] ${unitName}` : unitName;
                                let safeMatchText = matchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                                let regex = new RegExp(`(^|[\\s\\[\\]【】])` + safeMatchText + `($|[\\s\\[\\]P])`);
                                if (regex.test(t.text)) match = true;
                            }
                            if (match) {
                                // 所有任務（cross-mis）都算入 maxScheduledEnd
                                found = true;
                                let ep = Number(t.endPage) || 0;
                                if (ep > maxScheduledEnd) maxScheduledEnd = ep;
                                // 只限當前任務（targetCat/targetMis）的計入 misMaxEnd
                                if (targetCat && targetMis) {
                                    if (t.cat === targetCat && t.mis === targetMis) {
                                        misFound = true;
                                        if (ep > misMaxEnd) misMaxEnd = ep;
                                    }
                                } else {
                                    // 若沒傳 targetCat/targetMis，misMaxEnd 等於 maxScheduledEnd
                                    misMaxEnd = maxScheduledEnd;
                                }
                            }
                        }
                    }
                }
            }
            if (!found) return { isFullyScheduled: false, maxEnd: 0, misMaxEnd: 0 };
            let uEnd = Number(unitEnd) || 0;
            // isFullyScheduled：只用當前任務的 misMaxEnd 來判斷（跨任務不影響顯示）
            // maxScheduledEnd：保留給日後擴充用，現已不影響 isFullyScheduled
            if (uEnd > 0 && misMaxEnd < uEnd) {
                return { isFullyScheduled: false, maxEnd: maxScheduledEnd, misMaxEnd: misMaxEnd };
            }
            return { isFullyScheduled: true, maxEnd: maxScheduledEnd, misMaxEnd: misMaxEnd };
        }
        function loadBoardHeader() {
            var title = localStorage.getItem(STORAGE_KEY_BOARD_TITLE) || '學習地圖與專案進度看板';
            var logo = localStorage.getItem(STORAGE_KEY_BOARD_LOGO) || '';
            var emoji = localStorage.getItem(STORAGE_KEY_BOARD_EMOJI) || '📊';
            var logoH = parseFloat(localStorage.getItem(STORAGE_KEY_BOARD_LOGO_HEIGHT)) || 1.2;
            var logoW = parseFloat(localStorage.getItem(STORAGE_KEY_BOARD_LOGO_WIDTH)) || 1.2;
            var logoFit = localStorage.getItem(STORAGE_KEY_BOARD_LOGO_FIT) || 'cover';
            var html = '';
            if (logo) {
                html += `<img onclick="event.stopPropagation(); openBoardSettings();" title="🎨 點此自訂看板標題與圖示" src="${logo}" style="cursor:pointer; height:${logoH}em; width:${logoW}em; border-radius:8px; margin-right:8px; object-fit:${logoFit}; vertical-align:middle; padding:2px; transition:all 0.2s;" onmouseover="this.style.opacity=0.8;" onmouseout="this.style.opacity=1;">`;
            } else {
                html += `<span onclick="event.stopPropagation(); openBoardSettings();" title="🎨 點此自訂看板標題與圖示" style="cursor:pointer; margin-right:8px; font-size:1.2em; vertical-align:middle; padding:4px 6px; border-radius:6px; transition:all 0.2s;" onmouseover="this.style.background='#f1f5f9';" onmouseout="this.style.background='transparent';">${emoji}</span>`;
            }
            html += `<span style="vertical-align:middle;">${title}</span>`;
            el('main-app-title').innerHTML = html;
        }
        function updateBoardLogoPreview() {
            var logo = localStorage.getItem(STORAGE_KEY_BOARD_LOGO) || '';
            if (!logo) return;
            var title = localStorage.getItem(STORAGE_KEY_BOARD_TITLE) || '學習地圖與專案進度看板';
            var h = parseFloat(document.getElementById('board-logo-height').value) || 1.2;
            var w = parseFloat(document.getElementById('board-logo-width').value) || 1.2;
            var fit = document.getElementById('board-logo-fit').value || 'cover';
            var lockRatio = document.getElementById('board-logo-lock-ratio').checked;
            document.getElementById('board-logo-height-label').textContent = h.toFixed(1);
            document.getElementById('board-logo-width-label').textContent = w.toFixed(1);
            // 鎖定寬高比時: 同步 width slider 跟著 height 變
            if (lockRatio) {
                // 用 img 原始比例計算 (從 logo data URL)
                var img = new Image();
                img.onload = function() {
                    var ratio = img.width / img.height;
                    var newW = (h * ratio).toFixed(1);
                    document.getElementById('board-logo-width').value = newW;
                    document.getElementById('board-logo-width-label').textContent = newW;
                    document.getElementById('board-logo-preview-title').innerHTML =
                        `<img src="${logo}" style="height:${h}em; width:${newW}em; border-radius:8px; margin-right:8px; object-fit:${fit}; vertical-align:middle;"><span style="vertical-align:middle;">${title}</span>`;
                };
                img.src = logo;
            } else {
                document.getElementById('board-logo-preview-title').innerHTML =
                    `<img src="${logo}" style="height:${h}em; width:${w}em; border-radius:8px; margin-right:8px; object-fit:${fit}; vertical-align:middle;"><span style="vertical-align:middle;">${title}</span>`;
            }
        }
        function saveBoardLogoSize() {
            var h = parseFloat(document.getElementById('board-logo-height').value) || 1.2;
            var w = parseFloat(document.getElementById('board-logo-width').value) || 1.2;
            var fit = document.getElementById('board-logo-fit').value || 'cover';
            localStorage.setItem(STORAGE_KEY_BOARD_LOGO_HEIGHT, h.toFixed(1));
            localStorage.setItem(STORAGE_KEY_BOARD_LOGO_WIDTH, w.toFixed(1));
            localStorage.setItem(STORAGE_KEY_BOARD_LOGO_FIT, fit);
            loadBoardHeader();
            closeModal('modal-board-settings');
            alert('✅ 圖片設定已儲存！');
        }
        function removeBoardLogo() {
            if (!confirm('確定要移除自訂圖片嗎？將恢復使用預設圖示。')) return;
            localStorage.removeItem(STORAGE_KEY_BOARD_LOGO);
            localStorage.removeItem(STORAGE_KEY_BOARD_LOGO_HEIGHT);
            localStorage.removeItem(STORAGE_KEY_BOARD_LOGO_WIDTH);
            localStorage.removeItem(STORAGE_KEY_BOARD_LOGO_FIT);
            localStorage.setItem(STORAGE_KEY_BOARD_EMOJI, '📊');
            loadBoardHeader();
            closeModal('modal-board-settings');
        }
        function applyTheme(theme) {
            document.documentElement.setAttribute('data-theme', theme);
            var btn = el('theme-toggle');
            if (btn) btn.innerHTML = theme === 'dark' ? '☀️' : '🌙';
        }
        function toggleTheme() {
            var current = document.documentElement.getAttribute('data-theme') || 'light';
            var next = current === 'dark' ? 'light' : 'dark';
            try { localStorage.setItem(STORAGE_KEY_THEME, next); } catch(e) {}
            applyTheme(next);
        }
        function loadTheme() {
            var saved = null;
            try { saved = localStorage.getItem(STORAGE_KEY_THEME); } catch(e) {}
            if (!saved) {
                saved = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            }
            applyTheme(saved);
        }
        function openBoardSettings() {
            el('board-title-input').value = localStorage.getItem(STORAGE_KEY_BOARD_TITLE) || '學習地圖與專案進度看板';
            el('board-logo-upload').value = '';
            
            const emojis = ['📘','📚','🔖','📖','📝','✏️','🥇','🥈','🥉','🏆','🎖️','💯','🎓','🌟','🎯','🚀','💡','📊','🧠'];
            el('board-emoji-grid').innerHTML = emojis.map(e => `<div class="emoji-btn" onclick="setBoardEmoji('${e}')">${e}</div>`).join('');
            
            openModal('modal-board-settings');
        }
        function setBoardEmoji(emoji) {
            localStorage.setItem(STORAGE_KEY_BOARD_EMOJI, emoji);
            localStorage.removeItem(STORAGE_KEY_BOARD_LOGO);
            loadBoardHeader();
            closeModal('modal-board-settings');
        }
        function handleBoardLogoUpload(input) {
            if (!input.files || !input.files[0]) return;
            let file = input.files[0];
            let reader = new FileReader();
            reader.onload = function(e) {
                let img = new Image();
                img.onload = function() {
                    // v1.5.54: 不裁方! 保留原始比例,只壓縮到合理大小 (max 800x800)
                    let maxDim = 800;
                    let w = img.width, h = img.height;
                    if (w > maxDim || h > maxDim) {
                        if (w > h) { h = h * (maxDim / w); w = maxDim; }
                        else { w = w * (maxDim / h); h = maxDim; }
                    }
                    let canvas = document.createElement('canvas');
                    canvas.width = Math.round(w);
                    canvas.height = Math.round(h);
                    let ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    let dataUrl = canvas.toDataURL('image/jpeg', 0.9);
                    localStorage.setItem(STORAGE_KEY_BOARD_LOGO, dataUrl);
                    // 顯示 size controls
                    document.getElementById('board-logo-preview').style.display = 'block';
                    document.getElementById('board-logo-height').value = '1.2';
                    document.getElementById('board-logo-width').value = '1.2';
                    document.getElementById('board-logo-fit').value = 'cover';
                    document.getElementById('board-logo-lock-ratio').checked = true;
                    document.getElementById('board-logo-width-row').style.display = 'block';
                    updateBoardLogoPreview();
                    loadBoardHeader();
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
        function saveBoardTitle() {
            let t = el('board-title-input').value.trim();
            if(t) localStorage.setItem(STORAGE_KEY_BOARD_TITLE, t);
            loadBoardHeader();
            closeModal('modal-board-settings');
        }
        // v1.5.181: 清理教材庫重複 unit (id 優先, name+start+end 備用, 跨 instance 也 dedup, 涵蓋舊 master 結構)
        // 之前 v1.5.179 只用 id 去重, 但很多 unit 沒有 id 欄位, 導致 dedup 沒生效
        function deduplicateMasterUnits(uid) {
            if (!multiData[uid]) return 0;
            var removed = 0;
            // 計算 unit 的 dedup key: v1.5.183 用 name+start+end (因為 migration 可能給同樣內容不同 id)
            // 若有 id 也加入, 避免不同 instance 內同 name 但不同 id 的 unit 被誤刪
            function unitKey(u) {
                if (!u) return '';
                return 'nse:' + (u.name || '') + ':' + (u.start || '') + ':' + (u.end || '');
            }
            Object.keys(multiData[uid].masters).forEach(function(cat) {
                var catMaster = multiData[uid].masters[cat];
                if (!catMaster) return;
                Object.keys(catMaster).forEach(function(sub) {
                    var s = catMaster[sub];
                    if (!s || !s.materials) return;
                    Object.keys(s.materials).forEach(function(typeName) {
                        var typeObj = s.materials[typeName];
                        if (!typeObj || !Array.isArray(typeObj.instances)) return;
                        // 1. 同一 instance + vol 內 dedup
                        typeObj.instances.forEach(function(ins) {
                            if (!ins || !ins.vols) return;
                            Object.keys(ins.vols).forEach(function(volName) {
                                var arr = ins.vols[volName];
                                if (!Array.isArray(arr) || arr.length < 2) return;
                                var seen = {};
                                var deduped = [];
                                arr.forEach(function(u) {
                                    var key = unitKey(u);
                                    if (!key) { deduped.push(u); return; }
                                    if (seen[key]) { removed++; return; }
                                    seen[key] = true;
                                    deduped.push(u);
                                });
                                if (deduped.length !== arr.length) {
                                    ins.vols[volName] = deduped;
                                }
                            });
                        });
                                            });
                });
            });
            return removed;
        }
        // v1.5.182: 診斷教材庫結構 (auto-dedup 沒效時 trace 用)
        function dedupTrace(uid) {
            if (!multiData[uid]) { console.log('v1.5.182: multiData[' + uid + '] 不存在'); return; }
            var u = multiData[uid];
            console.log('v1.5.182: 教材庫結構 trace for uid=' + uid);
            console.log('  - has masters (new):', !!u.masters, 'type=' + typeof u.masters);
            if (u.masters) {
                Object.keys(u.masters).forEach(function(cat) {
                    Object.keys(u.masters[cat]).forEach(function(sub) {
                        var s = u.masters[cat][sub];
                        if (!s || !s.materials) return;
                        Object.keys(s.materials).forEach(function(typeName) {
                            var typeObj = s.materials[typeName];
                            if (!typeObj || !Array.isArray(typeObj.instances)) return;
                            typeObj.instances.forEach(function(ins) {
                                if (!ins || !ins.vols) return;
                                Object.keys(ins.vols).forEach(function(volName) {
                                    var arr = ins.vols[volName];
                                    if (!Array.isArray(arr) || arr.length < 2) return;
                                    console.log('  - ' + cat + ' / ' + sub + ' / ' + typeName + ' / ' + ins.name + ' / ' + volName + ': ' + arr.length + ' units');
                                    arr.forEach(function(u, i) {
                                        var k = 'nse:' + (u.name||'') + ':' + (u.start||'') + ':' + (u.end||'') + (u.id ? ' [id:'+u.id+']' : '');
                                        console.log('      [' + i + '] key=' + k + ', name=' + u.name);
                                    });
                                });
                            });
                        });
                    });
                });
            }
            console.log('  - has master (old):', !!u.master, 'type=' + typeof u.master);
            if (u.master) {
                Object.keys(u.master).forEach(function(sub) {
                    var s = u.master[sub];
                    if (!s) return;
                    if (s.materials) {
                        Object.keys(s.materials).forEach(function(typeName) {
                            var typeObj = s.materials[typeName];
                            if (!typeObj || !Array.isArray(typeObj.instances)) return;
                            typeObj.instances.forEach(function(ins) {
                                if (!ins || !ins.vols) return;
                                Object.keys(ins.vols).forEach(function(volName) {
                                    var arr = ins.vols[volName];
                                    if (!Array.isArray(arr) || arr.length < 2) return;
                                    console.log('  - (old master) ' + sub + ' / ' + typeName + ' / ' + ins.name + ' / ' + volName + ': ' + arr.length + ' units');
                                });
                            });
                        });
                    }
                });
            }
        }
        // v1.5.181: 同時清理舊的 multiData[uid].master 結構 (v1.5.2 遷移前)
        function deduplicateLegacyMaster(uid) {
            if (!multiData[uid] || !multiData[uid].master) return 0;
            var removed = 0;
            function unitKey(u) {
                if (!u) return '';
                return 'nse:' + (u.name || '') + ':' + (u.start || '') + ':' + (u.end || '');
            }
            var master = multiData[uid].master;
            Object.keys(master).forEach(function(sub) {
                var s = master[sub];
                if (!s) return;
                // s.units (custom)
                if (Array.isArray(s.units)) {
                    var seen = {};
                    var deduped = [];
                    s.units.forEach(function(u) {
                        var key = unitKey(u);
                        if (!key) { deduped.push(u); return; }
                        if (seen[key]) { removed++; return; }
                        seen[key] = true;
                        deduped.push(u);
                    });
                    if (deduped.length !== s.units.length) s.units = deduped;
                }
                // s.vols (volume)
                if (s.vols && typeof s.vols === 'object') {
                    Object.keys(s.vols).forEach(function(volName) {
                        var arr = s.vols[volName];
                        if (!Array.isArray(arr) || arr.length < 2) return;
                        var seen2 = {};
                        var deduped2 = [];
                        arr.forEach(function(u) {
                            var key = unitKey(u);
                            if (!key) { deduped2.push(u); return; }
                            if (seen2[key]) { removed++; return; }
                            seen2[key] = true;
                            deduped2.push(u);
                        });
                        if (deduped2.length !== arr.length) s.vols[volName] = deduped2;
                    });
                }
                // s.reviewMaterials (舊 extra instances)
                if (Array.isArray(s.reviewMaterials)) {
                    s.reviewMaterials.forEach(function(rm) {
                        if (rm && Array.isArray(rm.units)) {
                            var seen3 = {};
                            var deduped3 = [];
                            rm.units.forEach(function(u) {
                                var key = unitKey(u);
                                if (!key) { deduped3.push(u); return; }
                                if (seen3[key]) { removed++; return; }
                                seen3[key] = true;
                                deduped3.push(u);
                            });
                            if (deduped3.length !== rm.units.length) rm.units = deduped3;
                        }
                    });
                }
            });
            return removed;
        }
        function initUsers() {
        // ============================================================
        // v1.5.3: 從備份復原 v1.5.2 搞丟的資料 (硬編碼備份)
        // 備份來源: StudyMap_Backup_2026-07-28.json (張裕宣)
        // 包含 8 個 subject (147 units) + 1 個 plan (159 tasks)
        // ============================================================
        window._v153_BACKUP_MASTER_STR = `{"國文":{"type":"custom","units":[{"id":"id_a337snneu","name":"字音","start":6,"end":24},{"id":"id_khjgzki3t","name":"字形","start":25,"end":40},{"id":"id_k4thkjbgf","name":"字義","start":41,"end":56},{"id":"id_y9c1z8a05","name":"詞語應用","start":57,"end":81},{"id":"id_nlm0dl9is","name":"成語總匯","start":82,"end":98},{"id":"id_ykbtz3clc","name":"標點符號與工具書檢索","start":99,"end":108},{"id":"id_1vpjoar9c","name":"漢字結構與字體演變","start":109,"end":120},{"id":"id_kb4n5f5bx","name":"詞類與句型","start":121,"end":134},{"id":"id_1myxtm72e","name":"應用文（一）","start":135,"end":150},{"id":"id_bmsga8msb","name":"應用文（二）","start":151,"end":166},{"id":"id_5crev4wx3","name":"文化常識","start":167,"end":186},{"id":"id_5l40wzoqg","name":"國學常識","start":187,"end":204},{"id":"id_53wvtcthx","name":"語法辨析","start":205,"end":218},{"id":"id_oyp0q66qs","name":"文章表現技巧","start":219,"end":241},{"id":"id_lioqv9znm","name":"文意填空與重組","start":243,"end":252},{"id":"id_8skr8ws5a","name":"白話文閱讀單題","start":253,"end":271},{"id":"id_796yklvak","name":"文言文閱讀單題","start":273,"end":285},{"id":"id_fpq8cxxak","name":"白話文閱讀題組","start":286,"end":305},{"id":"id_ccdgvje14","name":"文言文閱讀題組","start":306,"end":318},{"id":"id_ajvz8dnbk","name":"多文本對讀","start":319,"end":330},{"id":"id_c4v98ib9n","name":"會考寫作攻略","start":331,"end":341}]},"數學":{"type":"volume","vols":{"第一冊":[{"id":"id_rd22imfzw","name":"數與數線","start":12,"end":25},{"id":"id_kbuj2t97z","name":"標準分解式與分數運算","start":26,"end":38},{"id":"id_38j5anva6","name":"一元一次方程式","start":39,"end":50},{"id":"id_d3nnphewi","name":"二元一次聯立方程式","start":51,"end":62}],"第二冊":[{"id":"id_cflahwntk","name":"直角坐標與二元一次方程式的圖形","start":63,"end":73},{"id":"id_j9qs7yc81","name":"比例","start":74,"end":85},{"id":"id_intrmjsrz","name":"一元一次不等式","start":86,"end":97},{"id":"id_re9n8vw31","name":"線對稱與三視圖","start":98,"end":108},{"id":"id_9gvjstii6","name":"統計圖表與資料分析","start":109,"end":121}],"第三冊":[{"id":"id_xwqqj6om4","name":"乘法公式與多項式","start":127,"end":137},{"id":"id_m6c6f25sh","name":"平方根與畢氏定理","start":138,"end":150},{"id":"id_ds7m7nl0v","name":"因式分解與一元二次方程式","start":151,"end":166}],"第四冊":[{"id":"id_di73i3ib7","name":"數列與級數","start":167,"end":180},{"id":"id_3cwy29hmb","name":"線型函數","start":181,"end":190},{"id":"id_ll4g2dy0g","name":"三角形的基本性質","start":191,"end":207},{"id":"id_ecoi7pm0u","name":"平行與四邊形","start":208,"end":223}],"第五冊":[{"id":"id_4ecyf9hvr","name":"連比與相似形","start":229,"end":247},{"id":"id_n970x8zia","name":"圓形","start":248,"end":263},{"id":"id_qnph51h9u","name":"推理證明與三角形的心","start":264,"end":279}],"第六冊":[{"id":"id_xz2nx2t9v","name":"二次函數","start":280,"end":289},{"id":"id_mnjr1k6la","name":"統計與機率","start":290,"end":302},{"id":"id_0pxqq2pr4","name":"立體圖形","start":303,"end":314}],"模擬試題":[{"id":"id_qpiqnwa4m","name":"第1~2冊","start":122,"end":126},{"id":"id_q30q8hkzw","name":"第1~4冊","start":224,"end":228},{"id":"id_lmmj6b027","name":"第1~6冊","start":315,"end":320}]},"volOrder":["第一冊","第二冊","第三冊","第四冊","第五冊","第六冊","模擬試題"]},"英文":{"type":"volume","vols":{"第一冊":[{"id":"id_7i4r7f2nh","name":"U1","start":6,"end":27},{"id":"id_7j9r8ptwn","name":"U2","start":28,"end":49}],"第二冊":[{"id":"id_cbcii7964","name":"U3","start":50,"end":67},{"id":"id_qh65h8kl0","name":"U4","start":68,"end":87},{"id":"id_6bf0jucd4","name":"U5","start":88,"end":107}],"第1~2冊複習":[{"id":"id_wmze052x3","name":"語法統整與高分策略","start":108,"end":111},{"id":"id_e9mwjaca9","name":"模擬試題","start":112,"end":120}],"第三冊":[{"id":"id_55ro37e9j","name":"U6","start":121,"end":139},{"id":"id_k7cin8f4m","name":"U7","start":140,"end":161}],"第1~3冊複習":[{"id":"id_asbi3lrfw","name":"語法統整與高分策略","start":182,"end":184},{"id":"id_66fv06yn6","name":"模擬試題","start":185,"end":192}],"第四冊":[{"id":"id_6m7m904yl","name":"U9","start":193,"end":209},{"id":"id_rilj7ygio","name":"U10","start":210,"end":231},{"id":"id_ua033optz","name":"U11","start":232,"end":251}],"第1~4冊複習":[{"id":"id_msg0e46ii","name":"語法統整與高分策略","start":252,"end":254},{"id":"id_jni47s7cu","name":"模擬試題","start":255,"end":264}],"第五冊":[{"id":"id_hqi1zhbvr","name":"U12","start":265,"end":285},{"id":"id_t590wuoda","name":"U13","start":286,"end":305},{"id":"id_br039qu0m","name":"U14","start":306,"end":323}],"第1~5冊複習":[{"id":"id_dhr9tf6ew","name":"語法統整與高分策略","start":324,"end":326},{"id":"id_0ecrbvz49","name":"模擬試題","start":327,"end":335}],"第六冊":[{"id":"id_hsxlhyru5","name":"U15","start":336,"end":353},{"id":"id_8q7le6f0f","name":"U16","start":354,"end":371}],"第1~6冊複習":[{"id":"id_lpl11ksgn","name":"語法統整與高分策略","start":372,"end":374},{"id":"id_kyxxealqa","name":"模擬試題","start":375,"end":383}]},"volOrder":["第一冊","第二冊","第1~2冊複習","第三冊","第1~3冊複習","第四冊","第1~4冊複習","第五冊","第1~5冊複習","第六冊","第1~6冊複習"]},"理化":{"type":"volume","vols":{"第三冊":[{"id":"id_k4jlycgxb","name":"進入實驗室與基本測量","start":6,"end":19},{"id":"id_vctyj7xg4","name":"物質的世界","start":20,"end":34},{"id":"id_zc5gknaay","name":"波動與聲音","start":35,"end":49},{"id":"id_fyg8ay28z","name":"光","start":50,"end":69},{"id":"id_mtjtx26i6","name":"溫度與熱","start":70,"end":87},{"id":"id_0jh2c06eg","name":"探索物質組成","start":88,"end":104}],"第四冊":[{"id":"id_kthxmmfaa","name":"化學反應與氧化還原","start":105,"end":119},{"id":"id_rt28z4f2j","name":"電解質及酸鹼反應","start":120,"end":136},{"id":"id_oanu4kmy5","name":"反應速率與平衡","start":137,"end":149},{"id":"id_7svg5tz7t","name":"有機化合物","start":150,"end":164},{"id":"id_kuy7clht7","name":"力與壓力","start":165,"end":184}],"第五冊":[{"id":"id_1sryvtbdw","name":"直線運動","start":185,"end":201},{"id":"id_0ddc8fr13","name":"力與運動","start":202,"end":215},{"id":"id_y01gkb7qs","name":"功與能","start":216,"end":231},{"id":"id_4697y4ylz","name":"基本的靜電現象與電路","start":232,"end":247}],"第六冊":[{"id":"id_f7jzr1atf","name":"電的應用","start":248,"end":266},{"id":"id_gtyhw2854","name":"電流與磁現象","start":267,"end":281},{"id":"id_x6j3monpm","name":"跨科主題","start":282,"end":285}],"模擬會考":[{"id":"id_00254w8is","name":"素養題","start":286,"end":289}]},"volOrder":["第三冊","第四冊","第五冊","第六冊","模擬會考"]},"歷史":{"type":"volume","vols":{"第一二冊":[{"id":"id_vze8f9llk","name":"史前台灣與原住民","start":6,"end":17},{"id":"id_u3an90l3a","name":"大航海時代的台灣","start":18,"end":33},{"id":"id_h0k2n21qx","name":"清帝國治臺時期","start":34,"end":53},{"id":"id_envag7skd","name":"日本治臺時期","start":54,"end":71},{"id":"id_3fkbn9g3d","name":"戰後臺灣","start":72,"end":87}],"第三四冊":[{"id":"id_foxgusium","name":"商周到隋棠","start":92,"end":107},{"id":"id_g2owxjrzg","name":"宋元明清的東亞世界","start":108,"end":127},{"id":"id_f11tjzcp0","name":"西力衝擊下的東亞變革","start":126,"end":141},{"id":"id_myo0h6hre","name":"中華民國的建立與挑戰","start":142,"end":159},{"id":"id_lvxbpl5z7","name":"當代中國與東亞局勢","start":160,"end":174}],"第五六冊":[{"id":"id_madr220fe","name":"多元並立的古代文化","start":180,"end":195},{"id":"id_288a4atoe","name":"普世宗教與近代歐洲興起","start":196,"end":211},{"id":"id_fjj7oyq7p","name":"近代世界的互動與變革","start":212,"end":227},{"id":"id_il5sw751k","name":"現代國家與帝國主義","start":228,"end":243},{"id":"id_s2z78wbuk","name":"世界大戰語戰後局勢","start":244,"end":264}],"會考模擬試題":[{"id":"id_l7hm2v936","name":"1~2冊","start":88,"end":91},{"id":"id_bze1duzz6","name":"1~4冊","start":175,"end":179},{"id":"id_2mxqintp4","name":"1~6冊","start":265,"end":""}]},"volOrder":["第一二冊","第三四冊","第五六冊","會考模擬試題"]},"地理":{"type":"volume","vols":{"第一冊":[{"id":"id_72j6nh5zp","name":"臺灣的位置與影響","start":6,"end":21},{"id":"id_ohjjbjbey","name":"臺灣的地形、海洋與島嶼","start":22,"end":37},{"id":"id_hptsfxhrt","name":"臺灣的氣候與水文","start":38,"end":53}],"第二冊":[{"id":"id_a3d37xlek","name":"臺灣的人口與文化","start":54,"end":67},{"id":"id_ckea281yn","name":"臺灣的產業文化","start":68,"end":81},{"id":"id_km9cyexz8","name":"臺灣的聚落、交通與區域發展","start":82,"end":103}],"第三冊":[{"id":"id_g9h9za29u","name":"中國的自然環境與人口","start":104,"end":119},{"id":"id_zdezq1kcl","name":"中國的產業、經濟","start":120,"end":133},{"id":"id_6as6wpeqc","name":"全球氣候概述與東北亞","start":134,"end":151}],"第四冊":[{"id":"id_hnvam25dm","name":"東南亞、南亞","start":152,"end":163},{"id":"id_5j2e748rr","name":"西亞與北非","start":164,"end":175},{"id":"id_7wbsvu775","name":"漠南非洲","start":176,"end":187}],"第五冊":[{"id":"id_wwt7nhhlg","name":"歐洲與俄羅斯","start":194,"end":207},{"id":"id_26083i8gs","name":"美洲","start":208,"end":221},{"id":"id_663o264e1","name":"大洋洲、兩極地區與氣候變遷","start":222,"end":233}],"第六冊":[{"id":"id_q6x9cie5z","name":"臺灣的地名文化、農業與食品安全","start":234,"end":247}]},"volOrder":["第一冊","第二冊","第三冊","第四冊","第五冊","第六冊"]},"公民":{"type":"volume","vols":{"第一冊":[{"id":"id_qxwkc1kp6","name":"人性尊嚴、性別與家庭","start":5,"end":23},{"id":"id_woigz83jt","name":"學校、社會與部落","start":24,"end":36}],"第二冊":[{"id":"id_5euxpr7mz","name":"公民德性、志願結社與多元文化","start":37,"end":49},{"id":"id_2fgfumg39","name":"社會規範、公平正義與社會福利","start":50,"end":63}],"第三冊":[{"id":"id_gqprujdef","name":"國家、民主與公共意見","start":65,"end":76},{"id":"id_3wyiyxw8f","name":"權力分立與中央政府","start":77,"end":90},{"id":"id_gxxfioc8t","name":"地方政府與政治參與","start":91,"end":104}],"第四冊":[{"id":"id_pp8hc32jh","name":"憲法、民法與刑法","start":106,"end":125},{"id":"id_x4jz8e1rr","name":"民事與刑事糾紛的解決","start":126,"end":139},{"id":"id_p6rwwyc5j","name":"行政法規與兒少法律","start":140,"end":155}],"第五冊":[{"id":"id_h365vub9q","name":"選擇與資源分配","start":160,"end":172},{"id":"id_0mda8y5go","name":"競爭與交易","start":173,"end":181},{"id":"id_qgdw3k587","name":"貨幣與勞動","start":182,"end":191}],"第六冊":[{"id":"id_yv8mu44i3","name":"科技、全球化與國際社會","start":193,"end":205}]},"volOrder":["第一冊","第二冊","第三冊","第四冊","第五冊","第六冊"]},"生物":{"type":"volume","vols":{"第一冊":[{"id":"id_878mko3qo","name":"生命世界","start":6,"end":27},{"id":"id_zpndx1cqw","name":"養分","start":28,"end":48},{"id":"id_0j0yst2u1","name":"生物的運輸與防禦","start":49,"end":71},{"id":"id_r8nz2hhiy","name":"生物的協調作用","start":72,"end":90},{"id":"id_fw10iv9rr","name":"生物的恆定性","start":91,"end":108}],"第二冊":[{"id":"id_u0plxc9og","name":"生殖","start":109,"end":129},{"id":"id_rhbivtrpv","name":"遺傳","start":130,"end":149},{"id":"id_tufaxn71d","name":"地球上的生物","start":150,"end":176},{"id":"id_erfybvg61","name":"生物與環境","start":177,"end":199}]},"volOrder":["第一冊","第二冊"]}}`;
        window._v153_BACKUP_PLANS_STR = `[{"id":"id_769cz6dax","name":"會考複習 - 📦 暑假複習進度","start":"2026-07-17","end":"2026-08-17","grid":{"2026-07-11":[{"id":"id_940enyl8s","subject":"國文","text":"[國文] 字義 P.46~49","startPage":46,"endPage":49,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_k4thkjbgf","vol":"custom","unitName":"字義","postponeCount":0},{"id":"id_lhe2io8hc","subject":"理化","text":"[理化] 波動與聲音 P.43~49","startPage":43,"endPage":49,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_zc5gknaay","vol":"第三冊","unitName":"波動與聲音","postponeCount":0},{"id":"id_1h17bu643","subject":"生物","text":"[生物] 生命世界 P.6~27","startPage":6,"endPage":27,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_878mko3qo","vol":"第一冊","unitName":"生命世界","postponeCount":0}],"2026-07-10":[{"id":"id_39xfj370f","subject":"英文","text":"[🔄 順延] 英文 P.44~49","startPage":44,"endPage":48,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_7j9r8ptwn","vol":"第一冊","unitName":"U2","postponeCount":2},{"id":"id_cr56r4zav","subject":"數學","text":"[數學] 數列與級數 P.167~173","startPage":167,"endPage":173,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_di73i3ib7","vol":"第四冊","unitName":"數列與級數","postponeCount":0},{"id":"id_5j1cld35d","subject":"國文","text":"[國文] 字義 P.42~45","startPage":42,"endPage":45,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_k4thkjbgf","vol":"custom","unitName":"字義","postponeCount":0},{"id":"id_hn990xkuy","subject":"理化","text":"[理化] 波動與聲音 P.35~42","startPage":35,"endPage":42,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_zc5gknaay","vol":"第三冊","unitName":"波動與聲音","postponeCount":0},{"id":"id_s2jy2axb7","subject":"理化","text":"[理化] 波動與聲音 P.35~49","startPage":35,"endPage":49,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_zc5gknaay","vol":"第三冊","unitName":"波動與聲音","postponeCount":0},{"id":"id_n710erfs5","subject":"理化","text":"[理化] 波動與聲音 P.35~45","startPage":35,"endPage":45,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_zc5gknaay","vol":"第三冊","unitName":"波動與聲音","postponeCount":0}],"2026-07-09":[{"id":"id_es3mp675o","subject":"英文","text":"[🔄 順延] 英文 P.39~49","startPage":39,"endPage":43,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_7j9r8ptwn","vol":"第一冊","unitName":"U2","postponeCount":1},{"id":"id_2tuga9rvu","subject":"數學","text":"[數學] 因式分解與一元二次方程式 P.159~166","startPage":159,"endPage":166,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_ds7m7nl0v","vol":"第三冊","unitName":"因式分解與一元二次方程式","postponeCount":0},{"id":"id_63koljf24","subject":"國文","text":"[國文] 字形 P.38~40","startPage":38,"endPage":40,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_khjgzki3t","vol":"custom","unitName":"字形","postponeCount":0},{"id":"id_p4ueg7aki","subject":"國文","text":"[國文] 字義 P.41","startPage":41,"endPage":41,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_k4thkjbgf","vol":"custom","unitName":"字義","postponeCount":0},{"id":"id_9offy09uj","subject":"公民","text":"[公民] 人性尊嚴、性別與家庭 P.10~23","startPage":10,"endPage":23,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_qxwkc1kp6","vol":"第一冊","unitName":"人性尊嚴、性別與家庭","postponeCount":0}],"2026-07-08":[{"id":"id_tobv4nvvn","subject":"數學","text":"[數學] 因式分解與一元二次方程式 P.151~158","startPage":151,"endPage":158,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_ds7m7nl0v","vol":"第三冊","unitName":"因式分解與一元二次方程式","postponeCount":0},{"id":"id_6yerii6wp","subject":"國文","text":"[國文] 字形 P.34~37","startPage":34,"endPage":37,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_khjgzki3t","vol":"custom","unitName":"字形","postponeCount":0},{"id":"id_nyutegl8y","subject":"理化","text":"[理化] 物質的世界 P.27~34","startPage":27,"endPage":34,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_vctyj7xg4","vol":"第三冊","unitName":"物質的世界","postponeCount":0},{"id":"id_esomam15p","subject":"英文","text":"[英文] U2 P.34~49","startPage":34,"endPage":38,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_7j9r8ptwn","vol":"第一冊","unitName":"U2","postponeCount":0},{"id":"id_03hyub2d6","subject":"地理","text":"[地理] 臺灣的地形、海洋與島嶼 P.30~37","startPage":30,"endPage":37,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_ohjjbjbey","vol":"第一冊","unitName":"臺灣的地形、海洋與島嶼","postponeCount":0},{"id":"id_ftaawtj7r","subject":"歷史","text":"[歷史] 大航海時代的台灣 P.29~33","startPage":29,"endPage":33,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_u3an90l3a","vol":"第一二冊","unitName":"大航海時代的台灣","postponeCount":0}],"2026-07-07":[{"id":"id_mtnv5lady","subject":"數學","text":"[數學] 平方根與畢氏定理 P.145~150","startPage":145,"endPage":150,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_m6c6f25sh","vol":"第三冊","unitName":"平方根與畢氏定理","postponeCount":0},{"id":"id_jl0gvbrjf","subject":"國文","text":"[國文] 字形 P.30~33","startPage":30,"endPage":33,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_khjgzki3t","vol":"custom","unitName":"字形","postponeCount":0},{"id":"id_b9s7r4f0h","subject":"理化","text":"[理化] 物質的世界 P.20~26","startPage":20,"endPage":26,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_vctyj7xg4","vol":"第三冊","unitName":"物質的世界","postponeCount":0},{"id":"id_9rsysy85z","subject":"英文","text":"[英文] U2 P.28~33","startPage":29,"endPage":33,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_7j9r8ptwn","vol":"第一冊","unitName":"U2","postponeCount":0},{"id":"id_12rwx3sms","subject":"地理","text":"[地理] 臺灣的地形、海洋與島嶼 P.22~29","startPage":22,"endPage":29,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_ohjjbjbey","vol":"第一冊","unitName":"臺灣的地形、海洋與島嶼","postponeCount":0},{"id":"id_cgo9qt0b5","subject":"歷史","text":"[歷史] 大航海時代的台灣 P.23~28","startPage":23,"endPage":28,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_u3an90l3a","vol":"第一二冊","unitName":"大航海時代的台灣","postponeCount":0}],"2026-07-06":[{"id":"id_hb9lv61qt","subject":"國文","text":"[國文] 字形 P.26~29","startPage":26,"endPage":29,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_khjgzki3t","vol":"custom","unitName":"字形","postponeCount":0},{"id":"id_4z76s8ggs","subject":"數學","text":"[數學] 平方根與畢氏定理 P.138~144","startPage":138,"endPage":144,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_m6c6f25sh","vol":"第三冊","unitName":"平方根與畢氏定理","postponeCount":0},{"id":"id_n7prm6fag","subject":"英文","text":"[英文] U1 P.24~28","startPage":24,"endPage":28,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_7i4r7f2nh","vol":"第一冊","unitName":"U1","postponeCount":0}],"2026-07-04":[{"id":"id_r1ro46mz8","subject":"國文","text":"[國文] 字音 P.22~24","startPage":22,"endPage":24,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_a337snneu","vol":"custom","unitName":"字音","postponeCount":0},{"id":"id_w2uguwbp5","subject":"數學","text":"[數學] 乘法公式與多項式 P.133~137","startPage":133,"endPage":137,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_xwqqj6om4","vol":"第三冊","unitName":"乘法公式與多項式","postponeCount":0},{"id":"id_qg0yevb5g","subject":"國文","text":"[國文] 字形 P.25","startPage":25,"endPage":25,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_khjgzki3t","vol":"custom","unitName":"字形","postponeCount":0}],"2026-07-03":[{"id":"id_19diacrd9","subject":"數學","text":"[數學] 乘法公式與多項式 P.127~132","startPage":127,"endPage":132,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_xwqqj6om4","vol":"第三冊","unitName":"乘法公式與多項式","postponeCount":0},{"id":"id_98im8gz4n","subject":"國文","text":"[國文] 字音 P.18~21","startPage":18,"endPage":21,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_a337snneu","vol":"custom","unitName":"字音","postponeCount":0},{"id":"id_wiunmu5a5","subject":"理化","text":"[理化] 進入實驗室與基本測量 P.15~19","startPage":15,"endPage":19,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_k4jlycgxb","vol":"第三冊","unitName":"進入實驗室與基本測量","postponeCount":0},{"id":"id_1a2h56wad","subject":"地理","text":"[地理] 臺灣的位置與影響 P.18~21","startPage":18,"endPage":21,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_72j6nh5zp","vol":"第一冊","unitName":"臺灣的位置與影響","postponeCount":0},{"id":"id_6fyisqk6p","subject":"歷史","text":"[歷史] 大航海時代的台灣 P.18~22","startPage":18,"endPage":22,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_u3an90l3a","vol":"第一二冊","unitName":"大航海時代的台灣","postponeCount":0},{"id":"id_6j8mf8qyh","subject":"公民","text":"[公民] 人性尊嚴、性別與家庭 P.5~9","startPage":5,"endPage":9,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_qxwkc1kp6","vol":"第一冊","unitName":"人性尊嚴、性別與家庭","postponeCount":0},{"id":"id_f3d02jkhg","subject":"英文","text":"[英文] U1 P.19~23","startPage":19,"endPage":23,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_7i4r7f2nh","vol":"第一冊","unitName":"U1","postponeCount":0}],"2026-07-02":[{"id":"id_udz5spjyb","subject":"國文","text":"[國文] 字音 P.14~17","startPage":14,"endPage":17,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_a337snneu","vol":"custom","unitName":"字音","postponeCount":0},{"id":"id_oh5tsk8pu","subject":"歷史","text":"[歷史] 史前台灣與原住民 P.12~17","startPage":12,"endPage":17,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_vze8f9llk","vol":"第一二冊","unitName":"史前台灣與原住民","postponeCount":0},{"id":"id_hpp30lvbf","subject":"地理","text":"[地理] 臺灣的位置與影響 P.6~17","startPage":6,"endPage":17,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_72j6nh5zp","vol":"第一冊","unitName":"臺灣的位置與影響","postponeCount":0}],"2026-07-01":[{"id":"id_fzlp0f809","subject":"國文","text":"[國文] 字音 P.6~13","startPage":6,"endPage":13,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_a337snneu","vol":"custom","unitName":"字音","postponeCount":0},{"id":"id_y2150sdvf","subject":"理化","text":"[理化] 進入實驗室與基本測量 P.6~14","startPage":6,"endPage":14,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_k4jlycgxb","vol":"第三冊","unitName":"進入實驗室與基本測量","postponeCount":0},{"id":"id_nbomjz3nn","subject":"歷史","text":"[歷史] 史前台灣與原住民 P.6~11","startPage":6,"endPage":11,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_vze8f9llk","vol":"第一二冊","unitName":"史前台灣與原住民","postponeCount":0},{"id":"id_lt2d5cjg9","subject":"數學","text":"[數學] 數與數線 P.12~18","startPage":12,"endPage":18,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_rd22imfzw","vol":"第一冊","unitName":"數與數線","postponeCount":0},{"id":"id_9mznn2caj","subject":"英文","text":"[英文] U1 P.6~18","startPage":6,"endPage":18,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_7i4r7f2nh","vol":"第一冊","unitName":"U1","postponeCount":0}],"2026-07-13":[{"id":"id_vc6xh92qw","subject":"數學","text":"[數學] 數列與級數 P.174~180","startPage":174,"endPage":180,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_di73i3ib7","vol":"第四冊","unitName":"數列與級數","postponeCount":0},{"id":"id_2fqi9z41i","subject":"英文","text":"[🔄 順延] 英文 P.49~49","startPage":49,"endPage":49,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_7j9r8ptwn","vol":"第一冊","unitName":"U2","postponeCount":3},{"id":"id_t74vrj9tv","subject":"英文","text":"[英文] U3 P.50~53","startPage":50,"endPage":53,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_cbcii7964","vol":"第二冊","unitName":"U3","postponeCount":0},{"id":"id_o6phgna7h","subject":"國文","text":"[國文] 字義 P.50~54","startPage":50,"endPage":54,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_k4thkjbgf","vol":"custom","unitName":"字義","postponeCount":0}],"2026-07-21":[{"id":"id_x14tl7hmf","subject":"生物","text":"[生物] 生物的運輸與防禦 P.49~71","startPage":49,"endPage":71,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_0j0yst2u1","vol":"第一冊","unitName":"生物的運輸與防禦","postponeCount":0},{"id":"id_6g4o1kbgm","subject":"數學","text":"[數學] 三角形的基本性質 P.199~202","startPage":199,"endPage":202,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_ll4g2dy0g","vol":"第四冊","unitName":"三角形的基本性質","postponeCount":0}],"2026-07-14":[{"id":"id_75k3g35yd","subject":"數學","text":"[數學] 線型函數 P.181~185","startPage":181,"endPage":185,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_3cwy29hmb","vol":"第四冊","unitName":"線型函數","postponeCount":0},{"id":"id_wgzbu9o05","subject":"地理","text":"[地理] 臺灣的氣候與水文 P.38~45","startPage":38,"endPage":45,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_hptsfxhrt","vol":"第一冊","unitName":"臺灣的氣候與水文","postponeCount":0},{"id":"id_2y7pqsnyq","subject":"歷史","text":"[歷史] 清帝國治臺時期 P.34~43","startPage":34,"endPage":43,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_h0k2n21qx","vol":"第一二冊","unitName":"清帝國治臺時期","postponeCount":0},{"id":"id_wmw07i66h","subject":"英文","text":"[英文] U3 P.54~58","startPage":54,"endPage":58,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_cbcii7964","vol":"第二冊","unitName":"U3","postponeCount":0},{"id":"id_swzzm2qjc","subject":"國文","text":"[國文] 字義 P.55~56","startPage":55,"endPage":56,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_k4thkjbgf","vol":"custom","unitName":"字義","postponeCount":0},{"id":"id_1rc3ktyj8","subject":"國文","text":"[國文] 詞語應用 P.57~59","startPage":57,"endPage":59,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_y9c1z8a05","vol":"custom","unitName":"詞語應用","postponeCount":0},{"id":"id_yv2tj9xtg","subject":"理化","text":"[理化] 光 P.50~59","startPage":50,"endPage":59,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_fyg8ay28z","vol":"第三冊","unitName":"光","postponeCount":0}],"2026-07-22":[{"id":"id_o44hlgokc","subject":"數學","text":"[數學] 三角形的基本性質 P.203~207","startPage":203,"endPage":207,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_ll4g2dy0g","vol":"第四冊","unitName":"三角形的基本性質","postponeCount":1},{"id":"id_ycclvpljk","subject":"理化","text":"[理化] 溫度與熱 P.80~83","startPage":80,"endPage":83,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_mtjtx26i6","vol":"第三冊","unitName":"溫度與熱","postponeCount":0},{"id":"id_ifsrfl3ww","subject":"英文","text":"[英文] U4 P.74~78","startPage":74,"endPage":78,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_qh65h8kl0","vol":"第二冊","unitName":"U4","postponeCount":0}],"2026-07-15":[{"id":"id_ipcxbwn6f","subject":"英文","text":"[英文] U3 P.59~63","startPage":59,"endPage":63,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_cbcii7964","vol":"第二冊","unitName":"U3","postponeCount":1},{"id":"id_aquwaldem","subject":"數學","text":"[數學] 線型函數 P.186~190","startPage":186,"endPage":190,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_3cwy29hmb","vol":"第四冊","unitName":"線型函數","postponeCount":0},{"id":"id_jhg25wozs","subject":"地理","text":"[地理] 臺灣的氣候與水文 P.46~53","startPage":46,"endPage":53,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_hptsfxhrt","vol":"第一冊","unitName":"臺灣的氣候與水文","postponeCount":0},{"id":"id_t2i9o9hel","subject":"歷史","text":"[歷史] 清帝國治臺時期 P.44~53","startPage":44,"endPage":53,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_h0k2n21qx","vol":"第一二冊","unitName":"清帝國治臺時期","postponeCount":0},{"id":"id_63ay0uvhz","subject":"歷史","text":"[歷史] 日本治臺時期 P.54~54","startPage":54,"endPage":54,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0},{"id":"id_yzyojvqol","subject":"國文","text":"[國文] 詞語應用 P.60~63","startPage":60,"endPage":63,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_y9c1z8a05","vol":"custom","unitName":"詞語應用","postponeCount":0},{"id":"id_o293kcapj","subject":"理化","text":"[理化] 光 P.60~69","startPage":60,"endPage":69,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_fyg8ay28z","vol":"第三冊","unitName":"光","postponeCount":0}],"2026-07-16":[{"id":"id_3rh1e4rjj","subject":"英文","text":"[英文] U3 P.64~68","startPage":64,"endPage":68,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_cbcii7964","vol":"第二冊","unitName":"U3","postponeCount":2},{"id":"id_85b5j17fx","subject":"公民","text":"[公民] 學校、社會與部落 P.24~29","startPage":24,"endPage":29,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_woigz83jt","vol":"第一冊","unitName":"學校、社會與部落","postponeCount":0},{"id":"id_3vogutart","subject":"數學","text":"[數學] 數與數線 P.19~25","startPage":19,"endPage":25,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_rd22imfzw","vol":"第一冊","unitName":"數與數線","postponeCount":0},{"id":"id_lwflxcvyw","subject":"理化","text":"[理化] 溫度與熱 P.70~79","startPage":70,"endPage":79,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_mtjtx26i6","vol":"第三冊","unitName":"溫度與熱","postponeCount":0},{"id":"id_vbax32niu","subject":"國文","text":"[國文] 詞語應用 P.64~67","startPage":64,"endPage":67,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_y9c1z8a05","vol":"custom","unitName":"詞語應用","postponeCount":0}],"2026-07-17":[{"id":"id_w3jgg5tih","subject":"公民","text":"[公民] 學校、社會與部落 P.30~36","startPage":30,"endPage":36,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_woigz83jt","vol":"第一冊","unitName":"學校、社會與部落","postponeCount":0},{"id":"id_bvjh4t5d7","subject":"數學","text":"[數學] 三角形的基本性質 P.191~198","startPage":191,"endPage":198,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_ll4g2dy0g","vol":"第四冊","unitName":"三角形的基本性質","postponeCount":0},{"id":"id_6nuz6frhk","subject":"英文","text":"[英文] U4 P.69~73","startPage":69,"endPage":73,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_qh65h8kl0","vol":"第二冊","unitName":"U4","postponeCount":0},{"id":"id_ibsdr6pof","subject":"國文","text":"[國文] 詞語應用 P.68~71","startPage":68,"endPage":71,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_y9c1z8a05","vol":"custom","unitName":"詞語應用","postponeCount":0}],"2026-07-18":[{"id":"id_422sqzz6h","subject":"生物","text":"[生物] 養分 P.28~48","startPage":28,"endPage":48,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_zpndx1cqw","vol":"第一冊","unitName":"養分","postponeCount":0},{"id":"id_arohcaq27","subject":"國文","text":"[國文] 詞語應用 P.72~75","startPage":72,"endPage":75,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_y9c1z8a05","vol":"custom","unitName":"詞語應用","postponeCount":0}],"2026-07-23":[{"id":"id_h9e9yijen","subject":"英文","text":"[英文] U4 P.79~83","startPage":79,"endPage":83,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_qh65h8kl0","vol":"第二冊","unitName":"U4","postponeCount":1},{"id":"id_eqcax55ru","subject":"理化","text":"[理化] 溫度與熱 P.84~87","startPage":84,"endPage":87,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_mtjtx26i6","vol":"第三冊","unitName":"溫度與熱","postponeCount":1},{"id":"id_21agynxta","subject":"國文","text":"[國文] 成語總匯 P.82~83","startPage":82,"endPage":83,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_nlm0dl9is","vol":"","unitName":"成語總匯","postponeCount":0},{"id":"id_bwqpou2m0","subject":"數學","text":"[數學] 標準分解式與分數運算 P.26~28","startPage":26,"endPage":28,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_kbuj2t97z","vol":"第一冊","unitName":"標準分解式與分數運算","postponeCount":0}],"2026-07-24":[{"id":"id_eu5hkq97e","subject":"英文","text":"[英文] U4 P.84~87","startPage":84,"endPage":87,"isDone":true,"cat":"會考複習","mis":"📦 暑假複習進度","unitId":"id_qh65h8kl0","vol":"第二冊","unitName":"U4","postponeCount":2},{"id":"id_ssvatn1bz","subject":"地理","text":"[地理] 臺灣的人口與文化 P.54~56","startPage":54,"endPage":56,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_a3d37xlek","vol":"第二冊","unitName":"臺灣的人口與文化","postponeCount":0},{"id":"id_oucaq6pqj","subject":"公民","text":"[公民] 公民德性、志願結社與多元文化 P.37~39","startPage":37,"endPage":39,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_5euxpr7mz","vol":"第二冊","unitName":"公民德性、志願結社與多元文化","postponeCount":0},{"id":"id_85uwacuvn","subject":"理化","text":"[理化] 探索物質組成 P.88~90","startPage":88,"endPage":90,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_0jh2c06eg","vol":"第三冊","unitName":"探索物質組成","postponeCount":0},{"id":"id_zg78ujz0f","subject":"歷史","text":"[歷史] 日本治臺時期 P.56~58","startPage":56,"endPage":58,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0}],"2026-07-20":[{"id":"id_enl5bbzk7","subject":"國文","text":"[國文] 詞語應用 P.76~81","startPage":76,"endPage":81,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_y9c1z8a05","vol":"custom","unitName":"詞語應用","postponeCount":0}],"2026-07-25":[{"id":"id_7l289mzem","subject":"國文","text":"[國文] 成語總匯 P.84~86","startPage":84,"endPage":86,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_nlm0dl9is","vol":"","unitName":"成語總匯","postponeCount":0},{"id":"id_zl9xzzzgr","subject":"數學","text":"[數學] 標準分解式與分數運算 P.29~32","startPage":29,"endPage":32,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_kbuj2t97z","vol":"第一冊","unitName":"標準分解式與分數運算","postponeCount":0},{"id":"id_5fm4n2l56","subject":"英文","text":"[英文] U5 P.88~94","startPage":88,"endPage":94,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_6bf0jucd4","vol":"第二冊","unitName":"U5","postponeCount":0},{"id":"id_qn0gc3laz","subject":"歷史","text":"[歷史] 日本治臺時期 P.59~63","startPage":59,"endPage":63,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0}],"2026-07-26":[{"id":"id_xtlr86hke","subject":"國文","text":"[國文] 成語總匯 P.87~88","startPage":87,"endPage":88,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_nlm0dl9is","vol":"","unitName":"成語總匯","postponeCount":0,"isAuto":true},{"id":"id_5o26kyvjl","subject":"數學","text":"[數學] [第一冊] 標準分解式與分數運算 P.33~35","startPage":33,"endPage":35,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_kbuj2t97z","vol":"第一冊","unitName":"標準分解式與分數運算","postponeCount":0,"isAuto":true},{"id":"id_bk4eyo8bg","subject":"英文","text":"[英文] [第二冊] U5 P.95~98","startPage":95,"endPage":98,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_6bf0jucd4","vol":"第二冊","unitName":"U5","postponeCount":0,"isAuto":true},{"id":"id_bk4eyo8bg","subject":"英文","text":"[英文] [第二冊] U5 P.95~98","startPage":95,"endPage":98,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_6bf0jucd4","vol":"第二冊","unitName":"U5","postponeCount":0,"isAuto":true},{"id":"id_nmpegpu2k","subject":"歷史","text":"[歷史] [第一二冊] 日本治臺時期 P.64~65","startPage":64,"endPage":65,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0,"isAuto":true},{"id":"id_vgdg36tod","subject":"地理","text":"[地理] [第二冊] 臺灣的人口與文化 P.57~58","startPage":57,"endPage":58,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_a3d37xlek","vol":"第二冊","unitName":"臺灣的人口與文化","postponeCount":0,"isAuto":true},{"id":"id_wer33ref2","subject":"公民","text":"[公民] [第二冊] 公民德性、志願結社與多元文化 P.40~41","startPage":40,"endPage":41,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_5euxpr7mz","vol":"第二冊","unitName":"公民德性、志願結社與多元文化","postponeCount":0,"isAuto":true}],"2026-07-27":[{"id":"id_7ztxwdpv5","subject":"理化","text":"[理化] [第三冊] 探索物質組成 P.91~92","startPage":91,"endPage":92,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_0jh2c06eg","vol":"第三冊","unitName":"探索物質組成","postponeCount":0,"isAuto":true},{"id":"id_otqusjvmu","subject":"生物","text":"[生物] [第一冊] 生物的協調作用 P.72~74","startPage":72,"endPage":74,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_r8nz2hhiy","vol":"第一冊","unitName":"生物的協調作用","postponeCount":0,"isAuto":true},{"id":"id_mewy68n33","subject":"國文","text":"[國文] 成語總匯 P.89","startPage":89,"endPage":89,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_nlm0dl9is","vol":"","unitName":"成語總匯","postponeCount":0,"isAuto":true},{"id":"id_s58gup47j","subject":"數學","text":"[數學] [第一冊] 標準分解式與分數運算 P.36~38","startPage":36,"endPage":38,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_kbuj2t97z","vol":"第一冊","unitName":"標準分解式與多項式","postponeCount":0,"isAuto":true},{"id":"id_ombn4xca4","subject":"英文","text":"[英文] [第二冊] U5 P.99~103","startPage":99,"endPage":103,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_6bf0jucd4","vol":"第二冊","unitName":"U5","postponeCount":0,"isAuto":true},{"id":"id_1im5lwphy","subject":"歷史","text":"[歷史] [第一二冊] 日本治臺時期 P.66","startPage":66,"endPage":66,"isDone":true,"cat":"會考複習","mis":"📚 一模","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0,"isAuto":true}],"2026-07-28":[{"id":"id_6soptxiy1","subject":"地理","text":"[地理] [第二冊] 臺灣的人口與文化 P.59~63","startPage":59,"endPage":63,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_a3d37xlek","vol":"第二冊","unitName":"臺灣的人口與文化","postponeCount":0,"isAuto":true},{"id":"id_9y3zk7mva","subject":"公民","text":"[公民] [第二冊] 公民德性、志願結社與多元文化 P.42~45","startPage":42,"endPage":45,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_5euxpr7mz","vol":"第二冊","unitName":"公民德性、志願結社與多元文化","postponeCount":0,"isAuto":true},{"id":"id_74sptj56s","subject":"理化","text":"[理化] [第三冊] 探索物質組成 P.93~97","startPage":93,"endPage":97,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_0jh2c06eg","vol":"第三冊","unitName":"探索物質組成","postponeCount":0,"isAuto":true},{"id":"id_fbslyjtfb","subject":"生物","text":"[生物] [第一冊] 生物的協調作用 P.75~77","startPage":75,"endPage":77,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_r8nz2hhiy","vol":"第一冊","unitName":"生物的協調作用","postponeCount":0,"isAuto":true},{"id":"id_gv4cn8n3h","subject":"國文","text":"[國文] 成語總匯 P.90~91","startPage":90,"endPage":91,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_nlm0dl9is","vol":"","unitName":"成語總匯","postponeCount":0,"isAuto":true},{"id":"id_nj1sdeeaf","subject":"英文","text":"[英文] [第二冊] U5 P.104~107","startPage":104,"endPage":107,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_6bf0jucd4","vol":"第二冊","unitName":"U5","postponeCount":0,"isAuto":true},{"id":"id_594cv0xwz","subject":"歷史","text":"[歷史] [第一二冊] 日本治臺時期 P.67~68","startPage":67,"endPage":68,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0,"isAuto":true},{"id":"id_oycxdfxle","subject":"數學","text":"[數學] [第一冊] 一元一次方程式 P.39~42","startPage":39,"endPage":42,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_38j5anva6","vol":"第一冊","unitName":"一元一次方程式","postponeCount":0,"isAuto":true}],"2026-07-29":[{"id":"id_p10xxys2h","subject":"生物","text":"[生物] [第一冊] 生物的協調作用 P.78~84","startPage":78,"endPage":84,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_r8nz2hhiy","vol":"第一冊","unitName":"生物的協調作用","postponeCount":0,"isAuto":true},{"id":"id_phhehw99s","subject":"國文","text":"[國文] 成語總匯 P.92~95","startPage":92,"endPage":95,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_nlm0dl9is","vol":"","unitName":"成語總匯","postponeCount":0,"isAuto":true},{"id":"id_qzvb841n4","subject":"英文","text":"[英文] [第1~2冊複習] 語法統整與高分策略 P.108","startPage":108,"endPage":108,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_wmze052x3","vol":"第1~2冊複習","unitName":"語法統整與高分策略","postponeCount":0,"isAuto":true},{"id":"id_0i2n5odyd","subject":"歷史","text":"[歷史] [第一二冊] 日本治臺時期 P.69","startPage":69,"endPage":69,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0,"isAuto":true},{"id":"id_6tjc3ow6u","subject":"地理","text":"[地理] [第二冊] 臺灣的人口與文化 P.64~65","startPage":64,"endPage":65,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_a3d37xlek","vol":"第二冊","unitName":"臺灣的人口與文化","postponeCount":0,"isAuto":true},{"id":"id_uw1vt838f","subject":"公民","text":"[公民] [第二冊] 公民德性、志願結社與多元文化 P.46~47","startPage":46,"endPage":47,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_5euxpr7mz","vol":"第二冊","unitName":"公民德性、志願結社與多元文化","postponeCount":0,"isAuto":true},{"id":"id_p84w1y27n","subject":"理化","text":"[理化] [第三冊] 探索物質組成 P.98~99","startPage":98,"endPage":99,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_0jh2c06eg","vol":"第三冊","unitName":"探索物質組成","postponeCount":0,"isAuto":true},{"id":"id_idpmjdyvp","subject":"數學","text":"[數學] [第一冊] 一元一次方程式 P.43~48","startPage":43,"endPage":48,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_38j5anva6","vol":"第一冊","unitName":"一元一次方程式","postponeCount":0,"isAuto":true}],"2026-07-30":[{"id":"id_b4xafvodn","subject":"英文","text":"[英文] [第1~2冊複習] 語法統整與高分策略 P.109~110","startPage":109,"endPage":110,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_wmze052x3","vol":"第1~2冊複習","unitName":"語法統整與高分策略","postponeCount":0,"isAuto":true},{"id":"id_p83s1hy6i","subject":"歷史","text":"[歷史] [第一二冊] 日本治臺時期 P.70~71","startPage":70,"endPage":71,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_envag7skd","vol":"第一二冊","unitName":"日本治臺時期","postponeCount":0,"isAuto":true},{"id":"id_d6cwdogp4","subject":"地理","text":"[地理] [第二冊] 臺灣的人口與文化 P.66~67","startPage":66,"endPage":67,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_a3d37xlek","vol":"第二冊","unitName":"臺灣的人口與文化","postponeCount":0,"isAuto":true},{"id":"id_qgcp3doy7","subject":"公民","text":"[公民] [第二冊] 公民德性、志願結社與多元文化 P.48~49","startPage":48,"endPage":49,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_5euxpr7mz","vol":"第二冊","unitName":"公民德性、志願結社與多元文化","postponeCount":0,"isAuto":true},{"id":"id_ewr1xs5hr","subject":"理化","text":"[理化] [第三冊] 探索物質組成 P.100~102","startPage":100,"endPage":102,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_0jh2c06eg","vol":"第三冊","unitName":"探索物質組成","postponeCount":0,"isAuto":true},{"id":"id_v4fu0cj3k","subject":"生物","text":"[生物] [第一冊] 生物的協調作用 P.85~87","startPage":85,"endPage":87,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_r8nz2hhiy","vol":"第一冊","unitName":"生物的協調作用","postponeCount":0,"isAuto":true},{"id":"id_v3a8yn5nv","subject":"數學","text":"[數學] [第一冊] 一元一次方程式 P.49~50","startPage":49,"endPage":50,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_38j5anva6","vol":"第一冊","unitName":"一元一次方程式","postponeCount":0,"isAuto":true}],"2026-07-31":[{"id":"id_7un9xgwwy","subject":"國文","text":"[國文] 成語總匯 P.96~98","startPage":96,"endPage":98,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_nlm0dl9is","vol":"","unitName":"成語總匯","postponeCount":0,"isAuto":true},{"id":"id_fe8w8585d","subject":"英文","text":"[英文] [第1~2冊複習] 語法統整與高分策略 P.111","startPage":111,"endPage":111,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_wmze052x3","vol":"第1~2冊複習","unitName":"語法統整與高分策略","postponeCount":0,"isAuto":true},{"id":"id_fobiplz9n","subject":"英文","text":"[英文] [第1~2冊複習] 模擬試題 P.112~114","startPage":112,"endPage":114,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_e9mwjaca9","vol":"第1~2冊複習","unitName":"模擬試題","postponeCount":0,"isAuto":true},{"id":"id_nz9x64em6","subject":"歷史","text":"[歷史] [第一二冊] 戰後臺灣 P.72~74","startPage":72,"endPage":74,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_3fkbn9g3d","vol":"第一二冊","unitName":"戰後臺灣","postponeCount":0,"isAuto":true},{"id":"id_qzpgojwf3","subject":"地理","text":"[地理] [第二冊] 臺灣的產業文化 P.68~70","startPage":68,"endPage":70,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_ckea281yn","vol":"第二冊","unitName":"臺灣的產業文化","postponeCount":0,"isAuto":true},{"id":"id_lszinli8q","subject":"公民","text":"[公民] [第二冊] 社會規範、公平正義與社會福利 P.50~52","startPage":50,"endPage":52,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_2fgfumg39","vol":"第二冊","unitName":"社會規範、公平正義與社會福利","postponeCount":0,"isAuto":true},{"id":"id_l5crtzp6y","subject":"理化","text":"[理化] [第三冊] 探索物質組成 P.103~104","startPage":103,"endPage":104,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_0jh2c06eg","vol":"第三冊","unitName":"探索物質組成","postponeCount":0,"isAuto":true},{"id":"id_tml9ad3t3","subject":"生物","text":"[生物] [第一冊] 生物的協調作用 P.88~90","startPage":88,"endPage":90,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_r8nz2hhiy","vol":"第一冊","unitName":"生物的協調作用","postponeCount":0,"isAuto":true},{"id":"id_0thzt159x","subject":"數學","text":"[數學] [第一冊] 二元一次聯立方程式 P.51~56","startPage":51,"endPage":56,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_d3nnphewi","vol":"第一冊","unitName":"二元一次聯立方程式","postponeCount":0,"isAuto":true}],"2026-08-01":[{"id":"id_08f3mzst1","subject":"歷史","text":"[歷史] [第一二冊] 戰後臺灣 P.75~77","startPage":75,"endPage":77,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_3fkbn9g3d","vol":"第一二冊","unitName":"戰後臺灣","postponeCount":0,"isAuto":true},{"id":"id_2ll7xvvr9","subject":"地理","text":"[地理] [第二冊] 臺灣的產業文化 P.71~73","startPage":71,"endPage":73,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_ckea281yn","vol":"第二冊","unitName":"臺灣的產業文化","postponeCount":0,"isAuto":true},{"id":"id_5shs3kps6","subject":"公民","text":"[公民] [第二冊] 社會規範、公平正義與社會福利 P.53~55","startPage":53,"endPage":55,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_2fgfumg39","vol":"第二冊","unitName":"社會規範、公平正義與社會福利","postponeCount":0,"isAuto":true},{"id":"id_rmamqzn4i","subject":"生物","text":"[生物] [第一冊] 生物的恆定性 P.91~93","startPage":91,"endPage":93,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_fw10iv9rr","vol":"第一冊","unitName":"生物的恆定性","postponeCount":0,"isAuto":true},{"id":"id_thkx22ry8","subject":"國文","text":"[國文] 白話文閱讀題組 P.286~288","startPage":286,"endPage":288,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_fpq8cxxak","vol":"","unitName":"白話文閱讀題組","postponeCount":0,"isAuto":true},{"id":"id_81zym6vzz","subject":"數學","text":"[數學] [第一冊] 二元一次聯立方程式 P.57~62","startPage":57,"endPage":62,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_d3nnphewi","vol":"第一冊","unitName":"二元一次聯立方程式","postponeCount":0,"isAuto":true}],"2026-08-02":[{"id":"id_4bpl11o9i","subject":"英文","text":"[英文] [第1~2冊複習] 模擬試題 P.115~117","startPage":115,"endPage":117,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_e9mwjaca9","vol":"第1~2冊複習","unitName":"模擬試題","postponeCount":0,"isAuto":true},{"id":"id_nlwxpsfr4","subject":"歷史","text":"[歷史] [第一二冊] 戰後臺灣 P.78~81","startPage":78,"endPage":81,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_3fkbn9g3d","vol":"第一二冊","unitName":"戰後臺灣","postponeCount":0,"isAuto":true},{"id":"id_oaj96hry6","subject":"地理","text":"[地理] [第二冊] 臺灣的產業文化 P.74~75","startPage":74,"endPage":75,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_ckea281yn","vol":"第二冊","unitName":"臺灣的產業文化","postponeCount":0,"isAuto":true},{"id":"id_vnwyhngz1","subject":"公民","text":"[公民] [第二冊] 社會規範、公平正義與社會福利 P.56~57","startPage":56,"endPage":57,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_2fgfumg39","vol":"第二冊","unitName":"社會規範、公平正義與社會福利","postponeCount":0,"isAuto":true},{"id":"id_yj40q8aap","subject":"生物","text":"[生物] [第一冊] 生物的恆定性 P.94~96","startPage":94,"endPage":96,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_fw10iv9rr","vol":"第一冊","unitName":"生物的恆定性","postponeCount":0,"isAuto":true},{"id":"id_soxa59hqs","subject":"國文","text":"[國文] 白話文閱讀題組 P.289~291","startPage":289,"endPage":291,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_fpq8cxxak","vol":"","unitName":"白話文閱讀題組","postponeCount":0,"isAuto":true},{"id":"id_1kaqvwv48","subject":"數學","text":"[數學] [第二冊] 直角坐標與二元一次方程式的圖形 P.63~68","startPage":63,"endPage":68,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_cflahwntk","vol":"第二冊","unitName":"直角坐標與二元一次方程式的圖形","postponeCount":0,"isAuto":true}],"2026-08-03":[{"id":"id_ob0a3ga6k","subject":"英文","text":"[英文] [第1~2冊複習] 模擬試題 P.118~120","startPage":118,"endPage":120,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_e9mwjaca9","vol":"第11~2冊複習","unitName":"模擬試題","postponeCount":0,"isAuto":true},{"id":"id_38o0r8ggb","subject":"歷史","text":"[歷史] [第一二冊] 戰後臺灣 P.82~84","startPage":82,"endPage":84,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_3fkbn9g3d","vol":"第一二冊","unitName":"戰後臺灣","postponeCount":0,"isAuto":true},{"id":"id_qstxi4xnz","subject":"地理","text":"[地理] [第二冊] 臺灣的產業文化 P.76~78","startPage":76,"endPage":78,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_ckea281yn","vol":"第二冊","unitName":"臺灣的產業文化","postponeCount":0,"isAuto":true},{"id":"id_jtm8m3v6c","subject":"公民","text":"[公民] [第二冊] 社會規範、公平正義與社會福利 P.58~60","startPage":58,"endPage":60,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_2fgfumg39","vol":"第二冊","unitName":"社會規範、公平正義與社會福利","postponeCount":0,"isAuto":true},{"id":"id_rzkaudtun","subject":"生物","text":"[生物] [第一冊] 生物的恆定性 P.97~99","startPage":97,"endPage":99,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_fw10iv9rr","vol":"第一冊","unitName":"生物的恆定性","postponeCount":0,"isAuto":true},{"id":"id_3j5c30wma","subject":"數學","text":"[數學] [第二冊] 直角坐標與二元一次方程式的圖形 P.69~72","startPage":69,"endPage":72,"isDone":false,"cat":"會考複習","mis":"📚 一模","unitId":"id_cflahwntk","vol":"第二冊","unitName":"直角坐標與二元一次方程式的圖形","postponeCount":0,"isAuto":true}]}}]`;
        function _v153RestoreFromBackup(uid) {
            if (!multiData[uid]) return;
            var user = multiData[uid];
            // 只在 master 是空的時候才復原 (避免覆蓋現有資料)
            var masterEmpty = !user.master || (typeof user.master === 'object' && Object.keys(user.master).length === 0);
            var plansEmpty = !user.plans || (Array.isArray(user.plans) && user.plans.length === 0);
            if (masterEmpty || plansEmpty) {
                try {
                    if (masterEmpty && window._v153_BACKUP_MASTER_STR) {
                        user.master = JSON.parse(window._v153_BACKUP_MASTER_STR);
                        console.log('v1.5.3: ✅ 從備份復原 master (' + Object.keys(user.master).length + ' 個 subject)');
                    }
                    if (plansEmpty && window._v153_BACKUP_PLANS_STR) {
                        var backupPlans = JSON.parse(window._v153_BACKUP_PLANS_STR);
                        if (!Array.isArray(user.plans)) user.plans = [];
                        backupPlans.forEach(function(p) {
                            user.plans.push(p);
                        });
                        console.log('v1.5.3: ✅ 從備份復原 plans (' + user.plans.length + ' 個 plan)');
                    }
                } catch(e) {
                    console.error('v1.5.3: ❌ 備份復原失敗:', e);
                }
            }
        }
        // ============================================================
        // v1.5.4: 加地科 subject + mission rename + 從 plans 重建 appMissions
        // ============================================================
        function _v154Migrate(uid) {
            var user = multiData[uid];
            if (!user) return;
            // 1. 加「地科」subject (空的) - v1.5.8 改寫到 masters[會考複習]
            if (user.masters && user.masters['會考複習'] && !user.masters['會考複習']['地科']) {
                user.masters['會考複習']['地科'] = {
                    materials: {
                        '複習講義': { id: 'mt_' + genId(), name: '複習講義', instances: [] },
                        '複習卷': { id: 'mt_' + genId(), name: '複習卷', instances: [] },
                        '數字題本': { id: 'mt_' + genId(), name: '數字題本', instances: [] },
                        '模擬題本': { id: 'mt_' + genId(), name: '模擬題本', instances: [] },
                        '考古題': { id: 'mt_' + genId(), name: '考古題', instances: [] }
                    }
                };
                console.log('v1.5.4: ✅ 加了「地科」subject (空的, 9 個 subject 總計)');
            }
            // 2. Rename missions in plans (📚 一模 → 一模, 📦 暑假複習進度 → 二模)
            var renameCount = 0;
            (user.plans || []).forEach(function(plan) {
                Object.keys(plan.grid || {}).forEach(function(dStr) {
                    (plan.grid[dStr] || []).forEach(function(t) {
                        if (t.mis === '📚 一模') {
                            t.mis = '一模';
                            renameCount++;
                        } else if (t.mis === '📦 暑假複習進度') {
                            t.mis = '二模';
                            renameCount++;
                        }
                    });
                });
            });
            if (renameCount > 0) {
                console.log('v1.5.4: ✅ 改名 ' + renameCount + ' 個 task 的 mission');
            }
            // 3. 從 plans 重建 user.missions (appMissions)
            // v1.5.20: ⚠️ 修正 — 之前 每次 init 都覆蓋 user.missions, 連「tab 2 勾選」 的 資料 都 丟 失
            // 修正為 merge: 保留 既有 user.missions, 再 從 plans 補 上 (去重)
            var rebuilt = {};
            (user.plans || []).forEach(function(plan) {
                Object.keys(plan.grid || {}).forEach(function(dStr) {
                    (plan.grid[dStr] || []).forEach(function(t) {
                        if (!t.cat || !t.mis || !t.unitId) return;
                        if (!rebuilt[t.cat]) rebuilt[t.cat] = {};
                        if (!rebuilt[t.cat][t.mis]) rebuilt[t.cat][t.mis] = [];
                        if (rebuilt[t.cat][t.mis].indexOf(t.unitId) === -1) {
                            rebuilt[t.cat][t.mis].push(t.unitId);
                        }
                    });
                });
            });
            // 4. 確保 missions 結構有 會考複習 + 段考複習 categories
            if (!rebuilt['會考複習']) rebuilt['會考複習'] = {};
            if (!rebuilt['會考複習']['一模']) rebuilt['會考複習']['一模'] = [];
            if (!rebuilt['會考複習']['二模']) rebuilt['會考複習']['二模'] = [];
            if (!rebuilt['段考複習']) rebuilt['段考複習'] = {};
            // v1.5.20: merge 既有 user.missions, 不覆蓋
            var existingMissions = user.missions || {};
            user.missions = rebuilt;
            var mergedCount = 0;
            Object.keys(existingMissions).forEach(function(cat) {
                if (!user.missions[cat]) user.missions[cat] = {};
                Object.keys(existingMissions[cat]).forEach(function(mis) {
                    if (!user.missions[cat][mis]) {
                        user.missions[cat][mis] = existingMissions[cat][mis].slice();
                    } else {
                        existingMissions[cat][mis].forEach(function(uid) {
                            if (user.missions[cat][mis].indexOf(uid) === -1) {
                                user.missions[cat][mis].push(uid);
                                mergedCount++;
                            }
                        });
                    }
                });
            });
            if (mergedCount > 0) {
                console.log('v1.5.20: ✅ merge ' + mergedCount + ' 個 tab 2 勾選的 unit ID (從 plans 推 不出 來 的)');
            }
            console.log('v1.5.20: ✅ 重建 missions (' + Object.keys(rebuilt).length + ' categories)');
            Object.keys(rebuilt).forEach(function(cat) {
                var misNames = Object.keys(rebuilt[cat]);
                var totalUnitIds = misNames.reduce(function(s, m) { return s + rebuilt[cat][m].length; }, 0);
                console.log('  - ' + cat + ': ' + misNames.length + ' missions (' + totalUnitIds + ' unitIds total)');
                misNames.forEach(function(m) {
                    console.log('    • ' + m + ': ' + rebuilt[cat][m].length + ' units');
                });
            });
        }
        // v1.5.8: migrate - 進度大分類 (Category) 獨立教材庫
        // 從舊結構 master → masters[cat]
        // 現有 8 個 subject (v1.5.3 從備份復原) 全部是會考複習 mission 用的, 搬到 masters[會考複習]
        // 加 masters[段考複習] = {} 空殻 (等 Denias 自己建)
        function _v158Migrate(uid) {
            var user = multiData[uid];
            if (!user) return;
            // 1. 如果有 master 但沒有 masters → migrate
            if (user.master && !user.masters) {
                console.log('v1.5.8: 檢測到舊 master 結構, 開始 migrate 到 masters[cat]');
                user.masters = {
                    '會考複習': user.master
                };
                delete user.master;
                console.log('v1.5.8: ✅ 舊 master (含 ' + Object.keys(user.masters['會考複習']).length + ' 個 subject) 搬到 masters[會考複習]');
            }
            // 2. 確保 masters 存在
            if (!user.masters) user.masters = {};
            // 3. 從 missions keys 補上可能缺的 cat (例如 Denias 之後手動加 mission)
            if (user.missions) {
                Object.keys(user.missions).forEach(function(cat) {
                    if (!user.masters[cat]) {
                        user.masters[cat] = {};
                        console.log('v1.5.8: 補上 masters[' + cat + '] = {} (空的)');
                    }
                });
            }
            // 4. 確保兩個預設 cat 都存在
            if (!user.masters['會考複習']) user.masters['會考複習'] = {};
            if (!user.masters['段考複習']) user.masters['段考複習'] = {};
            // v1.5.11: 為「段考複習」自動建 8 個 default 科目 (Denias 16:02 要求, 不要 confirm dialog)
            if (Object.keys(user.masters['段考複習']).length === 0 && !user._v1511_default_added) {
                var defaults = ['國文','數學','英文','歷史','地理','公民','理化','地科'];
                defaults.forEach(function(subName) {
                    user.masters['段考複習'][subName] = { materials: {} };
                });
                user._v1511_default_added = true;
                console.log('v1.5.11: 為「段考複習」自動建了 ' + defaults.length + ' 個 default subjects');
            }
            console.log('v1.5.8: ✅ migrate 完成, masters cats = [' + Object.keys(user.masters).join(', ') + ']');
            Object.keys(user.masters).forEach(function(cat) {
                console.log('  - ' + cat + ': ' + Object.keys(user.masters[cat]).length + ' 個 subject');
            });
        }
        // v1.5.29: 同步 plan.grid 裡 task.mis 跟 log.mission
        // 原因: 之前任務排序/重排順延後，task 的頁數範圍可能跟原始 log 對不上
        // 先試嚴格比對 (startPage/endPage 完全相等)，再寬鬆比對 (頁數重疊)
        function _v1529Migrate(uid) {
            var user = multiData[uid];
            if (!user) return;
            if (user._v1529_plan_grid_mis_synced) return; // 確保只跑一次
            var updated = 0;
            (user.plans || []).forEach(function(plan){
                Object.keys(plan.grid || {}).forEach(function(dStr){
                    (plan.grid[dStr] || []).forEach(function(t){
                        if (!t.unitId || !t.subject || !t.mis) return;
                        // 找對應日期/單元的 log
                        var logs = (user.logs || []).filter(function(l){
                            return l.unitId === t.unitId && l.subject === t.subject;
                        });
                        var matchLog = null;
                        // 先試嚴格比對 (頁數完全相等)
                        for (var i = 0; i < logs.length; i++) {
                            if (Number(logs[i].start) === Number(t.startPage) && Number(logs[i].end) === Number(t.endPage)) {
                                matchLog = logs[i]; break;
                            }
                        }
                        // 寬鬆比對 (頁數重疊) - 用於順延任務
                        if (!matchLog) {
                            for (var j = 0; j < logs.length; j++) {
                                if (Number(logs[j].end) >= Number(t.startPage) && Number(logs[j].start) <= Number(t.endPage)) {
                                    matchLog = logs[j]; break;
                                }
                            }
                        }
                        if (matchLog && matchLog.mission && matchLog.mission !== t.mis) {
                            console.log('v1.5.29: ' + t.unitName + ' P.' + t.startPage + '~' + t.endPage + ' | ' + t.mis + ' → ' + matchLog.mission);
                            t.mis = matchLog.mission;
                            updated++;
                        }
                    });
                });
            });
            user._v1529_plan_grid_mis_synced = true;
            if (updated > 0) {
                console.log('v1.5.29: ✅ 同步 ' + updated + ' 筆 task.mis 跟 log.mission');
            } else {
                console.log('v1.5.29: ✅ task.mis 已跟 log.mission 同步，無需更新');
            }
        }
        // v1.5.34: 統一教材類型順序為 defaultTypes 順序 (複習講義 → 複習卷 → 數字題本 → 模擬題本 → 考古題)
function _v1534Migrate(uid) {
            var user = multiData[uid];
            if (!user) return;
            if (user._v1534_type_order_fixed) return;
            var defaultOrder = ['複習講義','複習卷','數字題本','模擬題本','考古題'];
            var fixed = 0;
            function fixCat(catObj) {
                if (!catObj) return;
                Object.keys(catObj).forEach(function(subName){
                    var subj = catObj[subName];
                    if (!subj || !subj.materials) return;
                    var mats = subj.materials;
                    var ordered = {};
                    // 先按 defaultOrder 加
                    defaultOrder.forEach(function(t){
                        if (mats[t]) ordered[t] = mats[t];
                    });
                    // 再加自訂類型 (不在 defaultOrder)
                    Object.keys(mats).forEach(function(t){
                        if (defaultOrder.indexOf(t) === -1) ordered[t] = mats[t];
                    });
                    if (JSON.stringify(Object.keys(mats)) !== JSON.stringify(Object.keys(ordered))) {
                        subj.materials = ordered;
                        fixed++;
                    }
                });
            }
            if (user.masters) {
                Object.keys(user.masters).forEach(function(catName){
                    fixCat(user.masters[catName]);
                });
            }
            user._v1534_type_order_fixed = true;
            if (fixed > 0) {
                console.log('v1.5.34: ✅ 統一了 ' + fixed + ' 個 subject 的教材類型順序');
            } else {
                console.log('v1.5.34: ✅ 所有教材類型順序皆已統一，無需修正');
            }
        }
        // v1.5.144: Migration - 為現有 material type 加 unitBased flag + 為 instance 加 alias
        (function migrateUnitBasedAndAlias() {
            const unitBasedTypes = { '複習卷': true, '數字題本': true, '模擬題本': true, '考古題': true };
            let fixedType = 0, fixedAlias = 0;
            if (!multiData || !multiData.students) return;
            multiData.students.forEach(function(stu) {
                if (!stu.masters) return;
                stu.masters.forEach(function(subj) {
                    if (!subj.materials) return;
                    Object.keys(subj.materials).forEach(function(typeName) {
                        const typeObj = subj.materials[typeName];
                        if (typeof typeObj.unitBased === 'undefined') {
                            typeObj.unitBased = unitBasedTypes[typeName] || false;
                            fixedType++;
                        }
                        if (!typeObj.instances) return;
                        typeObj.instances.forEach(function(ins) {
                            if (typeof ins.alias === 'undefined' && ins.name) {
                                ins.alias = ins.name.charAt(0);
                                fixedAlias++;
                            }
                        });
                    });
                });
            });
            if (fixedType > 0 || fixedAlias > 0) {
                saveToLocal();
                console.log('v1.5.144: 補上 ' + fixedType + ' 個 type 的 unitBased, ' + fixedAlias + ' 個 instance 的 alias');
            } else {
                console.log('v1.5.144: ✅ 所有 type 已有 unitBased, 所有 instance 已有 alias');
            }
        })();
loadBoardHeader();
            var currentDataStr = localStorage.getItem(STORAGE_KEY_FAMILY);
            if (currentDataStr) {
                try {
                    multiData = JSON.parse(currentDataStr);
                } catch (parseErr) {
                    // v1.4.12: JSON parse 失敗 — 不要 mask 整個 app, 給詳細訊息
                    console.error("JSON 解析失敗:", parseErr);
                    console.error("原始資料 (前 500 字):", currentDataStr.substring(0, 500));
                    var backupKey = STORAGE_KEY_FAMILY + '_backup_' + Date.now();
                    localStorage.setItem(backupKey, currentDataStr);
                    alert("⚠️ 資料檔案毀損！\n\n已自動備份到:\n" + backupKey + "\n\n將以空白資料重新開始。舊資料可手動從 localStorage 復原。\n\n錯誤訊息: " + parseErr.message);
                    multiData = { "user_A": { name: "學生 A", master: {}, missions: {}, logs: [], plans: [], avatar: "" } };
                }
            } else {
                multiData = { "user_A": { name: "學生 A", master: {}, missions: {}, logs: [], plans: [], avatar: "" } };
            }
            try {
                Object.keys(multiData).forEach(uid => {
                    if (!multiData[uid].plans) multiData[uid].plans = [];
                    if (typeof multiData[uid].avatar === 'undefined') multiData[uid].avatar = '';
                    if (!multiData[uid].logs) multiData[uid].logs = [];
                    // v1.5.3: 從備份復原 (在 v1.5.2 migrate 之前, 這樣 v1.5.2 migrate 才會 transform 正確的舊資料)
                    _v153RestoreFromBackup(uid);
                    // v1.5.4: 加地科 subject + mission rename + 從 plans 重建 appMissions
                    _v154Migrate(uid);
                    // v1.5.8: 進度大分類獨立教材庫 migrate (在 v1.5.2 migrate 之前, 讓 master 結構還是舊的時被搬到 masters[cat])
                    _v158Migrate(uid);
                    // v1.5.29: 同步 plan.grid 裡 task.mis 跟 log.mission (頁數重疊比對，處理順延任務)
                    _v1529Migrate(uid);
                    // v1.5.34: 統一教材類型順序為 defaultTypes 順序
                    _v1534Migrate(uid);
                    // v1.6.64: 自動補 typeName/instanceName + within-match remap
                    _v164Migrate(uid);
                    // v1.5.2: migrate - 重新設計為 3 層架構 (Material Type + Instance + Units)
                    // 從 v1.5.1 升級: 把主教材 units 搬到「複習講義」的第一個 instance「(原主教材)」
                    // v1.5.8 改: iterate masters[cat] (不再 iterate 舊 master)
                    if (multiData[uid].masters) {
                        Object.keys(multiData[uid].masters).forEach(function(catName) {
                            var catSubjects = multiData[uid].masters[catName];
                            if (!catSubjects || typeof catSubjects !== 'object') return;
                            Object.keys(catSubjects).forEach(function(subName) {
                                var subj = catSubjects[subName];
                            if (subj && typeof subj === 'object') {
                                // 檢查是否已經是 v1.5.2 架構
                                if (!subj.materials) {
                                    // 預設 5 個 Material Type
                                    subj.materials = {
                                        '複習講義': { id: 'mt_' + genId(), name: '複習講義', instances: [] },
                                        '複習卷': { id: 'mt_' + genId(), name: '複習卷', instances: [] },
                                        '數字題本': { id: 'mt_' + genId(), name: '數字題本', instances: [] },
                                        '模擬題本': { id: 'mt_' + genId(), name: '模擬題本', instances: [] },
                                        '考古題': { id: 'mt_' + genId(), name: '考古題', instances: [] }
                                    };
                                    // 1. 把 v1.5.1 主教材的 units 搬到「複習講義」的第一個 instance「(原主教材)」
                                    var mainUnits = subj.units || [];
                                    if (subj.type === 'volume') {
                                        // volume 模式: 合併所有 vols 內的 units
                                        mainUnits = [];
                                        Object.keys(subj.vols || {}).forEach(function(volName) {
                                            (subj.vols[volName] || []).forEach(function(u) {
                                                mainUnits.push(Object.assign({}, u, { vol: volName }));
                                            });
                                        });
                                    }
                                    if (mainUnits.length > 0) {
                                        subj.materials['複習講義'].instances.push({
                                            id: 'ins_' + genId(),
                                            name: '(原主教材)',
                                            type: subj.type || 'custom',
                                            units: mainUnits,
                                            vols: subj.vols || null,
                                            volOrder: subj.volOrder || null
                                        });
                                    }
                                    // 2. 把 v1.5.1 reviewMaterials 遷移 (例如「翰將參考書」)
                                    if (subj.reviewMaterials && Array.isArray(subj.reviewMaterials)) {
                                        subj.reviewMaterials.forEach(function(rm) {
                                            // 跳過預設的「複習講義」 (因為已經是預設類別)
                                            if (rm.name === '複習講義') return;
                                            // 其他作為「複習卷」類別的 instance
                                            subj.materials['複習卷'].instances.push({
                                                id: 'ins_' + genId(),
                                                name: rm.name,
                                                type: rm.type || 'custom',
                                                units: rm.units || [],
                                                vols: rm.vols || null,
                                                volOrder: rm.volOrder || null
                                            });
                                        });
                                    }
                                    // 3. 刪除舊欄位
                                    delete subj.units;
                                    delete subj.type;
                                    delete subj.vols;
                                    delete subj.volOrder;
                                    delete subj.reviewMaterials;
                                    if (typeof window._v152Migrated === 'undefined') window._v152Migrated = 0;
                                    window._v152Migrated++;
                                }
                            }
                            });
                        });
                    }
                    multiData[uid].plans.forEach(plan => {
                        if (plan && plan.grid) {
                            Object.keys(plan.grid).forEach(dStr => {
                                if (Array.isArray(plan.grid[dStr])) {
                                    plan.grid[dStr].forEach(t => {
                                        if (t && typeof t.text === 'string' && t.text.includes('[完]')) {
                                            t.text = t.text.replace(/\[完\]\s*/g, '');
                                        }
                                        if (typeof t.postponeCount === 'undefined') t.postponeCount = 0;
                                    });
                                }
                            });
                        }
                    });
                    multiData[uid].logs.forEach(log => {
                        if (log) {
                            if (typeof log.detail === 'string' && log.detail.includes('[完]')) {
                                log.detail = log.detail.replace(/\[完\]\s*/g, '');
                            }
                            if (typeof log.unitName === 'string' && log.unitName.includes('[完]')) {
                                log.unitName = log.unitName.replace(/\[完\]\s*/g, '');
                            }
                            // v1.4.28: migration - 暑期複習進度 → 暑假複習進度
                            if (log.mission && typeof log.mission === 'string' && log.mission.indexOf('暑期複習進度') >= 0) {
                                log.mission = log.mission.replace('暑期複習進度', '暑假複習進度');
                                if (typeof window._v1428Migrated === 'undefined') window._v1428Migrated = 0;
                                window._v1428Migrated++;
                            }
                        }
                    });
                    
                    multiData[uid].logs = multiData[uid].logs.filter(log => 
                        log && log.category !== 'undefined' && log.subject !== 'undefined' && log.subject !== 'test1' && log.unitName !== 'test1'
                    );
                });
                
                if (typeof window._v1428Migrated !== 'undefined' && window._v1428Migrated > 0) {
                    console.log('v1.4.28: migration 完成, 已將 ' + window._v1428Migrated + ' 筆 log 的 mission 從「暑期複習進度」改為「暑假複習進度」');
                }
                window._v1428Migrated = 0;
                if (typeof window._v151Migrated !== 'undefined' && window._v151Migrated > 0) {
                    console.log('v1.5.1: migration 完成, 已為 ' + window._v151Migrated + ' 個 subject 加 reviewMaterials 欄位');
                }
                window._v151Migrated = 0;
                if (typeof window._v152Migrated !== 'undefined' && window._v152Migrated > 0) {
                    console.log('v1.5.2: migration 完成, 已為 ' + window._v152Migrated + ' 個 subject 升級為 3 層架構 (Material Type + Instance), 主教材搬到「複習講義」的「(原主教材)」instance');
                }
                window._v152Migrated = 0;
                
                // v1.5.182: 自動清理教材庫重複 unit (新架構 + 舊架構都掃, 確保一定跑)
                try {
                    var dedupCount = 0;
                    Object.keys(multiData).forEach(function(uid) {
                        dedupCount += deduplicateMasterUnits(uid);
                        dedupCount += deduplicateLegacyMaster(uid);
                    });
                    if (dedupCount > 0) {
                        console.log('v1.5.182: 清理教材庫重複 unit, 共移除 ' + dedupCount + ' 筆');
                    } else {
                        console.log('v1.5.182: 教材庫沒有重複 unit (auto-dedup 完成)');
                    }
                } catch (e) {
                    console.error('v1.5.182: auto-dedup 失敗:', e.message);
                }
                localStorage.setItem(STORAGE_KEY_FAMILY, JSON.stringify(multiData));
                currentUserId = localStorage.getItem(STORAGE_KEY_CURRENT_USER);
                if (!currentUserId || !multiData[currentUserId]) currentUserId = Object.keys(multiData)[0];
                
                var sel = el('user-selector');
                sel.innerHTML = Object.keys(multiData).map(uid => `<option value="${uid}">${multiData[uid].name}</option>`).join('');
                sel.value = currentUserId;
                
                switchUser();
                applyPlannerButtonsColors();
            } catch (e) {
                console.error("初始化錯誤:", e);
                console.error("錯誤堆疊:", e.stack);
                alert("系統初始化錯誤\n\n錯誤訊息: " + e.message + "\n\n請打開 F12 (開發者工具) → Console 看詳細錯誤, 或聯繫開發者。\n\n資料已備份於 localStorage 開頭是 'learningProgressBoardFamily_backup_' 的 key。");
            }
        }
        function autoMigrateLogsToCalendar() {
            if (!appPlans || appPlans.length === 0) return;
            var pid = el('planner-selector') ? el('planner-selector').value : null;
            var targetPlan = appPlans.find(p => p.id === pid);
            if (!targetPlan) targetPlan = appPlans[appPlans.length - 1]; 
            var changed = false;
            
            let allTasksMap = new Map();
            appPlans.forEach(plan => {
                if(!plan.grid) return;
                Object.keys(plan.grid).forEach(dStr => {
                    plan.grid[dStr].forEach(t => {
                        allTasksMap.set(t.id, { task: t, plan: plan, dateStr: dStr });
                    });
                });
            });
            let tasksThatShouldBeDone = new Set();
            appLogs.forEach(log => {
                if(log.category === '🔄 系統重排' || log.category === '🗓️ 計畫管理') return;
                
                var logDate = log.date;
                
                if(log.id && log.id.startsWith('cal_')) {
                    var linkedTaskId = log.id.replace('cal_', '');
                    var match = allTasksMap.get(linkedTaskId);
                    
                    if (match) {
                        tasksThatShouldBeDone.add(linkedTaskId);
                    } else {
                        if(!targetPlan.grid[logDate]) targetPlan.grid[logDate] = [];
                        var textStr = `[${log.subject}] ${log.unitName}`;
                        if (log.start && log.end && log.start !== log.end) textStr += ` P.${log.start}~${log.end}`;
                        else if (log.start && log.start === log.end) textStr += ` P.${log.start}`;
                        
                        var newTask = {
                            id: linkedTaskId, subject: log.subject, text: textStr, startPage: log.start, endPage: log.end,
                            isDone: true, cat: log.category, mis: log.mission, unitId: log.unitId, vol: log.volume, unitName: log.unitName, postponeCount: 0
                        };
                        targetPlan.grid[logDate].push(newTask);
                        allTasksMap.set(linkedTaskId, { task: newTask, plan: targetPlan, dateStr: logDate });
                        tasksThatShouldBeDone.add(linkedTaskId);
                        changed = true;
                    }
                } else {
                    if(!targetPlan.grid[logDate]) targetPlan.grid[logDate] = [];
                    var exists = targetPlan.grid[logDate].find(t => t.subject === log.subject && t.startPage === log.start && t.endPage === log.end);
                    
                    if(!exists) {
                        var newTaskId = genId();
                        var textStr = `[${log.subject}] ${log.unitName}`;
                        if (log.start && log.end && log.start !== log.end) textStr += ` P.${log.start}~${log.end}`;
                        else if (log.start && log.start === log.end) textStr += ` P.${log.start}`;
                        
                        var newTask = {
                            id: newTaskId, subject: log.subject, text: textStr, startPage: log.start, endPage: log.end,
                            isDone: true, cat: log.category, mis: log.mission, unitId: log.unitId, vol: log.volume, unitName: log.unitName, postponeCount: 0
                        };
                        targetPlan.grid[logDate].push(newTask);
                        allTasksMap.set(newTaskId, { task: newTask, plan: targetPlan, dateStr: logDate });
                        
                        log.id = 'cal_' + newTaskId;
                        log.detail = log.unitName; 
                        tasksThatShouldBeDone.add(newTaskId);
                        changed = true;
                    } else {
                        log.id = 'cal_' + exists.id;
                        log.detail = log.unitName;
                        tasksThatShouldBeDone.add(exists.id);
                        changed = true;
                    }
                }
            });
            allTasksMap.forEach((val, taskId) => {
                let isDoneStatus = tasksThatShouldBeDone.has(taskId);
                if (val.task.isDone !== isDoneStatus) {
                    val.task.isDone = isDoneStatus;
                    changed = true;
                }
            });
            
            if(changed) saveToLocal();
        }
        function switchUser() {
            currentUserId = el('user-selector').value;
            localStorage.setItem(STORAGE_KEY_CURRENT_USER, currentUserId);
            var user = multiData[currentUserId];
            // v1.5.8: masters 是 per-category 教材庫, 預設載入第一個 cat
            appMissions = user.missions || {};
            appLogs = user.logs || [];
            appPlans = user.plans || [];
            // v1.6.63: remap plan tasks to current masters unitIds
            // 新任務有 typeName+instanceName → 精確配對；舊任務靠 unitName + page range
            {var _oldPlans = appPlans.slice(); appPlans.length = 0;
            _oldPlans.forEach(function(p) {
                var np = Object.assign({}, p, {grid: {}});
                if(p.grid) Object.keys(p.grid).forEach(function(d) {
                    np.grid[d] = (p.grid[d]||[]).slice();
                });
                appPlans.push(np);
                Object.keys(np.grid).forEach(function(d) {
                    (np.grid[d]||[]).forEach(function(t) {
                        if(!t || !t.unitName || !t.cat) return;
                        var masterEntry = (multiData[currentUserId].masters[t.cat]||{})[t.subject||''];
                        if(!masterEntry) return;
                        var allUnits = _collectSubjectUnits(masterEntry);
                        var match = null;
                        if(t.typeName && t.instanceName) {
                            // 新任務：依 typeName + instanceName + unitName 精確配對
                            // v1.6.171: 加 vol 鎖 (跟 _v164Migrate 一致 — 否則跨 vol 同名 unit 會被指到第一個找到的 vol)
                            match = allUnits.find(function(u){
                                return u.name === t.unitName && u._typeName === t.typeName && u._instanceName === t.instanceName &&
                                       (!u.vol || !t.vol || u.vol === t.vol);
                            });
                        }
                        if(!match) {
                            // v1.6.64: 退階用 within-match (task 範圍在 unit 範圍內)
                            // v1.6.171: 加 vol 鎖
                            match = allUnits.find(function(u){
                                if(u.name !== t.unitName) return false;
                                if(u.vol != null && t.vol && u.vol !== t.vol) return false;
                                if(t.startPage != null && t.endPage != null && u.start != null && u.end != null) {
                                    return u.start <= t.startPage && u.end >= t.endPage;
                                }
                                return true;
                            });
                        }
                        if(match && match.id !== t.unitId) {
                            t.unitId = match.id;
                        }
                    });
                });
            });}
            // v1.6.64: within-match fallback 已涵蓋 partial coverage (e.g., 大滿貫 P.39-50 任務 P.39-42)
            var cats = Object.keys(user.masters || {});
            if (cats.length === 0) {
                appCurrentCat = '';
                appMaster = {};
            } else {
                appCurrentCat = cats[0];
                appMaster = user.masters[appCurrentCat] || {};
            }
            // v1.5.16: 補上 missing type (只 repair 會考複習, 不污染段考複習)
// v1.5.13 原邏輯會遍歷所有 cat (包括段考複習), 但 v1.5.8 是 Category 完全獨立教材庫, 段考複習不該被會考 type 污染
// Denias 23:08 回報: 段考複習不該看到「複習講義/複習卷/數字題本/模擬題本/考古題」這些會考 type
            var defaultTypes = ['複習講義','複習卷','數字題本','模擬題本','考古題'];
            var repairedCount = 0;
            if (user && user.masters && user.masters['會考複習']) {
                // v1.6.138: 讀取使用者刪過的 type marker (永久尊重刪除意願)
                var userDeleted = (user._deletedTypes && user._deletedTypes['會考複習']) || {};
                Object.keys(user.masters['會考複習']).forEach(function(subName) {
                    var subj = user.masters['會考複習'][subName];
                    if (subj && subj.materials) {
                        var deletedInThisSub = userDeleted[subName] || [];
                        defaultTypes.forEach(function(t) {
                            // v1.6.138: 跳過使用者明確刪除過的 type
                            if (!subj.materials[t] && deletedInThisSub.indexOf(t) < 0) {
                                subj.materials[t] = { id: 'mt_' + genId(), name: t, instances: [] };
                                repairedCount++;
                            }
                        });
                    }
                });
            }
            if (repairedCount > 0) {
                console.log('v1.5.16: 自動補上會考複習 ' + repairedCount + ' 個 missing 預設教材類型');
                // v1.5.182: 自動清理教材庫重複 unit (新架構 + 舊架構都掃, 確保一定跑)
                try {
                    var dedupCount = 0;
                    Object.keys(multiData).forEach(function(uid) {
                        dedupCount += deduplicateMasterUnits(uid);
                        dedupCount += deduplicateLegacyMaster(uid);
                    });
                    if (dedupCount > 0) {
                        console.log('v1.5.182: 清理教材庫重複 unit, 共移除 ' + dedupCount + ' 筆');
                    } else {
                        console.log('v1.5.182: 教材庫沒有重複 unit (auto-dedup 完成)');
                    }
                } catch (e) {
                    console.error('v1.5.182: auto-dedup 失敗:', e.message);
                }
                localStorage.setItem(STORAGE_KEY_FAMILY, JSON.stringify(multiData));
            }
            var av = el('current-user-avatar');
            if (av) {
                av.src = user.avatar || DEFAULT_AVATAR;
                av.style.display = 'block';
            }
            // v1.5.99: 切換使用者時自動清理歷史重複任務
            var cleanedOnSwitch = cleanDuplicateSameDayTasks();
            if (cleanedOnSwitch > 0) {
                console.log('🧹 v1.5.99 切換使用者時清理 ' + cleanedOnSwitch + ' 筆同一天同單元重複任務');
                // v1.5.182: 自動清理教材庫重複 unit (新架構 + 舊架構都掃, 確保一定跑)
                try {
                    var dedupCount = 0;
                    Object.keys(multiData).forEach(function(uid) {
                        dedupCount += deduplicateMasterUnits(uid);
                        dedupCount += deduplicateLegacyMaster(uid);
                    });
                    if (dedupCount > 0) {
                        console.log('v1.5.182: 清理教材庫重複 unit, 共移除 ' + dedupCount + ' 筆');
                    } else {
                        console.log('v1.5.182: 教材庫沒有重複 unit (auto-dedup 完成)');
                    }
                } catch (e) {
                    console.error('v1.5.182: auto-dedup 失敗:', e.message);
                }
                localStorage.setItem(STORAGE_KEY_FAMILY, JSON.stringify(multiData));
            }
            
            autoMigrateLogsToCalendar();
            updateFilters();
        }
        function saveToLocal() {
            if(multiData[currentUserId]) {
                // v1.5.8: appMaster 是當前 cat 的教材庫, 寫回 user.masters[appCurrentCat]
                if (!multiData[currentUserId].masters) multiData[currentUserId].masters = {};
                if (appCurrentCat) multiData[currentUserId].masters[appCurrentCat] = appMaster;
                multiData[currentUserId].missions = appMissions;
                multiData[currentUserId].logs = appLogs;
                multiData[currentUserId].plans = appPlans;
            }
            // v1.5.119: invalidate schedule map cache (plan.grid 可能改了)
            invalidateSchedCache();
            // v1.5.17: try/catch 防止 setItem 失敗 (容量 / permission) 導致資料丟失不被發現
            try {
                // v1.5.106: 任何 save 前先做安全備份 (不限時間, 最多 10 個)
                pushSafetyBackup('saveToLocal');
                // v1.5.102: 儲存前 snapshot 到 undoStack (最多 5 步)
                pushUndoSnapshot();
                // v1.5.182: 自動清理教材庫重複 unit (新架構 + 舊架構都掃, 確保一定跑)
                try {
                    var dedupCount = 0;
                    Object.keys(multiData).forEach(function(uid) {
                        dedupCount += deduplicateMasterUnits(uid);
                        dedupCount += deduplicateLegacyMaster(uid);
                    });
                    if (dedupCount > 0) {
                        console.log('v1.5.182: 清理教材庫重複 unit, 共移除 ' + dedupCount + ' 筆');
                    } else {
                        console.log('v1.5.182: 教材庫沒有重複 unit (auto-dedup 完成)');
                    }
                } catch (e) {
                    console.error('v1.5.182: auto-dedup 失敗:', e.message);
                }
                localStorage.setItem(STORAGE_KEY_FAMILY, JSON.stringify(multiData));
            } catch(e) {
                console.error('v1.5.17 saveToLocal FAILED:', e.message, 'size:', JSON.stringify(multiData).length);
                // v1.5.153: quota exceeded 時, 自動清理 backups 後重試
                if (e && e.name && e.name.indexOf('QuotaExceeded') >= 0) {
                    try {
                        // 清空最佔空間的 backups
                        localStorage.removeItem(STORAGE_KEY_SAFETY);
                        localStorage.removeItem(STORAGE_KEY_UNDO);
                        localStorage.removeItem(STORAGE_KEY_NAMED);
                        // 再試一次
                        // v1.5.182: 自動清理教材庫重複 unit (新架構 + 舊架構都掃, 確保一定跑)
                try {
                    var dedupCount = 0;
                    Object.keys(multiData).forEach(function(uid) {
                        dedupCount += deduplicateMasterUnits(uid);
                        dedupCount += deduplicateLegacyMaster(uid);
                    });
                    if (dedupCount > 0) {
                        console.log('v1.5.182: 清理教材庫重複 unit, 共移除 ' + dedupCount + ' 筆');
                    } else {
                        console.log('v1.5.182: 教材庫沒有重複 unit (auto-dedup 完成)');
                    }
                } catch (e) {
                    console.error('v1.5.182: auto-dedup 失敗:', e.message);
                }
                localStorage.setItem(STORAGE_KEY_FAMILY, JSON.stringify(multiData));
                        console.log('v1.5.153: 已清理 backups, 儲存成功');
                        return;  // 成功, 不顯示錯誤
                    } catch(e2) {
                        console.error('v1.5.153: 清理後仍失敗:', e2.message);
                    }
                }
                showSaveErrorToast(e);
            }
        }
        // v1.5.102: Undo / Snapshot 機制
        var STORAGE_KEY_UNDO = 'StudyMap_UndoStack_V102';
        var STORAGE_KEY_NAMED = 'StudyMap_NamedSnapshots_V102';
        var STORAGE_KEY_SAFETY = 'StudyMap_SafetyBackup_V106';
        var MAX_UNDO_STEPS = 5;
        var MAX_NAMED_SNAPSHOTS = 10;
        var MAX_SAFETY_BACKUPS = 10;  // 不限時間但最多 10 個
        // v1.5.106: 安全備份 (任何修改 plans 的動作前呼叫)
        function pushSafetyBackup(reason) {
            try {
                if (!currentUserId) return;
                var raw = localStorage.getItem(STORAGE_KEY_SAFETY) || '{}';
                var backups = JSON.parse(raw);
                if (!backups[currentUserId]) backups[currentUserId] = [];
                var snap = JSON.parse(JSON.stringify(multiData[currentUserId]));
                snap._time = Date.now();
                snap._reason = reason || 'unknown';
                backups[currentUserId].push(snap);
                // 只保留最近 MAX_SAFETY_BACKUPS 個
                if (backups[currentUserId].length > MAX_SAFETY_BACKUPS) {
                    backups[currentUserId] = backups[currentUserId].slice(-MAX_SAFETY_BACKUPS);
                }
                localStorage.setItem(STORAGE_KEY_SAFETY, JSON.stringify(backups));
            } catch(e) {
                console.warn('pushSafetyBackup failed:', e.message);
            }
        }
        function listSafetyBackups() {
            try {
                if (!currentUserId) return [];
                var raw = localStorage.getItem(STORAGE_KEY_SAFETY) || '{}';
                var backups = JSON.parse(raw);
                return backups[currentUserId] || [];
            } catch(e) {
                return [];
            }
        }
        function restoreSafetyBackup(idx) {
            var backups = listSafetyBackups();
            if (idx < 0 || idx >= backups.length) {
                alert('❌ 備份不存在');
                return;
            }
            var snap = backups[idx];
            var timeStr = new Date(snap._time).toLocaleString();
            if (!confirm('🛡️ 確定還原到 ' + timeStr + ' (原因: ' + (snap._reason || '?') + ') 的備份?\n\n目前的資料會被覆蓋, 但其他備份仍保留。')) return;
            try {
                multiData[currentUserId] = JSON.parse(JSON.stringify(snap));
                delete multiData[currentUserId]._time;
                delete multiData[currentUserId]._reason;
                saveToLocal();
                location.reload();
            } catch(e) {
                alert('❌ 還原失敗: ' + e.message);
            }
        }
        function showSafetyBackups() {
            var backups = listSafetyBackups();
            if (backups.length === 0) {
                alert('🛡️ 沒有安全備份\n\n備份會在 saveToLocal / generatePlan / deleteCurrentPlan / saveCalendarTask 時自動建立。');
                return;
            }
            var html = '<div style="max-height:400px; overflow-y:auto;">';
            backups.slice().reverse().forEach(function(snap, revIdx) {
                var idx = backups.length - 1 - revIdx;
                var timeStr = new Date(snap._time).toLocaleString();
                html += '<div style="padding:10px; margin-bottom:8px; border:1px solid #e2e8f0; border-radius:6px; background:#fefce8;">' +
                    '<div style="font-weight:bold; margin-bottom:4px;">📦 備份 #' + (idx + 1) + ' - ' + timeStr + '</div>' +
                    '<div style="color:#7f8c8d; font-size:0.85em; margin-bottom:6px;">原因: ' + escapeHtml(snap._reason || 'unknown') + '</div>' +
                    '<button class="btn-primary" style="padding:5px 15px;" onclick="closeSafetyModal(); restoreSafetyBackup(' + idx + ')">↶ 還原此備份</button>' +
                    '</div>';
            });
            html += '</div>';
            // 開 modal
            var existing = el('modal-safety-backup');
            if (existing) existing.remove();
            var modal = document.createElement('div');
            modal.id = 'modal-safety-backup';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3500';
            modal.style.display = 'flex';
            modal.innerHTML = '<div class="modal-content" style="max-width:600px;">' +
                '<div class="modal-header"><h2 style="color:var(--accent);">🛡️ 安全備份還原</h2></div>' +
                '<div style="padding: 15px;">' + html + '</div>' +
                '<div style="text-align:right; padding: 0 15px 15px;"><button type="button" class="btn-outline" onclick="closeSafetyModal()">關閉</button></div>' +
                '</div>';
            document.body.appendChild(modal);
            el('modal-safety-backup').addEventListener('click', function(e) {
                if (e.target.id === 'modal-safety-backup') closeSafetyModal();
            });
        }
        function closeSafetyModal() {
            var m = el('modal-safety-backup');
            if (m) m.remove();
        }
        function pushUndoSnapshot() {
            try {
                var raw = localStorage.getItem(STORAGE_KEY_UNDO) || '{}';
                var stack = JSON.parse(raw);
                if (!stack[currentUserId]) stack[currentUserId] = [];
                // 深拷貝 multiData 摘要 (plans + logs + missions)
                var snap = JSON.parse(JSON.stringify({
                    plans: multiData[currentUserId].plans,
                    logs: multiData[currentUserId].logs,
                    missions: multiData[currentUserId].missions
                }));
                snap._time = Date.now();
                stack[currentUserId].push(snap);
                // 只保留最近 MAX_UNDO_STEPS 個
                if (stack[currentUserId].length > MAX_UNDO_STEPS) {
                    stack[currentUserId] = stack[currentUserId].slice(-MAX_UNDO_STEPS);
                }
                localStorage.setItem(STORAGE_KEY_UNDO, JSON.stringify(stack));
            } catch(e) {
                console.warn('pushUndoSnapshot failed:', e.message);
            }
        }
        function performUndo() {
            try {
                var raw = localStorage.getItem(STORAGE_KEY_UNDO) || '{}';
                var stack = JSON.parse(raw);
                var userStack = stack[currentUserId] || [];
                if (userStack.length === 0) {
                    alert('❌ 沒有可還原的快照。');
                    return;
                }
                var lastSnap = userStack.pop();
                var timeStr = new Date(lastSnap._time).toLocaleString();
                if (!confirm('↶ 還原到 ' + timeStr + ' 的狀態？\n(目前的變更會被覆蓋)')) {
                    return;
                }
                // 還原 plans / logs / missions
                multiData[currentUserId].plans = lastSnap.plans;
                multiData[currentUserId].logs = lastSnap.logs;
                multiData[currentUserId].missions = lastSnap.missions;
                appPlans = lastSnap.plans;
                appLogs = lastSnap.logs;
                appMissions = lastSnap.missions;
                // 寫回 stack (扣掉一個)
                stack[currentUserId] = userStack;
                localStorage.setItem(STORAGE_KEY_UNDO, JSON.stringify(stack));
                saveToLocal();
                renderCalendar();
                renderDashboard();
                renderTreeView();
                alert('✅ 已還原到 ' + timeStr + '\n剩餘 ' + userStack.length + ' 步可還原');
            } catch(e) {
                console.error('performUndo failed:', e.message);
                alert('還原失敗: ' + e.message);
            }
        }
        function saveNamedSnapshot() {
            var name = prompt('📌 為快照命名 (例如「段考前 v1」):', '');
            if (!name) return;
            try {
                var raw = localStorage.getItem(STORAGE_KEY_NAMED) || '{}';
                var named = JSON.parse(raw);
                if (!named[currentUserId]) named[currentUserId] = [];
                var snap = JSON.parse(JSON.stringify({
                    plans: multiData[currentUserId].plans,
                    logs: multiData[currentUserId].logs,
                    missions: multiData[currentUserId].missions
                }));
                snap.name = name;
                snap.time = Date.now();
                named[currentUserId].push(snap);
                // 只保留 MAX_NAMED_SNAPSHOTS 個
                if (named[currentUserId].length > MAX_NAMED_SNAPSHOTS) {
                    named[currentUserId] = named[currentUserId].slice(-MAX_NAMED_SNAPSHOTS);
                }
                localStorage.setItem(STORAGE_KEY_NAMED, JSON.stringify(named));
                alert('✅ 已儲存快照「' + name + '」');
                updateNamedSnapshotDisplay();
            } catch(e) {
                alert('儲存快照失敗: ' + e.message);
            }
        }
        function restoreNamedSnapshot(idx) {
            try {
                var raw = localStorage.getItem(STORAGE_KEY_NAMED) || '{}';
                var named = JSON.parse(raw);
                var userNamed = named[currentUserId] || [];
                if (idx >= userNamed.length) return;
                var snap = userNamed[idx];
                var timeStr = new Date(snap.time).toLocaleString();
                if (!confirm('↶ 還原到快照「' + snap.name + '」(' + timeStr + ')？')) return;
                multiData[currentUserId].plans = snap.plans;
                multiData[currentUserId].logs = snap.logs;
                multiData[currentUserId].missions = snap.missions;
                appPlans = snap.plans;
                appLogs = snap.logs;
                appMissions = snap.missions;
                saveToLocal();
                renderCalendar();
                renderDashboard();
                renderTreeView();
                alert('✅ 已還原到「' + snap.name + '」');
            } catch(e) {
                alert('還原失敗: ' + e.message);
            }
        }
        function deleteNamedSnapshot(idx) {
            try {
                var raw = localStorage.getItem(STORAGE_KEY_NAMED) || '{}';
                var named = JSON.parse(raw);
                var userNamed = named[currentUserId] || [];
                if (idx >= userNamed.length) return;
                var snap = userNamed[idx];
                if (!confirm('🗑️ 確定刪除快照「' + snap.name + '」？')) return;
                userNamed.splice(idx, 1);
                named[currentUserId] = userNamed;
                localStorage.setItem(STORAGE_KEY_NAMED, JSON.stringify(named));
                updateNamedSnapshotDisplay();
            } catch(e) {
                alert('刪除失敗: ' + e.message);
            }
        }
        function toggleSnapshotList() {
            var c = document.getElementById('named-snapshot-container');
            if (!c) return;
            c.style.display = c.style.display === 'none' ? 'block' : 'none';
            if (c.style.display === 'block') updateNamedSnapshotDisplay();
        }
        
        function updateNamedSnapshotDisplay() {
            var container = document.getElementById('named-snapshot-list');
            if (!container) return;
            try {
                var raw = localStorage.getItem(STORAGE_KEY_NAMED) || '{}';
                var named = JSON.parse(raw);
                var userNamed = named[currentUserId] || [];
                if (userNamed.length === 0) {
                    container.innerHTML = '<div style="color:#7f8c8d; padding:8px; font-size:0.85em;">尚無快照</div>';
                    return;
                }
                var html = '';
                userNamed.forEach(function(snap, idx) {
                    var timeStr = new Date(snap.time).toLocaleString();
                    html += '<div style="display:flex; align-items:center; gap:8px; padding:6px 8px; margin-bottom:4px; background:#fff; border:1px solid #e2e8f0; border-radius:4px;">' +
                        '<span style="flex:1; font-size:0.85em;">📸 <strong>' + escapeHtml(snap.name) + '</strong> <span style="color:#7f8c8d; font-size:0.8em;">(' + timeStr + ')</span></span>' +
                        '<button type="button" class="btn-primary" style="padding:3px 8px; font-size:0.8em;" onclick="restoreNamedSnapshot(' + idx + ')">↶ 還原</button>' +
                        '<button type="button" class="btn-danger" style="padding:3px 8px; font-size:0.8em;" onclick="deleteNamedSnapshot(' + idx + ')"></button>' +
                        '</div>';
                });
                container.innerHTML = html;
            } catch(e) {
                container.innerHTML = '<div style="color:#e74c3c; padding:8px;">讀取快照失敗</div>';
            }
        }
        // v1.5.17: 儲存失敗警告 UI
        function showSaveErrorToast(err) {
            var existing = el('save-error-toast');
            if (existing) existing.remove();
            var toast = document.createElement('div');
            toast.id = 'save-error-toast';
            toast.style.cssText = 'position:fixed; bottom:20px; right:20px; background:#e74c3c; color:white; padding:15px 20px; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,0.3); z-index:9999; max-width:400px; font-size:0.95em;';
            toast.innerHTML = '<b>⚠️ 資料儲存失敗！</b><br><small>' + escapeHtml(err.message) + '</small><br><br>資料只在記憶體, <b>reload 會丟失</b>!<br>請清理瀏覽器 cache / 關閉其他分頁釋放空間。' +
                '<br><br><button onclick="this.parentElement.remove()" style="background:white;color:#e74c3c;border:none;padding:5px 12px;border-radius:4px;cursor:pointer;font-weight:bold;">知道了</button>';
            document.body.appendChild(toast);
            setTimeout(function() { if (toast.parentElement) toast.remove(); }, 30000);
        }
        function checkDailyWorkload(plan, dateStr) {
            if (plan && plan.grid[dateStr] && plan.grid[dateStr].length >= 5) {
                setTimeout(() => {
                    alert(`⚠️ 溫馨提醒：${dateStr} 的排程似乎有點重 (目前已有 ${plan.grid[dateStr].length} 項任務)，是否考慮為孩子安排額外的『緩衝日』以免壓力過大？`);
                }, 300);
            }
        }
        var currentInputCallback = null;
        
        function openInputModal(title, defaultValue, callback) {
            el('input-modal-title').innerText = title;
            el('input-modal-text').value = defaultValue || '';
            currentInputCallback = callback;
            
            const icons = ['📘','📚','📖','📝','✏️','🎓','🎯','🚀','💡','🏆','🏅','🎖️','💯','🌟','✨','🔍','📊','📁','🍎','🐱','🐶','🐰','🐼','🧸','🦊','🦁','🐷','🐸','🐳','🍀','🌈','☀️','⭐'];
            el('input-emoji-grid').innerHTML = icons.map(e => `<div class="input-emoji-btn" title="加入 ${e} 圖示" onclick="addEmojiToInput('${e}')">${e}</div>`).join('');
            
            openModal('modal-input');
            setTimeout(() => el('input-modal-text').focus(), 100);
        }
        
        window.addEmojiToInput = function(emoji) {
            let input = el('input-modal-text');
            input.value = emoji + ' ' + input.value;
            input.focus();
        };
        function confirmInputModal() {
            var val = el('input-modal-text').value.trim();
            if(!val) return alert('不能空白，請輸入內容！');
            closeModal('modal-input');
            if(currentInputCallback) currentInputCallback(val);
        }
        
        function openModal(id) { el(id).style.display = 'flex'; }
        function closeModal(id) { var e = el(id); if (e) e.style.display = 'none'; }
        function populateSelect(elId, options, selected) {
            var sel = el(elId);
            if(!sel) return;
            if(options.length === 0) sel.innerHTML = '<option value="">(無)</option>';
            else {
                sel.innerHTML = options.map(opt => `<option value="${opt}">${opt}</option>`).join('');
                if (selected && options.includes(selected)) sel.value = selected;
            }
        }
        function buildMissionTree(cat, mis) {
            var tree = {};
            if(!appMissions[cat] || !appMissions[cat][mis]) return tree;
            // v1.5.8: 從 user.masters[cat] 讀教材庫 (不依賴 appMaster 全域變數, 避免切換 cat 後讀錯)
            var user = multiData[currentUserId];
            var catMaster = (user && user.masters && user.masters[cat]) ? user.masters[cat] : appMaster;
            var lookup = {};
            Object.keys(catMaster).forEach(function(sub) {
                var s = catMaster[sub];
                if (!s) return;
                _collectSubjectUnits(s).forEach(function(u) {
                    if (u && u.id) lookup[u.id] = { sub: sub, vol: u.vol || 'custom', unit: u };
                });
            });
            appMissions[cat][mis].forEach(uid => { var info = lookup[uid]; if (!info) return; if (!tree[info.sub]) tree[info.sub] = { type: 'materials', items: {} }; if (!tree[info.sub].items[info.vol]) tree[info.sub].items[info.vol] = []; tree[info.sub].items[info.vol].push(info.unit); }); Object.keys(tree).forEach(sub => { Object.keys(tree[sub].items).forEach(vol => { tree[sub].items[vol].sort((a, b) => { return (Number(a.start)||0) - (Number(b.start)||0); }); }); }); return tree;
        }
        // v1.5.5: 統一 subject unit 收集 helper — 兼容舊 (s.units / s.vols) + 新 (s.materials[*].instances[*])
        // v1.5.120: WeakMap cache — s 物件 reference 不變就返回快取結果
        var _collectSubjectUnitsCache = new WeakMap();
        function _collectSubjectUnits(s) {
            if (!s) return [];
            if (_collectSubjectUnitsCache.has(s)) return _collectSubjectUnitsCache.get(s);
            var result;
            // legacy v1.4: type='custom' + units
            if (s.type === 'custom' && Array.isArray(s.units)) {
                result = s.units.map(function(u) { return Object.assign({}, u, { vol: 'custom' }); });
            }
            // legacy v1.4: vols map
            else if (s.vols && typeof s.vols === 'object') {
                var out = [];
                (s.volOrder || Object.keys(s.vols)).forEach(function(volName) {
                    (s.vols[volName] || []).forEach(function(u) {
                        out.push(Object.assign({}, u, { vol: volName }));
                    });
                });
                result = out;
            }
            // v1.5.2+: materials[*].instances[*]
            else if (s.materials && typeof s.materials === 'object') {
                var out2 = [];
                var seenIds = {};  // v1.5.177: dedup by (type|inst|vol|id); v1.5.185: 簡化為 (type|inst|id) — ins.vols 與 ins.units 兩個分支會放同一個 u.id, 必須跨分支去重
                Object.keys(s.materials).forEach(function(typeName) {
                    var typeObj = s.materials[typeName];
                    if (!typeObj || !Array.isArray(typeObj.instances)) return;
                    typeObj.instances.forEach(function(ins) {
                        if (!ins) return;
                        if (ins.vols && typeof ins.vols === 'object') {
                            (ins.volOrder || Object.keys(ins.vols)).forEach(function(volName) {
                                (ins.vols[volName] || []).forEach(function(u) {
                                    if (u && u.id) {
                                        var k = typeName + '|' + ins.name + '|' + u.id;
                                        if (seenIds[k]) return;
                                        seenIds[k] = true;
                                        out2.push(Object.assign({}, u, { vol: volName, _typeName: typeName, _instanceName: ins.name }));
                                    }
                                });
                            });
                        }
                        if (Array.isArray(ins.units)) {
                            ins.units.forEach(function(u) {
                                if (u && u.id) {
                                    var k2 = typeName + '|' + ins.name + '|' + u.id;
                                    if (seenIds[k2]) return;
                                    seenIds[k2] = true;
                                    out2.push(Object.assign({}, u, {
                                        vol: ins.type === 'volume' ? (u.vol || 'custom') : typeName + '|' + ins.name,
                                        _instanceName: ins.name,
                                        _typeName: typeName
                                    }));
                                }
                            });
                        }
                    });
                });
                result = out2;
            }
            else {
                result = [];
            }
            _collectSubjectUnitsCache.set(s, result);
            return result;
        }
        function openPlanner() { 
            showPage('page-planner'); 
            updatePlannerSelector(); 
        }
        function updatePlannerSelector() {
            var sel = el('planner-selector');
            if(appPlans.length === 0) {
                sel.value = '';
                el('calendar-grid').innerHTML = '<div style="grid-column: 1 / -1; padding: 50px; text-align: center; color: #95a5a6;">請點擊上方「🪄 建立智慧排程計畫」開始！</div>';
                return;
            }
            sel.innerHTML = appPlans.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
            sel.value = appPlans[appPlans.length - 1].id;
            
            var catFilter = el('planner-cat-filter');
            if(catFilter) {
                var dashCat = el('filter-category') ? el('filter-category').value : 'ALL';
                var dashMis = el('filter-mission') ? el('filter-mission').value : 'ALL';
                var catOpts = '<option value="ALL">🌟 全部顯示</option>';
                Object.keys(appMissions).forEach(c => catOpts += `<option value="${c}">${c}</option>`);
                catFilter.innerHTML = catOpts;
                catFilter.value = Object.keys(appMissions).includes(dashCat) ? dashCat : 'ALL';
                
                onPlannerCatChange(true); 
                var misFilter = el('planner-mis-filter');
                if (misFilter) {
                    let hasOpt = Array.from(misFilter.options).some(opt => opt.value === dashMis);
                    misFilter.value = (dashMis !== 'ALL' && hasOpt) ? dashMis : 'ALL';
                }
            }
            renderCalendar();
        }
        
        function onPlannerCatChange(skipRender) {
            let cat = el('planner-cat-filter').value;
            let misSel = el('planner-mis-filter');
            let currentMis = misSel.value || 'ALL';
            
            if (!cat || cat === 'ALL') {
                misSel.innerHTML = '<option value="ALL">🌟 全部任務</option>';
            } else {
                let opts = '<option value="ALL">🌟 全部任務</option>';
                if(appMissions[cat]) {
                    Object.keys(appMissions[cat]).forEach(m => opts += `<option value="${m}">${m}</option>`);
                }
                misSel.innerHTML = opts;
                if(appMissions[cat] && appMissions[cat][currentMis]) misSel.value = currentMis;
                else misSel.value = 'ALL';
            }
            if(skipRender !== true) renderCalendar();
        }
        function changeMonth(delta) {
            console.log('[changeMonth] 啟動, delta=' + delta + ', appPlans.length=' + (appPlans ? appPlans.length : 'NULL') + ', planner-selector.value=' + (el('planner-selector') ? el('planner-selector').value : 'NULL'));
            currentViewDate.setMonth(currentViewDate.getMonth() + delta);
            console.log('[changeMonth] currentViewDate=' + currentViewDate.toISOString());
            try {
                renderCalendar();
                console.log('[changeMonth] renderCalendar 完成, grid.length=' + (el('calendar-grid') ? el('calendar-grid').innerHTML.length : 0));
            } catch(e) {
                console.error('[changeMonth] ERROR:', e.message, e.stack);
            }
        }
        window.toggleTaskDone = function(e, pid, dateStr, taskId) {
            e.stopPropagation();
            var plan = appPlans.find(p => p.id === pid);
            if (!plan) return;
            var taskArr = plan.grid[dateStr];
            if (!taskArr) return;
            var task = taskArr.find(t => t.id === taskId);
            if (task) {
                task.isDone = e.target.checked;
                
                let getParsedUnit = (subject, text) => {
                    if (!appMaster[subject]) return null;
                    let sInfo = appMaster[subject];
                    if (sInfo.type === 'custom') {
                        let u = sInfo.units.find(x => text.includes(x.name));
                        if(u) return { id: u.id, vol: '', name: u.name };
                    } else {
                        let vols = sInfo.volOrder || Object.keys(sInfo.vols);
                        for(let v of vols) {
                            let u = sInfo.vols[v].find(x => text.includes(x.name));
                            if(u) return { id: u.id, vol: v, name: u.name };
                        }
                    }
                    return null;
                };
                if(task.isDone) {
                    let unitId = task.unitId;
                    let vol = task.vol;
                    let unitName = task.unitName;
                    let cat = task.cat;
                    let mis = task.mis;
                    if (!unitId && task.subject) {
                        let parsed = getParsedUnit(task.subject, task.text);
                        if (parsed) {
                            unitId = parsed.id;
                            vol = parsed.vol;
                            unitName = parsed.name;
                        }
                    }
                    if (unitId && (!cat || !mis)) {
                        for (let c in appMissions) {
                            for (let m in appMissions[c]) {
                                if (appMissions[c][m].includes(unitId)) {
                                    cat = c; mis = m; break;
                                }
                            }
                            if (cat) break;
                        }
                    }
                    
                    let extractedUnitName = unitName || task.text.replace(/\[.*?\] /, '').split(' P.')[0].replace(/^【.*?】\s*/, '').replace(/🔔\s*/g, '');
                    var logEntry = {
                        id: 'cal_' + task.id, 
                        date: dateStr,
                        category: cat || '手動排程',
                        mission: mis || plan.name,
                        subject: task.subject || '自訂',
                        volume: vol || '',
                        unitId: unitId || ('dummy_' + task.id),
                        unitName: extractedUnitName,
                        start: task.startPage || 0,
                        end: task.endPage || 0,
                        pages: (task.endPage && task.startPage && task.endPage >= task.startPage) ? (task.endPage - task.startPage + 1) : 1,
                        detail: extractedUnitName
                    };
                    
                    appLogs = appLogs.filter(l => l.id !== 'cal_' + task.id);
                    appLogs.push(logEntry);
                } else {
                    appLogs = appLogs.filter(l => l.id !== 'cal_' + task.id);
                }
                
                saveToLocal();
                renderCalendar();
                renderDashboard();
                renderTreeView();  // v1.6.51: 同步更新 Tree View
                if (el('page-history') && el('page-history').style.display === 'block') renderHistoryTable();
            }
        };
        window.dragTask = function(e, pid, dateStr, taskId) { e.stopPropagation(); e.dataTransfer.setData("text/plain", JSON.stringify({pid, dateStr, taskId})); e.dataTransfer.effectAllowed = "move"; };
        window.allowDrop = function(e) { e.preventDefault(); e.dataTransfer.dropEffect = "move"; };
        window.dropTask = function(e, targetDateStr) {
            e.preventDefault();
            var data = e.dataTransfer.getData("text/plain");
            if(!data) return;
            try {
                var obj = JSON.parse(data);
                if(obj.dateStr === targetDateStr) return; 
                
                var plan = appPlans.find(p => p.id === obj.pid);
                if(!plan) return;
                var taskArr = plan.grid[obj.dateStr];
                if(!taskArr) return;
                var taskIdx = taskArr.findIndex(t => t.id === obj.taskId);
                
                if(taskIdx > -1) {
                    var task = taskArr.splice(taskIdx, 1)[0];
                    if(!plan.grid[targetDateStr]) plan.grid[targetDateStr] = [];
                    plan.grid[targetDateStr].push(task);
                    
                    appLogs.push({ id: genId(), date: obj.dateStr, category: '🔄 系統重排', mission: plan.name, subject: task.subject||'自訂', unitName: '拖曳順延/微調', start: task.startPage||0, end: task.endPage||0, pages: 0, detail: `手動拖曳將任務從 ${obj.dateStr} 移至 ${targetDateStr}` });
                    
                    var existLogIdx = appLogs.findIndex(l => l.id === 'cal_' + task.id);
                    if (existLogIdx > -1) appLogs[existLogIdx].date = targetDateStr;
                    saveToLocal();
                    renderCalendar();
                    checkDailyWorkload(plan, targetDateStr);
                    if (el('page-history') && el('page-history').style.display === 'block') renderHistoryTable();
                }
            } catch(err) { console.error(err); }
        };
        function renderCalendar() {
            autoMigrateLogsToCalendar();
            var pid = el('planner-selector').value;
            console.log('[renderCalendar] pid=' + JSON.stringify(pid) + ', appPlans.length=' + (appPlans ? appPlans.length : 'NULL'));
            // v1.5.168: planner-selector 空時 fallback 用 last plan (避免從其他頁面跳入月曆後 changeMonth 看起來沒動作)
            if (!pid && appPlans && appPlans.length > 0) {
                var lastPlan = appPlans[appPlans.length - 1];
                el('planner-selector').value = lastPlan.id;
                pid = lastPlan.id;
                console.log('[renderCalendar] fallback to last plan: ' + pid);
            }
            if(!pid) { console.log('[renderCalendar] pid 空, return'); el('calendar-grid').innerHTML = ''; return; }
            var plan = appPlans.find(p => p.id === pid); 
            console.log('[renderCalendar] plan=' + (plan ? plan.name : 'NULL'));
            if(!plan) return;
            
            let fCat = el('planner-cat-filter') ? el('planner-cat-filter').value : 'ALL';
            let fMis = el('planner-mis-filter') ? el('planner-mis-filter').value : 'ALL';
            let allowedUnitIds = new Set();
            let allowedSubjects = new Set();
            
            if (fCat !== 'ALL' && appMissions[fCat]) {  // v1.5.83: 加防呆 appMissions[fCat]
                if (fMis !== 'ALL' && appMissions[fCat][fMis]) {
                    (appMissions[fCat][fMis] || []).forEach(id => allowedUnitIds.add(id));
                    let mTree = buildMissionTree(fCat, fMis);
                    Object.keys(mTree).forEach(sub => allowedSubjects.add(sub));
                } else if (fMis === 'ALL') {
                    Object.keys(appMissions[fCat]).forEach(m => {
                        (appMissions[fCat][m] || []).forEach(id => allowedUnitIds.add(id));
                        let mTree = buildMissionTree(fCat, m);
                        Object.keys(mTree).forEach(sub => allowedSubjects.add(sub));
                    });
                } else {
                    // v1.5.83: fMis 找不到 (可能 emoji 被截斷),fallback 用 ALL
                    Object.keys(appMissions[fCat]).forEach(m => {
                        (appMissions[fCat][m] || []).forEach(id => allowedUnitIds.add(id));
                        let mTree = buildMissionTree(fCat, m);
                        Object.keys(mTree).forEach(sub => allowedSubjects.add(sub));
                    });
                }
            }
            
            var year = currentViewDate.getFullYear();
            var month = currentViewDate.getMonth();
            el('current-month-display').innerText = `${year}年 ${month + 1}月`;
            var firstDay = new Date(year, month, 1);
            var startDate = new Date(firstDay);
            startDate.setDate(startDate.getDate() - startDate.getDay());
            var html = '';
            var todayStr = getLocalDateString(new Date());
            if(!plan.grid || typeof plan.grid !== 'object') plan.grid = {};
            // v1.5.87: highlight 橫條改到獨立容器 (在月曆切換的同一排最左側)
            var highlightUid = window._highlightUnitId;
            var bannerEl = el('calendar-highlight-banner');
            if (highlightUid && window._treeScheduledUnits && window._treeScheduledUnits[highlightUid]) {
                var hsu = window._treeScheduledUnits[highlightUid];
                var cleanMis = (hsu.firstMis || '').replace(/^[\uD800-\uDBFF][\uDC00-\uDFFF]+\s*/g, '').trim();
                bannerEl.innerHTML = '<span class="banner-content">📌 ' + escapeHtml(hsu.unitName || '單元') + ' (' + escapeHtml(hsu.firstCat) + ' → ' + escapeHtml(cleanMis) + ')</span><button onclick="returnToTreeView()">← 返回樹狀圖</button>';
                bannerEl.style.display = 'inline-flex';
            } else {
                bannerEl.style.display = 'none';
            }
            for(var i=0; i<42; i++) {
                var d = new Date(startDate); d.setDate(startDate.getDate() + i);
                var dStr = getLocalDateString(d);
                var isOtherMonth = d.getMonth() !== month;
                var isWeekend = d.getDay() === 0 || d.getDay() === 6;
                var classStr = `calendar-day ${isOtherMonth ? 'other-month' : ''} ${isWeekend ? 'weekend' : ''}`;
                // v1.5.164: 事件 chip (月曆 cell 頂部)
                var eventsHtml = '';
                var dayEvents = (plan.events || []).filter(function(ev) { return ev.date === dStr; });
                if (dayEvents.length > 0) {
                    eventsHtml = '<div style="margin-bottom:4px;">';
                    dayEvents.forEach(function(ev) {
                        var hoursText = (ev.hours === 0) ? '0hr' : (ev.hours + 'hr');
                        var title = ev.name + (ev.type ? ' [' + ev.type + ']' : '') + ' | ' + hoursText;
                        eventsHtml += '<span style="display:inline-block; background:#fef3c7; color:#92400e; font-size:0.7em; padding:2px 6px; border-radius:8px; margin:1px; cursor:pointer;" title="' + escapeHtml(title) + '" onclick="event.stopPropagation();openEventsModal(\'' + dStr + '\')">📌' + escapeHtml(ev.name) + '</span>';
                    });
                    eventsHtml += '</div>';
                }
                var tasksHtml = '';
                var tasks = Array.isArray(plan.grid[dStr]) ? plan.grid[dStr] : [];
                
                let filteredTasks = [...tasks];
                if (fCat !== 'ALL') {
                    filteredTasks = filteredTasks.filter(t => {
                        if (t.unitId) {
                            return allowedUnitIds.has(t.unitId);
                        }
                        if (t.cat) {
                            if (t.cat !== fCat) return false;
                            if (fMis !== 'ALL' && t.mis !== fMis) return false;
                            return true;
                        }
                        if (!appMaster[t.subject]) return true; 
                        if (allowedSubjects && !allowedSubjects.has(t.subject)) return false;
                        return true;
                    });
                }
                var targetOrder = ['國文', '數學', '英文', '歷史', '地理', '公民', '理化', '生物'];
                filteredTasks.sort((a, b) => {
                    var idxA = targetOrder.indexOf(a.subject);
                    var idxB = targetOrder.indexOf(b.subject);
                    if (idxA === -1) idxA = 999;
                    if (idxB === -1) idxB = 999;
                    if (idxA !== idxB) return idxA - idxB;
                    return (a.subject || '').localeCompare(b.subject || '');
                });
                
                if(filteredTasks.length > 0) {
                    filteredTasks.forEach(task => {
                        var isOverdue = !task.isDone && dStr < todayStr;
                        var isBottleneck = (task.postponeCount >= 3);
                        var bottleneckMark = (isBottleneck && !task.isDone) ? `<span style="color:#c0392b; font-weight:900; margin-right:4px;" title="此任務已連續順延3次以上，建議調整難度！">🆘[卡關]</span>` : '';
                        
                        var cmCat = task.cat || '';
                        var cmMis = task.mis || '';
                        if (!cmCat || !cmMis) {
                            if (task.unitId) {
                                for(let c in appMissions) {
                                    for(let m in appMissions[c]) {
                                        if(appMissions[c][m].includes(task.unitId)) { cmCat = c; cmMis = m; break; }
                                    }
                                    if (cmCat) break;
                                }
                            }
                        }
                        var linkedLog = appLogs.find(l => l.id === 'cal_' + task.id);
                        var prefixCat = cmCat;
                        var prefixMis = cmMis;
                        
                        var cleanText = task.text.replace(/\[🔄 順延\]\s*/g, '').replace(/🔔\s*/g, '').replace(/^【.*?】\s*/, '');
                        var isReminder = task.text.includes('🔔');
                        // v1.5.106: 跨單元任務動態生成多色文字 (C+E 方案)
                        var crossRanges = getCrossUnitRanges(task);
                        var crossUnitHtml = null;
                        if (crossRanges) {
                            // 顏色: 第 1 個 unit 藍色 #3b82f6, 第 2 個 unit 綠色 #10b981
                            var colors = ['#3b82f6', '#10b981'];
                            var htmlParts = [];
                            crossRanges.forEach(function(r, idx) {
                                var color = colors[idx % 2];
                                var pageStr = (r.start === r.end) ? 'P.' + r.start : 'P.' + r.start + '~' + r.end;
                                htmlParts.push('<span style="color:' + color + '; font-weight:bold;">' + pageStr + ' ' + escapeHtml(r.name) + '</span>');
                            });
                            crossUnitHtml = htmlParts.join(' <span style="color:#94a3b8;">+</span> ');
                        }
                        if (linkedLog) {
                            var detailStr = linkedLog.detail || linkedLog.unitName || '';
                            var subStr = linkedLog.subject || task.subject || '';
                            
                            if (linkedLog.category && linkedLog.category !== '手動排程' && linkedLog.category !== '🔄 系統重排' && linkedLog.category !== '🗓️ 計畫管理') {
                                prefixCat = linkedLog.category;
                            }
                            if (linkedLog.mission) {
                                prefixMis = linkedLog.mission;
                            }
                            
                            cleanText = `[${subStr}] ${detailStr}`;
                            if (linkedLog.start && linkedLog.end && linkedLog.start !== linkedLog.end) {
                                cleanText += ` P.${linkedLog.start}~${linkedLog.end}`;
                            } else if (linkedLog.start && linkedLog.start === linkedLog.end) {
                                cleanText += ` P.${linkedLog.start}`;
                            }
                        }
                        var displayText = cleanText;
                        if (isReminder) displayText = '🔔 ' + displayText;
                        // v1.5.106: 跨單元任務用多色文字取代原本 P.XX~YY
                        if (crossUnitHtml) {
                            displayText = displayText.replace(/P\.\d+(~\d+)?\s*$/, '').trim() + ' ' + crossUnitHtml;
                        }
                        var titleAttr = (displayText || "").replace(/"/g, '&quot;');
                        if (crossRanges) {
                            titleAttr += ' | 跨單元: ' + crossRanges.map(function(r) { return r.name + ' (' + (r.end - r.start + 1) + '頁)'; }).join(' + ');
                        }
                        var taskClasses = `task-item ${task.isDone ? 'done' : ''} ${isOverdue ? 'overdue' : ''} ${(isBottleneck && !task.isDone) ? 'bottleneck' : ''}`;
                        
                        tasksHtml += `
                        <div class="${taskClasses}" 
                            draggable="true" 
                            ondragstart="dragTask(event, '${pid}', '${dStr}', '${task.id}')"
                            onclick="editCalendarTask('${pid}', '${dStr}', '${task.id}')" title="${titleAttr}">
                            <div style="display:flex; align-items:flex-start; gap:6px;">
                                <input type="checkbox" ${task.isDone ? 'checked' : ''} onclick="toggleTaskDone(event, '${pid}', '${dStr}', '${task.id}')" style="margin-top:3px; width:14px; height:14px; cursor:pointer; flex-shrink:0;">
                                <span class="task-text" style="flex:1; word-break:break-all;">${bottleneckMark}${displayText}</span>
                            </div>
                        </div>`;
                    });
                }
                
                var isToday = dStr === todayStr ? 'background:var(--accent); color:white; border-radius:4px;' : '';
                
                // v1.5.86: 檢查這個日期是否有 highlight 單元的任務
                var hasHighlight = false;
                if (highlightUid && tasks && tasks.length > 0) {
                    hasHighlight = tasks.some(function(t) { return t.unitId === highlightUid; });
                }
                var classStrWithHighlight = hasHighlight ? classStr + ' has-highlight' : classStr;
                
                html += `
                <div class="${classStrWithHighlight}" ondragover="allowDrop(event)" ondrop="dropTask(event, '${dStr}')">
                    ${hasHighlight ? '<span class="highlight-pin" title="包含醒目單元">📌</span>' : ''}
                    <div class="date-label-container">
                        <span class="date-num" style="${isToday}">${d.getDate()}</span>
                        <button class="add-event-btn" title="手動新增自訂進度" onclick="openAddEventModal('${dStr}', '${pid}'); event.stopPropagation();">＋</button>
                    </div>
                    ${eventsHtml}${tasksHtml}
                </div>`;
            }
            el('calendar-grid').innerHTML = html;
        }
        function openDoubleCheck() {
            let pid = el('planner-selector').value;
            if(!pid) return alert('請先選擇計畫！');
            let plan = appPlans.find(p => p.id === pid);
            let todayStr = getLocalDateString(new Date());
            let overdueTasks = [];
            
            Object.keys(plan.grid).forEach(dateStr => {
                if (dateStr < todayStr) {
                    let tasks = plan.grid[dateStr] || [];
                    tasks.forEach(t => {
                        if (!t.isDone) {
                            overdueTasks.push({ date: dateStr, task: t });
                        }
                    });
                }
            });
            
            overdueTasks.sort((a, b) => a.date.localeCompare(b.date));
            if (overdueTasks.length === 0) {
                return alert('🎉 太棒了！Double Check 完成，目前沒有任何落後未回報的進度！');
            }
            
            let html = '';
            overdueTasks.forEach((item, i) => {
                let defaultNextDate = new Date();
                defaultNextDate.setDate(defaultNextDate.getDate()); 
                let dStr = getLocalDateString(defaultNextDate);
                
                html += `<div class="form-group" style="background:#fdf2e9; border:1px solid #fad7a1;">
                    <div style="font-weight:bold; color:#d35400; margin-bottom:5px;">📅 原日期: ${item.date} | 📌 ${item.task.subject || '自訂'}</div>
                    <div style="font-size:0.95em; color:var(--primary); margin-bottom:10px;">${item.task.text}</div>
                    <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                        <label style="margin:0; font-size:0.9em;">延期至：</label>
                        <input type="date" id="dc-date-${i}" value="${dStr}" style="width:auto; padding:5px;">
                        <button class="btn-success" style="padding:6px 12px; font-size:0.9em;" onclick="rescheduleTask('${item.date}', '${item.task.id}', 'dc-date-${i}')">🔄 重新安排 (順延)</button>
                        <button class="btn-danger" style="padding:6px 12px; font-size:0.9em;" onclick="deleteCalendarTaskDirect('${item.date}', '${item.task.id}')">🗑️ 刪除</button>
                    </div>
                </div>`;
            });
            
            el('dc-list').innerHTML = html;
            openModal('modal-double-check');
        }
        function rescheduleTask(oldDateStr, taskId, dateInputId) {
            let pid = el('planner-selector').value;
            let plan = appPlans.find(p => p.id === pid);
            let newDateStr = el(dateInputId).value;
            if(!newDateStr) return alert('請選擇新日期！');
            
            let tasks = plan.grid[oldDateStr];
            let taskIdx = tasks.findIndex(t => t.id === taskId);
            if (taskIdx === -1) return alert('任務找不到！');
            
            let task = tasks[taskIdx];
            tasks.splice(taskIdx, 1); 
            
            if (!plan.grid[newDateStr]) plan.grid[newDateStr] = [];
            task.text = task.text.replace(/\[🔄 順延\]\s*/g, '');
            task.postponeCount = (task.postponeCount || 0) + 1;
            
            plan.grid[newDateStr].push(task);
            
            appLogs.push({ id: genId(), date: oldDateStr, category: '🔄 系統重排', mission: plan.name, subject: task.subject||'手動', unitName: 'DoubleCheck延期', start: task.startPage||0, end: task.endPage||0, pages: 0, detail: `從 ${oldDateStr} 手動順延至 ${newDateStr}` });
            
            saveToLocal();
            openDoubleCheck(); 
            renderCalendar();
            checkDailyWorkload(plan, newDateStr);
        }
        function deleteCalendarTaskDirect(dateStr, taskId) {
            if(!confirm("確定要直接刪除此落後任務嗎？")) return;
            let pid = el('planner-selector').value;
            let plan = appPlans.find(p => p.id === pid);
            if(Array.isArray(plan.grid[dateStr])) {
                plan.grid[dateStr] = plan.grid[dateStr].filter(t => t.id !== taskId);
            }
            appLogs = appLogs.filter(l => l.id !== 'cal_' + taskId);
            saveToLocal();
            openDoubleCheck();
            renderCalendar();
            renderDashboard();
            if (el('page-history') && el('page-history').style.display === 'block') renderHistoryTable();
        }
        // ==========================================
        // 修正處 2：修改開啓智慧排程精靈時的過濾邏輯
        // 導入 getUnitScheduleStatus，並自動將「剩餘未完成範圍」帶入
        // ==========================================
        function openWizard() {
            populateSelect('wz-cat', Object.keys(appMissions));
            
            var currentCat = el('planner-cat-filter') ? el('planner-cat-filter').value : 'ALL';
            var currentMis = el('planner-mis-filter') ? el('planner-mis-filter').value : 'ALL';
            if (currentCat !== 'ALL' && appMissions[currentCat]) {
                el('wz-cat').value = currentCat;
            }
            wzUpdateMis();
            
            if (currentCat !== 'ALL' && currentMis !== 'ALL' && appMissions[currentCat] && appMissions[currentCat][currentMis]) {
                el('wz-mis').value = currentMis;
            }
            wzUpdateSubjects();
            var prefs = loadWizardPrefs();
            for(let i=0; i<=6; i++) {
                if(prefs.hours && prefs.hours[i] !== undefined) {
                    el('wz-hrs-' + i).value = prefs.hours[i];
                }
            }
            if (el('wz-quickread-discount')) {
                el('wz-quickread-discount').value = prefs.quickReadDiscount || 60;
            }
            // v1.6.146: 同步智慧排程模式 UI 狀態 (radio → 邊框/描述)
            var initialModeRadio = document.querySelector('input[name="wz-schedule-mode"]:checked');
            if (initialModeRadio && typeof setWizardScheduleMode === 'function') {
                setWizardScheduleMode(initialModeRadio.value);
            }
            var dStart = new Date();
            el('wz-startdate').value = getLocalDateString(dStart);
            var dEnd = new Date(); dEnd.setMonth(dEnd.getMonth() + 1);
            el('wz-enddate').value = getLocalDateString(dEnd);
            // v1.5.112: 確保當前 plan 有 hourConfig, 讀取其 defaults 填入 wz-hrs-X
            var wizPlan = getCurrentWizardPlan();
            if (wizPlan) {
                ensurePlanHourConfig(wizPlan);
                var hcDefaults = wizPlan.hourConfig.defaults;
                for (let i = 0; i <= 6; i++) {
                    if (hcDefaults && hcDefaults[i] !== undefined) {
                        el('wz-hrs-' + i).value = hcDefaults[i];
                    }
                }
                renderHourOverrides();
            } else {
                var ovContainer = el('wz-overrides-container');
                if (ovContainer) ovContainer.innerHTML = '<div style="color:#7f8c8d; font-size:0.85em;">(請先選擇計畫名稱才能設定 override)</div>';
                // v1.5.113: plan 為 null 時 disable 新增按鈕
                var addBtn = document.querySelector('button[onclick="addHourOverride()"]');
                if (addBtn) {
                    addBtn.disabled = true;
                    addBtn.style.opacity = '0.5';
                    addBtn.style.cursor = 'not-allowed';
                    addBtn.title = '請先選擇計畫';
                }
            }
            // v1.5.113: 有 plan 時啟用按鈕
            var addBtn2 = document.querySelector('button[onclick="addHourOverride()"]');
            if (addBtn2 && wizPlan) {
                addBtn2.disabled = false;
                addBtn2.style.opacity = '1';
                addBtn2.style.cursor = 'pointer';
                addBtn2.title = '';
            }
            openModal('modal-wizard');
        }
        // v1.5.112: 取得 wizard 當前操作的 plan
        function getCurrentWizardPlan() {
            var pid = el('planner-selector').value;
            if (pid) {
                var p = appPlans.find(function(x){ return x.id === pid; });
                if (p) return p;
            }
            return null;
        }
        // v1.5.112: 渲染 wizard 內的 overrides 列表
        function renderHourOverrides() {
            var container = el('wz-overrides-container');
            if (!container) return;
            var plan = getCurrentWizardPlan();
            if (!plan) { container.innerHTML = ''; return; }
            ensurePlanHourConfig(plan);
            var overrides = plan.hourConfig.overrides || [];
            if (overrides.length === 0) {
                container.innerHTML = '<div style="color:#a8a29e; font-size:0.85em; padding:10px; text-align:center; background:rgba(255,255,255,0.6); border-radius:6px; border:1px dashed #fde047;">尚無設定 · 點上方「＋ 新增」建立</div>';
                return;
            }
            var html = '';
            overrides.forEach(function(ov, idx) {
                var daysShort = ['日', '一', '二', '三', '四', '五', '六'];
                // v1.5.114: 計算總時數
                var totalHours = 0;
                for (var i = 0; i <= 6; i++) {
                    totalHours += (ov.dailyHours && ov.dailyHours[i] !== undefined) ? ov.dailyHours[i] : 0;
                }
                // 計算天數
                var dayCount = 0;
                if (ov.start && ov.end) {
                    var s = new Date(ov.start), e = new Date(ov.end);
                    dayCount = Math.round((e - s) / 86400000) + 1;
                }
                var noteStr = ov.note ? ' · ' + ov.note : '';
                var specialDates = ov.specialDates || [];
                var hasRange = ov.start && ov.end;
                var hasSpecial = specialDates.length > 0;
                html += '<div style="background:#fffbeb; border:1px solid #fde047; border-radius:8px; padding:10px 12px; margin-bottom:8px;">';
                // 頂部: 日期 + 備註 + edit/delete
                html += '<div style="display:flex; justify-content:space-between; align-items:center; gap:10px; margin-bottom:' + (hasRange || hasSpecial ? '8px' : '0') + ';">';
                html += '<div style="flex:1; min-width:0; overflow:hidden;">';
                if (hasRange) {
                    html += '<div style="display:flex; align-items:center; gap:6px; margin-bottom:4px; flex-wrap:nowrap; white-space:nowrap; overflow:hidden;">';
                    html += '<span style="background:#a16207; color:white; padding:2px 8px; border-radius:10px; font-size:0.85em; font-weight:bold; flex-shrink:0;">' + dayCount + ' 天</span>';
                    var dateRangeStr = formatDateRange(ov.start, ov.end);
                    html += '<strong style="color:#92400e; flex-shrink:0;" title="' + ov.start + ' ~ ' + ov.end + '">' + dateRangeStr + '</strong>';
                    if (ov.note) html += '<span style="color:#a16207; font-size:0.85em; flex-shrink:1; overflow:hidden; text-overflow:ellipsis;">' + escapeHtml(ov.note) + '</span>';
                    html += '</div>';
                }
                if (!hasRange && ov.note) {
                    html += '<div style="color:#a16207; font-size:0.9em; font-weight:bold;">📍 ' + escapeHtml(ov.note) + '</div>';
                }
                if (!hasRange && !ov.note) {
                    html += '<div style="color:#a16207; font-size:0.85em;">(未命名)</div>';
                }
                html += '</div>';
                // 右: edit/delete 按鈕
                html += '<div style="display:flex; gap:4px; flex-shrink:0;">';
                html += '<button type="button" title="編輯" style="padding:4px 8px; background:#f59e0b; color:white; border:none; border-radius:5px; cursor:pointer; font-size:0.85em;" onclick="editHourOverride(' + idx + ')">✏️</button>';
                html += '<button type="button" title="刪除" style="padding:4px 8px; background:#ef4444; color:white; border:none; border-radius:5px; cursor:pointer; font-size:0.85em;" onclick="deleteHourOverride(' + idx + ')"></button>';
                html += '</div>';
                html += '</div>';
                // 中: 7 天時數條 + 總時數 (僅連續範圍)
                if (hasRange) {
                    html += '<div style="display:flex; gap:2px; align-items:center;">';
                    for (var i = 0; i <= 6; i++) {
                        var h = (ov.dailyHours && ov.dailyHours[i] !== undefined) ? ov.dailyHours[i] : 0;
                        var bgColor = h === 0 ? '#e5e7eb' : (h >= 1 ? '#3b82f6' : '#93c5fd');
                        var textColor = h === 0 ? '#9ca3af' : 'white';
                        html += '<div title="週' + daysShort[i] + ': ' + h + '小時" style="flex:1; min-width:24px; padding:3px 2px; text-align:center; background:' + bgColor + '; color:' + textColor + '; font-size:0.7em; border-radius:3px;">';
                        html += daysShort[i] + '<br>' + h;
                        html += '</div>';
                    }
                    html += '<div style="margin-left:8px; padding:2px 8px; background:#fef3c7; border:1px solid #fbbf24; border-radius:10px; font-size:0.8em; font-weight:bold; color:#92400e;">合計 ' + totalHours + 'h</div>';
                    html += '</div>';
                }
                // 下: 特殊日期 chip
                if (hasSpecial) {
                    html += '<div style="margin-top:8px; padding-top:8px; border-top:1px dashed #fde047; display:flex; gap:6px; flex-wrap:wrap; align-items:center;">';
                    html += '<span style="font-size:0.75em; color:#1e40af; font-weight:bold;">📍 特殊日期:</span>';
                    specialDates.forEach(function(sd) {
                        var sdNote = sd.note ? ' · ' + escapeHtml(sd.note) : '';
                        var sdColor = sd.hours === 0 ? '#94a3b8' : '#3b82f6';
                        html += '<span style="background:#dbeafe; color:#1e40af; padding:2px 8px; border-radius:10px; font-size:0.8em; font-weight:bold; border:1px solid #' + sdColor + ';">' + sd.date + ' · ' + sd.hours + 'h' + sdNote + '</span>';
                    });
                    html += '</div>';
                }
                html += '</div>';
            });
            container.innerHTML = html;
        }
        // v1.5.112: 新增 override
        function addHourOverride() {
            // v1.5.113: 防呆 - 如果沒有當前 plan, 不開 modal, 提示選 plan
            var plan = getCurrentWizardPlan();
            if (!plan) {
                alert('請先在上方選擇計畫名稱！\n\n(計畫名稱欄位 = 大分類 + 任務組合)\n選擇後才能設定自訂日期時數。');
                return;
            }
            window._editingOverrideIdx = -1;
            el('hov-start').value = '';
            el('hov-end').value = '';
            el('hov-note').value = '';
            for (var i = 0; i <= 6; i++) el('hov-h-' + i).value = 0;
            // v1.5.115: 初始化特殊日期為空
            window._hovSpecialDates = [];
            renderSpecialDatesInModal();
            openModal('modal-hour-override');
        }
        // v1.5.112: 編輯 override
        function editHourOverride(idx) {
            var plan = getCurrentWizardPlan();
            if (!plan) return;
            var ov = plan.hourConfig.overrides[idx];
            if (!ov) return;
            window._editingOverrideIdx = idx;
            el('hov-start').value = ov.start || '';
            el('hov-end').value = ov.end || '';
            el('hov-note').value = ov.note || '';
            for (var i = 0; i <= 6; i++) {
                el('hov-h-' + i).value = (ov.dailyHours && ov.dailyHours[i] !== undefined) ? ov.dailyHours[i] : 0;
            }
            // v1.5.115: 載入特殊日期
            window._hovSpecialDates = (ov.specialDates || []).map(function(sd) {
                return { date: sd.date || '', hours: sd.hours !== undefined ? sd.hours : 1.0, note: sd.note || '' };
            });
            renderSpecialDatesInModal();
            openModal('modal-hour-override');
        }
        // v1.5.112: 刪除 override
        function deleteHourOverride(idx) {
            var plan = getCurrentWizardPlan();
            if (!plan) return;
            ensurePlanHourConfig(plan);
            if (!confirm('確定要刪除這個自訂日期範圍？')) return;
            plan.hourConfig.overrides.splice(idx, 1);
            saveToLocal();
            renderHourOverrides();
        }
        // v1.5.112: 儲存 override (新增或編輯)
        function saveHourOverride() {
            var plan = getCurrentWizardPlan();
            if (!plan) {
                alert('請先選擇計畫！\n\n(請確認上方「計畫名稱」欄位已有值)\n選擇後才能儲存自訂日期時數。');
                return;
            }
            // v1.5.113: iOS Safari 相容性 - 強制 blur 確保 date picker 同步 .value
            try { el('hov-start').blur(); el('hov-end').blur(); } catch(e) {}
            ensurePlanHourConfig(plan);
            var start = el('hov-start').value;
            var end = el('hov-end').value;
            // v1.5.115: 允許只填特殊日期 (不需要連續範圍)
            var hasSpecialDates = (window._hovSpecialDates && window._hovSpecialDates.length > 0);
            if ((!start || !end) && !hasSpecialDates) {
                alert('請填寫「連續範圍」或至少一個「特殊日期」！\n\n(目前連續範圍: 開始="' + start + '", 結束="' + end + '")');
                return;
            }
            if (start && end && start > end) { alert('結束日期不能早於開始日期！'); return; }
            var dailyHours = {};
            for (var i = 0; i <= 6; i++) {
                dailyHours[i] = Number(el('hov-h-' + i).value) || 0;
            }
            // v1.5.115: 收集特殊日期 (過濾空值)
            var specialDates = [];
            if (window._hovSpecialDates) {
                window._hovSpecialDates.forEach(function(sd) {
                    if (sd.date) {
                        specialDates.push({
                            date: sd.date,
                            hours: Number(sd.hours) || 0,
                            note: sd.note || ''
                        });
                    }
                });
            }
            var ov = {
                start: start || '',
                end: end || '',
                dailyHours: dailyHours,
                note: el('hov-note').value || '',
                specialDates: specialDates
            };
            var idx = window._editingOverrideIdx;
            if (idx === undefined || idx < 0) {
                plan.hourConfig.overrides.push(ov);
            } else {
                plan.hourConfig.overrides[idx] = ov;
            }
            window._editingOverrideIdx = -1;
            window._hovSpecialDates = null;
            saveToLocal();
            closeModal('modal-hour-override');
            renderHourOverrides();
        }
        // v1.5.115: 特殊日期 UI helpers
        function addSpecialDateRow(date, hours, note) {
            if (!window._hovSpecialDates) window._hovSpecialDates = [];
            window._hovSpecialDates.push({
                date: date || '',
                hours: hours !== undefined ? hours : 1.0,
                note: note || ''
            });
            renderSpecialDatesInModal();
        }
        function removeSpecialDateRow(idx) {
            if (!window._hovSpecialDates) return;
            window._hovSpecialDates.splice(idx, 1);
            renderSpecialDatesInModal();
        }
        function renderSpecialDatesInModal() {
            var container = el('hov-special-dates-container');
            if (!container) return;
            var list = window._hovSpecialDates || [];
            if (list.length === 0) {
                container.innerHTML = '<div style="color:#94a3b8; font-size:0.85em; padding:8px; text-align:center;">尚無無特殊日期</div>';
                return;
            }
            var html = '';
            list.forEach(function(sd, idx) {
                html += '<div style="display:flex; gap:6px; align-items:center; background:white; padding:6px 8px; border-radius:6px; border:1px solid #cbd5e1; margin-bottom:6px;">';
                html += '<input type="date" value="' + (sd.date || '') + '" onchange="updateSpecialDateField(' + idx + ', \'date\', this.value)" style="padding:3px; border-radius:4px; border:1px solid #cbd5e1; font-size:0.9em; width:130px;">';
                html += '<input type="number" value="' + (sd.hours !== undefined ? sd.hours : 1.0) + '" min="0" step="0.5" onchange="updateSpecialDateField(' + idx + ', \'hours\', this.value)" style="padding:3px; border-radius:4px; border:1px solid #cbd5e1; font-size:0.9em; width:55px; text-align:center;">';
                html += '<span style="font-size:0.8em; color:var(--secondary);">小時</span>';
                html += '<input type="text" value="' + escapeHtml(sd.note || '') + '" placeholder="備註 (例: 模擬考)" onchange="updateSpecialDateField(' + idx + ', \'note\', this.value)" style="flex:1; padding:3px 6px; border-radius:4px; border:1px solid #cbd5e1; font-size:0.9em;">';
                html += '<button type="button" onclick="removeSpecialDateRow(' + idx + ')" style="background:#ef4444; color:white; border:none; padding:3px 7px; border-radius:4px; cursor:pointer; font-size:0.8em;" title="刪除">🗑</button>';
                html += '</div>';
            });
            container.innerHTML = html;
        }
        function updateSpecialDateField(idx, field, value) {
            if (!window._hovSpecialDates || !window._hovSpecialDates[idx]) return;
            window._hovSpecialDates[idx][field] = value;
        }
        function wzUpdateMis() { 
            var cat = el('wz-cat').value; 
            if(!cat || !appMissions[cat]) { populateSelect('wz-mis', []); } 
            else { populateSelect('wz-mis', Object.keys(appMissions[cat])); } 
            wzUpdateSubjects(); 
        }
        // v1.5.117: 預掃 plan.grid 建 Map[unitId] → {maxEnd, misMaxEnd}
// 取代原先逐個 unit 呼叫 getUnitScheduleStatus 掃描整個 grid
// 從 O(units × grid_size) 降到 O(grid_size + units) — 大幅加速
function buildScheduleMap(targetCat, targetMis) {
    var map = {};
    var pid = el('planner-selector') ? el('planner-selector').value : null;
    if (!pid && appPlans.length > 0) pid = appPlans[appPlans.length - 1].id;
    var plan = pid ? appPlans.find(function(p) { return p.id === pid; }) : null;
    if (!plan || !plan.grid) return map;
    for (var dateStr in plan.grid) {
        var tasks = plan.grid[dateStr];
        if (!Array.isArray(tasks)) continue;
        for (var ti = 0; ti < tasks.length; ti++) {
            var t = tasks[ti];
            if (!t.unitId) continue;
            var ep = Number(t.endPage) || 0;
            if (!map[t.unitId]) map[t.unitId] = { maxEnd: 0, misMaxEnd: 0 };
            var entry = map[t.unitId];
            if (ep > entry.maxEnd) entry.maxEnd = ep;
            if (targetCat && targetMis && t.cat === targetCat && t.mis === targetMis) {
                if (ep > entry.misMaxEnd) entry.misMaxEnd = ep;
            } else if (!targetCat || !targetMis) {
                entry.misMaxEnd = entry.maxEnd;
            }
        }
    }
    return map;
}
function wzUpdateSubjects() {
            var cat = el('wz-cat') ? el('wz-cat').value : '';
            var mis = el('wz-mis') ? el('wz-mis').value : '';
            var nameInput = el('wz-name');
            if (nameInput) { nameInput.value = (cat && mis) ? (cat + ' - ' + mis) : ''; }
            wizardSubjects = [];
            var prefs = loadWizardPrefs();
            if (cat && mis) {
                var mTree = buildMissionTree(cat, mis);
                var subKeys = Object.keys(mTree);
                subKeys = getSortedSubjects(subKeys);
                // v1.5.117 + v1.5.119: 用共用 cache 讀 schedule map
                var scheduleMap = getScheduleMapFromCache(cat, mis);
                subKeys.forEach(sub => {
                    var sTree = mTree[sub];
                    var availableUnits = [];
                    var extract = (u, volName, typeName, instanceName) => {
                        var sm = scheduleMap[u.id] || { maxEnd: 0, misMaxEnd: 0 };
                        // v1.5.24: 移除 isFullyScheduled filter，全部顯示讓用戶自由選擇要不要再排
                        availableUnits.push({ id: u.id, name: u.name, vol: volName, typeName: typeName || '', instanceName: instanceName || '', uObj: { ...u }, misMaxEnd: sm.misMaxEnd, quickRead: false });
                    };
                    if (sTree.type === 'custom') {
                        sTree.items['custom'].forEach(u => extract(u, '', '', ''));
                    } else {
                        var vols = Object.keys(sTree.items); // v1.6.136: 包含 instance-prefixed vol
                        vols.forEach(v => sTree.items[v].forEach(u => extract(u, v, u._typeName || '', u._instanceName || '')));
                    }
                    if (availableUnits.length > 0) {
                        var defProgVal = (prefs.subjects && prefs.subjects[sub] && prefs.subjects[sub].progVal) ? prefs.subjects[sub].progVal : 1;
                        var defHours = (prefs.subjects && prefs.subjects[sub] && prefs.subjects[sub].hoursPerUnit) ? prefs.subjects[sub].hoursPerUnit : 2.0;
                        // v1.5.24: 未排過的（misMaxEnd===0）排在前面，已排過的排在後面
                        // v1.5.29: 排序 — 三層優先序
                            // 1. 屬於當前 mission (unitId 在 appMissions[cat][mis] 裡) 的未排過 → 最前面
                            // 2. 屬於當前 mission 的已排過
                            // 3. 不屬於當前 mission 的未排過
                            // 4. 不屬於當前 mission 的已排過
                            // 同優先序內按頁數排序
                            var misUnitIds = (appMissions[cat] && appMissions[cat][mis]) ? appMissions[cat][mis] : [];
                            var misSet = new Set(misUnitIds);
                            availableUnits.sort((a, b) => {
                                var aInMis = misSet.has(a.id) ? 0 : 1;
                                var bInMis = misSet.has(b.id) ? 0 : 1;
                                var aUnscheduled = (a.misMaxEnd === 0) ? 0 : 1;
                                var bUnscheduled = (b.misMaxEnd === 0) ? 0 : 1;
                                // 兩層 key 合併排序: inMis * 2 + unscheduled
                                var aKey = aInMis * 2 + aUnscheduled;
                                var bKey = bInMis * 2 + bUnscheduled;
                                if (aKey !== bKey) return aKey - bKey;
                                return (Number(a.uObj.start)||0) - (Number(b.uObj.start)||0);
                            });
                        var savedMode = (prefs.subjects && prefs.subjects[sub] && prefs.subjects[sub].displayMode) ? prefs.subjects[sub].displayMode : (prefs.globalDisplayMode || 'D');
                        // v1.5.112: default 改為非全選, 用戶主動勾選要的 unit
                        var allUIds = availableUnits.map(u => u.id);
                        var savedSel = (prefs.subjects && prefs.subjects[sub] && prefs.subjects[sub].selectedUnitIds) ? prefs.subjects[sub].selectedUnitIds : [];
                        var selectedUnitIds = [];
                        var savedSet = new Set(savedSel);
                        allUIds.forEach(function(uid) { if (savedSet.has(uid)) selectedUnitIds.push(uid); });
                        // v1.6.141: 從 prefs 讀 scheduleMode/daysPerUnit (Migration fallback 到頁面級或預設)
                        var savedScheduleMode = (prefs.subjects && prefs.subjects[sub] && prefs.subjects[sub].scheduleMode) ? prefs.subjects[sub].scheduleMode : (prefs.scheduleMode || 'hours');
                        var savedDaysPerUnit = (prefs.subjects && prefs.subjects[sub] && prefs.subjects[sub].daysPerUnit) ? prefs.subjects[sub].daysPerUnit : 2;
                        wizardSubjects.push({
                            name: sub,
                            progVal: defProgVal,
                            progType: 'unit',
                            hoursPerUnit: defHours,
                            availableUnits: availableUnits,
                            selectedUnitIds: selectedUnitIds,  // v1.5.112: default 為空 (除非 prefs 有保存)
                            displayMode: savedMode,
                            scheduleMode: savedScheduleMode,  // v1.6.141
                            daysPerUnit: savedDaysPerUnit,    // v1.6.141
                            collapsed: {} // key: groupKey → true/false
                        });
                    }
                });
            }
            renderWizardSubjects();
            // v1.6.152: 顯示載入統計 (幫助診斷「看不到單元」)
            try {
                var totalAvail = 0, totalSelected = 0;
                wizardSubjects.forEach(function(ws) {
                    totalAvail += ws.availableUnits.length;
                    totalSelected += ws.selectedUnitIds.length;
                });
                console.log('[v1.6.152 wzUpdateSubjects] ' + wizardSubjects.length + ' 個科目, ' + totalAvail + ' 個可用單元, ' + totalSelected + ' 個已選');
                wizardSubjects.forEach(function(ws, i) {
                    var scheduled = ws.availableUnits.filter(function(u) { return u.misMaxEnd > 0; }).length;
                    console.log('  [' + i + '] ' + ws.name + ': ' + ws.availableUnits.length + ' 個可用 (' + scheduled + ' 已排, ' + (ws.availableUnits.length - scheduled) + ' 未排)');
                });
            } catch(e) {}
        }
        
        function renderWizardSubjects() { 
            var container = el('wz-step2-container');
            // v1.6.153: 統計所有科目加總單元數,有科目但沒單元時提示
            var totalAvailAll = wizardSubjects.reduce(function(sum, ws) { return sum + ws.availableUnits.length; }, 0);
            if (wizardSubjects.length === 0) {
                container.innerHTML = '<div style="color:#7f8c8d; padding:10px; border:1px solid var(--border); border-radius:8px; background:white;">此專案尚未設定任何教材範圍，或者所有單元皆已排入月曆中。</div>';
                return;
            }
            if (totalAvailAll === 0) {
                // v1.6.153: 有科目但都沒單元 — 給明確指引
                var subjNames = wizardSubjects.map(function(ws){return ws.name;}).join('、');
                var mTxt = (el('wz-mis') && el('wz-mis').value) ? el('wz-mis').value : '(未選)';
                var cTxt = (el('wz-cat') && el('wz-cat').value) ? el('wz-cat').value : '(未選)';
                container.innerHTML = '<div style="background:#fee2e2; border:1px solid #fca5a5; border-radius:8px; padding:14px 16px; color:#991b1b; line-height:1.6;">' +
                    '<h3 style="margin-top:0; color:#991b1b;">⚠️ 當前專案 (類別: ' + escapeHtml(cTxt) + ', 任務: ' + escapeHtml(mTxt) + ') 找不到任何單元</h3>' +
                    '<p>系統偵測到 ' + wizardSubjects.length + ' 個科目 (' + escapeHtml(subjNames) + '),但每個科目的單元清單都是空的。</p>' +
                    '<p><b>可能原因:</b></p>' +
                    '<ul style="margin-left:20px;">' +
                    '<li>當前任務 (mission) 的 unitIds 與教材庫 (master) 的 unitId 對應不上</li>' +
                    '<li>教材庫結構有變更,需重新整理頁面 (Ctrl+Shift+R)</li>' +
                    '</ul>' +
                    '<p style="margin-bottom:0;">💡 <b>建議:</b> 試試別的 mission (任務),或按 F12 → Console 看 [v1.6.152 wzUpdateSubjects] 訊息截圖給開發者。</p>' +
                    '</div>';
                return;
            }
            var html = '';
            // v1.5.114: 批次快捷按鈕
            html += '<div style="display:flex; gap:8px; margin-bottom:12px; flex-wrap:wrap; padding:8px; background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px;">';
            html += '<span style="font-weight:bold; color:var(--secondary); font-size:0.85em; display:flex; align-items:center;">⚡ 批次:</span>';
            html += '<button type="button" onclick="selectUnscheduledUnits()" style="background:#3b82f6; color:white; border:none; padding:5px 12px; border-radius:5px; cursor:pointer; font-size:0.85em;" title="自動勾選所有 misMaxEnd===0 的 unit">☀️ 只勾選未排過的</button>';
            html += '<button type="button" onclick="selectScheduledUnits()" style="background:#f59e0b; color:white; border:none; padding:5px 12px; border-radius:5px; cursor:pointer; font-size:0.85em;" title="自動勾選所有 misMaxEnd>0 的 unit (已排過的)">🔁 只勾選已排過的</button>';
            html += '<button type="button" onclick="selectAllUnits()" style="background:#10b981; color:white; border:none; padding:5px 12px; border-radius:5px; cursor:pointer; font-size:0.85em;" title="勾選全部">☑ 全部勾選</button>';
            html += '<button type="button" onclick="clearAllUnits()" style="background:#94a3b8; color:white; border:none; padding:5px 12px; border-radius:5px; cursor:pointer; font-size:0.85em;" title="取消全部">☐ 全部取消</button>';
            html += '</div>';
            wizardSubjects.forEach((ws, i) => {
                var allSelected = (ws.availableUnits.length > 0) && (ws.selectedUnitIds.length === ws.availableUnits.length);
                var someSelected = ws.selectedUnitIds.length > 0 && !allSelected;
                var isMasterChecked = allSelected ? 'checked' : '';
                var isMasterIndet = someSelected ? 'data-indet="1"' : '';
                var selCount = ws.selectedUnitIds.length;
                var totalCount = ws.availableUnits.length;
                var masterLabel = allSelected ? '☑ 全選 (取消)' : (someSelected ? '▣ 部分已選 (' + selCount + '/' + totalCount + ')' : '☐ 全部未選 (全選)');
                html += `<div style="background: white; border: 1px solid var(--border); border-radius: 8px; margin-bottom: 15px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
                    <div style="background: var(--primary); color: white; padding: 10px 15px; font-weight: bold; display:flex; justify-content:space-between; align-items:center;">
                        <span>📘 ${ws.name}</span>
                        <div>
                            <label style="margin-right:10px; font-size:0.9em; cursor:pointer; ${someSelected ? 'color:#fbbf24; font-weight:bold;' : ''}"><input type="checkbox" class="wz-master-cb" ${isMasterChecked} ${isMasterIndet} onchange="toggleWizardSubjectUnits(${i}, this.checked)" style="width:auto; margin-right:5px;"><span class="wz-master-label">${masterLabel}</span></label>
                        </div>
                    </div>
                    <div style="padding: 15px;">
                        <div style="display: flex; gap: 15px; margin-bottom: 15px; flex-wrap: wrap; align-items:center; background:#f8fafc; padding:10px; border-radius:6px; border:1px solid #e2e8f0;">
                            <div>
                                <label style="display:inline; margin-right:5px; font-weight:bold; color:var(--secondary);">每週預定完成 單元數:</label>
                                <input type="number" value="${ws.progVal}" step="0.5" min="0.5" style="width:70px; padding:6px; border-radius:4px; border:1px solid #ccc;" onchange="wizardSubjects[${i}].progVal=Math.max(0.5, Number(this.value)); saveWizardPrefs(); renderWizardSubjects();" title="每週預定完成的單元數量">
                            </div>
                            <div>
                                <label style="display:inline; margin-right:5px; font-weight:bold; color:var(--secondary);">每單元所需時數:</label>
                                <input type="number" value="${ws.hoursPerUnit}" min="0.5" step="0.5" list="hours-list" style="width:70px; padding:6px; border-radius:4px; border:1px solid #ccc;" onchange="wizardSubjects[${i}].hoursPerUnit=Math.max(0.5, Number(this.value)); saveWizardPrefs(); renderWizardSubjects();"> 小時
                            </div>
                            <!-- v1.6.141: 單元模式 B 額外欄位 -->
                            ${ws.scheduleMode === 'units' ? `
                            <div style="display:flex; gap:8px; align-items:center; background:#f0f9ff; padding:6px 10px; border-radius:6px; border:1px solid #7dd3fc;">
                                <span style="font-size:0.82em; color:#0369a1; font-weight:bold;">📅 單元模式:</span>
                                <label style="font-size:0.82em;">每 unit 分</label>
                                <input type="number" value="${ws.daysPerUnit}" min="1" step="1" style="width:55px; padding:5px; border-radius:4px; border:1px solid #7dd3fc;" onchange="wizardSubjects[${i}].daysPerUnit=Math.max(1, Math.round(Number(this.value))); saveWizardPrefs(); renderWizardSubjects();">
                                <span style="font-size:0.82em;">天讀完 → 每天讀此 unit:</span>
                                <strong style="color:#0369a1; font-size:0.95em;">${(Number(ws.hoursPerUnit) / Math.max(1, Number(ws.daysPerUnit))).toFixed(2)} 小時</strong>
                            </div>
                            ` : ''}
                            <div style="margin-left:auto; display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                                <span style="font-weight:bold; color:var(--secondary); font-size:0.85em;">顯示方式:</span>
                                ${['A','B','C','D','E'].map(function(m){
                                    var labels = {A:'教材類型', B:'冊數/版本', C:'mission+篩選', D:'標籤', E:'摺疊'};
                                    var checked = ws.displayMode === m ? 'checked' : '';
                                    return '<label style="font-size:0.8em; cursor:pointer; padding:3px 8px; border-radius:12px; border:1px solid ' + (ws.displayMode === m ? 'var(--accent)' : '#cbd5e1') + '; background:' + (ws.displayMode === m ? '#e0f2fe' : 'white') + ';"><input type="radio" name="wz-dm-' + i + '" value="' + m + '" ' + checked + ' onchange="setWizardDisplayMode(' + i + ', \'' + m + '\')" style="display:none;">' + labels[m] + '</label>';
                                }).join('')}
                            </div>
                        </div>
                        <div class="vertical-scroll" style="max-height: 180px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; background:#fff;">`;
                // v1.5.24: 全科目的快讀按鈕
                var hasScheduled = ws.availableUnits.some(u => u.misMaxEnd > 0);
                if (hasScheduled) {
                    html += `<div style="margin-bottom:10px;">
                        <button onclick="setAllQuickRead(${i}, true)" style="background:#f59e0b; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer; font-size:0.85em; margin-right:6px;">☀️ 全部已讀完的設為快讀</button>
                        <button onclick="setAllQuickRead(${i}, false)" style="background:#94a3b8; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer; font-size:0.85em;">↺ 取消全部快讀</button>
                    </div>`;
                }
                // v1.5.33: 依 displayMode 選擇渲染方式
                var mode = ws.displayMode || 'D';
                if (mode === 'D' || mode === 'A' || mode === 'B' || mode === 'C' || mode === 'E') {
                    if (mode === 'D') {
                        // v1.5.173: 模式 D 預設摺疊 (只顯示前 10 個 unit, 避免 Safari 一次 layout 太多 DOM)
                        // 解決「建立智慧排程」按鈕在 Safari 4-8 秒延遲 (root cause: Layout & Rendering, JS 瞬間)
                        var COLLAPSE_THRESHOLD = 10;
                        var isCollapsed = ws._modeDCollapsed === true;  // v1.6.152: 改預設展開 (讓用戶看到所有單元,包括已排過的)
                        var visibleUnits = isCollapsed ? ws.availableUnits.slice(0, COLLAPSE_THRESHOLD) : ws.availableUnits;
                        // v1.6.154: 顯示 mission 與 master 範圍的比較,讓用戶了解為什麼有些 unit 不見
                        var _debugCat = (el('wz-cat') && el('wz-cat').value) || '?';
                        var _debugMis = (el('wz-mis') && el('wz-mis').value) || '?';
                        var _misUnitCount = (appMissions[_debugCat] && appMissions[_debugCat][_debugMis]) ? appMissions[_debugCat][_debugMis].length : 0;
                        var _masterUnitCount = ws.availableUnits.length;
                        html += `<div style="background:#f5f3ff; border:1px solid #c4b5fd; border-radius:6px; padding:6px 12px; margin-bottom:6px; font-size:0.78em; color:#5b21b6;">
                            🔍 任務「${escapeHtml(_debugMis)}」的 unitIds 數 = ${_misUnitCount} · 科目「${escapeHtml(ws.name)}」在 master 內 unit 數 = ${ws.availableUnits.length}
                        </div>`;
                        // v1.6.153: 偵測 availableUnits 為 0 但科目應有 unit → 提示用戶
                        if (ws.availableUnits.length === 0) {
                            html += `<div style="background:#fee2e2; border:1px solid #fca5a5; border-radius:6px; padding:10px 14px; margin-bottom:8px; font-size:0.88em; color:#991b1b;">
                                ⚠️ <b>本科目 (${escapeHtml(ws.name)}) 在當前任務 (${escapeHtml(_debugMis)}) 找不到單元</b><br>
                                <span style="font-size:0.9em;">任務「${escapeHtml(_debugMis)}」內 ${escapeHtml(ws.name)} 的 unitId 數 = <b>${_misUnitCount}</b> (全部科目合計)</span><br>
                                可能原因:
                                <ul style="margin:4px 0 0 20px; padding:0;">
                                    <li>當前任務 (mission) 不包含 ${escapeHtml(ws.name)} 的單元 (mission 切到別的任務了)</li>
                                    <li>教材庫 (master) 沒有 ${escapeHtml(ws.name)} 的單元資料</li>
                                    <li>所有單元皆在別的任務中,當前 mission 沒對應到</li>
                                </ul>
                                💡 <b>建議:</b> 換到別的任務 (mission),或確認教材庫有資料
                            </div>`;
                        }
                        // v1.6.152: 顯示單元統計 (總數/已選/已排過/未排過) — 幫助診斷「看不到單元」問題
                        var schedCount = ws.availableUnits.filter(function(u){return u.misMaxEnd>0;}).length;
                        var unschedCount = ws.availableUnits.length - schedCount;
                        // v1.6.156: 把已排過/未排的 unit 名列出來 (最多各 5 個) — Denias 看了就能確認「看不到的單元到底是哪些」
                        var schedNames = ws.availableUnits.filter(function(u){return u.misMaxEnd>0;}).slice(0, 5).map(function(u){return u.name;}).join(', ');
                        var unschedNames = ws.availableUnits.filter(function(u){return u.misMaxEnd===0;}).slice(0, 5).map(function(u){return u.name;}).join(', ');
                        html += `<div style="background:#f0f9ff; border:1px solid #7dd3fc; border-radius:6px; padding:6px 12px; margin-bottom:8px; font-size:0.82em; color:#0369a1; display:flex; gap:12px; flex-wrap:wrap;">
                            <span>📦 <b>總計 ${ws.availableUnits.length}</b> 個單元</span>
                            <span>✅ 已選: <b>${ws.selectedUnitIds.length}</b></span>
                            <span>📅 已排過: <b style="color:#c2410c;">${schedCount}</b></span>
                            <span>☀️ 未排: <b style="color:#15803d;">${unschedCount}</b></span>
                            ${schedCount > 0 ? '<span style="margin-left:auto; color:#7c2d12;">💡 已排過的排在後面</span>' : ''}
                        </div>`;
                        // v1.6.156: 顯示「未排」unit 名稱前 5 個,讓 Denias 確認 list 上的單元有哪些
                        if (unschedNames) {
                            html += `<div style="font-size:0.78em; color:#15803d; margin-bottom:6px;">☀️ 未排 (顯示): ${escapeHtml(unschedNames)}${unschedCount > 5 ? ' …' : ''}</div>`;
                        }
                        if (schedNames) {
                            html += `<div style="font-size:0.78em; color:#c2410c; margin-bottom:6px;">📅 已排過 (排在後面): ${escapeHtml(schedNames)}${schedCount > 5 ? ' …' : ''}</div>`;
                        }
                        visibleUnits.forEach(u => {
                            html += renderWizardUnitRowHtml(ws, i, u);
                        });
                        if (ws.availableUnits.length > COLLAPSE_THRESHOLD) {
                            var hidden = ws.availableUnits.length - COLLAPSE_THRESHOLD;
                            var subjKey = 'd_' + i;
                            html += `<div class="wz-show-more" onclick="toggleWizardModeD(${i})">${isCollapsed ? '▶ 展開更多 (' + hidden + ' 個)' : '▼ 收合 (只看前 ' + COLLAPSE_THRESHOLD + ' 個)'}</div>`;
                        }
                    } else {
                        // 模式 A/B/C/E：分組渲染
                        var groups = {};
                        ws.availableUnits.forEach(u => {
                            var k = getGroupKey(mode, u);
                            if (!groups[k]) groups[k] = [];
                            groups[k].push(u);
                        });
                        Object.keys(groups).forEach(gKey => {
                            var gUnits = groups[gKey];
                            var allGChecked = gUnits.every(u => ws.selectedUnitIds.includes(u.id));
                            var isCollapsed = ws.collapsed[gKey];
                            html += `<div style="margin-bottom:8px; border:1px solid #e2e8f0; border-radius:6px; background:#fffbeb;">`;
                            html += `<div style="display:flex; align-items:center; padding:8px 10px; background:#fef3c7; cursor:pointer;" onclick="toggleWizardGroup(${i}, '${escapeHtml(gKey).replace(/'/g, "\\'")}')">`;
                            html += `<span style="margin-right:8px; font-weight:bold;">${isCollapsed ? '▶' : '▼'}</span>`;
                            html += `<span style="font-weight:bold; color:#92400e;">📦 ${gKey}</span>`;
                            html += `<span style="margin-left:8px; color:#78716c; font-size:0.85em;">(${gUnits.length} 個單元)</span>`;
                            html += `<label style="margin-left:auto; font-size:0.85em;" onclick="event.stopPropagation();"><input type="checkbox" class="wz-group-cb" ${allGChecked ? 'checked' : ''} onchange="toggleWizardGroupUnits(${i}, '${escapeHtml(gKey).replace(/'/g, "\\'")}', this.checked)" style="width:auto; margin-right:4px;">全選</label>`;
                            html += `</div>`;
                            if (!isCollapsed) {
                                html += `<div style="padding:8px;">`;
                                gUnits.forEach(u => {
                                    html += renderWizardUnitRowHtml(ws, i, u);
                                });
                                html += `</div>`;
                            }
                            html += `</div>`;
                        });
                    }
                }
                html += `</div></div></div>`;
            });
            container.innerHTML = html;
            // v1.5.112: 設定 indeterminate state (部分已選時)
            container.querySelectorAll('input[data-indet="1"]').forEach(function(cb) {
                cb.indeterminate = true;
            });
            // v1.5.112: debug log 顯示 selectedUnitIds 統計, 方便追蹤 bug 2
            wizardSubjects.forEach(function(ws, i) {
                if (ws.availableUnits.length > 0) {
                    console.log('[wizard ' + ws.name + '] selected: ' + ws.selectedUnitIds.length + '/' + ws.availableUnits.length);
                }
            });
        }
        // v1.5.173: 模式 D 展開/收合
        function toggleWizardModeD(subjIdx) {
            var ws = wizardSubjects[subjIdx];
            // 預設 collapsed (true), click 後變 false (展開), 再 click 變 true (收合)
            ws._modeDCollapsed = ws._modeDCollapsed === false;
            renderWizardSubjects();
        }
        // v1.5.33: 切換科目的顯示方式 (A/B/C/D/E)
        function setWizardDisplayMode(subjIdx, mode) {
            wizardSubjects[subjIdx].displayMode = mode;
            saveWizardPrefs();
            renderWizardSubjects();
        }
        // v1.5.33: 展開 / 收合群組
        function toggleWizardGroup(subjIdx, groupKey) {
            var ws = wizardSubjects[subjIdx];
            ws.collapsed[groupKey] = !ws.collapsed[groupKey];
            renderWizardSubjects();
        }
        // v1.5.33: 群組內的全選 / 取消全選
        function toggleWizardGroupUnits(subjIdx, groupKey, isChecked) {
            var ws = wizardSubjects[subjIdx];
            var groupUnits = ws.availableUnits.filter(function(u){
                return getGroupKey(ws.displayMode, u) === groupKey;
            });
            if (isChecked) {
                groupUnits.forEach(function(u){
                    if (ws.selectedUnitIds.indexOf(u.id) === -1) ws.selectedUnitIds.push(u.id);
                });
            } else {
                var removeIds = groupUnits.map(function(u){ return u.id; });
                ws.selectedUnitIds = ws.selectedUnitIds.filter(function(id){ return removeIds.indexOf(id) === -1; });
            }
            // v1.5.114: 不重建整個 DOM, 只更新此科目所有 unit + master
            updateSubjectUnitCheckboxes(subjIdx);
            updateSubjectMasterUI(subjIdx);
            debouncedSaveWizardPrefs();
        }
        function getGroupKey(mode, u) {
            if (mode === 'A') return u.typeName || '(未分類)';
            if (mode === 'B') return u.instanceName || u.vol || '(未分類)';
            if (mode === 'C') return u.misMaxEnd > 0 ? '已排過' : '未排過';
            return '_flat'; // D 和 E 不分組
        }
        // v1.5.35: 通用單元 HTML 渲染 (wizard + manual add 共用)
// opts = { isChecked, onChange, showQuickRead, u.quickRead, displayMode, context }
// v1.5.119: schedule map cache — 避免 isUnitScheduledAnywhere 每次都掃描所有 plan.grid
// renderWizardSubjects 內毎 unit 都會呼叫, 270 units × O(grid_size) 變 270 × O(1)
function getScheduleMapFromCache(targetCat, targetMis) {
    var pid = el('planner-selector') ? el('planner-selector').value : null;
    if (!pid && appPlans.length > 0) pid = appPlans[appPlans.length - 1].id;
    var key = (pid || 'null') + '|' + (targetCat || '') + '|' + (targetMis || '');
    if (window._schedCache && window._schedCache.key === key) return window._schedCache.map;
    var plan = pid ? appPlans.find(function(p) { return p.id === pid; }) : null;
    var map = {};
    if (plan && plan.grid) {
        for (var dateStr in plan.grid) {
            var tasks = plan.grid[dateStr];
            if (!Array.isArray(tasks)) continue;
            for (var ti = 0; ti < tasks.length; ti++) {
                var t = tasks[ti];
                if (!t.unitId) continue;
                var ep = Number(t.endPage) || 0;
                if (!map[t.unitId]) map[t.unitId] = { maxEnd: 0, misMaxEnd: 0 };
                var entry = map[t.unitId];
                if (ep > entry.maxEnd) entry.maxEnd = ep;
                if (targetCat && targetMis && t.cat === targetCat && t.mis === targetMis) {
                    if (ep > entry.misMaxEnd) entry.misMaxEnd = ep;
                } else if (!targetCat || !targetMis) {
                    entry.misMaxEnd = entry.maxEnd;
                }
            }
        }
    }
    window._schedCache = { key: key, map: map };
    return map;
}
function invalidateSchedCache() {
    window._schedCache = null;
}
function isUnitScheduledAnywhere(u) {
    // v1.5.100: 修 bug — 不只檢查「有任務」, 還要檢查「任務 maxEndPage >= 單元 end」
    // 否則只排了一半的單元會被誤判為「已排過」, 教材庫顯示黃色
    // v1.5.101: 加 debug log + 容錯 u.end 是字串/數字/undefined
    // v1.5.116: 支援 u.uObj.end (availU 結構)
    // v1.5.119: 用 schedule map cache, 避免每次掃描所有 plan.grid
    var cat = el('wz-cat') ? el('wz-cat').value : '';
    var mis = el('wz-mis') ? el('wz-mis').value : '';
    var sm = getScheduleMapFromCache(cat, mis)[u.id];
    var maxEndFound, misMaxEnd;
    if (sm) {
        maxEndFound = sm.maxEnd;
        misMaxEnd = sm.misMaxEnd;
    } else {
        // fallback: 沒 cache (非 wizard 環境), 用舊邏輯
        maxEndFound = 0;
        if (u.misMaxEnd && u.misMaxEnd > 0) maxEndFound = Math.max(maxEndFound, Number(u.misMaxEnd));
        for (var pi = 0; pi < appPlans.length; pi++) {
            var pgrid = appPlans[pi].grid || {};
            for (var d in pgrid) {
                var tasks = pgrid[d] || [];
                for (var ti = 0; ti < tasks.length; ti++) {
                    if (tasks[ti].unitId === u.id) {
                        var ep = Number(tasks[ti].endPage) || 0;
                        if (ep > maxEndFound) maxEndFound = ep;
                    }
                }
            }
        }
        misMaxEnd = maxEndFound;
    }
    var uEnd = Number(u.uObj ? u.uObj.end : u.end);
    if (uEnd > 0) {
        var result = maxEndFound >= uEnd;
        // v1.5.101: debug log 第一次執行
        if (!window._v5101Logged) {
            console.log('[isUnitScheduledAnywhere] u.id=' + u.id + ', u.end=' + (u.uObj ? u.uObj.end : u.end) + ' (=' + uEnd + '), maxEndFound=' + maxEndFound + ', return=' + result);
            window._v5101Logged = true;
        }
        return result;
    }
    return maxEndFound > 0;
}
// v1.5.107: 用 task 重疊頁數算每個 unit 的 donePages (用全部 cat, 不只 appMaster)
// v1.5.163: 簡單對應算法 - 對每個 mission 內 unit, 算 task.unitId === this unit.id 的 done pages
// 不用 overlap 跨單元分布 (避免跨單元任務的 pages 算到別 unit)
// v1.5.169: 簡單對應 + 跨單元任務補 overlap (mission 內 unit)
// 對每 isDone task:
//   1. task.unitId === unit.id (簡單對應): 加 task.pages 到 unit
//   2. task 跨 unit (跨單元任務): 加 overlap pages 到 unit (mission 內)
// 避免重複: 同一 task 的同一 page 只算進一個 unit
// v1.5.229 FIX: 還原 v1.5.228 正確 overlap 演算法 + 幽靈 unit 提前過濾
// 重點: overlap 分布是正確的設計(跨單元任務本該如此)，幽靈 unit 問題在 processUnit 過濾
function getUnitDonePagesByUnitIdMatch(filterCat, filterMis) {
    var result = {};
    if (!appPlans) return result;
    // v1.5.171: 跨單元任務 overlap + Set 去重 (mission 內 unit, 一致算法)
    var pageSet = {};
    var missionUnitMap = {};
    var masters = (multiData && multiData[currentUserId]) ? multiData[currentUserId].masters : null;
    var allCats = (filterCat && filterCat !== 'ALL') ? [filterCat] : (masters ? Object.keys(masters) : []);
    allCats.forEach(function(c) {
        var catMaster = masters ? masters[c] : null;
        if (!catMaster) return;
        Object.keys(catMaster).forEach(function(sub) {
            var s = catMaster[sub];
            if (!s) return;
            _collectSubjectUnits(s).forEach(function(u) {
                if (u && u.id) missionUnitMap[u.id] = { start: u.start, end: u.end, sub: sub };
            });
        });
    });
    function addPageSet(uid, s, e) {
        if (!pageSet[uid]) pageSet[uid] = new Set();
        for (var p = s; p <= e; p++) pageSet[uid].add(p);
    }
    appPlans.forEach(function(plan) {
        if (!plan.grid) return;
        Object.keys(plan.grid).forEach(function(dStr) {
            (plan.grid[dStr] || []).forEach(function(t) {
                if (!t || !t.isDone || !t.unitId) return;
                if (filterCat && filterCat !== 'ALL' && t.cat !== filterCat) return;
                if (filterMis && filterMis !== 'ALL' && t.mis !== filterMis) return;
                if (!t.startPage || !t.endPage || t.endPage < t.startPage) {
                    addPageSet(t.unitId, 1, 1);
                    return;
                }
                var s = t.startPage, e = t.endPage;
                var taskUnitInfo = missionUnitMap[t.unitId];
                var taskSub = taskUnitInfo ? taskUnitInfo.sub : null;
                Object.keys(missionUnitMap).forEach(function(uid) {
                    var u = missionUnitMap[uid];
                    if (!u || u.start === undefined || u.end === undefined) return;
                    if (u.sub !== taskSub) return;
                    // v1.6.51: skip overlap if this unit was never directly scheduled (no tasks in appPlans)
                    if (!window._treeScheduledUnits || !window._treeScheduledUnits[uid] || window._treeScheduledUnits[uid].totalTasks === 0) return;
                    var us = Math.max(s, u.start);
                    var ue = Math.min(e, u.end);
                    if (ue >= us) addPageSet(uid, us, ue);
                });
            });
        });
    });
    Object.keys(pageSet).forEach(function(uid) { result[uid] = pageSet[uid].size; });
    return result;
}
function getUnitDonePagesByOverlap(filterCat, filterMis) {
    var result = {};
    if (!appPlans || appPlans.length === 0) return result;
    var allUnits = {};
    var masters = (multiData && multiData[currentUserId]) ? multiData[currentUserId].masters : null;
    function collectUnits(s, subj) {
        if (!s || !s.materials) return;
        Object.keys(s.materials).forEach(function(mt) {
            var mat = s.materials[mt];
            if (!mat || !mat.instances) return;
            mat.instances.forEach(function(inst) {
                if (!inst) return;
                if (inst.vols && typeof inst.vols === 'object') {
                    Object.keys(inst.vols).forEach(function(volName) {
                        (inst.vols[volName] || []).forEach(function(u) {
                            if (u && u.id && !allUnits[u.id]) {
                                // v1.6.166: 加 vol 欄位,讓 overlap 能區分跨冊 unit (例: L1~2 在第二冊 vs 第三冊 都有 P.1)
                                allUnits[u.id] = {name: u.name, start: u.start, end: u.end, subj: subj, vol: volName};
                            }
                        });
                    });
                }
                if (inst.units && Array.isArray(inst.units)) {
                    inst.units.forEach(function(u) {
                        if (u && u.id && !allUnits[u.id]) {
                            allUnits[u.id] = {name: u.name, start: u.start, end: u.end, subj: subj};
                        }
                    });
                }
            });
        });
    }
    if (masters) {
        Object.keys(masters).forEach(function(cat) {
            var catSubjects = masters[cat];
            if (!catSubjects) return;
            Object.keys(catSubjects).forEach(function(subj) {
                collectUnits(catSubjects[subj], subj);
            });
        });
    }
    // fallback 用 appMaster
    if (Object.keys(allUnits).length === 0 && appMaster) {
        Object.keys(appMaster).forEach(function(subj) {
            collectUnits(appMaster[subj], subj);
        });
    }
    // v1.5.187 fix: 完全還原 v1.5.174 跨單元任務邏輯 (cross-unit overlap + 跨 sub 過濾 + Set 去重)
    // 保留 v1.5.186 樹狀圖 byVol 加 instanceName (獨立 patch)
    // v1.5.189 fix: 保留 v1.5.174 跨單元任務邏輯 (cross-unit overlap + 跨 sub 過濾),
    // 但加一個例外: 如果 unit 跟 task.unitId 直接對應的 unit page range 完全相同 (start+end 都一樣, 表示兩個 unit 標示同一份內容的不同面向, 例: 1~4冊 vs 1~4冊聽力), 則不計算 cross overlap
    // (修 bug3 「未排程 unit 顯示 N/M 進度」, 但保留 v1.5.172 跨單元任務邏輯)
    var taskDirectUnit = null;  // task.unitId 直接對應的 unit info
    appPlans.forEach(function(plan) {
        if (!plan.grid) return;
        Object.keys(plan.grid).forEach(function(dStr) {
            (plan.grid[dStr] || []).forEach(function(t) {
                if (!t || !t.isDone || !t.startPage || !t.endPage) return;
                if (filterCat && filterCat !== 'ALL' && t.cat !== filterCat) return;
                if (filterMis && filterMis !== 'ALL' && t.mis !== filterMis) return;
                var taskUnitInfo = allUnits[t.unitId];
                var taskSub = taskUnitInfo ? taskUnitInfo.subj : null;
                Object.keys(allUnits).forEach(function(uid) {
                    var u = allUnits[uid];
                    if (taskSub && u.subj !== taskSub) return;
                    // v1.5.189: 跳過「跟 task.unitId 直接對應 unit page range 完全相同」的 unit
                    // (例: 1~4冊 vs 1~4冊聽力, 兩個 unit 都 P.1-11, 但任務是給 1~4冊 不該污染 1~4冊聽力)
                    // 注意: 直接對應的 unit (uid === t.unitId) 仍要算 (即使 page range 完全相同, task 自己也要 cover 自己)
                    if (taskUnitInfo && uid !== t.unitId && u.start === taskUnitInfo.start && u.end === taskUnitInfo.end) {
                        return;
                    }
                    // v1.6.166 FIX: 跨冊 unit 不能互相污染
                    // 例: 英文/複習卷/大滿貫甲 L1~2 在第二~六冊都是 P.1,
                    //     如果 task 排到 第三冊 L1~2 (P.1), 不該污染 第二/四/五/六冊的 L1~2
                    // 條件: task 有 vol 且 unit 有 vol 且不相等 → 跳過 (視為不同冊)
                    // 向下相容: task 或 unit 沒 vol → 保留舊行為 (避免破壞現有資料)
                    if (t.vol && u.vol && t.vol !== u.vol) return;
                    // v1.6.51: skip overlap if this unit was never directly scheduled (no tasks in appPlans)
                    // This prevents units that were never scheduled from showing false donePages via cross-unit overlap
                    if (!window._treeScheduledUnits || !window._treeScheduledUnits[uid] || window._treeScheduledUnits[uid].totalTasks === 0) return;
                    var s = t.startPage > u.start ? t.startPage : u.start;
                    var e = t.endPage < u.end ? t.endPage : u.end;
                    if (e >= s) {
                        if (!result[uid + '_pages']) result[uid + '_pages'] = new Set();
                        var pageSet = result[uid + '_pages'];
                        var added = 0;
                        for (var p = s; p <= e; p++) {
                            if (!pageSet.has(p)) { pageSet.add(p); added++; }
                        }
                        if (added > 0) {
                            result[uid] = (result[uid] || 0) + added;
                        }
                    }
                });
            });
        });
    });
    return result;
}
// v1.5.107: 跨單元月曆標示 (用全部 cat, 不只 appMaster)
function getCrossUnitRanges(task) {
    if (!task || !task.startPage || !task.endPage) return null;
    var subj = task.subject;
    var s = null;
    var masters = (multiData && multiData[currentUserId]) ? multiData[currentUserId].masters : null;
    if (masters) {
        Object.keys(masters).forEach(function(cat) {
            if (s) return;
            if (masters[cat] && masters[cat][subj]) s = masters[cat][subj];
        });
    }
    if (!s && appMaster && appMaster[subj]) s = appMaster[subj];
    if (!s || !s.materials) return null;
    var units = [];
    Object.keys(s.materials).forEach(function(mt) {
        var mat = s.materials[mt];
        if (!mat || !mat.instances) return;
        mat.instances.forEach(function(inst) {
            if (!inst) return;
            if (inst.vols && typeof inst.vols === 'object') {
                Object.keys(inst.vols).forEach(function(volName) {
                    (inst.vols[volName] || []).forEach(function(u) {
                        if (u && u.id) units.push(u);
                    });
                });
            }
            if (inst.units && Array.isArray(inst.units)) {
                inst.units.forEach(function(u) {
                    if (u && u.id) units.push(u);
                });
            }
        });
    });
    var ranges = [];
    for (var p = task.startPage; p <= task.endPage; p++) {
        var foundUid = null;
        var foundName = null;
        for (var ui = 0; ui < units.length; ui++) {
            var u = units[ui];
            if (p >= u.start && p <= u.end) {
                foundUid = u.id;
                foundName = u.name;
                break;
            }
        }
        if (ranges.length === 0 || ranges[ranges.length - 1].unitId !== foundUid) {
            ranges.push({start: p, end: p, unitId: foundUid, name: foundName});
        } else {
            ranges[ranges.length - 1].end = p;
        }
    }
    ranges = ranges.filter(function(r) { return r.unitId !== null && r.end >= r.start; });
    if (ranges.length <= 1) return null;
    return ranges;
}
function renderUnitRowHtml(u, opts) {
    opts = opts || {};
    var isChecked = opts.isChecked ? 'checked' : '';
    var onChange = opts.onChange || '';
    var displayMode = opts.displayMode || 'D';
    var showQuickRead = opts.showQuickRead !== false; // wizard 預設 true, manual 設 false
    var prefix = u.vol ? `[${u.vol}] ` : '';
    var pageStr = (u.start && u.end && u.start !== u.end) ? ` (P.${u.start}~${u.end})` : ((u.start && u.start === u.end) ? ` (P.${u.start})` : '');
    var isScheduled = isUnitScheduledAnywhere(u);
    var qrChecked = u.quickRead ? 'checked' : '';
    var qrClass = u.quickRead ? 'on' : 'off';
    var instanceTag = '';
    if (displayMode === 'D' || displayMode === 'E') {
        if (u.typeName) instanceTag += '<span class="wz-type-tag">📖' + u.typeName + '</span>';
        // v1.5.155: 改用 alias (簡稱) 而不是 full name
        if (u.instanceName) {
            var instAlias = getInstanceAliasFromUnit(u);
            instanceTag += '<span class="wz-instance-tag" title="' + escapeHtml(u.instanceName) + '">📘' + instAlias + '</span>';
        }
    }
    var quickReadHtml = '';
    if (showQuickRead) {
        // v1.5.173: 用 className 取代 inline style (Safari layout 加速)
        quickReadHtml = `<label title="快讀（時數打折）" class="quick-read ${qrClass}">
                    <input type="checkbox" class="wz-qr-cb qr-cb" ${qrChecked} onchange="${opts.onQuickReadChange || ''}">☀️
                </label>`;
    }
    var schedMark = isScheduled ? ' <span class="wz-scheduled-mark">🔁</span>' : '';
    // v1.5.173: 用 className 取代 inline style (Safari layout 加速)
    return `<div class="wz-unit-row${isScheduled ? ' scheduled' : ''}">
                <input type="checkbox" class="wz-unit-cb unit-cb" value="${u.id}" ${isChecked} onchange="${onChange}">
                <label class="label-main">${instanceTag}${prefix}${u.name}${pageStr}${schedMark}</label>
                ${quickReadHtml}
            </div>`;
}
function renderWizardUnitRowHtml(ws, i, u) {
    return renderUnitRowHtml(u, {
        isChecked: ws.selectedUnitIds.includes(u.id),
        onChange: "toggleWizardUnit(" + i + ", '" + u.id + "', this.checked)",
        onQuickReadChange: "toggleWizardQuickRead(" + i + ", '" + u.id + "', this.checked)",
        displayMode: ws.displayMode,
        showQuickRead: true,
        quickRead: u.quickRead
    });
}
        function toggleWizardSubjectUnits(subjIdx, isChecked) {
            var ws = wizardSubjects[subjIdx];
            if (isChecked) {
                ws.selectedUnitIds = ws.availableUnits.map(u => u.id);
            } else {
                ws.selectedUnitIds = [];
            }
            // v1.5.114: 不重建整個 DOM, 只更新此科目的 unit + master checkbox
            updateSubjectUnitCheckboxes(subjIdx);
            updateSubjectMasterUI(subjIdx);
            debouncedSaveWizardPrefs();
        }
        // v1.5.114: 只更新某科目的所有 unit checkbox (master checkbox 全選/全不選後用)
        function updateSubjectUnitCheckboxes(subjIdx) {
            var ws = wizardSubjects[subjIdx];
            var subjContainer = el('wz-step2-container').children[subjIdx];
            if (!subjContainer) return;
            var unitCbs = subjContainer.querySelectorAll('input.wz-unit-cb');
            unitCbs.forEach(function(cb) {
                cb.checked = ws.selectedUnitIds.includes(cb.value);
            });
        }
        // v1.5.114: 只更新 master checkbox 的狀態 (label + indeterminate)
        function updateSubjectMasterUI(subjIdx) {
            var ws = wizardSubjects[subjIdx];
            var allSelected = ws.availableUnits.length > 0 && ws.selectedUnitIds.length === ws.availableUnits.length;
            var someSelected = ws.selectedUnitIds.length > 0 && !allSelected;
            var selCount = ws.selectedUnitIds.length;
            var totalCount = ws.availableUnits.length;
            var masterLabel = allSelected ? '☑ 全選 (取消)' : (someSelected ? '▣ 部分已選 (' + selCount + '/' + totalCount + ')' : '☐ 全部未選 (全選)');
            var subjContainer = el('wz-step2-container').children[subjIdx];
            if (!subjContainer) return;
            var masterCb = subjContainer.querySelector('input.wz-master-cb');
            if (masterCb) {
                masterCb.checked = allSelected;
                masterCb.indeterminate = someSelected;
            }
            var masterLabelEl = subjContainer.querySelector('.wz-master-label');
            if (masterLabelEl) masterLabelEl.textContent = masterLabel;
        }
        function toggleWizardUnit(subjIdx, unitId, isChecked) {
            var ws = wizardSubjects[subjIdx];
            if (isChecked && !ws.selectedUnitIds.includes(unitId)) {
                ws.selectedUnitIds.push(unitId);
            } else if (!isChecked) {
                ws.selectedUnitIds = ws.selectedUnitIds.filter(id => id !== unitId);
            }
            // v1.5.114: 不重建 DOM, 只更新 master (大幅提升效能)
            updateSubjectMasterUI(subjIdx);
            debouncedSaveWizardPrefs();
        }
        // v1.5.24: 快讀功能
        function toggleWizardQuickRead(subjIdx, unitId, isChecked) {
            var ws = wizardSubjects[subjIdx];
            var unit = ws.availableUnits.find(u => u.id === unitId);
            if (unit) unit.quickRead = isChecked;
            // v1.5.114: 不重建 DOM, 只更新該 unit 的快讀 checkbox 狀態
            updateUnitQuickReadUI(subjIdx, unitId, isChecked);
            debouncedSaveWizardPrefs();
        }
        function updateUnitQuickReadUI(subjIdx, unitId, isChecked) {
            var subjContainer = el('wz-step2-container').children[subjIdx];
            if (!subjContainer) return;
            // 找 onclick 含此 unitId 的快讀 checkbox
            var qrCbs = subjContainer.querySelectorAll('input.wz-qr-cb');
            qrCbs.forEach(function(cb) {
                var onchangeAttr = cb.getAttribute('onchange') || '';
                if (onchangeAttr.indexOf("'" + unitId + "'") !== -1) {
                    cb.checked = isChecked;
                }
            });
        }
        function setAllQuickRead(subjIdx, doQuickRead) {
            var ws = wizardSubjects[subjIdx];
            ws.availableUnits.forEach(u => {
                if (u.misMaxEnd > 0) u.quickRead = doQuickRead;
            });
            // v1.5.114: 不重建 DOM, 只批量更新快讀 checkbox
            var subjContainer = el('wz-step2-container').children[subjIdx];
            if (!subjContainer) return;
            var qrCbs = subjContainer.querySelectorAll('input.wz-qr-cb');
            qrCbs.forEach(function(cb) { cb.checked = doQuickRead; });
            debouncedSaveWizardPrefs();
        }
        // v1.5.114: debounce saveWizardPrefs (避免每次點都寫 localStorage)
        var _savePrefsTimer = null;
        function debouncedSaveWizardPrefs() {
            if (_savePrefsTimer) clearTimeout(_savePrefsTimer);
            _savePrefsTimer = setTimeout(function() {
                saveWizardPrefs();
                _savePrefsTimer = null;
            }, 300);
        }
        // v1.5.116: 日期範圍格式化 (同年同月縮寫, 跨年完整)
        // 例: 2026-08-12 ~ 2026-08-18 → 2026/08/12~08/18
        //     2026-08-12 ~ 2026-09-15 → 2026/08/12~09/15
        //     2026-12-30 ~ 2027-01-02 → 2026/12/30~2027/01/02
        function formatDateRange(start, end) {
            if (!start || !end) return '?';
            var sp = start.split('-');
            var ep = end.split('-');
            if (sp.length !== 3 || ep.length !== 3) return start + ' ~ ' + end;
            if (sp[0] !== ep[0]) {
                return sp[0] + '/' + sp[1] + '/' + sp[2] + '~' + ep[0] + '/' + ep[1] + '/' + ep[2];
            }
            if (sp[1] !== ep[1]) {
                return sp[0] + '/' + sp[1] + '/' + sp[2] + '~' + ep[1] + '/' + ep[2];
            }
            return sp[0] + '/' + sp[1] + '/' + sp[2] + '~' + ep[2];
        }
        // v1.5.114 + v1.5.116: 批次快捷勾選按鈕
        // v1.5.116 fix: 用 isUnitScheduledAnywhere 取代 misMaxEnd, 視覺跟邏輯一致
        // (原本 misMaxEnd===0 會漏掉「部分排過」的 unit, 那些 unit 視覺是深黃色但邏輯上 misMaxEnd>0)
        function selectUnscheduledUnits() {
            var changed = 0;
            wizardSubjects.forEach(function(ws) {
                var newSel = [];
                ws.availableUnits.forEach(function(availU) {
                    if (!isUnitScheduledAnywhere(availU)) newSel.push(availU.id);
                });
                if (newSel.length !== ws.selectedUnitIds.length) {
                    ws.selectedUnitIds = newSel;
                    changed++;
                }
            });
            if (changed > 0) {
                renderWizardSubjects();
                saveWizardPrefs();
            } else {
                alert('所有 unit 都已排過, 無未排過的 unit 可選。');
            }
        }
        function selectScheduledUnits() {
            var changed = 0;
            wizardSubjects.forEach(function(ws) {
                var newSel = [];
                ws.availableUnits.forEach(function(availU) {
                    if (isUnitScheduledAnywhere(availU)) newSel.push(availU.id);
                });
                if (newSel.length !== ws.selectedUnitIds.length) {
                    ws.selectedUnitIds = newSel;
                    changed++;
                }
            });
            if (changed > 0) {
                renderWizardSubjects();
                saveWizardPrefs();
            } else {
                alert('所有 unit 都未排過, 無已排過的 unit 可選。');
            }
        }
        function selectAllUnits() {
            wizardSubjects.forEach(function(ws) {
                ws.selectedUnitIds = ws.availableUnits.map(function(u) { return u.id; });
            });
            renderWizardSubjects();
            saveWizardPrefs();
        }
        function clearAllUnits() {
            wizardSubjects.forEach(function(ws) {
                ws.selectedUnitIds = [];
            });
            renderWizardSubjects();
            saveWizardPrefs();
        }
        function generatePlan() { try { _generatePlanInner(); } catch (e) { console.error('[v1.6.150 generatePlan ERROR]', e); alert('❌ 生成排程計畫發生錯誤：\n\n' + e.message + '\n\n請截圖給開發者 (按 F12 看 Console 有更多細節)'); }
        }
        function _generatePlanInner() { 
            var name = el('wz-name').value.trim(); 
            var startDateStr = el('wz-startdate').value;
            var endDateStr = el('wz-enddate').value; 
            
            if(!name || !startDateStr || !endDateStr || wizardSubjects.length === 0) return alert('請確認計畫名稱與選擇專案！'); 
            
            var startDate = new Date(startDateStr); startDate.setHours(0,0,0,0); 
            var endDate = new Date(endDateStr); endDate.setHours(0,0,0,0); 
            
            if(endDate <= startDate) return alert('完成日期必須大於開始日期！'); 
            var pid = el('planner-selector').value;
            var plan = null;
            if (pid) {
                plan = appPlans.find(p => p.id === pid);
            }
            
            if (!plan) {
                plan = { id: genId(), name: name, start: startDateStr, end: endDateStr, grid: {} }; 
                appPlans.push(plan);
            }
            
            if (!plan.grid) plan.grid = {};
            var dailyRemain = {};
            // v1.5.112: 用 plan.hourConfig 計算時數 (override > taskHours > defaults)
            ensurePlanHourConfig(plan);
            // 同步 wz-hrs-X 到 plan.hourConfig.defaults (讓計畫記住用戶設定)
            for (let i = 0; i <= 6; i++) {
                var inpVal = Number(el('wz-hrs-' + i).value) || 0;
                plan.hourConfig.defaults[i] = inpVal;
            }
            var planCat = el('wz-cat').value;
            // v1.5.112: 如果 plan 沒有設定自己的 taskHours, 從 appPrefs 拉過來
            if (!plan.hourConfig.taskHours || Object.keys(plan.hourConfig.taskHours).length === 0) {
                var appPrefs = loadAppPrefs();
                if (appPrefs && appPrefs.taskHours) {
                    plan.hourConfig.taskHours = Object.assign({}, appPrefs.taskHours);
                }
            }
            var d = new Date(startDate);
            while(d <= endDate) {
                var dStr = getLocalDateString(d);
                var dw = d.getDay();
                var dh = getEffectiveDailyHours(dStr, dw, plan.hourConfig, planCat, plan);
                
                if (dh > 0) {
                    var existingTasksCount = plan.grid[dStr] ? plan.grid[dStr].length : 0;
                    var usedHours = existingTasksCount * 1.0; 
                    var remain = dh - usedHours;
                    
                    if (remain > 0) {
                        dailyRemain[dStr] = remain;
                    }
                }
                d.setDate(d.getDate() + 1);
            }
            var allSubjectChunks = [];
            var totalCost = 0; 
            wizardSubjects.forEach(ws => {
                if (ws.selectedUnitIds.length === 0) return;
                var chunks = [];
                var hoursPerUnit = Number(ws.hoursPerUnit) || 1;
                var unitsPerWeek = Number(ws.progVal) || 1;
                // v1.6.141: 依 scheduleMode 分派 (模式 A: 時數 = 原行為; 模式 B: 單元 = v1.6.142.2 實作)
                var _scheduleMode = ws.scheduleMode || 'hours';
                ws.availableUnits.forEach(availU => {
                    if (!ws.selectedUnitIds.includes(availU.id)) return;
                    var u = availU.uObj;
                    var volName = availU.vol;
                    var prefix = volName ? `[${volName}] ` : '';
                    var s = Number(u.start) || 0;
                    var e = Number(u.end) || 0;
                    var totalPages = (s && e && e >= s) ? (e - s + 1) : 0;
                    var chunkSizeHours = 0.5;
                    var numChunks = Math.max(1, Math.ceil(hoursPerUnit / chunkSizeHours));
                    // v1.5.25: 快讀時數可自訂折扣百分比
                    var qrDiscount = 1.0;
                    var qrEl = el('wz-quickread-discount');
                    if (availU.quickRead && qrEl) {
                        var qrVal = Number(qrEl.value) || 60;
                        qrDiscount = Math.max(0.10, Math.min(0.95, qrVal / 100));
                    }
                    var effectiveHours = hoursPerUnit * (availU.quickRead ? qrDiscount : 1.0);
                    var actualCost = effectiveHours / numChunks;
                    var pagesPerChunk = totalPages > 0 ? (totalPages / numChunks) : 0;
                    var currentPage = s;
                    for (var i = 0; i < numChunks; i++) {
                        var cStart = currentPage;
                        var cEnd = Math.round(s + (i + 1) * pagesPerChunk - 1);
                        if (i === numChunks - 1) cEnd = e; 
                        chunks.push({
                            subject: ws.name,
                            unitId: u.id,
                            vol: volName,
                            unitName: u.name,
                            typeName: availU.typeName || '',
                            instanceName: availU.instanceName || '',
                            prefix: prefix,
                            startPage: (totalPages > 0) ? Math.round(cStart) : '',
                            endPage: (totalPages > 0) ? Math.round(cEnd) : '',
                            cost: actualCost,
                            ws: ws
                        });
                        totalCost += actualCost;
                        currentPage = cEnd + 1;
                    }
                });
                if (chunks.length > 0) {
                    allSubjectChunks.push({
                        ws: ws,
                        chunks: chunks
                    });
                }
            });
            var sortedDates = Object.keys(dailyRemain).filter(ds => dailyRemain[ds] > 0).sort();
            var totalCapacity = 0;
            var dateCapacities = {};
            
            sortedDates.forEach(ds => {
                totalCapacity += dailyRemain[ds];
                dateCapacities[ds] = dailyRemain[ds];
            });
            // v1.6.142.2: 模式 B (單元) pipeline 排程 — 把每個 unit 的多個 chunks 重組成「每 unit 佔 N 個有效讀書日」
            // 策略: 對每個 mode='units' 的 ws, 把它的 chunks 按 unit 分組, 每組內的 chunks 沿 sortedDates 連續 N 天放置
            // 然後把所有 mode B 的 chunks 重新放回 allSubjectChunks
            var tasksCreated = 0;
            var _hasUnitMode = wizardSubjects.some(function(ws) { return ws.scheduleMode === 'units' && ws.selectedUnitIds.length > 0; });
            if (_hasUnitMode) {
                var unitModeAssignments = {}; // ds -> [{subject, unitId, vol, unitName, typeName, instanceName, prefix, startPage, endPage, cost, ws}]
                var unitModeWarnings = [];
                // 依 ws 順序處理 (維持現有優先權)
                wizardSubjects.forEach(function(ws) {
                    if (ws.scheduleMode !== 'units') return;
                    if (ws.selectedUnitIds.length === 0) return;
                    var hoursPerUnit = Number(ws.hoursPerUnit) || 1;
                    var daysPerUnit = Math.max(1, Math.round(ws.daysPerUnit != null && ws.daysPerUnit !== '' ? Number(ws.daysPerUnit) : 2));
                    // perDayCost = hoursPerUnit / daysPerUnit (模式 B 統一時間模型)
                    // 收集這個 ws 選中的 chunks (按 selectedUnitIds 順序 + 沿用 A 模式的 numChunks)
                    var myChunksByUnit = {}; // unitId -> [chunk, chunk, ...]
                    var myChunksOrder = [];   // [unitId, unitId, ...] 維持選中順序
                    // 從現有 chunks 找 (allSubjectChunks 是空 array 結構, 還沒填)
                    // 我們需要重新計算 (因為 A 模式 chunks 沒在 allSubjectChunks 裡)
                    // 改: 直接從 ws 重建 chunks (重複 A 模式邏輯, 但只用 mode B 需要的部分)
                    var chunkSizeHours = 0.5;
                    var numChunks = Math.max(1, Math.ceil(hoursPerUnit / chunkSizeHours));
                    var qrEl = el('wz-quickread-discount');
                    var qrDiscount = 1.0;
                    if (qrEl) {
                        var qrVal = Number(qrEl.value) || 60;
                        qrDiscount = Math.max(0.10, Math.min(0.95, qrVal / 100));
                    }
                    ws.availableUnits.forEach(function(availU) {
                        if (!ws.selectedUnitIds.includes(availU.id)) return;
                        var u = availU.uObj;
                        var volName = availU.vol;
                        var prefix = volName ? ('[' + volName + '] ') : '';
                        var s = Number(u.start) || 0;
                        var e = Number(u.end) || 0;
                        var totalPages = (s && e && e >= s) ? (e - s + 1) : 0;
                        var effectiveHours = hoursPerUnit * (availU.quickRead ? qrDiscount : 1.0);
                        var actualCost = effectiveHours / numChunks;
                        var pagesPerChunk = totalPages > 0 ? (totalPages / numChunks) : 0;
                        var currentPage = s;
                        for (var i = 0; i < numChunks; i++) {
                            var cStart = currentPage;
                            var cEnd = Math.round(s + (i + 1) * pagesPerChunk - 1);
                            if (i === numChunks - 1) cEnd = e;
                            var ch = {
                                subject: ws.name,
                                unitId: u.id,
                                vol: volName,
                                unitName: u.name,
                                typeName: availU.typeName || '',
                                instanceName: availU.instanceName || '',
                                prefix: prefix,
                                startPage: (totalPages > 0) ? Math.round(cStart) : '',
                                endPage: (totalPages > 0) ? Math.round(cEnd) : '',
                                cost: actualCost,
                                ws: ws
                            };
                            if (!myChunksByUnit[u.id]) {
                                myChunksByUnit[u.id] = [];
                                myChunksOrder.push(u.id);
                            }
                            myChunksByUnit[u.id].push(ch);
                            currentPage = cEnd + 1;
                        }
                    });
                    // pipeline 排: 每個 unit 佔 daysPerUnit 個有效讀書日, 每天 1 個 chunk
                    // 沿 sortedDates 順序連續放
                    var dayCursor = 0; // 指向 sortedDates[dayCursor]
                    var unitQueue = myChunksOrder.slice(); // 還沒排完的 unit id 序列
                    while (unitQueue.length > 0 && dayCursor < sortedDates.length) {
                        var uId = unitQueue[0];
                        var chunksForUnit = myChunksByUnit[uId];
                        var placedThisUnit = 0;
                        // 把這個 unit 的每個 chunk 放到連續 daysPerUnit 天
                        for (var di = 0; di < daysPerUnit && di < chunksForUnit.length; di++) {
                            if (dayCursor >= sortedDates.length) break;
                            var ds = sortedDates[dayCursor];
                            var ch = chunksForUnit[di];
                            if (!unitModeAssignments[ds]) unitModeAssignments[ds] = [];
                            unitModeAssignments[ds].push(ch);
                            placedThisUnit++;
                            dayCursor++;
                        }
                        // 如果這個 unit 的 chunks 比 daysPerUnit 少 (numChunks < daysPerUnit)
                        if (placedThisUnit < chunksForUnit.length) {
                            // 警告: 用戶設 daysPerUnit 但 unit chunk 數不夠, 剩餘 chunk 排不進
                            unitModeWarnings.push(ws.name + ' / ' + (chunksForUnit[0] ? chunksForUnit[0].unitName : uId) +
                                ' : daysPerUnit=' + daysPerUnit + ' 但只有 ' + chunksForUnit.length + ' chunks');
                            // 強行塞到接下來的日子 (v1.6.149: 加 push 前 init, 修 TypeError)
                            for (var ri = placedThisUnit; ri < chunksForUnit.length; ri++) {
                                if (dayCursor >= sortedDates.length) break;
                                var ds2 = sortedDates[dayCursor];
                                if (!unitModeAssignments[ds2]) unitModeAssignments[ds2] = [];
                                unitModeAssignments[ds2].push(chunksForUnit[ri]);
                                dayCursor++;
                            }
                        }
                        unitQueue.shift(); // 這個 unit 處理完
                    }
                    // 警告: 排到 endDate 還沒完
                    if (unitQueue.length > 0) {
                        var remaining = unitQueue.map(function(id) {
                            var c0 = myChunksByUnit[id][0];
                            return c0 ? c0.unitName : id;
                        }).join(', ');
                        unitModeWarnings.push(ws.name + ': ' + unitQueue.length + ' 個 unit 排不進期間: ' + remaining);
                    }
                });
                // 把 unitModeAssignments 寫入 plan.grid (覆蓋當日 mode A 的結果)
                Object.keys(unitModeAssignments).forEach(function(ds) {
                    if (!plan.grid[ds]) plan.grid[ds] = [];
                    plan.grid[ds] = unitModeAssignments[ds].map(function(ch) {
                        return {
                            id: genId(),
                            date: ds,
                            subject: ch.subject,
                            task: ch.prefix + ch.unitName +
                                (ch.startPage !== '' ? ' (p' + ch.startPage + (ch.endPage !== '' ? ('-' + ch.endPage) : '') + ')' : ''),
                            unitId: ch.unitId,
                            vol: ch.vol,
                            unitName: ch.unitName,
                            typeName: ch.typeName,
                            instanceName: ch.instanceName,
                            duration: ch.cost,
                            ws: ch.ws
                        };
                    });
                    tasksCreated += plan.grid[ds].length;
                });
                // 警告 UI
                if (unitModeWarnings.length > 0) {
                    console.warn('v1.6.142.2 模式 B 警告:', unitModeWarnings);
                }
                // 模式 B 處理完就 return (不走時數模式的 executePlacement)
                if (unitModeWarnings.length > 0) {
                    // v1.6.151: 改用自訂 modal 取代 alert,可看到完整警告列表
                    showUnitWarningsModal(unitModeWarnings);
                }
                saveToLocal();  // v1.6.149: 修 bug — saveData 不存在,改用 saveToLocal
                closeModal('modal-wizard');
                return; // 模式 B 短路,不走時數模式 A 邏輯
            }
            if (totalCapacity <= 0) {
                return alert('⚠️ 錯誤：指定的期間與每日時數總合為 0，請檢查「每日讀書時數」設定或日期區間！');
            }
            var scaleRatio = totalCapacity > 0 ? (totalCost / totalCapacity) : 1;
            function executePlacement(multiplier) {
                var assignments = {};
                var unplaced = [];
                var used = {};
                sortedDates.forEach(ds => used[ds] = 0);
                var queues = allSubjectChunks.map(sc => ({
                    subject: sc.ws.name,
                    chunks: [...sc.chunks]
                }));
                
                var currentSubjIdx = 0; 
                sortedDates.forEach(ds => {
                    var baseEffectiveCap = dateCapacities[ds] * multiplier;
                    var consecutiveFailures = 0; 
                    
                    while (used[ds] < baseEffectiveCap && consecutiveFailures < queues.length) {
                        var q = queues[currentSubjIdx];
                        
                        if (q.chunks.length > 0) {
                            var chunk = q.chunks[0];
                            
                            var effectiveCap = baseEffectiveCap;
                            if (multiplier <= 1.0) {
                                effectiveCap = Math.max(effectiveCap, Math.min(chunk.cost, dateCapacities[ds]));
                            }
                            if (used[ds] + chunk.cost <= effectiveCap + 0.01) {
                                if (!assignments[ds]) assignments[ds] = [];
                                assignments[ds].push(chunk);
                                used[ds] += chunk.cost;     
                                q.chunks.shift();           
                                consecutiveFailures = 0;    
                            } else {
                                consecutiveFailures++;      
                            }
                        } else {
                            consecutiveFailures++;          
                        }
                        currentSubjIdx = (currentSubjIdx + 1) % queues.length;
                    }
                });
                queues.forEach(q => {
                    unplaced.push(...q.chunks);
                });
                return { assignments, unplaced, used };
            }
            var baseMultiplier = scaleRatio <= 1 ? scaleRatio : 1.0;
            var result = executePlacement(baseMultiplier);
            if (result.unplaced.length > 0 && totalCost <= totalCapacity) {
                result = executePlacement(1.0);
            }
            var dateAssignments = result.assignments;
            var unplacedChunks = result.unplaced;
            
            var userChoseForceFit = false;
            if (unplacedChunks.length > 0) {
                var missingHours = totalCost - totalCapacity;
                if (missingHours < 0) missingHours = 0;
                var unplacedSet = new Set();
                unplacedChunks.forEach(c => unplacedSet.add(`[${c.subject}] ${c.unitName}`));
                
                var msg = `⚠️ 警告：排程期間與每日時數不足！\n\n`;
                msg += `您設定的計畫期間無法容納所有勾選的進度，總共短缺了約 ${missingHours.toFixed(1)} 小時。\n\n`;
                msg += `以下單元因為時間不足而被排除：\n`;
                Array.from(unplacedSet).forEach(n => msg += ` - ${n}\n`);
                msg += `\n您希望如何處理這些排不進去的進度？\n`;
                msg += `👉 按【確定】：採用「等比例放大重新裝箱」，強制分攤到每一天 (嚴格維持單元循序不打亂)。\n`;
                msg += `👉 按【取消】：維持「誠實捨棄」原則，自動排除上述放不下的單元。`;
                if (confirm(msg)) {
                    var forceMultiplier = (totalCost / totalCapacity) * 1.05 + 0.1;
                    var forceResult = executePlacement(forceMultiplier);
                    dateAssignments = forceResult.assignments;
                    unplacedChunks = forceResult.unplaced;
                    userChoseForceFit = true;
                }
            }
            for (var ds in dateAssignments) {
                var chunksDay = dateAssignments[ds];
                var subjGroups = {};
                chunksDay.forEach(c => {
                    if (!subjGroups[c.subject]) subjGroups[c.subject] = [];
                    subjGroups[c.subject].push(c);
                });
                for (var subName in subjGroups) {
                    var cList = subjGroups[subName];
                    var mergedByUnit = {};
                    cList.forEach(c => {
                        if (!mergedByUnit[c.unitId]) {
                            mergedByUnit[c.unitId] = { ...c, startPage: c.startPage, endPage: c.endPage };
                        } else {
                            var existing = mergedByUnit[c.unitId];
                            if (c.endPage !== '') existing.endPage = Math.max(existing.endPage || 0, c.endPage);
                            if (c.startPage !== '' && (existing.startPage === '' || c.startPage < existing.startPage)) existing.startPage = c.startPage;
                        }
                    });
                    for (var uid in mergedByUnit) {
                        var item = mergedByUnit[uid];
                        var textStr = `[${subName}] ${item.prefix}${item.unitName}`;
                        if (item.startPage !== '' && item.endPage !== '') {
                            if (item.startPage === item.endPage) textStr += ` P.${item.startPage}`;
                            else textStr += ` P.${item.startPage}~${item.endPage}`;
                        }
                        if (!plan.grid[ds]) plan.grid[ds] = [];
                        plan.grid[ds].push({
                            id: genId(), subject: subName, text: textStr,
                            startPage: item.startPage !== '' ? item.startPage : 0,
                            endPage: item.endPage !== '' ? item.endPage : 0,
                            isDone: false,
                            cat: el('wz-cat').value, mis: el('wz-mis').value,
                            unitId: item.unitId, vol: item.vol, unitName: item.unitName,
                            typeName: item.typeName || '',
                            instanceName: item.instanceName || '',
                            postponeCount: 0,
                            isAuto: true,
                            wizardRunId: 'w_' + Date.now(),  // v1.5.102: 標記是哪次 wizard 跑的
                            wizardRunTime: Date.now()  // v1.5.103: 給「刪除排程」用
                        });
                        tasksCreated++;
                    }
                }
            }
            
            if(tasksCreated === 0) return alert('沒有產生任何任務！\n請檢查：\n1. 所有單元是否已經被手動排程過了\n2. 每日總時數是否過少\n3. 設定的日期區間內是否有非手動排程的空檔日');
            // v1.5.102: 記錄最後一次 wizard 跑的時間 (給「刪除排程」用)
            if (typeof plan !== 'undefined' && plan) {
                plan.lastWizardRunTime = Date.now();
            }
            if (unplacedChunks.length > 0) {
                if (userChoseForceFit) {
                    alert('🎉 處理完畢！已將剩餘進度強制分攤排入月曆。');
                } else {
                    alert('🎉 處理完畢！已誠實捨棄超出時數的單元，保留了您的進度品質。');
                }
            } else {
                alert('🎉 智慧排程建立完成！\n已根據您的「每日時數上限」與「每單元速度（單元數與時數）」，為您均勻排入進度表。');
            }
            
            appLogs.push({ id: genId(), date: getLocalDateString(new Date()), category: '🗓️ 計畫管理', mission: plan.name, subject: '系統', unitName: '-', start: 0, end: 0, pages: 0, detail: `依據排程精靈追加任務（嚴格遵照每日設定時數並利用剩餘空檔）。` }); 
            
            saveWizardPrefs();
            saveToLocal(); 
            closeModal('modal-wizard'); 
            updatePlannerSelector(); 
            renderCalendar(); 
        }
        // v1.6.151: 顯示模式 B 警告 modal (取代 alert)
        var _unitWarningsData = [];
        var _autoFixPlan = null;  // v1.6.159: 自動修正確認 modal 暫存
        function showUnitWarningsModal(warnings) {
            _unitWarningsData = warnings || [];
            var countEl = el('unit-warnings-count');
            if (countEl) countEl.textContent = _unitWarningsData.length;
            
            // 預覽區: 顯示前 5 個
            var preview = el('unit-warnings-preview');
            var full = el('unit-warnings-full');
            var expandBtn = el('unit-warnings-expand-btn');
            if (preview) {
                if (_unitWarningsData.length === 0) {
                    preview.innerHTML = '<div style="color:#94a3b8; text-align:center;">無警告</div>';
                } else {
                    preview.innerHTML = _unitWarningsData.slice(0, 5).map(function(w, i) {
                        return '<div>' + (i+1) + '. ' + escapeHtml(w) + '</div>';
                    }).join('');
                    if (_unitWarningsData.length > 5) {
                        preview.innerHTML += '<div style="color:#94a3b8; margin-top:6px; text-align:center;">... 還有 ' + (_unitWarningsData.length - 5) + ' 個 (按右上「📋 展開全部」查看)</div>';
                    }
                }
            }
            if (full) {
                if (_unitWarningsData.length > 0) {
                    full.innerHTML = _unitWarningsData.map(function(w, i) {
                        return '<div>' + (i+1) + '. ' + escapeHtml(w) + '</div>';
                    }).join('');
                }
            }
            if (expandBtn) {
                expandBtn.style.display = (_unitWarningsData.length > 5) ? '' : 'none';
            }
            // Reset to preview state
            if (full) full.style.display = 'none';
            if (expandBtn) expandBtn.textContent = '📋 展開全部';
            
            openModal('modal-unit-warnings');
        }
        
        function toggleUnitWarningsExpand() {
            var full = el('unit-warnings-full');
            var btn = el('unit-warnings-expand-btn');
            if (!full || !btn) return;
            if (full.style.display === 'none') {
                full.style.display = '';
                btn.textContent = '📋 收合';
            } else {
                full.style.display = 'none';
                btn.textContent = '📋 展開全部';
            }
        }
        
        function closeUnitWarningsModal() {
            closeModal('modal-unit-warnings');
        }
        // v1.6.159: 從警告 modal 「回 wizard 改設定」 — 保留 wizard 狀態,關掉警告 modal
        function backToWizardFromWarnings() {
            closeModal('modal-unit-warnings');
            openModal('modal-wizard');
        }
        // v1.6.159: 「自動修正並重排」 — 掃描每個 ws.scheduleMode === 'units' 的 unit,
        // 算 numChunks = ceil(hoursPerUnit / 0.5), 如果 daysPerUnit > numChunks 就調成 numChunks
        // 先彈確認對話框列出所有調整,確認後再執行
        function autoFixAndReplan() {
            var chunkSize = 0.5;
            var plan = [];
            // 按科目分組調整建議
            if (typeof wizardSubjects === 'undefined' || !wizardSubjects) {
                return alert('⚠️ wizardSubjects 尚未初始化,請重新進入智慧排程');
            }
            wizardSubjects.forEach(function(ws, wi) {
                if (ws.scheduleMode !== 'units') return;
                if (!ws.selectedUnitIds || ws.selectedUnitIds.length === 0) return;
                var hrs = Number(ws.hoursPerUnit) || 1;
                var maxChunks = Math.max(1, Math.ceil(hrs / chunkSize));
                var currentDays = Math.max(1, Math.round(Number(ws.daysPerUnit) || 2));
                var wsFixes = [];
                // 收集這個 ws 選中 unit 的「建議 daysPerUnit」
                ws.availableUnits.forEach(function(availU) {
                    if (!ws.selectedUnitIds.includes(availU.id)) return;
                    var u = availU.uObj;
                    var totalPages = (Number(u.start) || 0) && (Number(u.end) || 0) ? (Number(u.end) - Number(u.start) + 1) : 0;
                    var effectiveHrs = hrs * (availU.quickRead ? (Math.max(0.10, Math.min(0.95, Number(el('wz-quickread-discount') ? el('wz-quickread-discount').value : 60) / 100))) : 1.0);
                    var numChunks = Math.max(1, Math.ceil(effectiveHrs / chunkSize));
                    var suggestedDays = Math.min(numChunks, currentDays);
                    if (suggestedDays < currentDays) {
                        wsFixes.push({
                            name: u.name,
                            fromDays: currentDays,
                            toDays: suggestedDays,
                            numChunks: numChunks
                        });
                    }
                });
                if (wsFixes.length > 0) {
                    plan.push({
                        subjectName: ws.name,
                        subjectIdx: wi,
                        hoursPerUnit: hrs,
                        currentDays: currentDays,
                        maxChunks: maxChunks,
                        fixes: wsFixes
                    });
                }
            });
            if (plan.length === 0) {
                return alert('✅ 沒有需要自動修正的參數 (所有 unit 的 daysPerUnit 都 ≤ chunks 數)');
            }
            // 顯示確認 modal
            showAutoFixConfirmModal(plan);
        }
        // v1.6.159: 顯示自動修正確認 modal — 詳細列出每個調整
        function showAutoFixConfirmModal(plan) {
            // 計算總計
            var totalFixes = plan.reduce(function(s, w) { return s + w.fixes.length; }, 0);
            var html = '<div style="font-size:0.92em;">';
            html += '<div style="background:#fffbeb; border:1px solid #fde047; border-radius:8px; padding:10px 14px; margin-bottom:14px; color:#854d0e;">';
            html += '⚠️ <b>即將調整 ' + plan.length + ' 個科目,共 ' + totalFixes + ' 個 unit</b><br>';
            html += '<span style="font-size:0.88em;">只調整 <b>daysPerUnit</b>,不會動到選擇的科目或 unit。</span>';
            html += '</div>';
            plan.forEach(function(p) {
                html += '<div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:6px; padding:10px 14px; margin-bottom:10px;">';
                html += '<div style="font-weight:bold; color:#0c4a6e; margin-bottom:6px;">📚 ' + escapeHtml(p.subjectName) + ' <span style="font-weight:normal; color:#64748b; font-size:0.88em;">(hoursPerUnit=' + p.hoursPerUnit + ', 目前 daysPerUnit=' + p.currentDays + ', 最大 chunks=' + p.maxChunks + ')</span></div>';
                html += '<ul style="margin:4px 0 4px 16px; padding:0; font-size:0.88em; color:#475569;">';
                p.fixes.forEach(function(f) {
                    html += '<li>📝 <b>' + escapeHtml(f.name) + '</b>: daysPerUnit <span style="color:#dc2626;">' + f.fromDays + '</span> → <span style="color:#15803d;">' + f.toDays + '</span> <span style="color:#64748b;">(此 unit 只有 ' + f.numChunks + ' chunks)</span></li>';
                });
                html += '</ul></div>';
            });
            html += '<div style="background:#fef2f2; border:1px solid #fca5a5; border-radius:6px; padding:8px 12px; font-size:0.85em; color:#991b1b;">';
            html += '⚠️ 確認後會覆蓋現有排程。建議先在 wizard 內確認選擇無誤再執行。</div>';
            html += '</div>';
            // 設到 confirm modal body
            var body = el('auto-fix-confirm-body');
            if (body) body.innerHTML = html;
            _autoFixPlan = plan;
            closeModal('modal-unit-warnings');
            openModal('modal-auto-fix-confirm');
        }
        // v1.6.159: 執行自動修正 (確認後)
        function executeAutoFix() {
            if (!_autoFixPlan || _autoFixPlan.length === 0) {
                closeModal('modal-auto-fix-confirm');
                return;
            }
            console.log('[v1.6.159 executeAutoFix] 即將調整:', JSON.stringify(_autoFixPlan, null, 2));
            // 對每個 plan 項目,把對應 ws 的 daysPerUnit 改成 maxChunks (取最小,確保所有 unit 都不會 N > chunks)
            _autoFixPlan.forEach(function(p) {
                var ws = wizardSubjects[p.subjectIdx];
                if (!ws) return;
                // 用 maxChunks 當統一 daysPerUnit (這是 hrs / 0.5 ceiling)
                // 因為 selectedUnitIds 內可能有不同 page 範圍的 unit,但每個都是用同 hoursPerUnit,所以 numChunks 都一樣
                ws.daysPerUnit = p.maxChunks;
            });
            saveWizardPrefs();
            renderWizardSubjects();
            closeModal('modal-auto-fix-confirm');
            _autoFixPlan = null;
            // 重新執行 generatePlan
            if (typeof generatePlan === 'function') {
                try {
                    generatePlan();
                    console.log('[v1.6.159 executeAutoFix] ✅ 重排完成');
                } catch (e) {
                    console.error('[v1.6.159 executeAutoFix] ❌ generatePlan 失敗:', e);
                    alert('❌ 重排失敗:' + e.message);
                }
            }
        }
        
                // v1.5.111: 撤回智慧排程 - 自訂 modal 顯示「將被刪除/保留的清單」
        function showRevertWizardModal() {
            var pid = el('planner-selector').value;
            if (!pid) return alert('請先選擇計畫！');
            var plan = appPlans.find(p => p.id === pid);
            if (!plan || !plan.grid) return;
            
            var latestRunTime = 0;
            Object.keys(plan.grid).forEach(function(dStr) {
                (plan.grid[dStr] || []).forEach(function(t) {
                    if (t.wizardRunTime && t.wizardRunTime > latestRunTime) latestRunTime = t.wizardRunTime;
                });
            });
            if (!latestRunTime && plan.lastWizardRunTime) latestRunTime = plan.lastWizardRunTime;
            
            var toDelete = [];
            var toKeepAuto = [];
            var toKeepManual = [];
            
            Object.keys(plan.grid).forEach(function(dStr) {
                (plan.grid[dStr] || []).forEach(function(t) {
                    var isLatestWizard = (latestRunTime > 0) && t.wizardRunTime && t.wizardRunTime >= latestRunTime - 1000;
                    if (isLatestWizard) {
                        toDelete.push({date: dStr, task: t});
                    } else if (!t.isAuto) {
                        toKeepManual.push({date: dStr, task: t});
                    } else {
                        toKeepAuto.push({date: dStr, task: t});
                    }
                });
            });
            
            toDelete.sort(function(a, b) { return a.date.localeCompare(b.date); });
            
            var endChangeText = '';
            if (plan.lastWizardRunTime && plan.originalEndBeforeLastWizard && plan.end !== plan.originalEndBeforeLastWizard) {
                endChangeText = '<div style="background:#fff3cd; padding:10px; border-radius:6px; margin-top:8px; color:#856404;">' +
                    '<div style="font-weight:bold; margin-bottom:4px;">📅 計畫完成日期將被還原:</div>' +
                    '<div>原本 <strong>' + escapeHtml(plan.originalEndBeforeLastWizard) + '</strong> → 已延長到 <strong>' + escapeHtml(plan.end) + '</strong></div>' +
                    '<div style="margin-top:4px;">⚠️ 撤回後將還原到 <strong>' + escapeHtml(plan.originalEndBeforeLastWizard) + '</strong></div>' +
                    '</div>';
            }
            
            var deleteListHtml = '';
            var previewCount = Math.min(5, toDelete.length);
            if (toDelete.length === 0) {
                deleteListHtml = '<div style="color:#7f8c8d; padding:8px; text-align:center;">沒有找到可撤回的任務</div>';
            } else {
                for (var i = 0; i < previewCount; i++) {
                    var item = toDelete[i];
                    deleteListHtml += '<div style="padding:4px 8px; border-bottom:1px solid #f1f5f9; font-size:0.9em;">' +
                        '<span style="color:var(--accent); font-weight:bold;">' + escapeHtml(item.date) + '</span> ' +
                        '<span>' + escapeHtml(item.task.subject) + ' ' + escapeHtml(item.task.unitName || '') + ' P.' + item.task.startPage + '~' + item.task.endPage + '</span>' +
                        '</div>';
                }
                if (toDelete.length > previewCount) {
                    var fullListId = 'revert-full-list-' + Date.now();
                    deleteListHtml += '<div id="' + fullListId + '" style="display:none;">';
                    for (var j = previewCount; j < toDelete.length; j++) {
                        var it = toDelete[j];
                        deleteListHtml += '<div style="padding:4px 8px; border-bottom:1px solid #f1f5f9; font-size:0.9em;">' +
                            '<span style="color:var(--accent); font-weight:bold;">' + escapeHtml(it.date) + '</span> ' +
                            '<span>' + escapeHtml(it.task.subject) + ' ' + escapeHtml(it.task.unitName || '') + ' P.' + it.task.startPage + '~' + it.task.endPage + '</span>' +
                            '</div>';
                    }
                    deleteListHtml += '</div>' +
                        '<button type="button" class="btn-outline" onclick="document.getElementById(\'' + fullListId + '\').style.display=\'block\'; this.style.display=\'none\';" style="margin-top:6px; padding:4px 12px; font-size:0.85em;">📋 展開完整清單 (剩餘 ' + (toDelete.length - previewCount) + ' 筆)</button>';
                }
            }
            
            var existing = el('modal-revert-wizard');
            if (existing) existing.remove();
            
            var modal = document.createElement('div');
            modal.id = 'modal-revert-wizard';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3500';
            modal.style.display = 'flex';
            modal.innerHTML = '<div class="modal-content" style="max-width:600px;">' +
                '<div class="modal-header"><h2 style="color:var(--danger);">↩️ 撤回智慧排程</h2></div>' +
                '<div style="padding: 15px;">' +
                    '<div style="background:#fee; padding:12px; border-radius:6px; margin-bottom:12px;">' +
                        '<div style="font-weight:bold; color:var(--danger); margin-bottom:8px;">🗑️ 將刪除的任務 (' + toDelete.length + ' 筆):</div>' +
                        deleteListHtml +
                    '</div>' +
                    '<div style="background:#efe; padding:12px; border-radius:6px; margin-bottom:12px;">' +
                        '<div style="font-weight:bold; color:#27ae60; margin-bottom:6px;">✅ 將保留:</div>' +
                        '<div style="padding-left:12px; font-size:0.9em;">' +
                            '• 手動加的任務: <strong>' + toKeepManual.length + '</strong> 筆<br>' +
                            '• 之前的智慧排程: <strong>' + toKeepAuto.length + '</strong> 筆' +
                        '</div>' +
                    '</div>' +
                    endChangeText +
                '</div>' +
                '<div style="display:flex; gap:10px; justify-content:flex-end; padding:0 15px 15px;">' +
                    '<button type="button" class="btn-outline" onclick="closeRevertWizardModal()" style="padding:8px 20px;">✕ 取消</button>' +
                    '<button type="button" class="btn-danger" onclick="confirmRevertWizard()" style="padding:8px 20px;">✓ 確認撤回</button>' +
                '</div>' +
            '</div>';
            document.body.appendChild(modal);
            el('modal-revert-wizard').addEventListener('click', function(e) {
                if (e.target.id === 'modal-revert-wizard') closeRevertWizardModal();
            });
        }
        
        function closeRevertWizardModal() {
            var m = el('modal-revert-wizard');
            if (m) m.remove();
        }
        
        function confirmRevertWizard() {
            closeRevertWizardModal();
            // v1.5.111: 保留雙重確認 (原生 confirm)
            if (!confirm('⚠️ 確定要撤回智慧排程嗎？\n\n此操作會:\n• 刪除所有這次智慧排程產生的任務\n• 還原計畫完成日期\n• 保留所有手動加的任務\n\n確定執行？')) return;
            executeRevertWizard();
        }
        
        function executeRevertWizard() {
            var pid = el('planner-selector').value;
            var plan = appPlans.find(p => p.id === pid);
            if (!plan || !plan.grid) return;
            
            var latestRunTime = 0;
            Object.keys(plan.grid).forEach(function(dStr) {
                (plan.grid[dStr] || []).forEach(function(t) {
                    if (t.wizardRunTime && t.wizardRunTime > latestRunTime) latestRunTime = t.wizardRunTime;
                });
            });
            if (!latestRunTime && plan.lastWizardRunTime) latestRunTime = plan.lastWizardRunTime;
            
            if (plan.originalEndBeforeLastWizard && plan.end !== plan.originalEndBeforeLastWizard) {
                plan.end = plan.originalEndBeforeLastWizard;
            }
            
            var deletedCount = 0;
            var deletedUnits = {}; // v1.6.155: 收集被撤回的 unit
            Object.keys(plan.grid).forEach(function(dStr) {
                var origLen = plan.grid[dStr].length;
                if (latestRunTime > 0) {
                    plan.grid[dStr] = plan.grid[dStr].filter(function(t) {
                        if (!t.isAuto) return true;
                        if (!t.wizardRunId) return true;
                        if (t.wizardRunTime && t.wizardRunTime >= latestRunTime - 1000) {
                            var uKey = t.unitId || '?';
                            if (!deletedUnits[uKey]) {
                                deletedUnits[uKey] = { name: t.unitName || uKey, count: 0, cat: t.cat || '', mis: t.mis || '' };
                            }
                            deletedUnits[uKey].count++;
                            return false;
                        }
                        return true;
                    });
                } else {
                    plan.grid[dStr] = plan.grid[dStr].filter(function(t) {
                        if (t.isAuto) {
                            var uKey = t.unitId || '?';
                            if (!deletedUnits[uKey]) {
                                deletedUnits[uKey] = { name: t.unitName || uKey, count: 0, cat: t.cat || '', mis: t.mis || '' };
                            }
                            deletedUnits[uKey].count++;
                            return false;
                        }
                        return true;
                    });
                }
                deletedCount += (origLen - plan.grid[dStr].length);
                if (plan.grid[dStr].length === 0) delete plan.grid[dStr];
            });
            
            // v1.6.151: 清 schedule map cache, 下次開 wizard 才會讀到正確的 grid 狀態
            if (typeof invalidateSchedCache === 'function') invalidateSchedCache();
            saveToLocal();
            updatePlannerSelector();
            renderCalendar();
            // v1.6.152: 顯示撤回後狀態 (幫助診斷)
            console.log('[v1.6.152 executeRevertWizard] 已刪 ' + deletedCount + ' 筆, _schedCache 已清, grid keys: ' + Object.keys(plan.grid).length);
            // v1.6.155: 列出被刪的 unit 給用戶確認
            if (Object.keys(deletedUnits).length > 0) {
                var deletedArr = Object.keys(deletedUnits).map(function(uid){ return { id: uid, info: deletedUnits[uid] }; });
                console.log('[v1.6.155 executeRevertWizard] 被撤回的 unit (共 ' + deletedArr.length + ' 種, ' + deletedCount + ' 筆任務):');
                deletedArr.forEach(function(d){ console.log('  - ' + d.id + ' (' + d.info.name + ') x ' + d.info.count + (d.info.cat ? ' [' + d.info.cat + '/' + d.info.mis + ']' : '')); });
            }
            
            if (deletedCount > 0) {
                // v1.6.155: 列出被消失的 unit 讓用戶確認
                var unitLines = Object.keys(deletedUnits).map(function(uid) {
                    return '  - ' + deletedUnits[uid].name + ' (' + uid.substring(0, 8) + '...) x ' + deletedUnits[uid].count + ' 筆';
                }).join('\n');
                var firstInfo = Object.values(deletedUnits)[0];
                var catMisInfo = (firstInfo && firstInfo.cat) ? ('\n類別: ' + firstInfo.cat + ' / 任務: ' + firstInfo.mis) : '';
                alert('已撤回 ' + deletedCount + ' 筆智慧排程任務\n\n被撤回的單元 (共 ' + Object.keys(deletedUnits).length + ' 種)' + catMisInfo + ':\n' + unitLines + '\n\n提示:撤回後再次進入智慧排程,剛才的單元應會重新出現在選單中 (因為 cache 已清)。\n\n如果再進去還是看不到這些單元,請按 F12 看 console 並截圖給開發者');
            } else {
                alert('❌ 沒有找到可撤回的任務 (目前的進度皆為手動建立)');
            }
        }
        
        function deleteCurrentPlan() { 
            var pid = el('planner-selector').value; 
            if(!pid) return; 
            // v1.5.102: 改成只刪「最新一次 wizard 跑出來的」 (用 wizardRunId)
            var plan = appPlans.find(p => p.id === pid);
            if (!plan || !plan.grid) return;
            
            // 找最新 wizardRunId
            var latestRunId = null;
            var latestRunTime = 0;
            Object.keys(plan.grid).forEach(function(dStr) {
                (plan.grid[dStr] || []).forEach(function(t) {
                    if (t.wizardRunId && t.wizardRunTime && t.wizardRunTime > latestRunTime) {
                        latestRunId = t.wizardRunId;
                        latestRunTime = t.wizardRunTime;
                    }
                });
            });
            // fallback: 找 plan 自己的 lastWizardRunTime
            if (!latestRunTime && plan.lastWizardRunTime) {
                latestRunTime = plan.lastWizardRunTime;
            }
            // 找所有 isAuto 但沒 wizardRunId 的任務, 視為舊的
            var oldAutoCount = 0;
            Object.keys(plan.grid).forEach(function(dStr) {
                (plan.grid[dStr] || []).forEach(function(t) {
                    if (t.isAuto && !t.wizardRunId) oldAutoCount++;
                });
            });
            
            var confirmMsg = (latestRunTime > 0)
                ? "🗑️ 確定刪除「最新一次 wizard 排程」的任務嗎？\n(只刪最新一次跑的, 之前的智慧排程與手動加的都保留)\n\n⚠️ 注意: 還有 " + oldAutoCount + " 筆舊的自動排程任務 (沒 wizardRunId 標記) 將保留。"
                : "🗑️ 確定清除此計畫中的「自動排程」任務嗎？\n(將刪除所有 isAuto=true 的任務)\n\n⚠️ 注意: 此操作無法還原, 但手動任務會保留。";
            
            if(confirm(confirmMsg)) { 
                if(plan && plan.grid) {
                    var deletedCount = 0;
                    Object.keys(plan.grid).forEach(dStr => {
                        var origLen = plan.grid[dStr].length;
                        if (latestRunTime > 0) {
                            // 只刪最新一次 wizard 的任務
                            plan.grid[dStr] = plan.grid[dStr].filter(function(t) {
                                if (!t.isAuto) return true;  // 保留手動
                                if (!t.wizardRunId) return true;  // 保留舊 auto
                                if (t.wizardRunTime && t.wizardRunTime >= latestRunTime - 1000) return false;  // 刪最新
                                return true;
                            });
                        } else {
                            // 沒 lastWizardRunTime, fallback 刪所有 isAuto
                            plan.grid[dStr] = plan.grid[dStr].filter(t => !t.isAuto);
                        }
                        deletedCount += (origLen - plan.grid[dStr].length);
                        if(plan.grid[dStr].length === 0) delete plan.grid[dStr];
                    });
                    
                    saveToLocal(); 
                    updatePlannerSelector(); 
                    renderCalendar();
                    if (deletedCount > 0) {
                        alert(`已成功清除 ${deletedCount} 筆由智慧精靈建立的自動排程任務！`);
                    } else {
                        alert(`沒有找到任何自動排程的任務可刪除。(目前的進度皆為手動建立，系統已為您完全保留)`);
                    }
                }
            } 
        }
        function editCalendarTask(pid, dateStr, taskId) {
            var plan = appPlans.find(p => p.id === pid);
            var taskArr = Array.isArray(plan.grid[dateStr]) ? plan.grid[dateStr] : [];
            var task = taskArr.find(t => t.id === taskId);
            
            el('pc-date').value = dateStr; 
            el('pc-taskid').value = taskId;
            el('pc-subject').value = task.subject || '';
            el('pc-text').value = task.text || '';
            el('pc-start').value = task.startPage || '';
            el('pc-end').value = task.endPage || '';
            el('pc-old-end').value = task.endPage || '';
            
            openModal('modal-planner-cell');
        }
        function saveCalendarTask() {
            // v1.5.98: 儲存前先清理歷史重複任務 (合併同一天同單元的兩筆)
            var cleanedCount = cleanDuplicateSameDayTasks();
            if (cleanedCount > 0) {
                console.log('🧹 已清理 ' + cleanedCount + ' 筆同一天同單元重複任務');
            }
            
            var pid = el('planner-selector').value; 
            var dateStr = el('pc-date').value; 
            var taskId = el('pc-taskid').value;
            var plan = appPlans.find(p => p.id === pid); 
            var taskArr = Array.isArray(plan.grid[dateStr]) ? plan.grid[dateStr] : [];
            var task = taskArr.find(t => t.id === taskId);
            
            if(!task) return alert('找不到該任務！');
            var newSub = el('pc-subject').value;
            if(newSub) task.subject = newSub;
            task.startPage = Number(el('pc-start').value) || 0;
            var newEnd = Number(el('pc-end').value) || 0;
            var oldEnd = Number(el('pc-old-end').value) || 0;
            task.endPage = newEnd;
            var userText = el('pc-text').value;
            var baseText = userText.replace(/\s*P\.\d+(~\d+)?\s*$/, '').trim();
            
            // 1. 更新當前任務文字
            if (task.startPage && task.endPage) {
                if (task.startPage !== task.endPage) {
                    task.text = baseText + ` P.${task.startPage}~${task.endPage}`;
                } else {
                    task.text = baseText + ` P.${task.startPage}`;
                }
            } else if (task.startPage) {
                task.text = baseText + ` P.${task.startPage}`;
            } else {
                task.text = baseText;
            }
            // 2. 更新歷史 Log
            var linkedLog = appLogs.find(l => l.id === 'cal_' + task.id);
            if (linkedLog) {
                linkedLog.subject = task.subject;
                let extractedName = task.text.replace(`[${task.subject}] `, '').replace(/\s*P\.\d+(~\d+)?\s*$/, '').replace(/^【.*?】\s*/, '').replace(/🔔\s*/, '').trim();
                linkedLog.unitName = extractedName;
                linkedLog.detail = extractedName;
                linkedLog.start = task.startPage;
                linkedLog.end = task.endPage;
                linkedLog.pages = (task.endPage && task.startPage && task.endPage >= task.startPage) ? (task.endPage - task.startPage + 1) : 1;
            }
            // ==========================================
            // 3. 修正：連動推移後續任務的邏輯 (Ripple Effect)
            // ==========================================
            if (task.unitId && oldEnd && newEnd && oldEnd !== newEnd) {
                // v1.5.88: debug log
                let maxUnitEnd = newEnd;
                let foundMasterEnd = false;
                
                // (A) v1.5.92: 取得該單元真正的總結尾頁數 (maxUnitEnd)
                // 優先從 multiData 取得最新資料,fallback 才用 appMaster
                // v1.5.92: 支援新架構 (materials[*].instances[*].units)
                if (task.subject && task.unitId) {
                    let sInfo = null;
                    let user = multiData[currentUserId];
                    if (user && user.masters && task.cat && user.masters[task.cat]) {
                        sInfo = user.masters[task.cat][task.subject];
                    }
                    if (!sInfo && appMaster && appMaster[task.subject]) {
                        sInfo = appMaster[task.subject];
                    }
                    if (sInfo) {
                        let u = null;
                        if (sInfo.type === 'custom') {
                            u = sInfo.units.find(x => x.id === task.unitId);
                        } else if (sInfo.vols && Object.keys(sInfo.vols).length > 0) {
                            // 舊架構: sInfo.vols[冊名].units
                            for (let v in sInfo.vols) {
                                u = sInfo.vols[v].find(x => x.id === task.unitId);
                                if (u) break;
                            }
                        } else if (sInfo.materials) {
                            // v1.5.92: 新架構: sInfo.materials[類型].instances[].units
                            for (let matType in sInfo.materials) {
                                let mat = sInfo.materials[matType];
                                if (mat && mat.instances) {
                                    for (let inst of mat.instances) {
                                        if (inst && inst.units) {
                                            u = inst.units.find(x => x.id === task.unitId);
                                            if (u) break;
                                        }
                                    }
                                }
                                if (u) break;
                            }
                        }
                        if (u && u.end) {
                            maxUnitEnd = Number(u.end);
                            foundMasterEnd = true;
                        }
                    }
                }
                
                // 防呆: 1) 教材庫找不到時,從月曆上同 unitId 的任務推算 maxUnitEnd
                //      2) 如果新設定大於母體,以目前操作的最大值為準
                if (!foundMasterEnd) {
                    let maxEndInCalendar = Math.max(oldEnd, newEnd);
                    if (plan && plan.grid) {
                        Object.keys(plan.grid).forEach(d => {
                            (plan.grid[d] || []).forEach(t => {
                                if (t.unitId === task.unitId && t.endPage) {
                                    maxEndInCalendar = Math.max(maxEndInCalendar, t.endPage);
                                }
                            });
                        });
                    }
                    maxUnitEnd = maxEndInCalendar;
                }
                if (maxUnitEnd < Math.max(oldEnd, newEnd)) {
                    maxUnitEnd = Math.max(oldEnd, newEnd);
                }
                // v1.5.103: 提早宣告 overflowDates / overflowExceedsPlan (避免 TDZ error)
                let overflowDates = [];
                let overflowExceedsPlan = false;
                
                // (B) 收集此日期「之後」，屬於「同一個單元」且未完成的任務
                // v1.5.96: 排除已 done 的任務; 沒 isAuto 旗標也視為 auto (舊資料相容)
                // v1.5.97: 如果全部都 isAuto=false, 才跳過 (使用者手動加的不要重排)
                let futureTasks = [];
                let allManual = true;
                Object.keys(plan.grid).forEach(d => {
                    if (d > dateStr) {
                        plan.grid[d].forEach(t => {
                            if (t.unitId === task.unitId && !t.isDone) {
                                if (t.isAuto) allManual = false;
                                futureTasks.push({ date: d, task: t });
                            }
                        });
                    }
                });
                // 全部都是手動加的 → 不要自動重排
                if (allManual && futureTasks.length > 0 && !futureTasks.some(function(ft) { return ft.task.isAuto === undefined; })) {
                    futureTasks = [];
                }
                
                // 按照日期先後排序
                futureTasks.sort((a, b) => a.date.localeCompare(b.date));
                
                let currentStart = newEnd + 1; // 接下來要分配的起始頁
                
                // (C) v1.5.95: 平均重新分配 + 考慮 plan.end
                const cTotalPages = maxUnitEnd - newEnd;
                // 計算可用天數 (plan.end 存在時)
                let cAvailableDays = Infinity;
                if (plan.end) {
                    const todayDate = new Date(dateStr);
                    const planEndDate = new Date(plan.end);
                    cAvailableDays = Math.max(1, Math.ceil((planEndDate - todayDate) / (1000 * 60 * 60 * 24)));
                }
                // 理想天數: 3 頁/天
                const cIdealDays = Math.max(1, Math.ceil(cTotalPages / 3));
                // 實際天數: min(理想, 可用, 現有 futureTasks)
                let cUseDays = Math.min(
                    futureTasks.length,
                    cAvailableDays === Infinity ? cIdealDays : Math.min(cIdealDays, cAvailableDays)
                );
                if (cUseDays === 0 && cTotalPages > 0) cUseDays = 1;
                
                if (cUseDays > 0) {
                    const cPagesPerDay = Math.floor(cTotalPages / cUseDays);
                    const cExtraPages = cTotalPages % cUseDays;
                    
                    for (let i = 0; i < futureTasks.length; i++) {
                        const ft = futureTasks[i].task;
                        const fDate = futureTasks[i].date;
                        
                        // 多餘的 future tasks 刪除
                        if (i >= cUseDays || currentStart > maxUnitEnd) {
                            plan.grid[fDate] = plan.grid[fDate].filter(x => x.id !== ft.id);
                            continue;
                        }
                        
                        const dayPages = (i < cExtraPages) ? cPagesPerDay + 1 : cPagesPerDay;
                        const nextEnd = Math.min(currentStart + dayPages - 1, maxUnitEnd);
                        ft.startPage = currentStart;
                        ft.endPage = nextEnd;
                        
                        const ftBase = ft.text.replace(/\s*P\.\d+(~\d+)?\s*$/, '').trim();
                        ft.text = ftBase + (currentStart === nextEnd ? ` P.${currentStart}` : ` P.${currentStart}~${nextEnd}`);
                        
                        currentStart = nextEnd + 1;
                        
                        // v1.5.95: 檢查 plan.end
                        if (plan.end && fDate > plan.end) {
                            overflowExceedsPlan = true;
                        }
                        if (overflowDates.indexOf(fDate) === -1) overflowDates.push(fDate);
                    }
                }
                
                // (D) v1.5.93: 平均分配 + 超出 plan.end 警告
                // v1.5.103: overflowDates / overflowExceedsPlan 已在前面宣告
                let pendingTasks = [];  // 暫存待建立的任務,等使用者決定後才建
                let pendingOriginalEnd = null;  // 原本的 plan.end (用於取消時還原)
                let pendingNewEnd = null;  // 延長後的新 plan.end
                let subjectName = task.subject || '自訂';
                
                if (currentStart <= maxUnitEnd && newEnd < oldEnd) {
                    const totalPages = maxUnitEnd - currentStart + 1;
                    
                    // 計算可用天數 (plan.end - 今天)
                    let availableDays = Infinity;
                    if (plan.end) {
                        const todayDate = new Date(dateStr);
                        const planEndDate = new Date(plan.end);
                        const daysDiff = Math.ceil((planEndDate - todayDate) / (1000 * 60 * 60 * 24));
                        availableDays = Math.max(1, daysDiff);
                    }
                    
                    // 平均分攤 (3 頁/天),算出理想天數
                    const basePerDay = 3;
                    const idealDays = Math.max(1, Math.ceil(totalPages / basePerDay));
                    
                    // 起始日期
                    let startDate = new Date(dateStr);
                    if (futureTasks.length > 0) {
                        startDate = new Date(futureTasks[futureTasks.length - 1].date);
                    }
                    startDate.setDate(startDate.getDate() + 1);
                    
                    // 決定實際使用天數 (有限制就用限制內的天數)
                    const useDays = (availableDays === Infinity) ? idealDays : Math.min(idealDays, availableDays);
                    
                    // v1.5.93: 平均分配 (前 extraPages 天多 1 頁, 其餘 basePerDay)
                    const pagesPerDay = Math.floor(totalPages / useDays);
                    const extraPages = totalPages % useDays;
                    
                    let leftoverStart = currentStart;
                    let dayCount = 0;
                    
                    while (leftoverStart <= maxUnitEnd && dayCount < useDays) {
                        const dayPages = (dayCount < extraPages) ? pagesPerDay + 1 : pagesPerDay;
                        const dayEnd = Math.min(leftoverStart + dayPages - 1, maxUnitEnd);
                        let dayDateStr = getLocalDateString(startDate);
                        dayCount++;
                        // v1.5.98: 防呆 — 如果當天已有同 unitId 的任務, 跳過這天 (找下一個空日)
                        let dupAttempts = 0;
                        while (dupAttempts < 7 && plan.grid[dayDateStr] && (plan.grid[dayDateStr] || []).some(function(t) { return t.unitId === task.unitId; })) {
                            startDate.setDate(startDate.getDate() + 1);
                            dayDateStr = getLocalDateString(startDate);
                            dupAttempts++;
                        }
                        
                        // 檢查是否超出 mission 計畫完成日期
                        const exceedsPlan = plan.end && dayDateStr > plan.end;
                        if (exceedsPlan) overflowExceedsPlan = true;
                        overflowDates.push(dayDateStr);
                        
                        // v1.5.93: 暫存任務,等使用者決定
                        pendingTasks.push({
                            dateStr: dayDateStr,
                            startPage: leftoverStart,
                            endPage: dayEnd
                        });
                        
                        leftoverStart = dayEnd + 1;
                        startDate.setDate(startDate.getDate() + 1);
                    }
                    
                    // 暫存原本的 plan.end (用於取消時還原)
                    pendingOriginalEnd = plan.end;
                }
                
                // 改進 2 + 3: 顯示補排結果訊息 (v1.5.96: 不管 (C) 或 (D) 都要看)
                if ((currentStart <= maxUnitEnd || pendingTasks.length > 0) && newEnd < oldEnd) {
                    // v1.5.93: 建立所有 pendingTasks
                    pendingTasks.forEach(function(p) {
                        if (!plan.grid[p.dateStr]) plan.grid[p.dateStr] = [];
                        plan.grid[p.dateStr].unshift({
                            id: genId(), subject: subjectName, 
                            text: baseText + (p.startPage === p.endPage ? ` P.${p.startPage}` : ` P.${p.startPage}~${p.endPage}`),
                            startPage: p.startPage, endPage: p.endPage, isDone: false,
                            cat: task.cat, mis: task.mis, unitId: task.unitId, vol: task.vol, unitName: task.unitName,
                            postponeCount: (task.postponeCount || 0) + 1,
                            isAuto: task.isAuto
                        });
                        appLogs.push({ id: genId(), date: dateStr, category: '🔄 系統重排', mission: plan.name, subject: subjectName, unitName: '連動順延', start: p.startPage, end: p.endPage, pages: p.endPage - p.startPage + 1, detail: `手動調整進度，剩餘 P.${p.startPage}~${p.endPage} 順延至 ${p.dateStr}` });
                        checkDailyWorkload(plan, p.dateStr);
                    });
                    
                    // v1.5.95: 如果超出 plan.end, 撤銷任務並用 3 選項 modal
                    if (overflowExceedsPlan) {
                        // 撤銷剛才建立的任務
                        pendingTasks.forEach(function(p) {
                            plan.grid[p.dateStr] = (plan.grid[p.dateStr] || []).filter(function(t) { 
                                return !(t.startPage === p.startPage && t.endPage === p.endPage && t.unitId === task.unitId);
                            });
                        });
                        
                        // 計算讀書時數
                        const totalPages = pendingTasks.reduce((s, p) => s + (p.endPage - p.startPage + 1), 0);
                        const minutesPerPage = 5;
                        const availableDaysForPlan = Math.max(1, Math.ceil((new Date(plan.end) - new Date(dateStr)) / (1000 * 60 * 60 * 24)));
                        const neededDays = pendingTasks.length;
                        const addedMinutesPerDay = Math.ceil(totalPages * minutesPerPage / availableDaysForPlan);
                        const minExtraDays = Math.max(1, neededDays - availableDaysForPlan);
                        
                        const choiceMsg = `⚠️ 平均分配會超出計畫完成日期 (${plan.end})\n\n` +
                            `剩餘 ${totalPages} 頁需 ${neededDays} 天\n` +
                            `但計畫剩 ${availableDaysForPlan} 天\n\n` +
                            `📊 讀書時數估算 (預設 ${minutesPerPage} 分/頁):\n` +
                            `  - 總時數: ${totalPages * minutesPerPage} 分鐘\n` +
                            `  - 每天需 +${addedMinutesPerDay} 分鐘`;
                        
                        // v1.5.95: 用 3 選項 modal
                        openThreeChoiceModal(
                            '⏰ 重新分配超出計畫日期',
                            choiceMsg,
                            '📅 強制擠進',
                            '⏰ 延長完成日期',
                            '✕ 取消這次編輯',
                            function() {
                                // 選項 A: 強制擠進 - 重建任務
                                pendingTasks.forEach(function(p) {
                                    if (!plan.grid[p.dateStr]) plan.grid[p.dateStr] = [];
                                    plan.grid[p.dateStr].unshift({
                                        id: genId(), subject: subjectName, 
                                        text: baseText + (p.startPage === p.endPage ? ` P.${p.startPage}` : ` P.${p.startPage}~${p.endPage}`),
                                        startPage: p.startPage, endPage: p.endPage, isDone: false,
                                        cat: task.cat, mis: task.mis, unitId: task.unitId, vol: task.vol, unitName: task.unitName,
                                        postponeCount: (task.postponeCount || 0) + 1,
                                        isAuto: task.isAuto
                                    });
                                    appLogs.push({ id: genId(), date: dateStr, category: '🔄 系統重排', mission: plan.name, subject: subjectName, unitName: '連動順延 (強制擠進)', start: p.startPage, end: p.endPage, pages: p.endPage - p.startPage + 1, detail: `強制擠進, 超出計畫完成日期` });
                                    checkDailyWorkload(plan, p.dateStr);
                                });
                                alert(`✅ 已強制擠進 (每天 +${addedMinutesPerDay} 分鐘)。建議日後延長 plan.end。`);
                            },
                            function() {
                                // 選項 B: 延長完成日期
                                openExtendDateDialog(plan.end, minExtraDays, 7, function(days) {
                                    const newEndDate = new Date(plan.end);
                                    newEndDate.setDate(newEndDate.getDate() + days);
                                    const newEndDateStr = getLocalDateString(newEndDate);
                                    plan.end = newEndDateStr;
                                    
                                    // 重建任務
                                    pendingTasks.forEach(function(p) {
                                        if (!plan.grid[p.dateStr]) plan.grid[p.dateStr] = [];
                                        plan.grid[p.dateStr].unshift({
                                            id: genId(), subject: subjectName, 
                                            text: baseText + (p.startPage === p.endPage ? ` P.${p.startPage}` : ` P.${p.startPage}~${p.endPage}`),
                                            startPage: p.startPage, endPage: p.endPage, isDone: false,
                                            cat: task.cat, mis: task.mis, unitId: task.unitId, vol: task.vol, unitName: task.unitName,
                                            postponeCount: (task.postponeCount || 0) + 1,
                                            isAuto: task.isAuto
                                        });
                                        appLogs.push({ id: genId(), date: dateStr, category: '🔄 系統重排', mission: plan.name, subject: subjectName, unitName: '連動順延 (延長計畫)', start: p.startPage, end: p.endPage, pages: p.endPage - p.startPage + 1, detail: `延長 plan.end 至 ${newEndDateStr} 後排入` });
                                        checkDailyWorkload(plan, p.dateStr);
                                    });
                                    alert(`✅ 已延長 plan.end 至 ${newEndDateStr} 並建立任務。`);
                                });
                            },
                            function() {
                                // 選項 C: 完全取消
                                task.startPage = Number(el('pc-start').value) || 0;
                                task.endPage = oldEnd;
                                alert('已取消這次編輯。');
                            }
                        );
                    } else {
                        // 沒超出 plan.end
                        alert(`✅ 已為您更新進度!\n\n新增 ${pendingTasks.length} 個任務到 ${overflowDates[0]} ~ ${overflowDates[overflowDates.length - 1]}`);
                    }
                } else {
                    alert(`✅ 已為您更新進度！後續相關排程已自動連動推移。`);
                }
                
            } else if (!task.unitId && oldEnd && newEnd && newEnd < oldEnd) {
                // [保留機制]：若是「純手動無連動單元」的舊任務，退回原本的簡單順延邏輯
                var nextDate = new Date(dateStr); nextDate.setDate(nextDate.getDate() + 1);
                var nextDateStr = getLocalDateString(nextDate);
                
                if(!plan.grid[nextDateStr] || !Array.isArray(plan.grid[nextDateStr])) plan.grid[nextDateStr] = [];
                var subjectName = task.subject || '自訂';
                var newPcCount = (task.postponeCount || 0) + 1;
                plan.grid[nextDateStr].unshift({
                    id: genId(), subject: subjectName, text: `${baseText} P.${newEnd + 1}~${oldEnd}`, 
                    startPage: newEnd + 1, endPage: oldEnd, isDone: false,
                    cat: task.cat, mis: task.mis, unitId: task.unitId, vol: task.vol, unitName: task.unitName,
                    postponeCount: newPcCount,
                    isAuto: task.isAuto
                });
                
                appLogs.push({ id: genId(), date: dateStr, category: '🔄 系統重排', mission: plan.name, subject: subjectName, unitName: '微調順延', start: newEnd+1, end: oldEnd, pages: oldEnd-newEnd, detail: `手動調整落後，P.${newEnd+1}~${oldEnd} 順延至 ${nextDateStr}` });
                alert(`⚠️ 您縮減了範圍！未完成的 P.${newEnd+1}~${oldEnd} 已自動順延至明日(${nextDateStr})。`);
                checkDailyWorkload(plan, nextDateStr);
            }
            saveToLocal(); 
            closeModal('modal-planner-cell'); 
            renderCalendar();
            if (el('page-history') && el('page-history').style.display === 'block') renderHistoryTable();
        }
        // v1.5.106: 清理教材庫 P.1-1 placeholder unit (麻辣甲 U1 + 3800 第一冊)
        function cleanupP1PlaceholderUnits() {
            var targets = [
                {subj: '數學', material: '複習卷', instance: '麻辣甲', name: 'U1', id: 'id_rgzr5ba3n'},
                {subj: '數學', material: '數字題本', instance: '3800', name: '第一冊', id: 'id_20x1pkax1'}
            ];
            var deleted = [];
            if (!appMaster) return deleted;
            targets.forEach(function(t) {
                var s = appMaster[t.subj];
                if (!s || !s.materials) return;
                var mat = s.materials[t.material];
                if (!mat || !mat.instances) return;
                mat.instances.forEach(function(inst) {
                    if (inst.name !== t.instance) return;
                    if (!inst.units) return;
                    var origLen = inst.units.length;
                    inst.units = inst.units.filter(function(u) {
                        if (u.id === t.id && u.start === 1 && u.end === 1) {
                            deleted.push(t.subj + ' / ' + t.material + ' / ' + t.instance + ' / ' + t.name);
                            return false;
                        }
                        return true;
                    });
                });
            });
            if (deleted.length > 0) {
                saveToLocal();
                console.log('🧹 清理 P.1-1 placeholder: ' + deleted.length + ' 個');
            }
            return deleted;
        }
        // v1.5.106: 教材庫 P.1-1 清理 UI (含確認)
        function cleanupP1PlaceholderUnitsUI() {
            var deleted = cleanupP1PlaceholderUnits();
            if (deleted.length === 0) {
                alert('沒有找到 P.1-1 placeholder (可能已被清理過)');
                return;
            }
            alert('🧹 已清理 ' + deleted.length + ' 個 P.1-1 placeholder:\n\n' + deleted.join('\n'));
            // 重新渲染
            if (typeof renderTreeView === 'function') renderTreeView();
            if (typeof renderDashboard === 'function') renderDashboard();
        }
        // v1.5.98: 清理同一天同單元重複任務 (合併兩筆為一筆)
        function cleanDuplicateSameDayTasks() {
            if (!appPlans || appPlans.length === 0) return 0;
            let totalCleaned = 0;
            appPlans.forEach(function(plan) {
                if (!plan.grid) return;
                Object.keys(plan.grid).forEach(function(d) {
                    var tasks = plan.grid[d] || [];
                    if (tasks.length < 2) return;
                    var byUnit = {};
                    tasks.forEach(function(t) {
                        if (!t.unitId) return;
                        if (!byUnit[t.unitId]) byUnit[t.unitId] = [];
                        byUnit[t.unitId].push(t);
                    });
                    Object.keys(byUnit).forEach(function(uid) {
                        var group = byUnit[uid];
                        if (group.length < 2) return;
                        group.sort(function(a, b) { return (a.startPage || 0) - (b.startPage || 0); });
                        var baseText = group[0].text.replace(/P\.\d+(~\d+)?\s*$/, '').trim();
                        var merged = {
                            id: group[0].id,
                            subject: group[0].subject,
                            cat: group[0].cat,
                            mis: group[0].mis,
                            unitId: uid,
                            vol: group[0].vol,
                            unitName: group[0].unitName,
                            isAuto: group[0].isAuto,
                            postponeCount: group[0].postponeCount || 0,
                            startPage: group[0].startPage,
                            endPage: group[group.length - 1].endPage,
                            isDone: group.some(function(t) { return t.isDone; }),
                            text: baseText + ' P.' + group[0].startPage + '~' + group[group.length - 1].endPage
                        };
                        var remaining = tasks.filter(function(t) { return t.unitId !== uid; });
                        plan.grid[d] = remaining.concat([merged]);
                        totalCleaned += group.length - 1;
                    });
                });
            });
            return totalCleaned;
        }
        function deleteCalendarTask() {
            var pid = el('planner-selector').value; var dateStr = el('pc-date').value; var taskId = el('pc-taskid').value;
            var plan = appPlans.find(p => p.id === pid);
            if(Array.isArray(plan.grid[dateStr])) plan.grid[dateStr] = plan.grid[dateStr].filter(t => t.id !== taskId);
            appLogs = appLogs.filter(l => l.id !== 'cal_' + taskId);
            saveToLocal(); closeModal('modal-planner-cell'); renderCalendar(); renderDashboard(); 
            if (el('page-history') && el('page-history').style.display === 'block') renderHistoryTable();
        }
        // v1.5.46: helper — 取得目前活躍的 add-event 容器（modal 或 page-add-event）
        function getActiveAeContainer() {
            var modalEl = document.getElementById('modal-add-event');
            if (modalEl && modalEl.style.display !== 'none') return modalEl;
            return document.getElementById('page-add-event');
        }
        function openAddEventModal(dateStr, planId) {
            // v1.5.52: 明確寫入 page-add-event，徹底不用 modal
            var aeC = document.getElementById('page-add-event');
            aeC.querySelector('#ae-date').value = dateStr;
            aeC.querySelector('#ae-date').dataset.pid = planId;
            aeC.querySelector('#ae-date-display').innerText = dateStr;
            var currentCat = el('planner-cat-filter') ? el('planner-cat-filter').value : 'ALL';
            var currentMis = el('planner-mis-filter') ? el('planner-mis-filter').value : 'ALL';
            var catOpts = '<option value="">-- 純手動自訂行程 (不連動) --</option>';
            Object.keys(appMissions).forEach(c => catOpts += `<option value="${c}">${c}</option>`);
            aeC.querySelector('#ae-cat').innerHTML = catOpts;
            aeC.querySelector('#ae-subject').value = '';
            aeC.querySelector('#ae-text').value = '';
            aeC.querySelector('#ae-start').value = '';
            aeC.querySelector('#ae-end').value = '';
            aeC.querySelector('#ae-reminder').checked = false;
            window.aeSelectedItems = [];
            updateAeSelectedDisplay();
            if (currentCat !== 'ALL' && appMissions[currentCat]) {
                aeC.querySelector('#ae-cat').value = currentCat;
                onAeCatChange(currentMis !== 'ALL' ? currentMis : '');
            } else {
                aeC.querySelector('#ae-cat').value = '';
                aeC.querySelector('#ae-mis').innerHTML = '<option value="">(不選擇任務)</option>';
                aeC.querySelector('#ae-cards-dynamic').innerHTML = '<div style="color:#7f8c8d; padding:10px;">(請先選擇上方分類與任務)</div>';
                aeC.querySelector('#ae-nav-text').textContent = '--';
                aeC.querySelector('#ae-btn-prev').style.display = 'none';
                aeC.querySelector('#ae-btn-next').style.display = 'none';
            }
            // v1.5.53: 同時設 inline style + class，避免被舊 inline style 壓過
            var pp = document.getElementById('page-planner');
            if (pp) { pp.classList.remove('active'); pp.style.display = 'none'; }
            aeC.classList.add('active');
            aeC.style.display = 'block';
            window.scrollTo(0, 0);
        }
        // v1.5.46: 關閉新增頁，返回月曆
        function closeAddEventPage() {
            // v1.5.53: 同時設 inline style + class
            var aeC = document.getElementById('page-add-event');
            var pp = document.getElementById('page-planner');
            if (aeC) { aeC.classList.remove('active'); aeC.style.display = 'none'; }
            if (pp) { pp.classList.add('active'); pp.style.display = 'block'; }
            // 順便重刷月曆，確保顯示最新資料
            if (typeof renderCalendar === 'function') renderCalendar();
            window.scrollTo(0, 0);
        }
        // ==========================================
        // 修正處 3：手動新增視窗 (onAeMisChange) 導入 getUnitScheduleStatus
        // 並自動帶入剩餘的起訖範圍
        // ==========================================
        function onAeCatChange(preselectMis) {
            var aeC = getActiveAeContainer();
            var cat = aeC.querySelector('#ae-cat').value;
            if(!cat) {
                aeC.querySelector('#ae-mis').innerHTML = '<option value="">(不選擇任務)</option>';
                document.querySelectorAll('#ae-cards-dynamic').forEach(function(c){c.innerHTML = '<div style="color:#7f8c8d; padding:10px;">(請先選擇上方分類與任務)</div>';});
                aeC.querySelector('#ae-nav-text').textContent = '--';
                aeC.querySelector('#ae-btn-prev').style.display = 'none';
                aeC.querySelector('#ae-btn-next').style.display = 'none';
                return;
            }
            populateSelect('ae-mis', Object.keys(appMissions[cat] || {}), null);
            aeC.querySelector('#ae-mis').insertAdjacentHTML('afterbegin', '<option value="">-- 請選擇任務 --</option>');
            if (typeof preselectMis === 'string' && preselectMis && appMissions[cat][preselectMis]) {
                aeC.querySelector('#ae-mis').value = preselectMis;
            } else {
                aeC.querySelector('#ae-mis').value = '';
            }
            onAeMisChange();
        }
        function onAeMisChange() {
            var aeC = getActiveAeContainer();
            var cat = aeC.querySelector('#ae-cat').value;
            var mis = aeC.querySelector('#ae-mis').value;
            var container = aeC.querySelector('#ae-subject-unit-container');
            var cardsDynamic = getActiveAeContainer().querySelector('#ae-cards-dynamic');
            if(!cat || !mis) {
                cardsDynamic.innerHTML = '<div style="color:#7f8c8d; padding:10px;">(請先選擇上方分類與任務)</div>';
                getActiveAeContainer().querySelector('#ae-nav-text').textContent = '--';
                getActiveAeContainer().querySelector('#ae-btn-prev').style.display = 'none';
                getActiveAeContainer().querySelector('#ae-btn-next').style.display = 'none';
                return;
            }
            var mTree = buildMissionTree(cat, mis);
            var subKeys = Object.keys(mTree);
            subKeys = getSortedSubjects(subKeys);
            // 收集每個科目的 units
            var subjectData = {};
            subKeys.forEach(function(sub){
                var sTree = mTree[sub];
                var subUnits = [];
                if (sTree.type === 'custom') {
                    sTree.items['custom'].forEach(function(u){
                        subUnits.push({sub:sub, u:u, vol:'', typeName:u._typeName||'', instanceName:u._instanceName||''});
                    });
                } else {
                    var vols = Object.keys(sTree.items); // v1.6.136: 直接用 sTree.items keys (含 instance-prefixed vol)
                    vols.forEach(function(vol){
                        sTree.items[vol].forEach(function(u){
                            subUnits.push({sub:sub, u:u, vol:vol, typeName:u._typeName||'', instanceName:u._instanceName||''});
                        });
                    });
                }
                if (subUnits.length > 0) subjectData[sub] = subUnits;
            });
            var validSubs = Object.keys(subjectData);
            if (validSubs.length === 0) {
                cardsDynamic.innerHTML = '<div style="color:#27ae60; padding:10px; font-weight:bold;">🎉 此任務的所有單元都已經排入月曆囉！</div>';
                getActiveAeContainer().querySelector('#ae-btn-prev').style.display = 'none';
                getActiveAeContainer().querySelector('#ae-btn-next').style.display = 'none';
                getActiveAeContainer().querySelector('#ae-nav-text').textContent = '--';
                return;
            }
            if (window.aeCurrentSubIdx === undefined || window.aeCurrentSubIdx >= validSubs.length) {
                window.aeCurrentSubIdx = 0;
            }
            var total = validSubs.length;
            var currentSub = validSubs[window.aeCurrentSubIdx];
            var hideNav = total <= 1;
            // 更新 static 按鈕 + nav 文字
            getActiveAeContainer().querySelector('#ae-nav-text').textContent = (window.aeCurrentSubIdx + 1) + ' / ' + total + '  📘 ' + currentSub;
            getActiveAeContainer().querySelector('#ae-btn-prev').style.display = hideNav ? 'none' : 'flex';
            getActiveAeContainer().querySelector('#ae-btn-next').style.display = hideNav ? 'none' : 'flex';
            // 產生卡片 HTML，寫入 #ae-cards-dynamic
            var html = '';
            validSubs.forEach(function(sub, idx){
                var display = idx === window.aeCurrentSubIdx ? 'block' : 'none';
                html += '<div id="ae-subj-card-' + idx + '" style="display:' + display + ';">';
                html += renderAeSubjectCardHtml(sub, subjectData[sub], cat, mis);
                html += '</div>';
            });
            cardsDynamic.innerHTML = html;
        }
        // v1.5.39: 左右滑動切換科目
        function aeSlide(dir) {
            var cat = el('ae-cat').value;
            var mis = el('ae-mis').value;
            var mTree = buildMissionTree(cat, mis);
            var subKeys = Object.keys(mTree).filter(function(sub){
                var sTree = mTree[sub];
                if (sTree.type === 'custom') return sTree.items['custom'].length > 0;
                var vols = Object.keys(sTree.items); // v1.6.136: 直接用 sTree.items keys (含 instance-prefixed vol)
                return vols.some(function(vol){ return sTree.items[vol].length > 0; });
            });
            subKeys = getSortedSubjects(subKeys);
            var total = subKeys.length;
            window.aeCurrentSubIdx = (window.aeCurrentSubIdx + dir + total) % total;
            var currentSub = subKeys[window.aeCurrentSubIdx];
            // 切換卡片顯示
            subKeys.forEach(function(sub, idx){
                var cardEl = getActiveAeContainer().querySelector('#ae-subj-card-' + idx);
                if (cardEl) cardEl.style.display = idx === window.aeCurrentSubIdx ? 'block' : 'none';
            });
            // 更新 static nav 文字
            var navText = getActiveAeContainer().querySelector('#ae-nav-text');
            if (navText) navText.textContent = (window.aeCurrentSubIdx + 1) + ' / ' + total + '  📘 ' + currentSub;
        }
        // v1.5.37: 渲染一個科目的全寬卡片 — 含教材類型 radio 切換
        function renderAeSubjectCardHtml(sub, subUnits, cat, mis) {
            // v1.5.40: 預設 5 個教材類型排前面; v1.6.137: typeCount 額外的 typeName (如「模考歷屆」) 也 append
            var defaultOrder = ['複習講義','複習卷','數字題本','模擬題本','考古題'];
            // v1.6.140: 讀 _deletedTypes marker (array 結構: [typeName, ...]), 從 defaultOrder 移除使用者已刪除的 typeName
            // (v1.6.138 marker 寫入時用 array.push + indexOf; v1.6.139 誤用 object 查 key 所以壞了, 這裡修對)
            var _delArr = (multiData[currentUserId] && multiData[currentUserId]._deletedTypes && multiData[currentUserId]._deletedTypes[cat] && multiData[currentUserId]._deletedTypes[cat][sub]) || [];
            defaultOrder = defaultOrder.filter(function(t){ return _delArr.indexOf(t) < 0; });
            // 收集每個 type 各有幾個 unit
            var typeCount = {};
            subUnits.forEach(function(x){
                var t = x.typeName || '(未分類)';
                typeCount[t] = (typeCount[t] || 0) + 1;
            });
            // v1.6.137: 合併 defaultOrder + typeCount 額外的 typeName (例如自訂「模考歷屆」「素養題」)
            var orderedTypes = defaultOrder.slice();
            Object.keys(typeCount).forEach(function(t){
                if (orderedTypes.indexOf(t) < 0) orderedTypes.push(t);
            });
            // 預設選第一個有 unit 的 type
            var firstAvailable = null;
            orderedTypes.forEach(function(t){
                if (typeCount[t] > 0 && !firstAvailable) firstAvailable = t;
            });
            if (!window.aeSubjectType[sub] || typeCount[window.aeSubjectType[sub]] === undefined) {
                window.aeSubjectType[sub] = firstAvailable || orderedTypes[0];
            }
            var currentType = window.aeSubjectType[sub];
            // 標題列
            var html = '<div style="border: 1px solid var(--border); border-radius: 8px; background: #fff; overflow: hidden; display: flex; flex-direction: column; box-shadow: 0 2px 5px rgba(0,0,0,0.05); width: 100%; box-sizing: border-box;">';
            html += '<div style="background: var(--primary); color: white; padding: 10px 15px; font-weight: bold; font-size: 0.95em;">📘 ' + sub + '</div>';
            // 教材類型 radio — 永遠顯示全部 5 個
            html += '<div style="display:flex; gap:6px; align-items:center; flex-wrap:wrap; padding:10px 15px; background:#f8fafc; border-bottom:1px solid #e2e8f0;">';
            html += '<span style="font-weight:bold; color:var(--secondary); font-size:0.8em;">教材類型:</span>';
            orderedTypes.forEach(function(t){
                var hasUnits = typeCount[t] > 0;
                var isSelected = currentType === t;
                var borderColor = isSelected ? 'var(--accent)' : (hasUnits ? '#cbd5e1' : '#e2e8f0');
                var bgColor = isSelected ? '#e0f2fe' : (hasUnits ? 'white' : '#f1f5f9');
                var cursor = hasUnits ? 'pointer' : 'not-allowed';
                var opacity = hasUnits ? '1' : '0.45';
                var onclick = hasUnits ? ('setAeSubjectType(\'' + escapeHtml(sub) + '\', \'' + escapeHtml(t).replace(/'/g, "\\'") + '\')') : '';
                var label = escapeHtml(t);
                if (!hasUnits) label += ' (無)';
                html += '<label style="font-size:0.8em; cursor:' + cursor + '; padding:3px 8px; border-radius:12px; border:1px solid ' + borderColor + '; background:' + bgColor + '; opacity:' + opacity + ';" ' + (onclick ? 'onclick="' + onclick + '"' : '') + '>' + label + '</label>';
            });
            html += '</div>';
            // 單元列表 (依 currentType 過濾)
            html += '<div style="max-height: 340px; overflow-y: auto; padding: 12px;">';
            var filteredUnits = subUnits.filter(function(x){ return (x.typeName || '(未分類)') === currentType; });
            if (filteredUnits.length === 0) {
                html += '<div style="color:#7f8c8d; padding:15px; text-align:center; background:#f9fafb; border-radius:6px;">📝 此教材類型尚無單元</div>';
            } else {
                filteredUnits.forEach(function(x){
                    html += renderAeUnitCheckboxHtml(x, cat, mis, 'D');
                });
            }
            html += '</div></div>';
            return html;
        }
        // v1.5.37: 切換某科目的教材類型
        function setAeSubjectType(sub, typeName) {
            window.aeSubjectType[sub] = typeName;
            onAeMisChange();
        }
        // v1.5.35: 渲染手動新增的單元 checkbox row
        function renderAeUnitCheckboxHtml(x, cat, mis, displayMode) {
            var u = x.u;
            var sub = x.sub;
            var vol = x.vol;
            var safeName = (u.name||'').replace(/"/g, '&quot;').replace(/'/g, "\\'");
            var safeSub = sub.replace(/"/g, '&quot;').replace(/'/g, "\\'");
            var safeVol = vol ? vol.replace(/'/g, "\\'") : '';
            var isChecked = window.aeSelectedItems.find(function(i){ return i.unitId === u.id; }) ? 'checked' : '';
            var status = getUnitScheduleStatus(sub, u.name, vol, u.id, u.start, u.end, cat, mis);
            var uObj = Object.assign({}, u, { vol: vol, typeName: x.typeName, instanceName: x.instanceName, misMaxEnd: status.misMaxEnd });
            return renderUnitRowHtml(uObj, {
                isChecked: !!isChecked,
                onChange: "toggleAeUnitSelection('" + safeSub + "', '" + (u.start||'') + "', '" + (u.end||'') + "', '" + safeName + "', '" + u.id + "', '" + safeVol + "', '" + (x.typeName||'') + "', '" + (x.instanceName||'') + "', this.checked)",
                showQuickRead: false,
                displayMode: displayMode
            });
        }
        function toggleAeUnitSelection(sub, start, end, name, unitId, vol, typeName, instanceName, isChecked) {
            if (isChecked) {
                if (!window.aeSelectedItems.find(item => item.unitId === unitId)) {
                    window.aeSelectedItems.push({sub, start, end, name, unitId, vol, typeName, instanceName, origEnd: end});
                }
            } else {
                window.aeSelectedItems = window.aeSelectedItems.filter(item => item.unitId !== unitId);
            }
            updateAeSelectedDisplay();
        }
        window.updateAeItemPage = function(unitId, field, value) {
            let item = window.aeSelectedItems.find(x => x.unitId === unitId);
            if (item) {
                item[field] = value;
            }
        };
        function updateAeSelectedDisplay() {
            var aeC = getActiveAeContainer();
            var container = aeC.querySelector('#ae-selected-display-container');
            var carousel = aeC.querySelector('#ae-selected-carousel');
            var manualInputs = aeC.querySelector('#ae-manual-inputs-container');
            
            if (window.aeSelectedItems.length === 0) {
                container.style.display = 'none';
                manualInputs.style.display = 'block';
                return;
            }
            
            container.style.display = 'block';
            manualInputs.style.display = 'none'; 
            
            let grouped = {};
            window.aeSelectedItems.forEach(item => {
                if (!grouped[item.sub]) grouped[item.sub] = [];
                grouped[item.sub].push(item);
            });
            
            let html = '';
            Object.keys(grouped).forEach(sub => {
                let items = grouped[sub];
                let listHtml = items.map(i => {
                    let vStr = i.vol ? `[${i.vol}] ` : '';
                    return `<li style="margin-bottom:12px; border-bottom:1px dashed #e2e8f0; padding-bottom:10px;">
                                <div style="font-weight:bold; margin-bottom:5px; color:var(--primary);">${vStr}${i.name}</div>
                                <div style="display:flex; align-items:center; gap:8px; font-size:0.9em; color:var(--secondary);">
                                    <span>起頁：</span>
                                    <input type="number" id="ae-item-start-${i.unitId}" value="${i.start || ''}" min="0" style="width:70px; padding:4px;" onchange="updateAeItemPage('${i.unitId}', 'start', this.value)">
                                    <span>~ 迄頁：</span>
                                    <input type="number" id="ae-item-end-${i.unitId}" value="${i.end || ''}" min="0" style="width:70px; padding:4px;" onchange="updateAeItemPage('${i.unitId}', 'end', this.value)">
                                </div>
                            </li>`;
                }).join('');
                
                html += `
                <div style="border: 1px solid var(--success); border-radius: 8px; background: #fff; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 10px;">
                    <div style="background: var(--success); color: white; padding: 10px; font-weight: bold; font-size: 1.1em;">📘 ${sub} (${items.length} 個單元)</div>
                    <div style="padding: 15px; max-height: 200px; overflow-y: auto;">
                        <ul style="margin:0; padding-left:10px; list-style-type:none;">
                            ${listHtml}
                        </ul>
                    </div>
                </div>`;
            });
            
            carousel.innerHTML = html;
        }
        function saveNewEvent() {
            // v1.5.46: 支援 page 模式 — 所有表單欄位都從目前活躍的容器讀取
            var aeC = getActiveAeContainer();
            var aeDateEl = aeC.querySelector('#ae-date');
            var pid = aeDateEl ? aeDateEl.dataset.pid : '';
            var dateStr = aeDateEl ? aeDateEl.value : '';
            let reminder = aeC.querySelector('#ae-reminder').checked;
            let cat = aeC.querySelector('#ae-cat').value || '';
            let mis = aeC.querySelector('#ae-mis').value || '';
            let plan = appPlans.find(p => p.id === pid);
            if(!plan.grid[dateStr]) plan.grid[dateStr] = [];
            if (window.aeSelectedItems && window.aeSelectedItems.length > 0) {
                let hasUnfinished = false;
                let unfinishedTasks = [];
                window.aeSelectedItems.forEach(item => {
                    let ep = Number(item.end) || 0;
                    let origEp = Number(item.origEnd) || 0;
                    if (ep > 0 && origEp > 0 && ep < origEp) {
                        hasUnfinished = true;
                        unfinishedTasks.push({
                            ...item,
                            newStart: ep + 1,
                            newEnd: origEp
                        });
                    }
                });
                window.aeSelectedItems.forEach(item => {
                    let txt = item.name;
                    let sp = Number(item.start) || 0;
                    let ep = Number(item.end) || 0;
                    let displayText = (reminder ? '🔔 ' : '') + `[${item.sub}] ` + txt;
                    if (sp && ep) {
                        if (sp !== ep) displayText += ` P.${sp}~${ep}`;
                        else displayText += ` P.${sp}`;
                    }
                    plan.grid[dateStr].push({
                        id: genId(),
                        subject: item.sub,
                        text: displayText,
                        startPage: sp,
                        endPage: ep,
                        isDone: false,
                        cat: cat,
                        mis: mis,
                        unitId: item.unitId,
                        vol: item.vol,
                        unitName: txt,
                        typeName: item.typeName || '',
                        instanceName: item.instanceName || '',
                        postponeCount: 0
                    });
                });
                if (hasUnfinished) {
                    if (confirm("偵測到您縮減了完成範圍（頁碼），是否將該單元未完成的頁數（起迄頁數）新增至明日排程？")) {
                        let nextDate = new Date(dateStr);
                        nextDate.setDate(nextDate.getDate() + 1);
                        let nextDateStr = getLocalDateString(nextDate);
                        if (!plan.grid[nextDateStr]) plan.grid[nextDateStr] = [];
                        unfinishedTasks.forEach(item => {
                            let displayText = (reminder ? '🔔 ' : '') + `[${item.sub}] ` + item.name + ` P.${item.newStart}~${item.newEnd}`;
                            plan.grid[nextDateStr].push({
                                id: genId(),
                                subject: item.sub,
                                text: displayText,
                                startPage: item.newStart,
                                endPage: item.newEnd,
                                isDone: false,
                                cat: cat,
                                mis: mis,
                                unitId: item.unitId,
                                vol: item.vol,
                                unitName: item.name,
                                typeName: item.typeName || '',
                                instanceName: item.instanceName || '',
                                postponeCount: 0
                            });
                        });
                    }
                }
            } else {
                let sub = aeC.querySelector('#ae-subject').value.trim();
                let txt = aeC.querySelector('#ae-text').value.trim();
                let sp = Number(aeC.querySelector('#ae-start').value) || 0;
                let ep = Number(aeC.querySelector('#ae-end').value) || 0;
                if(!sub) return alert('請輸入標題或科目名稱！');
                let displayText = (reminder ? '🔔 ' : '') + `[${sub}] `;
                if (txt) displayText += txt;
                if (sp && ep) {
                    if (sp !== ep) displayText += (txt ? ' ' : '') + `P.${sp}~${ep}`;
                    else displayText += (txt ? ' ' : '') + `P.${sp}`;
                }
                plan.grid[dateStr].push({
                    id: genId(), subject: sub, text: displayText,
                    startPage: sp, endPage: ep, isDone: false,
                    cat: '', mis: '', unitId: '', vol: '', unitName: txt, postponeCount: 0
                });
            }
            saveToLocal();
            closeModal('modal-add-event');
            closeAddEventPage();
            renderCalendar();
            checkDailyWorkload(plan, dateStr);
        }
        // v1.5.143: 全域變數用於列印日期範圍
        var printSelStart = null;  // Date or null
        var printSelEnd = null;  // Date or null
        var printSelMonth = null;  // Date (當前顯示月)
        
        function openPrintModal() {
            // v1.5.143: 初始化列印設定 (月曆點選)
            var today = new Date();
            printSelMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            printSelStart = null;
            printSelEnd = null;
            
            // 複製當前分類/任務篩選到 modal
            var currentCat = el('planner-cat-filter') ? el('planner-cat-filter').value : 'ALL';
            var currentMis = el('planner-mis-filter') ? el('planner-mis-filter').value : 'ALL';
            
            // populate modal cat filter
            var modalCat = el('print-modal-cat-filter');
            if (modalCat && appMissions) {
                modalCat.innerHTML = '<option value="ALL">全部</option>';
                Object.keys(appMissions).forEach(function(cat) {
                    var opt = document.createElement('option');
                    opt.value = cat;
                    opt.textContent = cat;
                    modalCat.appendChild(opt);
                });
                modalCat.value = currentCat;
            }
            
            // populate modal mis filter
            onPrintModalCatChange();
            var modalMis = el('print-modal-mis-filter');
            if (modalMis) modalMis.value = currentMis;
            
            renderPrintCalendar();
            openModal('modal-print-settings');
        }
        
        function onPrintModalCatChange() {
            var modalCat = el('print-modal-cat-filter');
            var modalMis = el('print-modal-mis-filter');
            if (!modalMis || !modalCat) return;
            var cat = modalCat.value;
            modalMis.innerHTML = '<option value="ALL">全部</option>';
            if (cat !== 'ALL' && appMissions[cat]) {
                Object.keys(appMissions[cat]).forEach(function(mis) {
                    var opt = document.createElement('option');
                    opt.value = mis;
                    opt.textContent = mis;
                    modalMis.appendChild(opt);
                });
            }
        }
        
        function renderPrintCalendar() {
            var label = el('print-cal-month-label');
            var grid = el('print-cal-grid');
            if (!label || !grid || !printSelMonth) return;
            
            label.textContent = printSelMonth.getFullYear() + ' 年 ' + (printSelMonth.getMonth() + 1) + ' 月';
            
            var year = printSelMonth.getFullYear();
            var month = printSelMonth.getMonth();
            var firstDay = new Date(year, month, 1);
            var lastDay = new Date(year, month + 1, 0);
            var startWeekday = firstDay.getDay();  // 0 = 日
            var daysInMonth = lastDay.getDate();
            
            // 表頭: 日 一 二 三 四 五 六
            var html = '';
            ['日','一','二','三','四','五','六'].forEach(function(d) {
                html += '<div style="text-align:center; font-weight:bold; padding:4px; color:#475569;">' + d + '</div>';
            });
            
            // 上月月末幾天
            var prevMonthLastDay = new Date(year, month, 0).getDate();
            for (var i = startWeekday - 1; i >= 0; i--) {
                var d = prevMonthLastDay - i;
                var dateStr = formatYMD(new Date(year, month - 1, d));
                html += '<div class="print-cal-day print-cal-other" data-date="' + dateStr + '" onclick="clickPrintDate(\'' + dateStr + '\')">' + d + '</div>';
            }
            
            // 本月
            for (var d = 1; d <= daysInMonth; d++) {
                var dateStr = formatYMD(new Date(year, month, d));
                var classes = 'print-cal-day';
                if (printSelStart && getLocalDateString(printSelStart) === dateStr) classes += ' print-cal-sel-edge';
                else if (printSelEnd && getLocalDateString(printSelEnd) === dateStr) classes += ' print-cal-sel-edge';
                else if (printSelStart && printSelEnd) {
                    var dateObj = new Date(year, month, d);
                    if (dateObj > printSelStart && dateObj < printSelEnd) classes += ' print-cal-sel-mid';
                }
                html += '<div class="' + classes + '" data-date="' + dateStr + '" onclick="clickPrintDate(\'' + dateStr + '\')">' + d + '</div>';
            }
            
            // 下月頭幾天 (填滿 6 週)
            var totalCells = startWeekday + daysInMonth;
            var rowsNeeded = Math.ceil(totalCells / 7);
            var cellsNeeded = rowsNeeded * 7;
            var nextDays = cellsNeeded - totalCells;
            for (var d = 1; d <= nextDays; d++) {
                var dateStr = formatYMD(new Date(year, month + 1, d));
                html += '<div class="print-cal-day print-cal-other" data-date="' + dateStr + '" onclick="clickPrintDate(\'' + dateStr + '\')">' + d + '</div>';
            }
            
            grid.innerHTML = html;
            updatePrintRangeDisplay();
        }
        
        function clickPrintDate(dateStr) {
            var clicked = new Date(dateStr + 'T00:00:00');
            // 如果點的是其他月日期, 切換到該月
            if (clicked.getMonth() !== printSelMonth.getMonth() || clicked.getFullYear() !== printSelMonth.getFullYear()) {
                printSelMonth = new Date(clicked.getFullYear(), clicked.getMonth(), 1);
            }
            
            if (!printSelStart || (printSelStart && printSelEnd)) {
                // 開始選起, 或重新開始
                printSelStart = clicked;
                printSelEnd = null;
            } else if (clicked.getTime() === printSelStart.getTime()) {
                // 點同一個日期: 取消
                printSelStart = null;
                printSelEnd = null;
            } else if (clicked < printSelStart) {
                // 點早於 start: swap, 新的是 start
                printSelEnd = printSelStart;
                printSelStart = clicked;
            } else {
                // 點晚於 start: 設為 end
                printSelEnd = clicked;
            }
            
            renderPrintCalendar();
        }
        
        function changePrintMonth(delta) {
            if (!printSelMonth) return;
            printSelMonth = new Date(printSelMonth.getFullYear(), printSelMonth.getMonth() + delta, 1);
            renderPrintCalendar();
        }
        
        function clearPrintSelection() {
            printSelStart = null;
            printSelEnd = null;
            renderPrintCalendar();
        }
        
        function formatYMD(date) {
            var y = date.getFullYear();
            var m = String(date.getMonth() + 1).padStart(2, '0');
            var d = String(date.getDate()).padStart(2, '0');
            return y + '-' + m + '-' + d;
        }
        
        function updatePrintRangeDisplay() {
            var display = el('print-range-display');
            if (!display) return;
            if (!printSelStart && !printSelEnd) {
                display.innerHTML = '尚未選擇範圍 — 請點選 2 個日期';
                display.style.background = '#fef3c7';
            } else if (printSelStart && !printSelEnd) {
                display.innerHTML = '開始: ' + (printSelStart.getMonth() + 1) + '/' + printSelStart.getDate() + ' (再點一下設結束)';
                display.style.background = '#e0f7fa';
            } else {
                var days = Math.round((printSelEnd - printSelStart) / (1000 * 60 * 60 * 24)) + 1;
                display.innerHTML = '範圍: ' + (printSelStart.getMonth() + 1) + '/' + printSelStart.getDate() + ' ~ ' + (printSelEnd.getMonth() + 1) + '/' + printSelEnd.getDate() + ' (' + days + ' 天)';
                display.style.background = '#c8e6c9';
            }
        }
        // v1.5.143: 改為每 14 天一頁, 接收使用者選的日期範圍
        function executePrint() {
            if (!printSelStart || !printSelEnd) {
                return alert('請在月曆上點選 2 個日期設定列印範圍！');
            }
            if (printSelEnd < printSelStart) {
                return alert('結束日期不能早於開始日期！');
            }
            
            var startDate = new Date(printSelStart);
            var endDate = new Date(printSelEnd);
            
            var pid = el('planner-selector').value;
            var plan = null;
            if(pid) {
                plan = appPlans.find(p => p.id === pid);
            }
            
            var printArea = el('print-area');
            var html = '';
            
            // v1.5.143: 從 modal 的 select 讀分類/任務
            let fCat = el('print-modal-cat-filter') ? el('print-modal-cat-filter').value : 'ALL';
            let fMis = el('print-modal-mis-filter') ? el('print-modal-mis-filter').value : 'ALL';
            let allowedUnitIds = new Set();
            let allowedSubjects = new Set();
            
            if (fCat && fCat !== 'ALL') {
                if (fMis && fMis !== 'ALL') {
                    (appMissions[fCat][fMis] || []).forEach(id => allowedUnitIds.add(id));
                    let mTree = buildMissionTree(fCat, fMis);
                    Object.keys(mTree).forEach(sub => allowedSubjects.add(sub));
                } else {
                    Object.keys(appMissions[fCat] || {}).forEach(ms => {
                        (appMissions[fCat][ms] || []).forEach(id => allowedUnitIds.add(id));
                        let mTree = buildMissionTree(fCat, ms);
                        Object.keys(mTree).forEach(sub => allowedSubjects.add(sub));
                    });
                }
            }
            
            var targetOrder = ['國文', '數學', '英文', '歷史', '地理', '公民', '理化', '生物'];
            
            // 從 startDate 開始, 每 14 天 (兩週) 一頁
            var currStart = new Date(startDate);
            while (currStart <= endDate) {
                var pageEnd = new Date(currStart);
                pageEnd.setDate(pageEnd.getDate() + 13);  // +13 天 = 兩週 (含起始)
                if (pageEnd > endDate) pageEnd = new Date(endDate);
                
                // 標題: 跨月顯示 "X月Y日 - Z月W日", 同月顯示 "X月Y-W日"
                // v1.5.131: 標題格式改為 MM/DD~MM/DD (自動根據範圍調整)
                var titleText;
                var sy = currStart.getFullYear();
                var sm = currStart.getMonth() + 1;
                var sd = currStart.getDate();
                var ey = pageEnd.getFullYear();
                var em = pageEnd.getMonth() + 1;
                var ed = pageEnd.getDate();
                var endPart;
                if (ey !== sy) {
                    endPart = ey + '/' + em + '/' + ed;
                } else if (em !== sm) {
                    endPart = em + '/' + ed;
                } else {
                    endPart = ed.toString();
                }
                titleText = sm + '/' + sd + '~' + endPart;
                
                html += '<div class="print-page">';
                html += '<div class="print-title">' + titleText + ' 學習進度計畫表</div>';
                // v1.5.136: 改用 div + flex 取代 table (row 高由內容決定, 分頁在 row 間的框線)
                html += '<div class="print-week">';
                // v1.5.136: header row (科目 / 週日~週六)
                html += '<div class="print-row">';
                html += '<div class="print-cell col-subj header">科目</div>';
                html += '<div class="print-cell col-day header">週日</div>';
                html += '<div class="print-cell col-day header">週一</div>';
                html += '<div class="print-cell col-day header">週二</div>';
                html += '<div class="print-cell col-day header">週三</div>';
                html += '<div class="print-cell col-day header">週四</div>';
                html += '<div class="print-cell col-day header">週五</div>';
                html += '<div class="print-cell col-day header">週六</div>';
                html += '</div>';
                
                // 兩週: 每週一行
                var weekStart = new Date(currStart);
                while (weekStart <= pageEnd) {
                    var weekEndDate = new Date(weekStart);
                    weekEndDate.setDate(weekEndDate.getDate() + 6);
                    if (weekEndDate > pageEnd) weekEndDate = new Date(pageEnd);
                    
                    var weekDates = [];
                    var d = new Date(weekStart);
                    while (d <= weekEndDate) {
                        weekDates.push(new Date(d));
                        d.setDate(d.getDate() + 1);
                    }
                    var weekTasks = {};
                    var hasTasks = false;
                    if (plan && plan.grid) {
                        weekDates.forEach(function(cellDate) {
                            var dateStr = getLocalDateString(cellDate);
                            var tasks = plan.grid[dateStr] || [];
                            var filteredTasks = tasks.filter(function(t) {
                                if (!fCat || fCat === 'ALL') return true;
                                if (t.unitId) return allowedUnitIds.has(t.unitId);
                                if (t.cat) {
                                    if (t.cat !== fCat) return false;
                                    if (fMis && fMis !== 'ALL' && t.mis !== fMis) return false;
                                    return true;
                                }
                                if (!appMaster[t.subject]) return true;
                                if (allowedSubjects && allowedSubjects.size > 0 && !allowedSubjects.has(t.subject)) return false;
                                return true;
                            });
                            filteredTasks.forEach(function(t) {
                                var subj = t.subject || '其他';
                                if (!weekTasks[subj]) weekTasks[subj] = [];
                                var colIdx = weekDates.indexOf(cellDate);
                                if (!weekTasks[subj][colIdx]) weekTasks[subj][colIdx] = [];
                                weekTasks[subj][colIdx].push(t);
                                hasTasks = true;
                            });
                        });
                    }
                    // v1.5.129: 撤掉 v1.5.128 的 weekRowHeight + inline height (Denias 要的是 row 高由 task 數決定, 不是整週統一)
                    html += '<div class="print-row">';
                    html += '<div class="print-cell col-subj week-date">日期</div>';
                    weekDates.forEach(function(cellDate) {
                        html += '<div class="print-cell col-day week-date">' + cellDate.getDate() + '</div>';
                    });
                    html += '</div>';
                    if (hasTasks) {
                        // v1.5.137: 固定 8 subject rows (即使 weekTasks 沒有, 也生成空 row, 避免第二週 row 數不對)
                        var fixedSubjects = ['國文', '數學', '英文', '歷史', '地理', '公民', '理化']; // v1.5.143: 移除 '生物' (Denias 不要)
                        // 取 weekTasks 內有的 + fixedSubjects 內有的
                        var subjectsSet = {};
                        fixedSubjects.forEach(function(s) { subjectsSet[s] = true; });
                        Object.keys(weekTasks).forEach(function(s) { subjectsSet[s] = true; });
                        var subjects = Object.keys(subjectsSet);
                        subjects.sort(function(a, b) {
                            var idxA = targetOrder.indexOf(a); if (idxA === -1) idxA = 999;
                            var idxB = targetOrder.indexOf(b); if (idxB === -1) idxB = 999;
                            if (idxA !== idxB) return idxA - idxB;
                            return a.localeCompare(b);
                        });
                        subjects.forEach(function(subj) {
                            // v1.5.128: row 高 = 該週 max task row 高 (統一)
                            html += '<div class="print-row">';
                            html += '<div class="print-cell col-subj">' + subj + '</div>';
                            weekDates.forEach(function(_, idx) {
                                html += '<div class="print-cell col-day task">';
                                var tasks = (weekTasks[subj] && weekTasks[subj][idx]) || [];
                                tasks.forEach(function(t) {
                                    var pageText = '';
                                    var ctx = t.unitId ? findUnitContext(t.unitId) : null;
                                    if (ctx && isUnitBasedType(ctx.typeObj)) {
                                        // v1.5.144: Unit-based - 簡稱 + unit 名
                                        pageText = getInstanceAlias(ctx.instance) + ctx.unit.name;
                                    } else if (t.startPage && t.endPage) {
                                        pageText = t.startPage === t.endPage ? 'P.' + t.startPage : 'P.' + t.startPage + '~' + t.endPage;
                                    } else if (t.startPage) {
                                        pageText = 'P.' + t.startPage;
                                    } else {
                                        var match = t.text.match(/P\.\d+(?:~\d+)?/);
                                        if (match) pageText = match[0];
                                        else pageText = '✔️';
                                    }
                                    var box = t.isDone ? '☑ ' : '☐ ';
                                    var doneClass = t.isDone ? 'done' : '';
                                    html += '<div class="print-task ' + doneClass + '">' + box + pageText + '</div>';
                                });
                                html += '</div>';
                            });
                            html += '</div>';
                        });
                    } else {
                        html += '<div class="print-row">';
                        html += '<div class="print-cell col-subj" style="color:#cbd5e1;">(無排程)</div>';
                        for (var k = 0; k < weekDates.length; k++) html += '<div class="print-cell col-day"></div>';
                        html += '</div>';
                    }
                    html += '</div>';
                    
                    // 下週從 weekEndDate + 1 開始
                    weekStart = new Date(weekEndDate);
                    weekStart.setDate(weekStart.getDate() + 1);
                }
                
                html += '</div></div>';
                
                // 下兩週從 pageEnd + 1 開始
                currStart = new Date(pageEnd);
                currStart.setDate(currStart.getDate() + 1);
            }
            
            printArea.innerHTML = html;
            closeModal('modal-print-settings');
            // v1.5.138: 加 try/catch, 確保 window.print() 被呼叫 + 錯誤可見
            setTimeout(function() {
                try {
                    window.print();
                } catch(e) {
                    alert('列印失敗: ' + e.message + '\n請手動截圖報告');
                }
            }, 300);
        }
        // v1.5.129: 撤掉 autoShrinkPrintCSS (Denias 說字變小, 改用預設 7pt + row 高自然)
        function exportPlanJSON() {
            var pid = el('planner-selector').value;
            if(!pid) return alert('請先選擇要備份的計畫！');
            var plan = appPlans.find(p => p.id === pid);
            if(!plan) return alert('找不到該計畫！');
            var dataStr = JSON.stringify(plan, null, 2);
            var defaultFilename = plan.name + "_單一月曆備份_" + getLocalDateString(new Date()) + ".json";
            try {
                var blob = new Blob([dataStr], { type: "application/json" });
                var url = URL.createObjectURL(blob);
                var link = document.createElement("a");
                link.href = url;
                link.download = defaultFilename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
                alert('🎉 備份匯出成功！');
            } catch(err) {
                console.error(err);
                alert("月曆備份匯出失敗！");
            }
        }
        
        var importPlanFileEl = document.getElementById('import-plan-file'); if (importPlanFileEl) importPlanFileEl.addEventListener('change', function(e) { 
            var file = e.target.files[0]; 
            if (!file) return; 
            var reader = new FileReader(); 
            reader.onload = function(e) { 
                try { 
                    var importedPlan = JSON.parse(e.target.result); 
                    if (!importedPlan.id || !importedPlan.name || !importedPlan.grid) {
                        return alert("匯入失敗：無效的月曆檔案格式。");
                    }
                    if (confirm("⚠️ 確定要匯入此月曆計畫嗎？")) { 
                        var existingIndex = appPlans.findIndex(p => p.id === importedPlan.id);
                        if (existingIndex > -1) {
                            if (confirm("發現相同 ID 的計畫，是否覆蓋現有計畫？\n(按「取消」將作為新計畫匯入)")) {
                                appPlans[existingIndex] = importedPlan;
                            } else {
                                importedPlan.id = genId();
                                importedPlan.name = importedPlan.name + " (匯入)";
                                appPlans.push(importedPlan);
                            }
                        } else {
                            appPlans.push(importedPlan);
                        }
                        saveToLocal(); 
                        updatePlannerSelector();
                        el('planner-selector').value = importedPlan.id;
                        renderCalendar();
                        alert("🎉 月曆匯入成功！"); 
                    } 
                } catch(err) { 
                    alert("匯入失敗：檔案格式錯誤或無法解析。"); 
                } 
            }; 
            reader.readAsText(file); 
            e.target.value = ''; 
        });
        function openDailyInput() { 
            showPage('page-daily'); 
            el('daily-edit-id').value = ''; 
            el('daily-date').value = getLocalDateString(new Date()); 
            el('daily-start').value = ''; 
            el('daily-end').value = ''; 
            
            var fCat = el('filter-category') ? el('filter-category').value : 'ALL';
            var fMis = el('filter-mission') ? el('filter-mission').value : 'ALL';
            
            populateSelect('daily-category', Object.keys(appMissions), fCat !== 'ALL' ? fCat : null); 
            onDailyCategoryChange(); 
            
            if (fCat !== 'ALL' && fMis !== 'ALL') {
                el('daily-mission').value = fMis;
                onDailyMissionChange();
            }
            
            updateDailyPlanTasks(); 
        }
        
        function updateDailyPlanTasks() { 
            var dateStr = el('daily-date').value; 
            var cat = el('daily-category').value;
            var mis = el('daily-mission').value;
            var sel = el('daily-plan-task'); 
            var opts = '<option value="">(不關聯計畫任務)</option>'; 
            appPlans.forEach(plan => { 
                var tasks = Array.isArray(plan.grid[dateStr]) ? plan.grid[dateStr] : []; 
                tasks.forEach(t => { 
                    if (cat && t.cat !== cat) return;
                    if (mis && t.mis !== mis) return;
                    
                    var statusStr = t.isDone ? ' [✅已在月曆打卡]' : '';
                    opts += `<option value="${t.id}" data-pid="${plan.id}" data-sp="${t.startPage}" data-ep="${t.endPage}" data-sub="${t.subject}">${plan.name} - ${t.text}${statusStr}</option>`; 
                }); 
            }); 
            sel.innerHTML = opts; 
        }
        function onDailyPlanTaskSelect() { var sel = el('daily-plan-task'); var opt = sel.options[sel.selectedIndex]; if(opt.value) { el('daily-start').value = opt.dataset.sp || ''; el('daily-end').value = opt.dataset.ep || ''; } }
        
        function onDailyCategoryChange() { 
            var cat = el('daily-category').value; 
            if(!cat || !appMissions[cat]) { 
                populateSelect('daily-mission', []); 
                onDailyMissionChange(); 
                return; 
            } 
            populateSelect('daily-mission', Object.keys(appMissions[cat]), null); 
            onDailyMissionChange(); 
        }
        
        function onDailyMissionChange() { 
            var cat = el('daily-category').value; 
            var mis = el('daily-mission').value; 
            var select = el('daily-unit'); 
            
            updateDailyPlanTasks();
            
            if(!cat || !mis) { select.innerHTML = '<option value="">(請先選擇任務)</option>'; return; } 
            var mTree = buildMissionTree(cat, mis); 
            var html = ''; 
            var hasUnits = false; 
            Object.keys(mTree).forEach(sub => { 
                var sTree = mTree[sub]; 
                if (sTree.type === 'custom') { 
                    sTree.items['custom'].forEach(u => { html += `<option value="${u.id}" data-sub="${sub}" data-vol="custom">[${sub}] ${u.name} (P.${u.start}~${u.end})</option>`; hasUnits = true; }); 
                } else { 
                    var volsToRender = Object.keys(sTree.items); // v1.6.136: 包含 instance-prefixed vol 
                    volsToRender.forEach(vol => { sTree.items[vol].forEach(u => { html += `<option value="${u.id}" data-sub="${sub}" data-vol="${vol}">[${sub} - ${vol}] ${u.name} (P.${u.start}~${u.end})</option>`; hasUnits = true; }); }); 
                } 
            }); 
            if (!hasUnits) select.innerHTML = '<option value="">(⚠️ 尚未設定單元)</option>'; else select.innerHTML = html; 
        }
        
        function saveDailyLog() { 
            var id = el('daily-edit-id').value || genId(); 
            var dateStr = el('daily-date').value; 
            var sPage = Number(el('daily-start').value); 
            var ePage = Number(el('daily-end').value); 
            if (!sPage || !ePage) return alert('請輸入完成頁碼！'); 
            if (sPage > ePage) return alert('錯誤：起頁大於迄頁！'); 
            
            var taskSel = el('daily-plan-task'); 
            var taskId = taskSel.value; 
            if(taskId) { 
                var opt = taskSel.options[taskSel.selectedIndex]; 
                var pid = opt.dataset.pid; 
                var plan = appPlans.find(p => p.id === pid); 
                if(plan) { 
                    var taskArr = Array.isArray(plan.grid[dateStr]) ? plan.grid[dateStr] : []; 
                    var task = taskArr.find(t => t.id === taskId); 
                    if(task) { 
                        task.isDone = true; 
                        var planEnd = Number(task.endPage); 
                        
                        task.startPage = sPage;
                        task.endPage = ePage;
                        var baseSubject = task.subject || '自訂';
                        var baseName = task.unitName || task.text.replace(`[${baseSubject}] `, '').replace(/\s*P\.\d+(~\d+)?\s*$/, '').replace(/^【.*?】\s*/, '').replace(/🔔\s*/, '');
                        if (sPage && ePage && sPage !== ePage) {
                            task.text = `[${baseSubject}] ${baseName} P.${sPage}~${ePage}`;
                        } else if (sPage && sPage === ePage) {
                            task.text = `[${baseSubject}] ${baseName} P.${sPage}`;
                        } else {
                            task.text = `[${baseSubject}] ${baseName}`;
                        }
                        appLogs = appLogs.filter(l => l.id !== 'cal_' + task.id);
                        if(ePage < planEnd) { 
                            var diff = planEnd - ePage; 
                            alert(`⚠️ 系統偵測到進度落後！\n系統已自動將未完成的 P.${ePage+1}~${planEnd} 順延至明日。`); 
                            var nextDate = new Date(dateStr); nextDate.setDate(nextDate.getDate() + 1); 
                            var nextDateStr = getLocalDateString(nextDate); 
                            if(!plan.grid[nextDateStr] || !Array.isArray(plan.grid[nextDateStr])) plan.grid[nextDateStr] = []; 
                            var subjectName = task.subject || '自訂'; 
                            var newPcCount = (task.postponeCount || 0) + 1;
                            plan.grid[nextDateStr].unshift({ 
                                id: genId(), subject: subjectName, text: `[${subjectName}] ${baseName} P.${ePage + 1}~${planEnd}`, 
                                startPage: ePage + 1, endPage: planEnd, isDone: false,
                                cat: task.cat, mis: task.mis, unitId: task.unitId, vol: task.vol, unitName: task.unitName,
                                postponeCount: newPcCount,
                                isAuto: task.isAuto
                            }); 
                            appLogs.push({ id: genId(), date: dateStr, category: '🔄 系統重排', mission: plan.name, subject: subjectName, unitName: '自動順延', start: ePage+1, end: planEnd, pages: diff, detail: `進度落後，順延至 ${nextDateStr}` }); 
                            checkDailyWorkload(plan, nextDateStr);
                        } 
                    } 
                } 
            } 
            
            var cat = el('daily-category').value; 
            var mis = el('daily-mission').value; 
            if(cat && mis) { 
                var unitSelect = el('daily-unit'); 
                var unitId = unitSelect.value; 
                if (unitId) { 
                    var uOpt = unitSelect.options[unitSelect.selectedIndex]; 
                    var sub = uOpt.dataset.sub; 
                    var vol = uOpt.dataset.vol; 
                    var unitName = uOpt.text.split('] ')[1].split(' (')[0]; 
                    var logEntry = { id: id, date: dateStr, category: cat, mission: mis, subject: sub, volume: vol, unitId: unitId, unitName: unitName, start: sPage, end: ePage, pages: (ePage - sPage + 1), detail: unitName }; 
                    var existIdx = appLogs.findIndex(l => l.id === id); 
                    if (existIdx > -1) appLogs[existIdx] = logEntry; else appLogs.push(logEntry); 
                } 
            } 
            
            appLogs.sort((a, b) => new Date(b.date) - new Date(a.date)); 
            saveToLocal(); 
            returnToHome(); 
        }
        function openHistory() { 
            // v1.5.57: 改成切到 page-settings 的 history tab
            if (el('page-settings').style.display !== 'block') {
                showPage('page-settings');
            }
            switchTab('history');
            renderHistoryTable();
        }
        // === v1.4.0: 學習統計分析 ===
        function openStats() {
            showPage('page-stats');
            // v1.4.1 fix: 確保 starmap-root 顯示 (returnToHome 會把它 display:none)
            var sm = el('starmap-root');
            if (sm) sm.style.display = '';
            // 預設顯示樹狀圖
            renderTreeView();
        }
        // ============================================================
        // v1.6.71: Phase 2 - 上傳 + Crop + 中等版筆跡消除
        // ============================================================
        
        // v1.6.97: 照附件設計 - isManualAdding flag (按「新增框線」後啟用)
        
        // v1.6.97: 取消選取 - 清空所有 crop boxes (照附件)
        function WN_cancelSelection() {
            if (!confirm('確定要取消選取嗎？所有已框選的錯題將清除。')) return;
            // v1.6.104: 移除所有 crop boxes + 重置 event flag (允許下次上傳重新綁定)
            WN_CROP_EVENTS_INITED = false;
            var pageContainer = document.getElementById('wn-page-container');
            if (pageContainer) {
                pageContainer.querySelectorAll('.wn-crop-box').forEach(function(b) { b.remove(); });
            }
            WN_PHASE2_STATE.cropBoxes = [];
            WN_manualBoxes = [];
            WN_isManualAdding = false;
            var pageContainer = document.getElementById('wn-page-container');
            if (pageContainer) pageContainer.querySelectorAll('.wn-crop-box').forEach(function(b) { b.remove(); });
            document.getElementById('wn-crop-img').src = '';
            document.getElementById('wn-crop-area').style.display = 'none';
            document.getElementById('wn-crop-list').style.display = 'none';
            document.getElementById('wn-source-input').value = '';
        }
        // v1.6.77: 完成選取 - 顯示教材選擇表單 (不直接儲存)
        // v1.6.77: 拖拉移動 crop box
        function WN_startMove(e, idx) {
            e.preventDefault();
            e.stopPropagation();
            var box = WN_PHASE2_STATE.cropBoxes[idx];
            var startX = e.clientX;
            var startY = e.clientY;
            var origX = box.x;
            var origY = box.y;
            var img = document.getElementById('wn-crop-img');
            var overlay = document.getElementById('wn-crop-overlay');
            var rect = overlay.getBoundingClientRect();
            var scaleX = img.naturalWidth / rect.width;
            var scaleY = img.naturalHeight / rect.height;
            function onMove(ev) {
                var dx = (ev.clientX - startX) * scaleX;
                var dy = (ev.clientY - startY) * scaleY;
                box.x = Math.max(0, Math.min(img.naturalWidth - box.w, origX + dx));
                box.y = Math.max(0, Math.min(img.naturalHeight - box.h, origY + dy));
                WN_renderCropBoxes();
            }
            function onUp() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        }
        // v1.6.77: 拖拉 resize (左上角 / 右下角)
        function WN_startResize(e, idx, corner) {
            e.preventDefault();
            e.stopPropagation();
            var box = WN_PHASE2_STATE.cropBoxes[idx];
            var startX = e.clientX;
            var startY = e.clientY;
            var origX = box.x, origY = box.y, origW = box.w, origH = box.h;
            var img = document.getElementById('wn-crop-img');
            var overlay = document.getElementById('wn-crop-overlay');
            var rect = overlay.getBoundingClientRect();
            var scaleX = img.naturalWidth / rect.width;
            var scaleY = img.naturalHeight / rect.height;
            function onMove(ev) {
                var dx = (ev.clientX - startX) * scaleX;
                var dy = (ev.clientY - startY) * scaleY;
                if (corner === 'br') {
                    box.w = Math.max(20, origW + dx);
                    box.h = Math.max(20, origH + dy);
                } else if (corner === 'tl') {
                    var newW = Math.max(20, origW - dx);
                    var newH = Math.max(20, origH - dy);
                    box.x = origX + (origW - newW);
                    box.y = origY + (origH - newH);
                    box.w = newW;
                    box.h = newH;
                }
                WN_renderCropBoxes();
            }
            function onUp() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        }
        // v1.6.77: 從 crop box 中央 + 按鈕新增 crop
        function WN_addCropFromCenter(idx) {
            var srcBox = WN_PHASE2_STATE.cropBoxes[idx];
            var img = document.getElementById('wn-crop-img');
            var newBox = {
                x: Math.min(srcBox.x + srcBox.w + 10, img.naturalWidth - 50),
                y: srcBox.y,
                w: srcBox.w,
                h: srcBox.h
            };
            WN_PHASE2_STATE.cropBoxes.push(newBox);
            WN_renderCropBoxes();
        }
        function WN_renderCropDrawingPreview() {
            var overlay = document.getElementById('wn-crop-overlay');
            if (!overlay) return;
            // 移除暫存預覽 box
            var preview = document.getElementById('wn-crop-preview');
            if (preview) preview.remove();
            // 加新的預覽 box (畫到一半的)
            var box = WN_CROP_DRAW_STATE.currentBox;
            if (box && WN_CROP_DRAW_STATE.drawing) {
                var overlayRect = overlay.getBoundingClientRect();
                var img = document.getElementById('wn-crop-img');
                var scaleX = overlayRect.width / img.naturalWidth;
                var scaleY = overlayRect.height / img.naturalHeight;
                var div = document.createElement('div');
                div.id = 'wn-crop-preview';
                div.className = 'wn-crop-box';
                div.style.left = (box.x * scaleX) + 'px';
                div.style.top = (box.y * scaleY) + 'px';
                div.style.width = (box.w * scaleX) + 'px';
                div.style.height = (box.h * scaleY) + 'px';
                div.style.background = 'rgba(255, 200, 0, 0.3)';
                div.style.borderColor = '#ffc800';
                overlay.appendChild(div);
            }
        }
        // v1.6.86: 完整還原 v1.6.8 設計 - cropArea.onmousedown 統一處理
        // 對應 WN_PHASE2_STATE.cropBoxes (取代舊的 WN_STATE.cropBoxes)
        
        // 舊的 v1.6.77 + render function (保留以向後相容)
        // Crop 渲染 (v1.6.82: 照附件設計 - percentage 座標 + 直接 appendTo img-container)
        function WN_renderCropBoxes() {
            var overlay = document.getElementById('wn-crop-overlay');
            if (!overlay) return;
            overlay.innerHTML = '';
            WN_PHASE2_STATE.cropBoxes.forEach(function(box, idx) {
                var div = document.createElement('div');
                div.className = 'wn-crop-box';
                div.setAttribute('data-idx', idx);
                // v1.6.82: 改用 percentage 座標 (附件風格, 不受圖片縮放影響)
                div.style.left = box.x + '%';
                div.style.top = box.y + '%';
                div.style.width = box.w + '%';
                div.style.height = box.h + '%';
                div.innerHTML =
                    '<div class="wn-crop-label">#' + (idx + 1) + '</div>' +
                    '<div class="wn-crop-delete" onclick="WN_deleteCropBox(' + idx + ')">×</div>' +
                    '<div class="wn-resize-tl" onmousedown="WN_startResize(event, ' + idx + ', ' + chr(39) + 'tl' + chr(39) + ')"></div>' +
                    '<div class="wn-resize-br" onmousedown="WN_startResize(event, ' + idx + ', ' + chr(39) + 'br' + chr(39) + ')"></div>' +
                    '<div class="wn-add-btn" onclick="WN_addCropFromCenter(' + idx + ')">+</div>';
                // 拖拉移動 crop box
                div.addEventListener('mousedown', function(e) {
                    if (e.target.classList.contains('wn-resize-tl') || e.target.classList.contains('wn-resize-br') || e.target.classList.contains('wn-crop-delete') || e.target.classList.contains('wn-add-btn')) return;
                    WN_startMove(event, idx);
                });
                overlay.appendChild(div);
            });
            // 顯示教材選擇 (如果有 crop boxes)
            if (WN_PHASE2_STATE.cropBoxes.length > 0) {
                document.getElementById('wn-crop-list').style.display = 'block';
                WN_renderCropCards();
            } else {
                document.getElementById('wn-crop-list').style.display = 'none';
            }
        }
        // 中等版筆跡消除 (螢光筆 + 部分手寫)
        // 儲存全部 crop (自動下載 + localStorage)
        function WN_autoDownload(dataUrl, fileName) {
            var a = document.createElement('a');
            a.href = dataUrl;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }
        // v1.6.70: 錯題資料庫獨立 page
        function openWrongNotes() {
            showPage('page-wrongnotes');
            // 第一次進入時提示用戶建立資料夾
            if (!localStorage.getItem('StudyMap_WrongNotes_DisclaimerAck')) {
                alert('📂 第一次使用錯題資料庫：\n\n請先在瀏覽器下載資料夾下建立「學習進度看板」資料夾，\n並將瀏覽器的下載位置設定到這個資料夾。\n\n之後上傳的錯題圖片會自動下載到此資料夾。');
                localStorage.setItem('StudyMap_WrongNotes_DisclaimerAck', '1');
            }
            // v1.6.70.3: 用 addEventListener 綁定 (Safari 兼容)
            if (!window._wrongNotesTabsBound) {
                window._wrongNotesTabsBound = true;
                document.querySelectorAll('[data-wntab]').forEach(function(tab) {
                    tab.addEventListener('click', function() {
                        switchWrongNotesView(this.getAttribute('data-wntab'));
                    });
                });
            }
            // v1.6.70.3: 備份按鈕 addEventListener
            if (!window._backupBtnBound) {
                window._backupBtnBound = true;
                var backupBtn = document.getElementById('nav-btn-backup');
                if (backupBtn) {
                    backupBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        exportDataToFile();
                    });
                }
            }
            // v1.6.110: 移除 WN_initDragDrop (v1.6.108 已刪除此函式, 附件 iframe 內有自己的 drag & drop)
            // v1.6.76: document-level dragover/drop (防止瀏覽器預設開新分頁)
            if (!window._globalDragBound) {
                window._globalDragBound = true;
                document.addEventListener('dragover', function(e) {
                    e.preventDefault();
                });
                document.addEventListener('drop', function(e) {
                    e.preventDefault();
                });
            }
            // 預設顯示匯入頁
            switchWrongNotesView('import');
        }
        function switchWrongNotesView(view) {
            document.querySelectorAll('[data-wntab]').forEach(function(t) { t.classList.remove('active'); });
            // v1.6.70.4: 用 inline style 強制 display (Safari 對 CSS class 切換不可靠)
            document.querySelectorAll('.wn-page').forEach(function(p) {
                p.classList.remove('active');
                p.style.display = 'none';
            });
            var tBtn = document.querySelector('[data-wntab="' + view + '"]');
            if (tBtn) tBtn.classList.add('active');
            var pEl = document.getElementById('wn-page-' + view);
            if (pEl) {
                pEl.classList.add('active');
                pEl.style.display = 'block';
            }
        }
        function switchStatsView(view) {
            document.querySelectorAll('.stats-view').forEach(function(v) { v.classList.remove('active'); });
            document.querySelectorAll('.stats-tab').forEach(function(b) { b.classList.remove('active'); });
            // v1.5.200: 樹狀圖頁面隱藏看板篩選, 其他頁面照舊
            var filterBar = el('global-filter-bar');
            if (filterBar) filterBar.style.display = (view === 'tree') ? 'none' : '';
            var targetId = view === 'tree' ? 'stats-tree' : (view === 'monthly' ? 'stats-monthly' : (view === 'wrongnotes' ? 'stats-wrongnotes' : 'stats-accuracy'));
            el(targetId).classList.add('active');
            document.querySelectorAll('.stats-tab').forEach(function(b) {
                if (b.getAttribute('data-view') === view) b.classList.add('active');
            });
            if (view === 'tree') renderTreeView();
            else if (view === 'monthly') renderMonthlyAnalysis();
            else if (view === 'accuracy') renderAccuracyStats();
            else if (view === 'wrongnotes') { /* v1.6.67: iframe 自帶內容 */ }
        }
        
// 錯題資料庫 v1.6.0 (Phase 2+3)
        // ============================================================
        // --- 狀態 ---
        var WN_STATE = {
            currentStudent: '', currentSubject: '', currentMaterial: '', currentInstance: '', currentVolume: '', currentUnit: '',
            cropBoxes: [], eraseBoxes: [],
            mode: 'add', // 'add' | 'erase' | 'clean'
            importedImage: null, cleanImage: null, importedFileName: '',
            selectedReasons: [],
            practiceQuestions: [], practiceIndex: 0,
            practiceResults: {}, // id -> 'mastered' | 'stillwrong'
            // v1.6.66: multi-file flow state
            flowImages: [], // [{file: dataUrl, boxes: [], cropBoxDataUrls: []}]
            flowCurrentIdx: 0,
            flowPerCard: [] // [{student, subject, material, instance, volume, unit, reasons, content}]
        };
        // --- Tab 切換 ---
        
        // --- Phase 1: Drag & drop file upload (enhancement) ---
        document.addEventListener('DOMContentLoaded', function() {
            var zone = document.getElementById('wn-drop-zone');
            if (zone) {
                zone.addEventListener('dragover', function() { zone.classList.add('drag-over'); });
                zone.addEventListener('dragleave', function() { zone.classList.remove('drag-over'); });
                zone.addEventListener('drop', function(e) {
                    zone.classList.remove('drag-over');
                    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                        handleFilesForCrop(e.dataTransfer.files);
                    }
                });
            }
        });
        function WN_switchTab(tab) {
            document.querySelectorAll('.wn-tab').forEach(function(t){ t.classList.remove('active'); });
            document.querySelectorAll('.wn-page').forEach(function(p){ p.classList.remove('active'); });
            var tBtn = document.querySelector('.wn-tab[data-wntab="'+tab+'"]');
            if(tBtn) tBtn.classList.add('active');
            var tPage = document.getElementById('wn-'+tab);
            if(tPage) tPage.classList.add('active');
            if(tab === 'notes') WN_renderNotesList();
            if(tab === 'stats') WN_renderStats();
            if(tab === 'practice') WN_renderPracticeList();
        }
        // --- init WrongNotes view ---
        function WN_init() {
            WN_migrateNotes();
            WN_loadSubjectOptions();
            WN_loadStudentOptions();
            if(window._wn_pendingData) {
                WN_applyPendingData(window._wn_pendingData);
                window._wn_pendingData = null;
            }
        }
        function WN_waitForUsers(retry) {
            retry = retry || 0;
            if(retry > 10) { console.log('[WN] appUsers 載入逾時'); return; }
            var users = (typeof appUsers !== 'undefined' && appUsers && appUsers.length) ? appUsers : null;
            if(!users) {
                console.log('[WN] 等 appUsers... retry', retry);
                setTimeout(function(){ WN_waitForUsers(retry+1); }, 300);
                return;
            }
            // appUsers ready - populate student dropdown
            var sel = document.getElementById('wn-student');
            if(!sel) return;
            sel.innerHTML = '<option value="">請選擇</option>';
            users.forEach(function(u){
                var name = u.name || u;
                sel.innerHTML += '<option value="'+escapeHtml(name)+'">'+escapeHtml(name)+'</option>';
            });
            console.log('[WN] 學生 loaded:', users.length);
        }
        function WN_loadSubjectOptions() {
            var sbEl = document.getElementById('wn-subject');
            if(!sbEl) return;
            sbEl.innerHTML = '<option value="">請選擇</option>';
            try {
                if(typeof appMaster !== 'undefined' && appMaster) {
                    Object.keys(appMaster).forEach(function(sub){
                        if(!appMaster[sub] || typeof appMaster[sub] !== 'object') return;
                        if(!appMaster[sub].materials) return;
                        sbEl.innerHTML += '<option value="'+escapeHtml(sub)+'">'+escapeHtml(sub)+'</option>';
                    });
                }
            } catch(e){ console.log('[WN] loadSubjectOptions error:', e); }
        }
        // --- 舊筆記搬遷 myStudyNotes -> StudyMap_WrongNotes ---
        function WN_migrateNotes() {
            try {
                var old = localStorage.getItem('myStudyNotes');
                var nou = localStorage.getItem('StudyMap_WrongNotes');
                if(old && !nou) {
                    localStorage.setItem('StudyMap_WrongNotes', old);
                    console.log('[WN] 舊筆記已搬遷到 StudyMap_WrongNotes');
                }
            } catch(e){}
        }
        // --- 帶入資料（從答對率頁跳轉時呼叫） ---
        function WN_applyPendingData(data) {
            // data: {student, subject, material, instance, volume, unit}
            var sEl = document.getElementById('wn-student');
            var sbEl = document.getElementById('wn-subject');
            var matEl = document.getElementById('wn-material');
            var vEl = document.getElementById('wn-volume');
            var uEl = document.getElementById('wn-unit');
            if(sEl) sEl.value = data.student || '';
            if(sbEl) sbEl.value = data.subject || '';
            if(matEl) matEl.value = data.material || '';
            // 觸發 cascade：subject → material → instance → vol → unit
            if(matEl && matEl.value) WN_onMaterialChange(data.instance, data.volume, data.unit);
        }
        // --- 載入學生/科目/冊次/單元 下拉選單 ---
        function WN_loadStudentOptions() {
            var sel = document.getElementById('wn-student');
            if(!sel) return;
            // 學生資料在 multiData：{ userId: {name: "學生名", ...}, ... }
            console.log('[WN] WN_loadStudentOptions: multiData=', typeof multiData, multiData ? Object.keys(multiData) : 'null');
            var users = (typeof multiData !== 'undefined' && multiData) ? Object.keys(multiData).map(function(uid){ return {name: multiData[uid].name || uid}; }) : [];
            if(!users.length) {
                console.log('[WN] multiData not ready, waiting...');
                setTimeout(function(){ WN_loadStudentOptions(); }, 300);
                return;
            }
            sel.innerHTML = '<option value="">請選擇</option>';
            users.forEach(function(u){
                var name = u.name || '';
                sel.innerHTML += '<option value="'+escapeHtml(name)+'">'+escapeHtml(name)+'</option>';
            });
            console.log('[WN] 學生 loaded:', users.length, users.map(function(u){return u.name;}));
        }
        function WN_onStudentChange() {
            WN_STATE.currentStudent = document.getElementById('wn-student').value;
        }
        function WN_onSubjectChange(prefillVol, prefillUnit) {
            WN_STATE.isVolUnitShared = false;
            var subject = document.getElementById('wn-subject').value;
            var matSel = document.getElementById('wn-material');
            var volSel = document.getElementById('wn-volume');
            var unitSel = document.getElementById('wn-unit');
            WN_STATE.currentSubject = subject;
            matSel.innerHTML = '<option value="">請選擇</option>';
            document.getElementById('wn-instance').innerHTML = '<option value="">請選擇</option>';
            volSel.innerHTML = '<option value="">請選擇</option>';
            unitSel.innerHTML = '<option value="">請選擇</option>';
            if(!subject) return;
            try {
                // appMaster 結構：appMaster[subjectName] = { materials: { typeName: { instances: [{name, units}]} } }
                // 直接用 appMaster[subject] 取 materials（不需要繞 category）
                var subjData = (typeof appMaster !== 'undefined' && appMaster) ? (appMaster[subject] || null) : null;
                console.log('[WN] onSubjectChange subject=', subject, '-> subjData.materials=', subjData && subjData.materials ? Object.keys(subjData.materials) : 'null');
                if(subjData && subjData.materials) {
                    Object.keys(subjData.materials).forEach(function(matName){
                        matSel.innerHTML += '<option value="'+escapeHtml(matName)+'">'+escapeHtml(matName)+'</option>';
                    });
                }
            } catch(e){ console.log('[WN] onSubjectChange error:', e); }
        }
function WN_onMaterialChange(prefillInst, prefillVol, prefillUnit) {
            WN_STATE.isVolUnitShared = false;
            var subject = document.getElementById('wn-subject').value;
            var matName = document.getElementById('wn-material').value;
            var instSel = document.getElementById('wn-instance');
            var volSel = document.getElementById('wn-volume');
            var unitSel = document.getElementById('wn-unit');
            WN_STATE.currentMaterial = matName;
            WN_STATE.currentInstance = '';
            instSel.innerHTML = '<option value="">請選擇</option>';
            volSel.innerHTML = '<option value="">請選擇</option>';
            unitSel.innerHTML = '<option value="">請選擇</option>';
            if(!subject || !matName) return;
            try {
                // 教材類型 → instances (教材名稱)
                var subjData = (typeof appMaster !== 'undefined' && appMaster) ? (appMaster[subject] || null) : null;
                if(subjData && subjData.materials && subjData.materials[matName]) {
                    var instances = subjData.materials[matName].instances || [];
                    console.log('[WN] onMaterialChange mat=', matName, 'instances=', instances.map(function(i){ return i.name; }));
                    instances.forEach(function(inst){
                        instSel.innerHTML += '<option value="'+escapeHtml(inst.name)+'">'+escapeHtml(inst.name)+'</option>';
                    });
                }
            } catch(e){ console.log('[WN] onMaterialChange error:', e); }
            // 如果有預填的 instance/vol/unit，先等 instance 載入再設定
            if(prefillInst) {
                setTimeout(function(){
                    var opt = instSel.querySelector('option[value="'+prefillInst+'"]');
                    if(opt) {
                        instSel.value = prefillInst;
                        WN_onInstanceChange(prefillVol, prefillUnit);
                    }
                }, 50);
            }
        }
        // --- 選擇教材名稱後：設定冊次 + 單元 ---
        function WN_onInstanceChange(prefillVol, prefillUnit) {
            var subject = document.getElementById('wn-subject').value;
            var matName = document.getElementById('wn-material').value;
            var instName = document.getElementById('wn-instance').value;
            var volSel = document.getElementById('wn-volume');
            var unitSel = document.getElementById('wn-unit');
            WN_STATE.currentInstance = instName;
            volSel.innerHTML = '<option value="">請選擇</option>';
            unitSel.innerHTML = '<option value="">請選擇</option>';
            WN_STATE.isVolUnitShared = false;
            if(!subject || !matName || !instName) return;
            try {
                var subjData = (typeof appMaster !== 'undefined' && appMaster) ? (appMaster[subject] || null) : null;
                if(subjData && subjData.materials && subjData.materials[matName]) {
                    var instances = subjData.materials[matName].instances || [];
                    var inst = instances.find(function(i){ return i.name === instName; });
                    if(inst) {
                        console.log('[WN] onInstanceChange inst=', instName, 'vols=', inst.vols ? Object.keys(inst.vols) : 'none', 'volOrder=', JSON.stringify(inst.volOrder||[]), 'units=', JSON.stringify(inst.units||[]).slice(0,100));
                        // 判斷是否為「不分冊」教材：
                        // 條件A: volOrder=["不分冊"]
                        // 條件B: volOrder=[]（空）且 vols=null → 所有 units 都是同一冊次（不分冊）
                        var isNoVol = (inst.volOrder && inst.volOrder.length === 1 && inst.volOrder[0] === '不分冊') ||
                                     (!inst.volOrder || inst.volOrder.length === 0) && inst.vols === null;
                        console.log('[WN] isNoVol=', isNoVol, 'volOrder=', JSON.stringify(inst.volOrder||[]), 'vols=', inst.vols ? Object.keys(inst.vols) : 'null');
                        if(isNoVol) {
                            // 不分冊：冊次保持「請選擇」(空白)，單元直接顯示所有單元
                            volSel.innerHTML = '<option value="">請選擇</option>';
                            volSel.value = '';
                            WN_STATE.currentVolume = '';
                            // 直接把所有單元加入 unitSel
                            (inst.units || []).forEach(function(u){
                                var name = typeof u === 'object' ? (u.name || u) : u;
                                unitSel.innerHTML += '<option value="'+escapeHtml(name)+'">'+escapeHtml(name)+'</option>';
                            });
                            console.log('[WN] 不分冊單元:', (inst.units||[]).map(function(u){return typeof u==='object'?u.name:u;}));
                            if(prefillUnit) {
                                setTimeout(function(){
                                    var opt = unitSel.querySelector('option[value="'+prefillUnit+'"]');
                                    if(opt) unitSel.value = prefillUnit;
                                }, 50);
                            }
                            return; // 不繼續跑冊次邏輯
                        }
                        // 一般冊次教材：從 vols 讀冊次
                        else if(inst.vols) {
                            Object.keys(inst.vols).forEach(function(vol){
                                volSel.innerHTML += '<option value="'+escapeHtml(vol)+'">'+escapeHtml(vol)+'</option>';
                            });
                        }
                        // vols=null 且 volOrder=[] 且 units 沒有 vol 欄位 → 冊次=單元本身（如模擬題本翰林穩贏）
                        else if(inst.units && inst.units.length > 0) {
                            console.log('[WN] 冊次=單元 類型: units=', inst.units.map(function(u){return u.name;}));
                            WN_STATE.isVolUnitShared = true;
                            inst.units.forEach(function(u){
                                var name = typeof u === 'object' ? (u.name || u) : u;
                                volSel.innerHTML += '<option value="'+escapeHtml(name)+'">'+escapeHtml(name)+'</option>';
                            });
                        }
                    }
                }
            } catch(e){ console.log('[WN] onInstanceChange error:', e); }
            if(prefillVol && prefillVol !== '不分冊') {
                setTimeout(function(){
                    if(volSel.querySelector('option[value="'+prefillVol+'"]')) {
                        volSel.value = prefillVol;
                        WN_onVolumeChange(prefillUnit);
                    }
                }, 50);
            }
        }
        function WN_onVolumeChange(prefillUnit) {
            var subject = document.getElementById('wn-subject').value;
            var matName = document.getElementById('wn-material').value;
            var instName = document.getElementById('wn-instance').value;
            var volName = document.getElementById('wn-volume').value;
            var unitSel = document.getElementById('wn-unit');
            WN_STATE.currentVolume = volName;
            unitSel.innerHTML = '<option value="">請選擇</option>';
            if(!subject || !matName || !volName) return;
            try {
                var subjData = (typeof appMaster !== 'undefined' && appMaster) ? (appMaster[subject] || null) : null;
                if(subjData && subjData.materials && subjData.materials[matName]) {
                    var instances = subjData.materials[matName].instances || [];
                    var inst = instances.find(function(i){ return i.name === instName; });
                    if(inst) {
                        var units = [];
                        // 不分冊：直接從 inst.units 取（volName === "不分冊"）
                        if(volName === '不分冊' || (inst.volOrder && inst.volOrder.length === 1 && inst.volOrder[0] === '不分冊')) {
                            units = inst.units || [];
                        }
                        // 一般冊次教材：從 vols[volName] 取
                        else if(inst.vols && inst.vols[volName]) {
                            units = inst.vols[volName];
                        }
                        // units 有 vol 欄位
                        else if(inst.units) {
                            units = inst.units.filter(function(u){ return u.vol === volName; });
                        }
                        console.log('[WN] onVolumeChange vol=', volName, 'units count=', units.length, 'first=', units[0] ? (units[0].name||units[0]) : 'none');
                        // 冊次=單元類型：volName 有值但 units 為空 → 直接用 volName 填 unitSel
                        if(volName && !units.length && WN_STATE.isVolUnitShared) {
                            unitSel.innerHTML = '<option value="'+escapeHtml(volName)+'">'+escapeHtml(volName)+'</option>';
                            WN_STATE.currentUnit = volName;
                        } else {
                            units.forEach(function(u){
                                var name = typeof u === 'object' ? u.name : u;
                                unitSel.innerHTML += '<option value="'+escapeHtml(name)+'">'+escapeHtml(name)+'</option>';
                            });
                        }
                    }
                }
            } catch(e){ console.log('[WN] onVolumeChange error:', e); }
            if(prefillUnit) {
                setTimeout(function(){ if(unitSel.querySelector('option[value="'+prefillUnit+'"]')) unitSel.value = prefillUnit; }, 50);
            }
            WN_STATE.currentUnit = unitSel.value;
        }
        // --- 檔案處理 ---
        function WN_onDragOver(e) {
            e.preventDefault();
            e.stopPropagation();
            var dz = document.getElementById('wn-drop-zone');
            if(dz) dz.classList.add('drag-over');
        }
        function WN_onDrop(e) {
            e.preventDefault();
            e.stopPropagation();
            var dz = document.getElementById('wn-drop-zone');
            if(dz) dz.classList.remove('drag-over');
            var files = e.dataTransfer.files;
            if(files.length > 0) {
                var dt = new DataTransfer();
                for(var i=0; i<files.length; i++) dt.items.add(files[i]);
                var fi = document.getElementById('wn-file-input');
                fi.value = '';
                fi.files = dt.files;
            }
        }
        function WN_cancelImage() {
            var cropArea = document.getElementById('wn-crop-area');
            var dropZone = document.getElementById('wn-drop-zone');
            var modeBar = document.getElementById('wn-mode-bar');
            var img = document.getElementById('wn-crop-img');
            if(cropArea) cropArea.style.display = 'none';
            if(dropZone) dropZone.style.display = 'block';
            if(modeBar) modeBar.style.display = 'none';
            if(img) img.src = '';
            WN_STATE.importedImage = null;
            WN_STATE.importedFileName = null;
            WN_STATE.cropBoxes = [];
            WN_STATE.eraseBoxes = [];
            WN_renderBoxes();
            document.getElementById('wn-file-input').value = '';
        }
        function WN_handleFileInput(input) {
            if(!input.files.length) return;
            var file = input.files[0];
            WN_STATE.importedFileName = file.name;
            var reader = new FileReader();
            reader.onload = function(e) {
                WN_STATE.importedImage = e.target.result;
                WN_showCropImage(e.target.result);
            };
            reader.readAsDataURL(file);
        }
        function WN_renderBoxes() {
            var cropArea = document.getElementById('wn-crop-area');
            if(!cropArea) return;
            // 移除舊框
            cropArea.querySelectorAll('.wn-crop-box, .wn-erase-box').forEach(function(b){ b.remove(); });
            var img = document.getElementById('wn-crop-img');
            var rect = cropArea.getBoundingClientRect();
            var scaleX = rect.width / img.naturalWidth;
            var scaleY = rect.height / img.naturalHeight;
            // 繪製裁切框（藍色）
            WN_STATE.cropBoxes.forEach(function(box, i) {
                var div = document.createElement('div');
                div.className = 'wn-crop-box';
                div.style.left = (box.x * scaleX) + 'px';
                div.style.top = (box.y * scaleY) + 'px';
                div.style.width = (box.w * scaleX) + 'px';
                div.style.height = (box.h * scaleY) + 'px';
                div.innerHTML = '<span class="wn-box-num">'+(i+1)+'</span><button class="wn-box-delete" onclick="WN_deleteBox(event, box.id)">✕</button>';
                div.onmousedown = function(ev) {
                    ev.stopPropagation();
                    if(ev.target.classList.contains('wn-box-delete')) return;
                    ev.preventDefault();
                    var startX = ev.clientX, startY = ev.clientY;
                    var origX = box.x, origY = box.y;
                    function onMove(e) {
                        var dx = (e.clientX - startX) / scaleX;
                        var dy = (e.clientY - startY) / scaleY;
                        box.x = Math.max(0, origX + dx);
                        box.y = Math.max(0, origY + dy);
                        div.style.left = (box.x * scaleX) + 'px';
                        div.style.top = (box.y * scaleY) + 'px';
                    }
                    function onUp() {
                        document.removeEventListener('mousemove', onMove);
                        document.removeEventListener('mouseup', onUp);
                    }
                    document.addEventListener('mousemove', onMove);
                    document.addEventListener('mouseup', onUp);
                };
                cropArea.appendChild(div);
            });
            // 繪製消除框（紅色）
            WN_STATE.eraseBoxes.forEach(function(box, i) {
                var div = document.createElement('div');
                div.className = 'wn-erase-box';
                div.style.left = (box.x * scaleX) + 'px';
                div.style.top = (box.y * scaleY) + 'px';
                div.style.width = (box.w * scaleX) + 'px';
                div.style.height = (box.h * scaleY) + 'px';
                div.innerHTML = '<button class="wn-erase-del" onclick="WN_deleteEraseBox(event, box.id)">✕</button>';
                div.onmousedown = function(ev) {
                    ev.stopPropagation();
                    if(ev.target.classList.contains('wn-erase-del')) return;
                    ev.preventDefault();
                    var startX = ev.clientX, startY = ev.clientY;
                    var origX = box.x, origY = box.y;
                    function onMove(e) {
                        var dx = (e.clientX - startX) / scaleX;
                        var dy = (e.clientY - startY) / scaleY;
                        box.x = Math.max(0, origX + dx);
                        box.y = Math.max(0, origY + dy);
                        div.style.left = (box.x * scaleX) + 'px';
                        div.style.top = (box.y * scaleY) + 'px';
                    }
                    function onUp() {
                        document.removeEventListener('mousemove', onMove);
                        document.removeEventListener('mouseup', onUp);
                    }
                    document.addEventListener('mousemove', onMove);
                    document.addEventListener('mouseup', onUp);
                };
                cropArea.appendChild(div);
            });
        }
        function WN_deleteEraseBox(e, id) {
            e.stopPropagation();
            WN_STATE.eraseBoxes = WN_STATE.eraseBoxes.filter(function(b){ return b.id !== id; });
            WN_renderBoxes();
        }
        function WN_setMode(mode) {
            WN_STATE.mode = mode;
            WN_updateModeButtons();
        }
        function WN_updateModeButtons() {
            ['add','erase','clean'].forEach(function(m){
                var btn = document.getElementById('wn-mode-'+m);
                if(btn) btn.classList.toggle('active', WN_STATE.mode === m);
            });
            var cleanUpload = document.getElementById('wn-clean-upload');
            if(cleanUpload) cleanUpload.style.display = (WN_STATE.mode === 'clean') ? 'block' : 'none';
        }
        // --- 內容感知填補（消除答案） ---
        // --- 上傳乾淨版本 ---
        function WN_handleCleanImage(input) {
            if(!input.files.length) return;
            var reader = new FileReader();
            reader.onload = function(e) {
                WN_STATE.cleanImage = e.target.result;
                document.getElementById('wn-crop-img').src = e.target.result;
                WN_STATE.importedImage = e.target.result;
            };
            reader.readAsDataURL(input.files[0]);
        }
        // --- 錯題原因 ---
        function WN_toggleReason(el) {
            var reason = el.getAttribute('data-reason');
            el.classList.toggle('selected');
            if(el.classList.contains('selected')) {
                if(WN_STATE.selectedReasons.indexOf(reason) === -1) WN_STATE.selectedReasons.push(reason);
            } else {
                WN_STATE.selectedReasons = WN_STATE.selectedReasons.filter(function(r){ return r !== reason; });
            }
        }
        // --- 儲存筆記 ---
        // v1.6.66: 7-step flow functions
        function WN_completeCrop() {
            // 從 cropBoxes 建立 flowImages
            WN_STATE.flowImages = [];
            if (WN_STATE.cropBoxes.length > 0) {
                WN_STATE.cropBoxes.forEach(function(box) {
                    WN_STATE.flowImages.push({
                        file: WN_cropBoxToDataUrl(box),
                        boxes: [box]
                    });
                });
            }
            // 也加入 importedImage (如果有)
            if (WN_STATE.importedImage && WN_STATE.flowImages.length === 0) {
                WN_STATE.flowImages.push({
                    file: WN_STATE.importedImage,
                    boxes: []
                });
            }
            WN_STATE.flowPerCard = WN_STATE.flowImages.map(function() {
                return { student: '', subject: '', material: '', instance: '', volume: '', unit: '', reasons: [], content: '' };
            });
            WN_STATE.flowCurrentIdx = 0;
            // 關閉 crop modal, 顯示 flow modal + step form
            document.getElementById('crop-modal').style.display = 'none';
            var flowModal = document.getElementById('wn-flow-modal');
            if (flowModal) flowModal.style.display = 'block';
            WN_showStepForm();
        }
        function WN_showStepForm() {
            document.getElementById('wn-step-form').style.display = 'block';
            document.getElementById('wn-step-reasons').style.display = 'none';
            document.getElementById('wn-step-note').style.display = 'none';
            // 載入 dropdowns
            WN_flowLoadDropdowns();
            WN_flowRenderCurrentCard();
        }
        function WN_flowLoadDropdowns() {
            // 載入所有 dropdowns (學生/科目/教材類型/教材名/冊次/單元)
            WN_loadStudentOptions();
            var sEl = document.getElementById('wn-flow-subject');
            if (sEl) {
                sEl.innerHTML = '<option value="">請選擇</option>';
                if (typeof appMaster !== 'undefined' && appMaster) {
                    Object.keys(appMaster).forEach(function(sub) {
                        if (!appMaster[sub] || typeof appMaster[sub] !== 'object') return;
                        if (!appMaster[sub].materials) return;
                        sEl.innerHTML += '<option value="' + sub + '">' + sub + '</option>';
                    });
                }
            }
            // 載入當前卡的已存值
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx] || {};
            if (card.student) document.getElementById('wn-flow-student').value = card.student;
            if (card.subject) {
                document.getElementById('wn-flow-subject').value = card.subject;
                WN_flowSubjectChange();
            }
            WN_flowRenderCurrentCard();
        }
        function WN_flowSubjectChange() {
            var subject = document.getElementById('wn-flow-subject').value;
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            card.subject = subject;
            // 載入教材類型
            var matEl = document.getElementById('wn-flow-material');
            matEl.innerHTML = '<option value="">請選擇</option>';
            if (subject && appMaster[subject] && appMaster[subject].materials) {
                Object.keys(appMaster[subject].materials).forEach(function(mat) {
                    matEl.innerHTML += '<option value="' + mat + '">' + mat + '</option>';
                });
            }
            // 重設後續
            card.material = '';
            card.instance = '';
            card.volume = '';
            card.unit = '';
        }
        function WN_flowMaterialChange() {
            var subject = document.getElementById('wn-flow-subject').value;
            var material = document.getElementById('wn-flow-material').value;
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            card.material = material;
            // 載入教材名
            var instEl = document.getElementById('wn-flow-instance');
            instEl.innerHTML = '<option value="">請選擇</option>';
            if (subject && material && appMaster[subject].materials[material].instances) {
                appMaster[subject].materials[material].instances.forEach(function(inst) {
                    instEl.innerHTML += '<option value="' + inst.name + '">' + inst.name + '</option>';
                });
            }
            card.instance = '';
            card.volume = '';
            card.unit = '';
        }
        function WN_flowInstanceChange() {
            var subject = document.getElementById('wn-flow-subject').value;
            var material = document.getElementById('wn-flow-material').value;
            var instance = document.getElementById('wn-flow-instance').value;
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            card.instance = instance;
            // 載入冊次
            var volEl = document.getElementById('wn-flow-volume');
            volEl.innerHTML = '<option value="">請選擇</option>';
            if (subject && material && instance && appMaster[subject].materials[material].instances) {
                var inst = appMaster[subject].materials[material].instances.find(function(i) { return i.name === instance; });
                if (inst && inst.vols) {
                    Object.keys(inst.vols).forEach(function(vol) {
                        volEl.innerHTML += '<option value="' + vol + '">' + vol + '</option>';
                    });
                }
            }
            card.volume = '';
            card.unit = '';
        }
        function WN_flowVolumeChange() {
            var subject = document.getElementById('wn-flow-subject').value;
            var material = document.getElementById('wn-flow-material').value;
            var instance = document.getElementById('wn-flow-instance').value;
            var volume = document.getElementById('wn-flow-volume').value;
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            card.volume = volume;
            // 載入單元
            var unitEl = document.getElementById('wn-flow-unit');
            unitEl.innerHTML = '<option value="">請選擇</option>';
            if (subject && material && instance && volume && appMaster[subject].materials[material].instances) {
                var inst = appMaster[subject].materials[material].instances.find(function(i) { return i.name === instance; });
                if (inst && inst.vols && inst.vols[volume]) {
                    inst.vols[volume].forEach(function(u) {
                        unitEl.innerHTML += '<option value="' + u.id + '">' + u.name + '</option>';
                    });
                }
            }
            card.unit = '';
        }
        function WN_flowStudentChange() {
            WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx].student = document.getElementById('wn-flow-student').value;
        }
        function WN_flowRenderCurrentCard() {
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx] || {};
            if (card.student) document.getElementById('wn-flow-student').value = card.student;
            if (card.subject) document.getElementById('wn-flow-subject').value = card.subject;
            if (card.material) document.getElementById('wn-flow-material').value = card.material;
            if (card.instance) document.getElementById('wn-flow-instance').value = card.instance;
            if (card.volume) document.getElementById('wn-flow-volume').value = card.volume;
            if (card.unit) document.getElementById('wn-flow-unit').value = card.unit;
            // counter
            var total = WN_STATE.flowImages.length || 1;
            document.getElementById('wn-flow-counter').textContent = (WN_STATE.flowCurrentIdx + 1) + ' / ' + total;
        }
        function WN_flowPrevCard() {
            if (WN_STATE.flowCurrentIdx > 0) {
                WN_STATE.flowCurrentIdx--;
                WN_flowRenderCurrentCard();
            }
        }
        function WN_flowNextCard() {
            if (WN_STATE.flowCurrentIdx < WN_STATE.flowImages.length - 1) {
                WN_STATE.flowCurrentIdx++;
                WN_flowRenderCurrentCard();
            }
        }
        function WN_goToStep7() {
            // 從 5 個 checkboxes 收集 reasons
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            card.reasons = [];
            document.querySelectorAll('#wn-flow-reasons input[type="checkbox"]').forEach(function(cb) {
                if (cb.checked) card.reasons.push(cb.value);
            });
            document.getElementById('wn-step-form').style.display = 'none';
            document.getElementById('wn-step-reasons').style.display = 'block';
            document.getElementById('wn-step-note').style.display = 'none';
        }
        function WN_goToStepForm() {
            // 儲存目前 reasons 到 card
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            document.querySelectorAll('#wn-flow-reasons input[type="checkbox"]').forEach(function(cb) {
                if (cb.checked && card.reasons.indexOf(cb.value) === -1) {
                    card.reasons.push(cb.value);
                } else if (!cb.checked && card.reasons.indexOf(cb.value) >= 0) {
                    card.reasons.splice(card.reasons.indexOf(cb.value), 1);
                }
            });
            document.getElementById('wn-step-form').style.display = 'block';
            document.getElementById('wn-step-reasons').style.display = 'none';
            document.getElementById('wn-step-note').style.display = 'none';
        }
        function WN_generateNote() {
            // 從 5 個 checkboxes 收集 reasons (當前卡)
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            card.reasons = [];
            document.querySelectorAll('#wn-flow-reasons input[type="checkbox"]').forEach(function(cb) {
                if (cb.checked) card.reasons.push(cb.value);
            });
            // 渲染 note page
            document.getElementById('wn-step-form').style.display = 'none';
            document.getElementById('wn-step-reasons').style.display = 'none';
            document.getElementById('wn-step-note').style.display = 'block';
            // 填日期
            document.getElementById('wn-note-date').textContent = new Date().toISOString().slice(0, 10).replace(/-/g, '/');
            // 填 reasons
            var reasonsEl = document.getElementById('wn-note-reasons');
            reasonsEl.innerHTML = card.reasons.map(function(r) { return '☐ ' + r; }).join('<br>');
            // 填 images
            var imgsEl = document.getElementById('wn-note-images');
            imgsEl.innerHTML = WN_STATE.flowImages.map(function(img, i) {
                return '<img src="' + img.file + '" style="max-width:200px;margin:4px;border:1px solid #ccc;">';
            }).join('');
            document.getElementById('wn-note-content-display').value = card.content || '';
        }
        function WN_editNote() {
            // 回到 reasons
            document.getElementById('wn-step-form').style.display = 'none';
            document.getElementById('wn-step-reasons').style.display = 'block';
            document.getElementById('wn-step-note').style.display = 'none';
            // 重新 render checkboxes
            var card = WN_STATE.flowPerCard[WN_STATE.flowCurrentIdx];
            document.querySelectorAll('#wn-flow-reasons input[type="checkbox"]').forEach(function(cb) {
                cb.checked = card.reasons.indexOf(cb.value) >= 0;
            });
        }
        // --- 查看錯題筆記列表 ---
        function WN_renderNotesList() {
            var notes = WN_getNotes();
            var studentFilter = document.getElementById('wn-notes-student') ? document.getElementById('wn-notes-student').value : '';
            var subjectFilter = document.getElementById('wn-notes-subject') ? document.getElementById('wn-notes-subject').value : '';
            var volumeFilter = document.getElementById('wn-notes-volume') ? document.getElementById('wn-notes-volume').value : '';
            var filtered = notes.filter(function(n) {
                return (!studentFilter || n.student === studentFilter) &&
                       (!subjectFilter || n.subject === subjectFilter) &&
                       (!volumeFilter || n.volume === volumeFilter);
            });
            // 載入篩選下拉
            WN_loadNotesFilterOptions(notes);
            var list = document.getElementById('wn-notes-list');
            if(!list) return;
            if(!filtered.length) {
                list.innerHTML = '<div class="wn-empty">尚無錯題筆記，請由「匯入錯題」新增</div>';
                return;
            }
            list.innerHTML = filtered.map(function(n) {
                return '<div class="wn-note-card" data-id="'+n.id+'">' +
                    '<div class="wn-note-header" onclick="WN_toggleNoteExpand(this)">' +
                        '<div>' +
                            '<div style="font-weight:bold;color:var(--primary)">'+escapeHtml(n.subject)+' / '+escapeHtml(n.volume)+' / '+escapeHtml(n.unit)+'</div>' +
                            '<div class="wn-note-meta"><span>📅 '+n.date+'</span><span>👤 '+escapeHtml(n.student)+'</span><span>📌 '+escapeHtml(n.source)+'</span></div>' +
                        '</div>' +
                        '<input type="checkbox" class="wn-checkbox wn-note-check" data-id="'+n.id+'" onclick="WN_onNoteCheck(event)">' +
                    '</div>' +
                    '<div class="wn-note-content">' +
                        '<div style="margin-bottom:8px"><span class="wn-label">錯題原因:</span> '+(n.reasons||[]).join(', ')+'</div>' +
                        (n.imgUrl ? '<img class="wn-note-img" src="'+n.imgUrl+'">' : '') +
                        '<div style="margin-top:8px;white-space:pre-wrap">'+escapeHtml(n.content||'')+'</div>' +
                        '<div style="margin-top:10px;display:flex;gap:8px">' +
                            "<button class=\"wn-btn wn-btn-danger\" data-noteid=\""+n.id+"\" onclick=\"WN_deleteNote(this.dataset.noteid)\">🗑 刪除</button>" +
                        '</div>' +
                    '</div>' +
                '</div>';
            }).join('');
            WN_updateComposeBtn();
        }
        function WN_loadNotesFilterOptions(notes) {
            ['student','subject','volume'].forEach(function(type) {
                var sel = document.getElementById('wn-notes-'+type);
                if(!sel) return;
                var current = sel.value;
                var vals = [...new Set(notes.map(function(n){ return n[type]; }))];
                sel.innerHTML = '<option value="">全部'+(type==='student'?'學生':type==='subject'?'科目':'冊次')+'</option>';
                vals.forEach(function(v){ sel.innerHTML += '<option value="'+escapeHtml(v)+'">'+escapeHtml(v)+'</option>'; });
                sel.value = current;
            });
        }
        function WN_toggleNoteExpand(header) {
            var card = header.parentElement;
            card.classList.toggle('expanded');
        }
        function WN_onNoteCheck(e) {
            e.stopPropagation();
            WN_updateComposeBtn();
        }
        function WN_updateComposeBtn() {
            var checks = document.querySelectorAll('.wn-note-check:checked');
            var btn = document.getElementById('wn-compose-btn');
            if(btn) btn.disabled = !checks.length;
        }
        function WN_clearNotesFilter() {
            ['wn-notes-student','wn-notes-subject','wn-notes-volume'].forEach(function(id){
                var el = document.getElementById(id);
                if(el) el.value = '';
            });
            WN_renderNotesList();
        }
        function WN_deleteNote(id) {
            if(!confirm('確定刪除這筆記？')) return;
            var notes = WN_getNotes().filter(function(n){ return n.id !== id; });
            WN_saveNotes(notes);
            WN_renderNotesList();
        }
        // --- 組成練習卷 ---
        function WN_composePractice() {
            var checks = document.querySelectorAll('.wn-note-check:checked');
            if(!checks.length) { alert('請勾選要練習的錯題'); return; }
            var notes = WN_getNotes();
            var selected = [];
            checks.forEach(function(c){ var n = notes.find(function(x){ return x.id === c.getAttribute('data-id'); }); if(n) selected.push(n); });
            if(document.getElementById('wn-shuffle-practice').checked) {
                selected = selected.sort(function(){ return Math.random()-0.5; });
            }
            WN_STATE.practiceQuestions = selected;
            WN_STATE.practiceIndex = 0;
            WN_STATE.practiceResults = {};
            WN_switchTab('practice');
            WN_showPracticeQuestion();
        }
        // --- 錯題再練 ---
        function WN_renderPracticeList() {
            var notes = WN_getNotes();
            var studentFilter = document.getElementById('wn-practice-student') ? document.getElementById('wn-practice-student').value : '';
            var subjectFilter = document.getElementById('wn-practice-subject') ? document.getElementById('wn-practice-subject').value : '';
            var filtered = notes.filter(function(n) {
                return (!studentFilter || n.student === studentFilter) && (!subjectFilter || n.subject === subjectFilter);
            });
            var list = document.getElementById('wn-practice-list');
            if(!list) return;
            if(!filtered.length) {
                list.innerHTML = '<div class="wn-empty">尚無錯題可練習</div>';
                return;
            }
            list.innerHTML = filtered.map(function(n) {
                return '<div class="wn-note-card" style="cursor:default">' +
                    '<div class="wn-note-header" style="cursor:pointer" onclick="WN_toggleNoteExpand(this)">' +
                        '<div>' +
                            '<div style="font-weight:bold;color:var(--primary)">'+escapeHtml(n.subject)+' / '+escapeHtml(n.volume)+' / '+escapeHtml(n.unit)+'</div>' +
                            '<div class="wn-note-meta"><span>📅 '+n.date+'</span><span>👤 '+escapeHtml(n.student)+'</span></div>' +
                        '</div>' +
                        '<input type="checkbox" class="wn-checkbox wn-prac-check" data-id="'+n.id+'" onclick="WN_onPracCheck()">' +
                    '</div>' +
                    '<div class="wn-note-content">' +
                        (n.imgUrl ? '<img class="wn-note-img" src="'+n.imgUrl+'">' : '') +
                        '<div style="margin-top:8px"><span class="wn-label">原因:</span> '+(n.reasons||[]).join(', ')+'</div>' +
                    '</div>' +
                '</div>';
            }).join('');
            WN_updatePracBtns();
        }
        function WN_onPracCheck() {
            WN_updatePracBtns();
        }
        function WN_updatePracBtns() {
            var checks = document.querySelectorAll('.wn-prac-check:checked');
            var startBtn = document.getElementById('wn-start-practice-btn');
            var printBtn = document.getElementById('wn-print-btn');
            if(startBtn) startBtn.disabled = !checks.length;
            if(printBtn) printBtn.disabled = !checks.length;
        }
        function WN_clearPracticeFilter() {
            ['wn-practice-student','wn-practice-subject'].forEach(function(id){
                var el = document.getElementById(id);
                if(el) el.value = '';
            });
            WN_renderPracticeList();
        }
        function WN_startPractice() {
            var checks = document.querySelectorAll('.wn-prac-check:checked');
            if(!checks.length) { alert('請勾選要練習的錯題'); return; }
            var notes = WN_getNotes();
            var selected = [];
            checks.forEach(function(c){ var n = notes.find(function(x){ return x.id === c.getAttribute('data-id'); }); if(n) selected.push(n); });
            if(document.getElementById('wn-shuffle-practice').checked) {
                selected = selected.sort(function(){ return Math.random()-0.5; });
            }
            WN_STATE.practiceQuestions = selected;
            WN_STATE.practiceIndex = 0;
            WN_STATE.practiceResults = {};
            document.getElementById('wn-practice-select').style.display = 'none';
            document.getElementById('wn-practice-area').style.display = 'block';
            WN_showPracticeQuestion();
        }
        function WN_showPracticeQuestion() {
            var q = WN_STATE.practiceQuestions[WN_STATE.practiceIndex];
            if(!q) return;
            var progress = document.getElementById('wn-practice-progress');
            if(progress) progress.textContent = '第 '+(WN_STATE.practiceIndex+1)+' / '+WN_STATE.practiceQuestions.length+' 題';
            var area = document.getElementById('wn-practice-question');
            if(area) {
                area.innerHTML = (q.imgUrl ? '<img src="'+q.imgUrl+'" style="max-width:350px;border-radius:8px;margin:0 auto;display:block">' : '') +
                    '<div style="margin-top:12px;font-size:0.9em;color:var(--secondary)">' +
                        '<span>'+escapeHtml(q.subject)+' / '+escapeHtml(q.volume)+' / '+escapeHtml(q.unit)+'</span>' +
                        '<span style="margin-left:12px">錯題原因: '+(q.reasons||[]).join(', ')+'</span>' +
                    '</div>';
            }
            var reveal = document.getElementById('wn-answer-reveal');
            if(reveal) { reveal.classList.remove('show'); reveal.innerHTML = ''; }
        }
        function WN_nextQuestion() {
            if(WN_STATE.practiceIndex < WN_STATE.practiceQuestions.length-1) {
                WN_STATE.practiceIndex++;
                WN_showPracticeQuestion();
            } else {
                WN_finishPractice();
            }
        }
        function WN_prevQuestion() {
            if(WN_STATE.practiceIndex > 0) {
                WN_STATE.practiceIndex--;
                WN_showPracticeQuestion();
            }
        }
        function WN_markMastered() {
            var q = WN_STATE.practiceQuestions[WN_STATE.practiceIndex];
            if(q) {
                WN_STATE.practiceResults[q.id] = 'mastered';
                // 更新統計
                var notes = WN_getNotes();
                var note = notes.find(function(n){ return n.id === q.id; });
                if(note) { note.mastered = (note.mastered||0)+1; note.practiced = (note.practiced||0)+1; WN_saveNotes(notes); }
            }
            WN_nextQuestion();
        }
        function WN_markStillWrong() {
            var q = WN_STATE.practiceQuestions[WN_STATE.practiceIndex];
            if(q) {
                WN_STATE.practiceResults[q.id] = 'stillwrong';
                var notes = WN_getNotes();
                var note = notes.find(function(n){ return n.id === q.id; });
                if(note) { note.stillWrong = (note.stillWrong||0)+1; note.practiced = (note.practiced||0)+1; WN_saveNotes(notes); }
            }
            WN_nextQuestion();
        }
        function WN_finishPractice() {
            var results = WN_STATE.practiceResults;
            var total = WN_STATE.practiceQuestions.length;
            var mastered = Object.values(results).filter(function(v){ return v==='mastered'; }).length;
            var stillwrong = total - mastered;
            var area = document.getElementById('wn-practice-area');
            if(area) {
                area.innerHTML = '<div class="wn-section" style="text-align:center">' +
                    '<div style="font-size:3em;margin-bottom:15px">'+(stillwrong===0?'🎉':'📝')+'</div>' +
                    '<div style="font-size:1.3em;font-weight:bold;margin-bottom:15px">練習完成！</div>' +
                    '<div style="font-size:1.1em;color:var(--secondary)">總題數: '+total+'</div>' +
                    '<div style="font-size:1.1em;color:#27ae60;font-weight:bold">學會了: '+mastered+' 題</div>' +
                    '<div style="font-size:1.1em;color:#e74c3c;font-weight:bold;margin-bottom:20px">再錯: '+stillwrong+' 題</div>' +
                    '<div style="color:#95a5a6;margin-bottom:15px">再錯的題目已標記，稍後可再練習</div>' +
                    '<button class="wn-btn wn-btn-primary" onclick="WN_exitPractice()">🔙 返回</button>' +
                '</div>';
            }
        }
        function WN_exitPractice() {
            WN_STATE.practiceQuestions = [];
            WN_STATE.practiceIndex = 0;
            WN_STATE.practiceResults = {};
            document.getElementById('wn-practice-area').style.display = 'none';
            document.getElementById('wn-practice-select').style.display = 'block';
            WN_renderPracticeList();
        }
        // --- 列印練習卷 ---
        function WN_printPractice() {
            var checks = document.querySelectorAll('.wn-prac-check:checked');
            if(!checks.length) { alert('請勾選要列印的錯題'); return; }
            var notes = WN_getNotes();
            var selected = [];
            checks.forEach(function(c){ var n = notes.find(function(x){ return x.id === c.getAttribute('data-id'); }); if(n) selected.push(n); });
            var printArea = document.getElementById('wn-print-area');
            printArea.style.display = 'block';
            printArea.innerHTML = '<div style="font-family:serif;padding:20px">' +
                '<h2 style="text-align:center;margin-bottom:20px">錯題練習卷</h2>' +
                '<div style="margin-bottom:10px">姓名: __________ &nbsp; 日期: __________</div>' +
                selected.map(function(n,i){
                    return '<div style="margin-bottom:25px;page-break-inside:avoid">' +
                        '<div style="font-weight:bold;margin-bottom:5px">'+(i+1)+'. '+escapeHtml(n.subject)+' / '+escapeHtml(n.volume)+' / '+escapeHtml(n.unit)+'</div>' +
                        (n.imgUrl ? '<img src="'+n.imgUrl+'" style="max-width:500px">' : '') +
                        '<div style="margin-top:5px">答: ______________</div>' +
                    '</div>';
                }).join('<hr>') +
            '</div>';
            window.print();
            setTimeout(function(){ printArea.style.display = 'none'; }, 500);
        }
        // --- 錯題統計 ---
        function WN_renderStats() {
            var notes = WN_getNotes();
            var total = notes.length;
            var mastered = notes.filter(function(n){ return (n.mastered||0) > 0; }).length;
            var stillwrong = notes.filter(function(n){ return (n.stillWrong||0) > 0; }).length;
            var practice = notes.reduce(function(s,n){ return s+(n.practiced||0); }, 0);
            document.getElementById('wn-stat-total').textContent = total;
            document.getElementById('wn-stat-mastered').textContent = mastered;
            document.getElementById('wn-stat-stillwrong').textContent = stillwrong;
            document.getElementById('wn-stat-practice').textContent = practice;
            // 依科目
            var bySubject = {};
            notes.forEach(function(n){
                if(!bySubject[n.subject]) bySubject[n.subject] = {total:0, mastered:0, stillwrong:0};
                bySubject[n.subject].total++;
                if((n.mastered||0)>0) bySubject[n.subject].mastered++;
                if((n.stillWrong||0)>0) bySubject[n.subject].stillwrong++;
            });
            var statsEl = document.getElementById('wn-stats-by-subject');
            if(statsEl) {
                statsEl.innerHTML = Object.keys(bySubject).map(function(sb){
                    var d = bySubject[sb];
                    var rate = d.total > 0 ? Math.round((d.stillwrong/d.total)*100) : 0;
                    return '<div style="display:flex;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid var(--border)">' +
                        '<span style="min-width:60px;font-weight:600">'+escapeHtml(sb)+'</span>' +
                        '<div style="flex:1;height:8px;background:#f0f0f0;border-radius:4px"><div style="height:100%;width:'+rate+'%;background:#e74c3c;border-radius:4px"></div></div>' +
                        '<span style="color:#e74c3c;font-weight:bold">'+rate+'% 再錯率</span>' +
                        '<span style="color:#95a5a6;font-size:0.85em">('+d.stillwrong+'/'+d.total+')</span>' +
                    '</div>';
                }).join('');
            }
        }
        // --- renderWrongNotesView (由 switchStatsView 呼叫) ---
        function renderWrongNotesView() {
            // DEBUG: dump appMaster structure
            try {
                console.log('[WN] === appMaster Structure ===');
                console.log('[WN] appMaster type:', typeof appMaster);
                console.log('[WN] appMaster keys:', appMaster ? Object.keys(appMaster) : 'null');
                if(appMaster) {
                    Object.keys(appMaster).forEach(function(key) {
                        console.log('[WN] appMaster['+key+'] =', JSON.stringify(appMaster[key]).slice(0,300));
                    });
                }
                console.log('[WN] === END appMaster ===');
            } catch(e) { console.log('[WN] dump error:', e); }
            // 每次進入 tab 都重新整理下拉選單
            WN_migrateNotes();
            // 載入學生（用 multiData）
            var sel = document.getElementById('wn-student');
            if(sel) {
                sel.innerHTML = '<option value="">請選擇</option>';
                try {
                    if(typeof multiData !== 'undefined' && multiData) {
                        Object.keys(multiData).forEach(function(uid){
                            // 過濾 non-student keys（如 logs, students 等非學生資料）
                            if(!multiData[uid] || typeof multiData[uid] !== 'object' || !multiData[uid].name) return;
                            var name = multiData[uid].name || uid;
                            sel.innerHTML += '<option value="'+escapeHtml(name)+'">'+escapeHtml(name)+'</option>';
                        });
                    }
                    console.log('[WN] 學生 dropdown populated, count=', sel.options.length);
                } catch(e){ console.log('[WN] 學生載入錯誤:', e); }
            }
            // 載入科目：直接取 appMaster keys，過濾掉無效 key（如 materials 是屬性名）
            var sbEl = document.getElementById('wn-subject');
            if(sbEl) {
                sbEl.innerHTML = '<option value="">請選擇</option>';
                try {
                    if(typeof appMaster !== 'undefined' && appMaster) {
                        Object.keys(appMaster).forEach(function(sub){
                            // materials 是 appMaster 某個 subject 的屬性名稱（boolean），不是獨立科目，必須過濾
                            if(!appMaster[sub] || typeof appMaster[sub] !== 'object') return;
                            if(!appMaster[sub].materials) return;
                            sbEl.innerHTML += '<option value="'+escapeHtml(sub)+'">'+escapeHtml(sub)+'</option>';
                        });
                    }
                } catch(e){ console.log('[WN] 科目載入錯誤:', e); }
            }
            // 如果appMaster還是空的，等一下再試
            if(sbEl && sbEl.options.length <= 1) {
                setTimeout(function(){ renderWrongNotesView(); }, 1000);
            }
            // 如果有外部帶入資料
            if(window._wn_pendingData) {
                WN_applyPendingData(window._wn_pendingData);
                window._wn_pendingData = null;
            }
        }
        
        // v1.5.158: 答對率統計 (per-user storage, 改下拉立即重渲染)
        var STORAGE_KEY_ACCURACY_BASE = 'StudyMap_AccuracyRecords_V158';
        if (!window._accExtraExams) window._accExtraExams = [];
        if (!window._accFilters) window._accFilters = { subject: '__ALL__', unit: '__ALL__', typeName: '__ALL__', sort: 'rate' };
        function accStorageKey() {
            var uid = (typeof currentUserId !== 'undefined') ? currentUserId : 'default';
            return STORAGE_KEY_ACCURACY_BASE + '_' + uid;
        }
        function loadAccuracyRecords() {
            try {
                var records = JSON.parse(localStorage.getItem(accStorageKey()) || '[]');
                // v1.6.160 FIX: 自動遷移舊 records — 從主考試的 instanceName 補到 extraExam
                // 舊 extraExam 物件沒存 typeName/instanceName，修完 filter 邏輯後會完全不參與 rate 計算
                // 這裡自動把 record 主表單的 subject/typeName/instanceName 補到 extraExam
                if (Array.isArray(records)) {
                    records.forEach(function(r) {
                        if (!r.extraExams || !Array.isArray(r.extraExams)) return;
                        r.extraExams.forEach(function(e) {
                            if (!e.subject && r.subject) e.subject = r.subject;
                            if (!e.typeName && r.typeName) e.typeName = r.typeName;
                            if (!e.instanceName && r.instanceName) e.instanceName = r.instanceName;
                        });
                    });
                    // v1.6.164 MIGRATION: 自動標註「同 instance 內唯一」的 wrongUnits (vol|name 格式)
                    // v1.6.162 的 findUnitVols 是全局搜, 跨 instance 同名 (如 麻辣甲 L1~2 + 大滿貫甲 L1~2)
                    // 會誤判為 multi-vol 而跳過標註, 結果同一 instance 內其實唯一的單元 (如 L1~3, L4~6) 也漏掉
                    // v1.6.164 改成按 (sub, typeName, instanceId) 過濾, 只看同一 instance 內是否唯一
                    // v1.6.167: appMaster 只有當前 cat, 跨 cat instance (例: 段考複習 看 會考複習 的 record) 會找不到
                    // 改成掃 multiData[currentUserId].masters 所有 cat 找 (sub, typeName, instanceId)
                    var _v164Stats = { migrated: 0, skipped: 0, skippedReasons: {} };
                    var _v167AllMasters = (typeof multiData !== 'undefined' && multiData[currentUserId] && multiData[currentUserId].masters) || {};
                    function _v167FindIns(subName, typeName, instanceId) {
                        var cats = Object.keys(_v167AllMasters);
                        for (var ci = 0; ci < cats.length; ci++) {
                            var catM = _v167AllMasters[cats[ci]];
                            if (!catM || !catM[subName] || !catM[subName].materials) continue;
                            var typeObj = catM[subName].materials[typeName];
                            if (!typeObj || !Array.isArray(typeObj.instances)) continue;
                            var found = typeObj.instances.find(function(i) { return i.id === instanceId; });
                            if (found) return found;
                        }
                        return null;
                    }
                    records.forEach(function(r) {
                        if (!r.wrongUnits || !Array.isArray(r.wrongUnits)) return;
                        var hasNewFormat = r.wrongUnits.some(function(wu) { return wu && wu.indexOf('|') > 0; });
                        if (hasNewFormat) { _v164Stats.skipped++; return; }
                        var _instanceId = r.instanceId;
                        if (!_instanceId) { _v164Stats.skipped++; _v164Stats.skippedReasons['no-instanceId'] = (_v164Stats.skippedReasons['no-instanceId'] || 0) + 1; return; }
                        // v1.6.167: 跨 cat 找 instance (appMaster 只有當前 cat 的 subjects, 跨 cat record 會找不到)
                        var _ins = _v167FindIns(r.subject, r.typeName, _instanceId);
                        if (!_ins || _ins.type !== 'volume' || !_ins.vols) { _v164Stats.skipped++; _v164Stats.skippedReasons['no-vol-instance'] = (_v164Stats.skippedReasons['no-vol-instance'] || 0) + 1; return; }
                        var _newWrongUnits = [];
                        r.wrongUnits.forEach(function(wu) {
                            if (!wu || wu.indexOf('|') > 0) { _newWrongUnits.push(wu); return; }
                            var _matches = [];
                            Object.keys(_ins.vols).forEach(function(vol) {
                                (_ins.vols[vol] || []).forEach(function(u) {
                                    if (u.name === wu) _matches.push(vol);
                                });
                            });
                            if (_matches.length === 1) {
                                _newWrongUnits.push(_matches[0] + '|' + wu);
                                _v164Stats.migrated++;
                            } else {
                                _newWrongUnits.push(wu);  // 0 個 (單元已刪) 或 ≥2 個 (真的 multi-vol) → 保留舊格式
                            }
                        });
                        r.wrongUnits = _newWrongUnits;
                    });
                    if (_v164Stats.migrated > 0 || _v164Stats.skipped > 0) {
                        console.log('[v1.6.164 migration] migrated=' + _v164Stats.migrated + ' skipped=' + _v164Stats.skipped, _v164Stats.skippedReasons);
                        // 持久化 migration 結果 (有動到 records 才寫, 避免不必要的 IO)
                        if (_v164Stats.migrated > 0) {
                            try { localStorage.setItem(accStorageKey(), JSON.stringify(records)); } catch(e) {}
                        }
                    }
                }
                return records;
            }
            catch(e) { return []; }
        }
        function saveAccuracyRecords(records) {
            try { localStorage.setItem(accStorageKey(), JSON.stringify(records)); }
            catch(e) { showSaveErrorToast(e); }
        }
        function getAccuracySubjects() {
            var subs = Object.keys(appMaster || {});
            return subs.filter(function(s) { return appMaster[s] && appMaster[s].materials; });
        }
        function getAccuracyMaterialTypes(subject) {
            var s = appMaster[subject];
            if (!s || !s.materials) return [];
            return Object.keys(s.materials).filter(function(t) {
                return s.materials[t] && Array.isArray(s.materials[t].instances);
            });
        }
        function getAccuracyInstances(subject, typeName) {
            var s = appMaster[subject];
            if (!s || !s.materials || !s.materials[typeName]) return [];
            return s.materials[typeName].instances || [];
        }
        function getAccuracyUnits(subject, typeName, instanceId) {
            var s = appMaster[subject];
            if (!s || !s.materials || !s.materials[typeName]) return [];
            var typeObj = s.materials[typeName];
            var inst = typeObj.instances.find(function(i) { return i.id === instanceId; });
            if (!inst) return [];
            var units = [];
            if (inst.vols) {
                (inst.volOrder || Object.keys(inst.vols)).forEach(function(vol) {
                    (inst.vols[vol] || []).forEach(function(u) { units.push(u.name || u.id); });
                });
            }
            if (Array.isArray(inst.units)) {
                inst.units.forEach(function(u) { units.push(u.name || u.id); });
            }
            return units;
        }
        // v1.5.193: 從 unitId 找最後完成日期 (跨 plan 找 isDone task 的最新 dStr)
        function getUnitLastDoneDate(unitId) {
            if (!unitId || !Array.isArray(appPlans)) return null;
            var latest = null;
            appPlans.forEach(function(plan) {
                if (!plan.grid) return;
                Object.keys(plan.grid).forEach(function(dStr) {
                    (plan.grid[dStr] || []).forEach(function(t) {
                        if (!t || !t.isDone || t.unitId !== unitId) return;
                        if (!latest || dStr > latest) latest = dStr;
                    });
                });
            });
            return latest;
        }
        // v1.5.193: 從 unitId 跳到答對率頁, 自動帶 sub/type/instance/日期/錯題單元
        function jumpToAccuracyForUnit(unitId, unitName) {
            if (!unitId) return;
            // v1.5.219: 找 unit 跨所有 category
            var ctx = findUnitContextAnywhere(unitId, unitName);
            if (!ctx) {
                console.error('jumpToAccuracyForUnit: 找不到 unitId=' + unitId + (unitName ? ' / unitName=' + unitName : ''));
                return;
            }
            // 1. 切到答對率頁
            openStats();
            switchStatsView('accuracy');
            // v1.5.220: 輪詢策略 — 確保 dropdowns 真的有 options 才設值
            // (真實瀏覽器 form render 可能 0~200ms 才完成)
            var attempt = 0;
            var maxAttempts = 30;  // 30 * 30ms = 900ms max
            var tryFill = function() {
                attempt++;
                var subSel = el('acc-subject');
                if (!subSel) {
                    if (attempt < maxAttempts) { setTimeout(tryFill, 30); return; }
                    console.error('jumpToAccuracyForUnit: 嘗試 ' + attempt + ' 次後 acc-subject 仍找不到');
                    return;
                }
                // 檢查 options 是否 ready (subject 應該在 options)
                var subOptions = Array.from(subSel.options).map(function(o) { return o.value; });
                if (subOptions.indexOf(ctx.sub) < 0) {
                    console.warn('jumpToAccuracyForUnit: subject ' + ctx.sub + ' 不在 options, 等待 render... (attempt ' + attempt + ')');
                    if (attempt < maxAttempts) { setTimeout(tryFill, 30); return; }
                    console.error('jumpToAccuracyForUnit: 嘗試 ' + attempt + ' 次後 acc-subject options 仍沒 ' + ctx.sub);
                    return;
                }
                console.log('jumpToAccuracyForUnit: form ready (attempt ' + attempt + '), 開始填 dropdowns');
                // 2. 設 acc-subject (觸發 onchange cascade)
                subSel.value = ctx.sub;
                accOnSubjectChange();
                // 3. 設 acc-type
                var typeSel = el('acc-type');
                if (typeSel) {
                    var typeOptions = Array.from(typeSel.options).map(function(o) { return o.value; });
                    if (typeOptions.indexOf(ctx.typeName) >= 0) {
                        typeSel.value = ctx.typeName;
                    } else {
                        console.error('jumpToAccuracyForUnit: typeName=' + ctx.typeName + ' 不在 options [' + typeOptions.join(',') + ']');
                    }
                }
                accOnTypeChange();
                // 4. 設 acc-instance
                var instSel = el('acc-instance');
                if (instSel) {
                    var instOptions = Array.from(instSel.options).map(function(o) { return o.value; });
                    if (instOptions.indexOf(ctx.instance.id) >= 0) {
                        instSel.value = ctx.instance.id;
                    } else {
                        console.error('jumpToAccuracyForUnit: instance.id=' + ctx.instance.id + ' 不在 options [' + instOptions.join(',') + ']');
                    }
                }
                accOnInstanceChange();
                // 4.5. 設 acc-unit
                var unitSel = el('acc-unit');
                if (unitSel && ctx.unit && ctx.unit.name) {
                    var unitOptions = Array.from(unitSel.options).map(function(o) { return o.value; });
                    if (unitOptions.indexOf(ctx.unit.name) >= 0) {
                        unitSel.value = ctx.unit.name;
                    } else {
                        console.error('jumpToAccuracyForUnit: unit.name=' + ctx.unit.name + ' 不在 options [' + unitOptions.slice(0, 10).join(',') + '...]');
                    }
                }
                // 5. 預設考試日期 = 最後完成日期, 沒則今天
                var lastDate = getUnitLastDoneDate(unitId);
                if (!lastDate) {
                    var d = new Date();
                    lastDate = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                }
                var dateEl = el('acc-date');
                if (dateEl) { dateEl.value = lastDate; }
                // 6. 重置額外考卷清單
                // v1.6.162: 若 ctx.vol 有值, 用「vol|name」格式存 — 雙軌制避免跨 vol 污染
                //           若 ctx.vol 為 null (custom instance 無 vol), 用舊格式
                var volTag = ctx.vol ? (ctx.vol + '|') : '';
                window._accWrongUnits = [volTag + ctx.unit.name];
                window._accExtraExams = [];
                accRenderExtraExams();
                // 7. 滾動到表單
                var form = document.querySelector('.accuracy-form');
                if (form && form.scrollIntoView) form.scrollIntoView({ behavior: 'smooth', block: 'start' });
                // 8. 高亮該 unit row
                // v1.5.221: 不要 renderAccuracyStats() (會 rebuild form 蓋掉 dropdowns)
                // 只更新 _highlightedUnitName 變數, 然後只更新 table 部分 (或下次 switchStatsView 才生效)
                // v1.6.162: _highlightedUnitName 存「vol|name」格式 (若有 vol), 配合 table 雙軌比對
                window._highlightedUnitName = volTag + ctx.unit.name;
                // v1.5.228: highlight 用完整 ctx 比對 row (subject+typeName+instance.name+unitName)
                //            避免只 match unitName 跳到別科目的同名 row (例: 生物 第1回 → 跳成 數學 第1回)
                // v1.6.162: 比對 row textContent 時, 也比對「vol|name」格式 (新 records 存的格式)
                var rows = document.querySelectorAll('.accuracy-table tbody tr');
                var highlightedAny = false;
                for (var i = 0; i < rows.length; i++) {
                    var row = rows[i];
                    var tds = row.querySelectorAll('td');
                    if (tds.length < 4) continue;
                    // tds[1]=科目 tds[2]=教材類型 tds[3]=教材版本
                    var rowSub = ((tds[1] && tds[1].textContent) || '').trim();
                    var rowType = ((tds[2] && tds[2].textContent) || '').trim();
                    var rowInst = ((tds[3] && tds[3].textContent) || '').trim();
                    var rowText = row.textContent || '';
                    if (rowSub === ctx.sub && rowType === ctx.typeName && rowInst === ctx.instance.name &&
                        (rowText.indexOf(ctx.unit.name) >= 0 || rowText.indexOf(volTag + ctx.unit.name) >= 0)) {
                        row.style.background = '#F3B8B1';
                        if (row.scrollIntoView) row.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        highlightedAny = true;
                        break;
                    }
                }
                if (!highlightedAny) {
                    console.log('jumpToAccuracyForUnit: 找到 unit 但 records 表格沒有對應 row (可能尚未登錄 records 或 filter 擋住)');
                }
                console.log('jumpToAccuracyForUnit: dropdowns 設定完成');
            };
            setTimeout(tryFill, 50);
        }
        // v1.5.216: jumpToAccuracyForUnitHighlight 廢棄, 統一用 jumpToAccuracyForUnit
        function jumpToAccuracyForUnitHighlight(unitId, unitName) {
            jumpToAccuracyForUnit(unitId, unitName);
        }
        // v1.5.205: 樹狀圖點 unit name 跳過來也要高亮該 unit row (#F3B8B1)
        // v1.5.209: 答對率 bar 點擊 → 直接呼叫 jumpToAccuracyForUnit (它已有填 dropdowns + highlight 邏輯)
        function jumpToAccuracyForUnitHighlight(unitId, unitName) {
            jumpToAccuracyForUnit(unitId, unitName);
        }
        // v1.5.205 + v1.5.228 fix: 計算某 unit 的最近答對率
        // v1.5.228: 加 subject/typeName/instanceName 三層 context filter (避免 cross-instance 污染)
        //            例: 生物/麻辣甲/第1回 不該去拉 數學/麻辣甲/第1回 100% 的 records
        // 用 loose match (雙向 substring): 處理 unit name 不完全相同的情況
        // v1.6.162: 加第 5 參數 vol — 雙軌制支援
        //   新格式 wu = "vol|name" (例: "第三冊|L1~2") — 嚴格 match
        //   舊格式 wu = "name" (例: "L1~2") — 仍可 match (向後相容, 但 vol 已知時不 match 跨 vol 的舊記錄)
        //   vol 已知 + wu 有 vol prefix → 只 match 同 vol 的
        //   vol 已知 + wu 無 prefix → 仍 match (因新格式只用在「master 唯一 vol」的安全記錄)
        //   vol 不明 (null) → 跟舊邏輯一樣, 全部 match
        function getUnitAccuracyRate(unitName, sub, typeName, instanceName, vol) {
            var records = loadAccuracyRecords();
            var rates = [];
            function looseMatch(a, b) {
                if (!a || !b) return false;
                return a.indexOf(b) >= 0 || b.indexOf(a) >= 0;
            }
            // v1.6.162: 雙軌制 helper — 拆 vol|name 或回傳 name
            function splitVolName(wu) {
                var i = wu && wu.indexOf('|');
                return (i > 0) ? { vol: wu.substring(0, i), name: wu.substring(i + 1) } : { vol: null, name: wu };
            }
            // v1.6.162: 雙軌制 helper — 判斷一筆 wrongUnit 是否應該 match
            //   - vol 未知: 跟舊邏輯一樣, 只看 name
            //   - vol 已知: 允許「同 name 的新格式 (vol 相符)」+「同 name 的舊格式 (向下相容)」
            function wuMatches(wu) {
                var s = splitVolName(wu);
                if (s.name !== unitName) return false;
                if (!vol) return true;  // vol 未知, 只要 name 對就 match
                if (s.vol === null) return true;  // 舊格式, 向下相容
                return s.vol === vol;  // 新格式, vol 必須相符
            }
            function ctxMatch(r) {
                if (sub && r.subject !== sub) return false;
                if (typeName && r.typeName !== typeName) return false;
                if (instanceName && r.instanceName !== instanceName) return false;
                return true;
            }
            records.forEach(function(r) {
                if (!ctxMatch(r)) return;
                // 主考試 (Row 2 metadata) - v1.6.162: 用 wuMatches 雙軌制 match
                if (r.wrongUnits && Array.isArray(r.wrongUnits)) {
                    var exactMatched = r.wrongUnits.some(wuMatches);
                    // v1.6.162: looseMatch 只對「name 部分」做 (新格式的 vol prefix 不參與 loose match)
                    var looseMatched = !exactMatched && unitName.length >= 4 && r.wrongUnits.some(function(wu) {
                        var s = splitVolName(wu);
                        // loose match 僅看 name 部分; 且若 vol 已知, 須符合
                        if (vol && s.vol && s.vol !== vol) return false;
                        return looseMatch(s.name, unitName);
                    });
                    if ((exactMatched || looseMatched) && r.total > 0) rates.push(r.correct / r.total);
                }
                // 額外考卷 (chip 區) — 用同一個 ctx 過濾
                // v1.6.160 FIX: 改成跟 ctxMatch 一致的嚴格邏輯 — 只檢查查詢端 truthy
                // 之前 `e.subject && sub && ...` 三段都需要 record 端也有欄位才過濾
                // 但 extraExam 物件不存 typeName/instanceName，導致 instanceName 過濾永遠不生效
                // 結果: extraExam 會跨 instance 亂 match unit (例: 「全4冊統測」會 match 任何 instance 的同名 unit)
                if (r.extraExams && Array.isArray(r.extraExams)) {
                    r.extraExams.forEach(function(e) {
                        if (sub && e.subject !== sub) return;
                        if (typeName && e.typeName !== typeName) return;
                        if (instanceName && e.instanceName !== instanceName) return;
                        var exactMatch = e.name && e.name === unitName;
                        var looseMatchOk = !exactMatch && unitName.length >= 4 && e.name && looseMatch(e.name, unitName);
                        if ((exactMatch || looseMatchOk) && e.total > 0) {
                            rates.push(e.correct / e.total);
                        }
                    });
                }
            });
            if (rates.length === 0) return null;
            var sum = 0;
            for (var i = 0; i < rates.length; i++) sum += rates[i];
            return sum / rates.length;
        }
        // v1.5.206: 計算某 unit 的排程天數 (從 plan.grid 找此 unit 的不同日期數)
        function getUnitScheduledDays(unitId) {
            if (!unitId || !Array.isArray(appPlans)) return 0;
            var days = new Set();
            appPlans.forEach(function(plan) {
                if (!plan.grid) return;
                Object.keys(plan.grid).forEach(function(dStr) {
                    (plan.grid[dStr] || []).forEach(function(t) {
                        if (t && t.unitId === unitId) days.add(dStr);
                    });
                });
            });
            return days.size;
        }
        // v1.5.158: 取教材庫所有 unit + 記錄中出現過的 unit (合併去重)
        function getAllUnitsForFilter() {
            var set = new Set();
            // 教材庫的 unit
            Object.keys(appMaster || {}).forEach(function(sub) {
                var s = appMaster[sub];
                if (!s || !s.materials) return;
                Object.keys(s.materials).forEach(function(tName) {
                    var t = s.materials[tName];
                    if (!t || !Array.isArray(t.instances)) return;
                    t.instances.forEach(function(inst) {
                        if (inst.vols) {
                            (inst.volOrder || Object.keys(inst.vols)).forEach(function(vol) {
                                (inst.vols[vol] || []).forEach(function(u) {
                                    if (u.name) set.add(u.name);
                                });
                            });
                        }
                        if (Array.isArray(inst.units)) {
                            inst.units.forEach(function(u) { if (u.name) set.add(u.name); });
                        }
                    });
                });
            });
            // 記錄中出現過的 unit
            var records = loadAccuracyRecords();
            // v1.6.162: 收集時剝掉「vol|」prefix, 避免 set 內同時有「L1~2」跟「第三冊|L1~2」
            function _splitName(u) {
                var i = u && u.indexOf('|');
                return (i > 0) ? u.substring(i + 1) : u;
            }
            records.forEach(function(r) {
                (r.wrongUnits || []).forEach(function(u) { set.add(_splitName(u)); });
            });
            return Array.from(set);
        }
        function renderAccuracyStats() {
            var container = el('accuracy-root');
            if (!container) return;
            var records = loadAccuracyRecords();
            var subjects = getAccuracySubjects();
            var html = '';
            // ===== 輸入表單 =====
            // v1.5.198: Row 1 + Row 2 (樹狀圖跳轉區) 加 #CAE9E0 底色
            html += '<div class="accuracy-form">';
            html += '<h3 style="margin-top:0; color:var(--primary);">📝 新增答對率記錄</h3>';
            html += '<div class="accuracy-main-section">';
            // v1.5.194: 四個下拉選單 grid 4 欄同一排 (科目 / 教材類型 / 教材版本 / 單元名稱)
            html += '<div class="form-row accuracy-row-4col">';
            html += '<div class="accuracy-cell"><label>科目</label><select id="acc-subject" onchange="accOnSubjectChange()"><option value="">--選擇--</option>';
            subjects.forEach(function(s) { html += '<option value="' + escapeHtml(s) + '">' + escapeHtml(s) + '</option>'; });
            html += '</select></div>';
            html += '<div class="accuracy-cell"><label>教材類型</label><select id="acc-type" onchange="accOnTypeChange()" disabled><option value="">--先選科目--</option></select></div>';
            html += '<div class="accuracy-cell"><label>教材版本</label><select id="acc-instance" onchange="accOnInstanceChange()" disabled><option value="">--先選類型--</option></select></div>';
            html += '<div class="accuracy-cell"><label>單元名稱</label><select id="acc-unit" onchange="accOnUnitChange()" disabled><option value="">--先選教材版本--</option></select></div>';
            html += '</div>';
            // v1.5.194: 第二行 [總題數] [答對題數] [完成日期]
            html += '<div class="form-row">';
            html += '<label>總題數</label>';
            html += '<input type="number" id="acc-total" min="1" style="width:80px;" placeholder="例:50">';
            html += '<label>答對題數</label>';
            html += '<input type="number" id="acc-correct" min="0" style="width:80px;" placeholder="例:42">';
            html += '<label>完成日期</label>';
            html += '<input type="date" id="acc-date" style="width:140px;">';
            html += '</div>';
            html += '</div>';  // close accuracy-main-section (Row 1 + Row 2 區, #CAE9E0 底色)
            // v1.5.198: 「手動新增考卷」清單, grid 6 欄, 科目必填 (取消「限主考卷」預設)
            html += '<div class="accuracy-exams-section">';
            html += '<label style="font-weight:bold; color:var(--secondary); margin-bottom:6px;">手動新增考卷:</label>';
            html += '<div class="form-row accuracy-exam-input-row">';
            html += '<select id="acc-exam-subject" class="accuracy-exam-sel"><option value="">(請選擇)</option>';
            subjects.forEach(function(s) { html += '<option value="' + escapeHtml(s) + '">' + escapeHtml(s) + '</option>'; });
            html += '</select>';
            html += '<input type="text" id="acc-exam-name" placeholder="考卷名稱 (例:隨堂考)" style="width:130px;">';
            html += '<input type="text" id="acc-exam-range" placeholder="範圍 (例:P.5-10)" style="width:130px;">';
            html += '<input type="number" id="acc-exam-total" min="1" placeholder="總題數" style="width:80px;">';
            html += '<input type="number" id="acc-exam-correct" min="0" placeholder="答對題數" style="width:80px;">';
            html += '<input type="date" id="acc-exam-date" style="width:140px;">';
            html += '<button type="button" class="btn-outline" style="font-size:0.8em; padding:4px 10px; white-space:nowrap;" onclick="accAddExtraExam()">＋ 加入</button>';
            html += '</div>';
            html += '<div id="acc-extra-exams" style="margin:8px 0 10px 0;"></div>';
            html += '</div>';
            html += '<div style="text-align:right;">';
            html += '<button type="button" class="btn-primary" onclick="accSaveRecord()">💾 儲存記錄</button>';
            html += '</div>';
            html += '</div>';
            // ===== 篩選器 (v1.5.195: 1 行, 加排序 dropdown, 縮短寬度, 刪「改任...」) =====
            html += '<div class="accuracy-filter">';
            html += '<div class="form-row accuracy-filter-row">';
            html += '<label>科目</label>';
            html += '<select id="acc-filter-subject" class="accuracy-filter-sel" onchange="accOnFilterChange()"><option value="__ALL__">全部</option>';
            subjects.forEach(function(s) { html += '<option value="' + escapeHtml(s) + '">' + escapeHtml(s) + '</option>'; });
            html += '</select>';
            html += '<label>教材類型</label>';
            html += '<select id="acc-filter-type" class="accuracy-filter-sel" onchange="accOnFilterChange()"><option value="__ALL__">全部</option>';
            var allTypes = new Set();
            subjects.forEach(function(sub) {
                Object.keys((appMaster[sub] || {}).materials || {}).forEach(function(t) { allTypes.add(t); });
            });
            Array.from(allTypes).forEach(function(t) { html += '<option value="' + escapeHtml(t) + '">' + escapeHtml(t) + '</option>'; });
            html += '</select>';
            html += '<label>單元</label>';
            html += '<select id="acc-filter-unit" class="accuracy-filter-sel" onchange="accOnFilterChange()"><option value="__ALL__">全部</option>';
            var allUnits = getAllUnitsForFilter();
            allUnits.forEach(function(u) { html += '<option value="' + escapeHtml(u) + '">' + escapeHtml(u) + '</option>'; });
            html += '</select>';
            html += '<label>排序</label>';
            html += '<select id="acc-filter-sort" class="accuracy-filter-sel" onchange="accOnFilterChange()">';
            html += '<option value="rate">依正確率高低</option>';
            html += '<option value="date">依日期新舊</option>';
            html += '</select>';
            html += '</div>';
            html += '</div>';
            // ===== 篩選 + 排序 + 總表 =====
            var fSub = window._accFilters.subject;
            var fType = window._accFilters.typeName;
            var fUnit = window._accFilters.unit;
            var filtered = records.filter(function(r) {
                if (fSub !== '__ALL__' && r.subject !== fSub) return false;
                if (fType !== '__ALL__' && r.typeName !== fType) return false;
                if (fUnit !== '__ALL__') {
                    if (!r.wrongUnits || !Array.isArray(r.wrongUnits)) return false;
                    // v1.6.162: 雙軌制 filter — 接受「純 name」或「vol|name」任一格式
                    var _matched = r.wrongUnits.some(function(wu) {
                        var i = wu && wu.indexOf('|');
                        var name = (i > 0) ? wu.substring(i + 1) : wu;
                        return name === fUnit;
                    });
                    if (!_matched) return false;
                }
                return true;
            });
            // v1.5.195: 排序依 acc-filter-sort 選項 (依正確率高低 / 依日期新舊)
            var sortMode = (window._accFilters.sort || 'rate');
            if (sortMode === 'date') {
                // 日期 DESC (新→舊), 同日期按答對率 DESC
                filtered.sort(function(a, b) {
                    if (a.date !== b.date) return (b.date || '').localeCompare(a.date || '');
                    var ra = a.total > 0 ? (a.correct / a.total) : 0;
                    var rb = b.total > 0 ? (b.correct / b.total) : 0;
                    return rb - ra;
                });
            } else {
                // 預設依正確率 DESC
                filtered.sort(function(a, b) {
                    var ra = a.total > 0 ? (a.correct / a.total) : 0;
                    var rb = b.total > 0 ? (b.correct / b.total) : 0;
                    return rb - ra;
                });
            }
            if (filtered.length === 0) {
                html += '<div style="text-align:center; color:var(--secondary); padding:20px;">';
                html += records.length === 0 ? '尚無答對率記錄' : '目前篩選無記錄';
                html += '</div>';
            } else {
                html += '<h3 style="color:var(--primary); margin-bottom:10px;">📊 答對率總表 (共 ' + filtered.length + ' 筆)</h3>';
                // v1.5.206: colgroup 設寬度, 答對率欄加大 (18%), 操作欄縮窄 (6%)
                html += '<div class="accuracy-table-wrapper"><table class="accuracy-table"><colgroup>';
                html += '<col style="width:8%"><col style="width:7%"><col style="width:10%"><col style="width:9%"><col style="width:8%"><col style="width:5%"><col style="width:5%"><col style="width:16%"><col style="width:12%"><col style="width:6%">';
                html += '</colgroup><thead><tr>';
                html += '<th>日期</th><th>科目</th><th>教材類型</th><th>教材版本</th><th>冊數</th><th>總題數</th><th>答對</th><th>答對率</th><th>單元名稱</th><th>操作</th>';
                html += '</tr></thead><tbody>';
                filtered.forEach(function(r) {
                    var origIdx = records.indexOf(r);
                    var rate = r.total > 0 ? (r.correct / r.total * 100) : 0;
                    var rateColor = rate >= 96 ? '#27ae60' : (rate >= 90 ? '#f59e0b' : '#ef4444');
                    var barColor = rateColor;
                    // v1.5.203: 高亮該 unit (#F3B8B1 醒目提示)
                    // v1.6.162: 雙軌制 — highlightedUnitName 可能是「name」或「vol|name」
                    //           比對時只看 wrongUnit 的「name 部分」
                    var isHighlighted = false;
                    if (window._highlightedUnitName && r.wrongUnits && Array.isArray(r.wrongUnits)) {
                        var _hi = window._highlightedUnitName;
                        var _hiName = (function() {
                            var i = _hi.indexOf('|');
                            return (i > 0) ? _hi.substring(i + 1) : _hi;
                        })();
                        isHighlighted = r.wrongUnits.some(function(wu) {
                            var i = wu && wu.indexOf('|');
                            var n = (i > 0) ? wu.substring(i + 1) : wu;
                            return n === _hiName;
                        });
                    }
                    var rowStyle = isHighlighted ? ' style="background:#F3B8B1;"' : '';
                    html += '<tr' + rowStyle + '>';
                    html += '<td>' + (r.date || '-') + '</td>';
                    html += '<td>' + escapeHtml(r.subject || '') + '</td>';
                    html += '<td>' + escapeHtml(r.typeName || '') + '</td>';
                    html += '<td>' + escapeHtml(r.instanceName || '') + '</td>';
                    // v1.6.163: 冊數欄 — 從 wrongUnits 第一個取出 vol 標籤,沒有就顯示 '-'
                    var _volTag = '-';
                    if (r.wrongUnits && r.wrongUnits.length > 0) {
                        var _firstWu = r.wrongUnits[0];
                        var _vi = _firstWu && _firstWu.indexOf('|');
                        if (_vi > 0) _volTag = _firstWu.substring(0, _vi);
                    }
                    html += '<td>' + escapeHtml(_volTag) + '</td>';
                    html += '<td>' + r.total + '</td>';
                    html += '<td>' + r.correct + '</td>';
                    html += '<td>';
                    html += '<div class="accuracy-bar"><div class="accuracy-bar-fill" style="width:' + rate + '%; --bar-color:' + barColor + ';"></div><span class="accuracy-bar-text" style="position:absolute; left:50%; top:50%; transform:translate(-50%,-50%); color:#00814A; font-weight:bold; font-size:0.9em; pointer-events:none; white-space:nowrap;">' + rate.toFixed(1) + '%</span></div>';
                    html += '</td>';
                    // v1.6.162: 顯示時剝掉「vol|」prefix — 表格只顯示乾淨的 name, vol 資訊不混淆
                    // v1.6.165: 改成「vol unit」格式 (有 vol 時加前綴), 沒 vol 時保持原樣
                    //          這樣使用者可以一眼看出「這個 L1~3 是屬於哪一冊」
                    var _displayUnits = r.wrongUnits && r.wrongUnits.length > 0
                        ? r.wrongUnits.map(function(wu) {
                            if (!wu) return '';
                            var i = wu.indexOf('|');
                            return (i > 0) ? (wu.substring(0, i) + ' ' + wu.substring(i + 1)) : wu;
                        })
                        : [];
                    html += '<td>' + (_displayUnits.length > 0 ? _displayUnits.map(escapeHtml).join(', ') : '-') + '</td>';
                    html += '<td style="white-space:nowrap;">';
                    // v1.5.209: 編輯按鈕 #99D6EA, 刪除按鈕 #A4303F
                    html += '<button type="button" onclick="accEditRecord(' + origIdx + ')" title="編輯" style="background:#99D6EA; color:#333; border:none; padding:4px 8px; border-radius:4px; cursor:pointer; font-size:0.8em; margin-right:4px;">✏️</button>';
                    // v1.5.209: 刪除按鈕 #A4303F
                    html += '<button type="button" onclick="accDeleteRecord(' + origIdx + ')" title="刪除" style="background:#A4303F; color:white; border:none; padding:4px 8px; border-radius:4px; cursor:pointer; font-size:0.8em;">🗑</button>';
                    html += '</td>';
                    html += '</tr>';
                });
                html += '</tbody></table></div>';
                // 統計摘要
                var totalCorrect = filtered.reduce(function(s, r) { return s + (r.correct || 0); }, 0);
                var totalQuestions = filtered.reduce(function(s, r) { return s + (r.total || 0); }, 0);
                var overallRate = totalQuestions > 0 ? (totalCorrect / totalQuestions * 100) : 0;
                var overallColor = overallRate >= 96 ? '#27ae60' : (overallRate >= 90 ? '#f59e0b' : '#ef4444');
                var summaryLabel = (fSub !== '__ALL__' || fType !== '__ALL__' || fUnit !== '__ALL__') ? '(篩選後)' : '(全部)';
                html += '<div style="margin-top:16px; padding:12px; background:#f0f8ff; border-radius:8px; border:1px solid var(--border);">';
                html += '<strong>📈 總答對率 ' + summaryLabel + ': ' + totalCorrect + '/' + totalQuestions + ' = <span style="color:' + overallColor + '; font-size:1.2em;">' + overallRate.toFixed(1) + '%</span></strong>';
                html += '</div>';
            }
            container.innerHTML = html;
            // 設定今天日期
            var dateInput = el('acc-date');
            if (dateInput) dateInput.value = new Date().toISOString().slice(0, 10);
            // 套用 filter dropdown 狀態
            setTimeout(function() {
                if (el('acc-filter-subject')) el('acc-filter-subject').value = window._accFilters.subject;
                if (el('acc-filter-type')) el('acc-filter-type').value = window._accFilters.typeName;
                if (el('acc-filter-unit')) el('acc-filter-unit').value = window._accFilters.unit;
            }, 0);
            accRenderExtraExams();
        }
        function accOnSubjectChange() {
            var sub = el('acc-subject').value;
            var typeSel = el('acc-type');
            var instSel = el('acc-instance');
            var unitSel = el('acc-unit');
            if (!sub) {
                typeSel.innerHTML = '<option value="">--先選科目--</option>';
                typeSel.disabled = true;
                instSel.innerHTML = '<option value="">--先選類型--</option>';
                instSel.disabled = true;
                unitSel.innerHTML = '<option value="">--先選教材版本--</option>';
                unitSel.disabled = true;
                return;
            }
            var types = getAccuracyMaterialTypes(sub);
            typeSel.innerHTML = '<option value="">--選擇--</option>' + types.map(function(t) { return '<option value="' + escapeHtml(t) + '">' + escapeHtml(t) + '</option>'; }).join('');
            typeSel.disabled = false;
            instSel.innerHTML = '<option value="">--先選類型--</option>';
            instSel.disabled = true;
            unitSel.innerHTML = '<option value="">--先選教材版本--</option>';
            unitSel.disabled = true;
        }
        function accOnTypeChange() {
            var sub = el('acc-subject').value;
            var typeName = el('acc-type').value;
            var instSel = el('acc-instance');
            var unitSel = el('acc-unit');
            if (!sub || !typeName) {
                instSel.innerHTML = '<option value="">--先選類型--</option>';
                instSel.disabled = true;
                unitSel.innerHTML = '<option value="">--先選教材版本--</option>';
                unitSel.disabled = true;
                return;
            }
            var insts = getAccuracyInstances(sub, typeName);
            instSel.innerHTML = '<option value="">--選擇--</option>' + insts.map(function(i) { return '<option value="' + i.id + '">' + escapeHtml(i.name) + '</option>'; }).join('');
            instSel.disabled = false;
            unitSel.innerHTML = '<option value="">--先選教材版本--</option>';
            unitSel.disabled = true;
        }
        function accOnInstanceChange() {
            var sub = el('acc-subject').value;
            var typeName = el('acc-type').value;
            var instId = el('acc-instance').value;
            var unitSel = el('acc-unit');
            if (!sub || !typeName || !instId) {
                unitSel.innerHTML = '<option value="">--先選教材版本--</option>';
                unitSel.disabled = true;
                return;
            }
            var units = getAccuracyUnits(sub, typeName, instId);
            unitSel.innerHTML = '<option value="">--選擇--</option>' + units.map(function(u) { return '<option value="' + escapeHtml(u) + '">' + escapeHtml(u) + '</option>'; }).join('');
            unitSel.disabled = false;
        }
        function accOnUnitChange() {
            // v1.5.194: dropdown 選了直接加 chip (取代原本「+加入」按鈕)
            var unitSel = el('acc-unit');
            var unitName = unitSel.value;
            if (!unitName) return;
            if (window._accWrongUnits.indexOf(unitName) >= 0) {
                unitSel.value = '';
                return;
            }
            window._accWrongUnits.push(unitName);
            accRenderExtraExams();
            unitSel.value = '';  // reset 準備下次選
        }
        // v1.5.198: 加入額外考卷 (grid 6 欄, 科目必填, 取消「限主考卷」)
        function accAddExtraExam() {
            var name = (el('acc-exam-name').value || '').trim();
            var range = (el('acc-exam-range').value || '').trim();
            var total = parseInt(el('acc-exam-total').value, 10);
            var correct = parseInt(el('acc-exam-correct').value, 10);
            var date = el('acc-exam-date').value;
            var subjSel = el('acc-exam-subject');
            var subject = subjSel ? subjSel.value : '';
            if (!subject) return alert('請選擇科目!');
            if (!name) return alert('請輸入考卷名稱!');
            if (isNaN(total) || total < 1) return alert('請輸入總題數!');
            if (isNaN(correct) || correct < 0) return alert('請輸入答對題數!');
            if (correct > total) return alert('答對題數不能大於總題數!');
            if (!date) return alert('請選擇完成日期!');
            // v1.6.160 FIX: 從主表單 instance dropdown 抓 typeName/instanceName/id,一起存進 extraExam
            // 這樣 getUnitAccuracyRate 渲染時才能正確過濾
            var mainTypeName = el('acc-type').value || '';
            var mainInstSel = el('acc-instance');
            var mainInstId = mainInstSel ? mainInstSel.value : '';
            var mainInstName = mainInstId ? ((mainInstSel.options[mainInstSel.selectedIndex] || {}).text || '') : '';
            window._accExtraExams.push({
                subject: subject,
                typeName: mainTypeName,
                instanceId: mainInstId,
                instanceName: mainInstName,
                name: name,
                range: range,
                total: total,
                correct: correct,
                date: date
            });
            // 清空輸入 (科目 dropdown 回到「請選擇」)
            el('acc-exam-subject').value = '';
            el('acc-exam-name').value = '';
            el('acc-exam-range').value = '';
            el('acc-exam-total').value = '';
            el('acc-exam-correct').value = '';
            el('acc-exam-date').value = '';
            accRenderExtraExams();
        }
        function accRemoveExtraExam(idx) {
            window._accExtraExams.splice(idx, 1);
            accRenderExtraExams();
        }
        // v1.5.196: 改顯示考卷清單 (顯示科目/考卷名稱/範圍/總題數/答對/完成日期)
        function accRenderExtraExams() {
            var container = el('acc-extra-exams');
            if (!container) return;
            if (!window._accExtraExams || window._accExtraExams.length === 0) {
                container.innerHTML = '<span style="color:#94a3b8; font-size:0.85em;">(尚無額外考卷)</span>';
                return;
            }
            container.innerHTML = window._accExtraExams.map(function(e, idx) {
                var rate = e.total > 0 ? (e.correct / e.total * 100).toFixed(1) : '-';
                var subj = e.subject ? e.subject + ' / ' : '';
                return '<div class="accuracy-extra-exam-chip">'
                    + '<span class="exam-subject">' + escapeHtml(subj) + '</span>'
                    + '<span class="exam-name">' + escapeHtml(e.name || '-') + '</span>'
                    + '<span class="exam-range">' + escapeHtml(e.range || '-') + '</span>'
                    + '<span class="exam-rate">' + e.correct + '/' + e.total + ' (' + rate + '%)</span>'
                    + '<span class="exam-date">' + escapeHtml(e.date || '-') + '</span>'
                    + '<button type="button" class="exam-remove" onclick="accRemoveExtraExam(' + idx + ')" title="移除此考卷">移除</button>'
                    + '</div>';
            }).join('');
        }
        function accSaveRecord() {
            var sub = el('acc-subject').value;
            var typeName = el('acc-type').value;
            var instSel = el('acc-instance');
            var instId = instSel.value;
            var instName = instId ? (instSel.options[instSel.selectedIndex] || {}).text : '';
            var total = parseInt(el('acc-total').value, 10);
            var correct = parseInt(el('acc-correct').value, 10);
            var date = el('acc-date').value;
            if (!sub) return alert('請選擇科目!');
            if (!typeName) return alert('請選擇教材類型!');
            if (!instId) return alert('請選擇教材版本!');
            if (!total || total < 1) return alert('請填入總題數!');
            if (isNaN(correct) || correct < 0) return alert('請填入答對題數!');
            if (correct > total) return alert('答對題數不能大於總題數!');
            if (!date) return alert('請選擇日期!');
            var records = loadAccuracyRecords();
            var record;
            var extraExams = (window._accExtraExams || []).slice();
            if (window._editingRecordId) {
                // 編輯模式: 覆蓋原 record (保留原本 id)
                record = {
                    id: window._editingRecordId,
                    date: date,
                    subject: sub,
                    typeName: typeName,
                    instanceId: instId,
                    instanceName: instName,
                    total: total,
                    correct: correct,
                    wrongUnits: (window._accWrongUnits || []).slice(),  // 向後相容舊 records
                    extraExams: extraExams
                };
                records[window._editingRecordIdx] = record;
            } else {
                // 新增模式
                record = {
                    id: 'acc_' + genId(),
                    date: date,
                    subject: sub,
                    typeName: typeName,
                    instanceId: instId,
                    instanceName: instName,
                    total: total,
                    correct: correct,
                    wrongUnits: (window._accWrongUnits || []).slice(),  // 向後相容
                    extraExams: extraExams
                };
                records.push(record);
            }
            saveAccuracyRecords(records);
            // 重置編輯狀態
            window._editingRecordId = null;
            window._editingRecordIdx = null;
            window._accWrongUnits = [];
            window._accExtraExams = [];
            renderAccuracyStats();
        }
        // v1.5.195: 編輯模式 — 把 record 載入 form, 儲存時覆蓋原 record
        function accEditRecord(idx) {
            var records = loadAccuracyRecords();
            if (idx < 0 || idx >= records.length) return;
            var r = records[idx];
            window._editingRecordId = r.id;
            window._editingRecordIdx = idx;
            window._accWrongUnits = (r.wrongUnits || []).slice();
            window._accExtraExams = (r.extraExams || []).slice();
            // 設 dropdowns (trigger cascade)
            var subSel = el('acc-subject');
            subSel.value = r.subject || '';
            accOnSubjectChange();
            var typeSel = el('acc-type');
            if (r.typeName) typeSel.value = r.typeName;
            accOnTypeChange();
            var instSel = el('acc-instance');
            if (r.instanceId) instSel.value = r.instanceId;
            accOnInstanceChange();
            // 設值
            el('acc-total').value = r.total || '';
            el('acc-correct').value = r.correct || '';
            el('acc-date').value = r.date || '';
            // 改儲存按鈕為「更新」+ 顯示「取消編輯」
            var saveBtn = document.querySelector('.accuracy-form .btn-primary');
            if (saveBtn) saveBtn.innerHTML = '💾 更新';
            if (!document.getElementById('acc-cancel-edit')) {
                var cancelBtn = document.createElement('button');
                cancelBtn.id = 'acc-cancel-edit';
                cancelBtn.type = 'button';
                cancelBtn.className = 'btn-outline';
                cancelBtn.style.cssText = 'font-size:0.8em; padding:4px 10px; margin-right:8px;';
                cancelBtn.textContent = '❌ 取消編輯';
                cancelBtn.onclick = accCancelEdit;
                saveBtn.parentNode.insertBefore(cancelBtn, saveBtn);
            }
            accRenderExtraExams();
            // 滾動到表單
            var form = document.querySelector('.accuracy-form');
            if (form) form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        function accCancelEdit() {
            window._editingRecordId = null;
            window._editingRecordIdx = null;
            window._accWrongUnits = [];
            window._accExtraExams = [];
            el('acc-subject').value = '';
            accOnSubjectChange();
            el('acc-total').value = '';
            el('acc-correct').value = '';
            el('acc-date').value = '';
            var saveBtn = document.querySelector('.accuracy-form .btn-primary');
            if (saveBtn) saveBtn.innerHTML = '💾 儲存記錄';
            var cancelBtn = document.getElementById('acc-cancel-edit');
            if (cancelBtn) cancelBtn.remove();
            accRenderExtraExams();
            renderAccuracyStats();
        }
        function accDeleteRecord(idx) {
            var records = loadAccuracyRecords();
            if (idx >= 0 && idx < records.length) {
                records.splice(idx, 1);
                saveAccuracyRecords(records);
                renderAccuracyStats();
            }
        }
        function accOnFilterChange() {
            window._accFilters.subject = el('acc-filter-subject').value;
            window._accFilters.typeName = el('acc-filter-type').value;
            window._accFilters.unit = el('acc-filter-unit').value;
            window._accFilters.sort = el('acc-filter-sort') ? el('acc-filter-sort').value : 'rate';
            renderAccuracyStats();
        }
        // v1.5.164: 月曆事件管理 (events)
        var STORAGE_KEY_EVENTS_PREFIX = 'StudyMap_PlanEvents_V164_';
        function getCurrentEventsPlanId() {
            var sel = el('planner-selector');
            if (sel && sel.value) return sel.value;
            if (appPlans && appPlans.length > 0) return appPlans[appPlans.length - 1].id;
            return null;
        }
        function loadPlanEvents(planId) {
            if (!planId) return [];
            var raw = localStorage.getItem(STORAGE_KEY_EVENTS_PREFIX + planId);
            if (!raw) return [];
            try { return JSON.parse(raw) || []; } catch(e) { return []; }
        }
        function savePlanEvents(planId, events) {
            if (!planId) return;
            try { localStorage.setItem(STORAGE_KEY_EVENTS_PREFIX + planId, JSON.stringify(events)); }
            catch(e) { showSaveErrorToast(e); }
        }
        function getPlanEvents() {
            var pid = getCurrentEventsPlanId();
            return loadPlanEvents(pid);
        }
        function savePlanEventsNow(events) {
            var pid = getCurrentEventsPlanId();
            savePlanEvents(pid, events);
        }
        function openEventsModal(defaultDate) {
            var existing = el('modal-events');
            if (existing) existing.remove();
            var modal = document.createElement('div');
            modal.id = 'modal-events';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3400';
            modal.style.display = 'flex';
            modal.innerHTML = '<div class="modal-content" style="max-width: 720px;">' +
                '<div class="modal-header"><h2>📌 月曆事件管理</h2><button type="button" class="close-btn" onclick="document.getElementById(\'modal-events\').remove()">&times;</button></div>' +
                '<div style="padding: 16px;">' +
                    '<div style="background:#fef3c7; border:1px solid #fde047; border-radius:8px; padding:10px; margin-bottom:14px; font-size:0.85em; color:#92400e;">' +
                        '💡 事件優先序最高，可設置考試/活動等。Default 時數 0 = 整天不能讀書。' +
                    '</div>' +
                    '<h3 style="margin-top:0;">📝 新增事件</h3>' +
                    '<div class="form-row">' +
                        '<label>日期</label>' +
                        '<input type="date" id="ev-date" value="' + (defaultDate || new Date().toISOString().slice(0,10)) + '">' +
                    '</div>' +
                    '<div class="form-row">' +
                        '<label>名稱</label>' +
                        '<input type="text" id="ev-name" placeholder="例：模模考、校外活動">' +
                    '</div>' +
                    '<div class="form-row">' +
                        '<label>類型</label>' +
                        '<input type="text" id="ev-type" placeholder="例：exam、activity、reminder">' +
                    '</div>' +
                    '<div class="form-row">' +
                        '<label>可讀書時數</label>' +
                        '<input type="number" id="ev-hours" value="0" min="0" max="24" step="0.5" style="width:80px;">' +
                        '<small style="color:#7f8c8d;">default 0 (整天不能讀書)</small>' +
                    '</div>' +
                    '<div class="form-row">' +
                        '<label>備註</label>' +
                        '<input type="text" id="ev-note" placeholder="選填">' +
                    '</div>' +
                    '<div style="text-align:right; margin-top:8px;">' +
                        '<button type="button" class="btn-primary" onclick="savePlanEventFromModal()">💾 儲存事件</button>' +
                    '</div>' +
                    '<hr style="margin: 20px 0;">' +
                    '<h3>📋 現有事件</h3>' +
                    '<div id="ev-list"></div>' +
                '</div>' +
            '</div>';
            document.body.appendChild(modal);
            renderPlanEventList();
        }
        function renderPlanEventList() {
            var container = el('ev-list');
            if (!container) return;
            var events = getPlanEvents();
            if (events.length === 0) {
                container.innerHTML = '<div style="color:#94a3b8; font-size:0.85em; padding:8px;">尚無事件</div>';
                return;
            }
            // 按日期排序
            events.sort(function(a, b) { return a.date.localeCompare(b.date); });
            var html = '<table class="accuracy-table" style="width:100%;"><thead><tr>' +
                '<th>日期</th><th>名稱</th><th>類型</th><th>時數</th><th>備註</th><th>操作</th>' +
                '</tr></thead><tbody>';
            events.forEach(function(ev, idx) {
                var hoursText = ev.hours === 0 ? '<span style="color:#ef4444;">0hr</span>' : ev.hours + 'hr';
                var typeText = ev.type ? ev.type : '-';
                var noteText = ev.note ? ev.note : '-';
                html += '<tr>' +
                    '<td>' + ev.date + '</td>' +
                    '<td><b>' + escapeHtml(ev.name) + '</b></td>' +
                    '<td>' + escapeHtml(typeText) + '</td>' +
                    '<td>' + hoursText + '</td>' +
                    '<td style="font-size:0.85em; color:#7f8c8d;">' + escapeHtml(noteText) + '</td>' +
                    '<td><button type="button" onclick="deletePlanEvent(\'' + ev.id + '\')" style="background:#ef4444; color:white; border:none; padding:3px 7px; border-radius:4px; cursor:pointer; font-size:0.8em;">🗑</button></td>' +
                    '</tr>';
            });
            html += '</tbody></table>';
            container.innerHTML = html;
        }
        function savePlanEventFromModal() {
            var date = el('ev-date').value;
            var name = el('ev-name').value.trim();
            var type = el('ev-type').value.trim();
            var hours = Number(el('ev-hours').value);
            var note = el('ev-note').value.trim();
            if (!date) return alert('請選擇日期!');
            if (!name) return alert('請輸入名稱!');
            if (isNaN(hours)) return alert('時數格式錯誤!');
            var ev = {
                id: 'evt_' + genId(),
                date: date,
                name: name,
                type: type,
                hours: hours,
                note: note
            };
            var events = getPlanEvents();
            events.push(ev);
            savePlanEventsNow(events);
            el('ev-name').value = '';
            el('ev-note').value = '';
            renderPlanEventList();
            renderCalendar();
        }
        function deletePlanEvent(id) {
            var events = getPlanEvents();
            events = events.filter(function(e) { return e.id !== id; });
            savePlanEventsNow(events);
            renderPlanEventList();
            renderCalendar();
        }
        function renderHistoryTable() {
            var todayStr = getLocalDateString(new Date());
            var sortedLogs = [...appLogs].sort((a, b) => new Date(b.date) - new Date(a.date));
            var tbody = el('history-tbody');
            var status = el('history-status');
            tbody.innerHTML = '';
            if (status) status.textContent = '載入中… 共 ' + sortedLogs.length + ' 筆';
            // v1.5.175: batchSize 50→10, 初次 render 更快, 之後續批補上
            var batchSize = 10;
            var idx = 0;
            function renderRow(log) {
                var isToday = log.date === todayStr;
                var detailText = log.detail || log.unitName || '';
                var pageStr = (log.start && log.end && log.start !== log.end) ? 'P.' + log.start + '~' + log.end : (log.start ? 'P.' + log.start : '-');
                var colorClass = log.category === '🔄 系統重排' ? 'history-category-sys' : (log.category === '🗓️ 計畫管理' ? 'history-category-mgmt' : 'history-category-default');
                var tr = document.createElement('tr');
                // v1.5.174: className 取代 inline style (Safari layout 加速)
                if (isToday) tr.className = 'history-row-today';
                tr.innerHTML = '<td>' + log.date + '</td>' +
                    '<td class="history-category ' + colorClass + '">' + log.category + '</td>' +
                    '<td>' + (log.subject || '') + '</td>' +
                    '<td class="history-detail">' + detailText + '</td>' +
                    '<td>' + pageStr + '</td>' +
                    '<td>' + (log.pages || 0) + ' 頁</td>' +
                    '<td>' +
                        '<button class="btn-warning" style="padding:4px 8px; margin-bottom:4px;" title="編輯" onclick="openEditLog(\'' + log.id + '\')">✏️</button>' +
                        '<button class="btn-danger" style="padding:4px 8px;" title="刪除" onclick="deleteLog(\'' + log.id + '\')"></button>' +
                    '</td>';
                return tr;
            }
            function renderBatch() {
                var end = Math.min(idx + batchSize, sortedLogs.length);
                var frag = document.createDocumentFragment();
                for (var i = idx; i < end; i++) {
                    frag.appendChild(renderRow(sortedLogs[i]));
                }
                tbody.appendChild(frag);
                idx = end;
                if (status) status.textContent = '已載入 ' + idx + ' / ' + sortedLogs.length + ' 筆';
                if (idx < sortedLogs.length) {
                    requestAnimationFrame(renderBatch);
                } else if (status) {
                    status.textContent = '✅ 共 ' + sortedLogs.length + ' 筆歷史紀錄';
                }
            }
            renderBatch();
        }
        function deleteLog(id) { 
            if (confirm('確定刪除此紀錄？')) { 
                if (id.startsWith('cal_')) {
                    var taskId = id.replace('cal_', '');
                    appPlans.forEach(p => {
                        Object.keys(p.grid).forEach(dateStr => {
                            var t = p.grid[dateStr].find(task => task.id === taskId);
                            if (t) {
                                t.isDone = false;
                            }
                        });
                    });
                }
                
                appLogs = appLogs.filter(l => l.id !== id); 
                saveToLocal(); 
                renderHistoryTable(); 
                renderDashboard(); 
                if (el('page-planner') && el('page-planner').style.display === 'block') renderCalendar();
            } 
        }
        function openEditLog(id) {
            var log = appLogs.find(l => l.id === id);
            if(!log) return;
            el('edit-log-id').value = log.id;
            el('edit-log-date').value = log.date;
            el('edit-log-subject').value = log.subject || '';
            el('edit-log-unitname').value = log.detail || log.unitName || ''; 
            el('edit-log-start').value = log.start || 0;
            el('edit-log-end').value = log.end || 0;
            openModal('modal-edit-log');
        }
        function saveLogEdit() {
            var id = el('edit-log-id').value;
            var log = appLogs.find(l => l.id === id);
            if (!log) return;
            
            var oldDate = log.date;
            log.date = el('edit-log-date').value;
            log.subject = el('edit-log-subject').value;
            
            var newText = el('edit-log-unitname').value;
            log.unitName = newText;
            log.detail = newText; 
            
            log.start = Number(el('edit-log-start').value) || 0;
            log.end = Number(el('edit-log-end').value) || 0;
            log.pages = log.end >= log.start ? (log.end - log.start + 1) : 1;
            if (log.id.startsWith('cal_')) {
                var taskId = log.id.replace('cal_', '');
                appPlans.forEach(p => {
                    if (p.grid[oldDate]) {
                        var tIdx = p.grid[oldDate].findIndex(t => t.id === taskId);
                        if (tIdx > -1) {
                            var t = p.grid[oldDate][tIdx];
                            t.subject = log.subject;
                            t.unitName = log.unitName;
                            
                            var textStr = `[${log.subject}] ${log.unitName}`;
                            if (log.start && log.end && log.start !== log.end) textStr += ` P.${log.start}~${log.end}`;
                            else if (log.start && log.start === log.end) textStr += ` P.${log.start}`;
                            
                            var isReminder = t.text.includes('🔔');
                            if (isReminder) textStr = '🔔 ' + textStr;
                            t.text = textStr;
                            t.startPage = log.start;
                            t.endPage = log.end;
                            
                            if (oldDate !== log.date) {
                                p.grid[oldDate].splice(tIdx, 1);
                                if(!p.grid[log.date]) p.grid[log.date] = [];
                                p.grid[log.date].push(t);
                            }
                        }
                    }
                });
            }
            
            appLogs.sort((a, b) => new Date(b.date) - new Date(a.date)); 
            saveToLocal();
            closeModal('modal-edit-log');
            renderHistoryTable();
            renderDashboard();
            if(el('page-planner') && el('page-planner').style.display === 'block') renderCalendar();
        }
        // 同步所有大分類與任務的下拉式選單
        function syncAllCatMisDropdowns(newCatValue = null, newMisValue = null) {
            var activeCat = newCatValue || (el('pane-master').classList.contains('active') ? el('master-set-cat').value : el('set-cat').value);
            var activeMis = newMisValue || (el('pane-master').classList.contains('active') ? el('master-set-mis').value : el('set-mis').value);
            populateSelect('master-set-cat', Object.keys(appMissions), activeCat);
            populateSelect('set-cat', Object.keys(appMissions), activeCat);
            
            if (activeCat && appMissions[activeCat]) {
                populateSelect('master-set-mis', Object.keys(appMissions[activeCat]), activeMis);
                populateSelect('set-mis', Object.keys(appMissions[activeCat]), activeMis);
            } else {
                populateSelect('master-set-mis', []);
                populateSelect('set-mis', []);
            }
        }
        function openSettings() {
            showPage('page-settings');
            populateSelect('master-set-cat', Object.keys(appMissions));
            // v1.5.8: 先讀當前 cat 的教材
            onMasterSetCatChange();
            // v1.5.2: 確保每個 subject 都有 materials 欄位 (defensive)
            Object.keys(appMaster).forEach(function(s) {
                if (!appMaster[s].materials) appMaster[s].materials = {};
            });
            populateMasterTypeDropdown();
            renderMasterEditor();
            populateSelect('set-cat', Object.keys(appMissions));
            onSetCatChange();
        }
        function switchTab(tabId) { 
            if(el('pane-master') && el('pane-master').classList.contains('active')) extractCurrentEditorData(); 
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active')); 
            document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active')); 
            if(el('btn-tab-' + tabId)) el('btn-tab-' + tabId).classList.add('active'); 
            if(el('pane-' + tabId)) el('pane-' + tabId).classList.add('active'); 
            if(tabId === 'mission') renderMissionCheckboxes(); 
            // v1.5.58: history tab 切換時自動 render 表格
            if(tabId === 'history' && typeof renderHistoryTable === 'function') renderHistoryTable(); 
        }
        
        function extractCurrentEditorData() {
            var sub = lastMasterSub || el('master-subject').value;
            if(!sub || !appMaster[sub]) { return; }
            function extractData(containerId) {
                var container = document.getElementById(containerId);
                if (!container) return [];
                var rows = container.querySelectorAll('.setting-unit-row');
                var data = [];
                for(var i=0; i<rows.length; i++) {
                    var s = Number(rows[i].querySelector('.cfg-start').value);
                    var e = Number(rows[i].querySelector('.cfg-end').value);
                    if(s && e && s > e) { var temp = s; s = e; e = temp; }
                    data.push({
                        id: rows[i].dataset.uid,
                        name: rows[i].querySelector('.cfg-name').value || '未命名',
                        start: s||'',
                        end: e||''
                    });
                }
                return data;
            }
            // v1.5.2: 根據 instance 決定存哪裡 (不再用 layer)
            var data = getCurrentInstanceData();
            if (!data) { window.isMasterDirty = false; return; }
            var target = data.instance;
            if (target.type === 'custom') {
                target.units = extractData('cfg-list-custom');
            } else {
                var newVolOrder = [];
                var groups = document.querySelectorAll('#master-editor-root .vol-group');
                groups.forEach(g => {
                    var volName = g.dataset.vol;
                    newVolOrder.push(volName);
                    if(document.getElementById('cfg-list-'+volName)) {
                        target.vols[volName] = extractData('cfg-list-'+volName);
                    }
                });
                target.volOrder = newVolOrder;
            }
            window.isMasterDirty = false;
        }
        function handleMasterSubjectChange(opts) {
            opts = opts || {};
            let sel = el('master-subject');
            if (window.isMasterDirty && !opts.skipDirtyCheck) {
                if (!confirm("⚠️ 您的設定尚未儲存！\n確定要切換科目嗎？\n(按「確定」將放棄變更，按「取消」可留在此畫面儲存)")) {
                    sel.value = lastMasterSub;
                    return;
                }
            }
            window.isMasterDirty = false;
            // v1.5.2: 重新 populate Material Type dropdown
            populateMasterTypeDropdown();
            // v1.5.0: skipLoadUnits 參數 - wizard 內新增分類時不預填既有單元
            window._skipLoadUnits = opts.skipLoadUnits;
            renderMasterEditor();
            window._skipLoadUnits = false;
        }
        // v1.5.1: 教材層 dropdown populate
        // v1.5.2: populate Material Type dropdown (5 個預設)
        function populateMasterTypeDropdown() {
            var sub = el('master-subject').value;
            var typeSel = el('master-type');
            if (!typeSel || !sub) return;
            typeSel.innerHTML = '';
            var subject = appMaster[sub];
            var materials = (subject && subject.materials) ? subject.materials : {};
            Object.keys(materials).forEach(function(typeName) {
                var typeObj = materials[typeName];
                typeSel.innerHTML += '<option value="' + escapeHtml(typeName) + '">📁 ' + escapeHtml(typeName) + '</option>';
            });
            // 預設選第一個
            var firstType = Object.keys(materials)[0];
            if (firstType) {
                typeSel.value = firstType;
                populateMasterInstanceDropdown(firstType);
            }
        }
        // v1.5.2: populate Instance dropdown (依 type)
        function populateMasterInstanceDropdown(typeName) {
            if (!typeName) {
                typeName = el('master-type').value;
            }
            var instSel = el('master-instance');
            if (!instSel) return;
            instSel.innerHTML = '';
            var sub = el('master-subject').value;
            if (!sub || !typeName) return;
            var subject = appMaster[sub];
            var typeObj = subject && subject.materials && subject.materials[typeName];
            if (!typeObj) {
                instSel.innerHTML += '<option value="" disabled>-- 請先選教材類型 --</option>';
                return;
            }
            var instances = typeObj.instances || [];
            instances.forEach(function(ins) {
                instSel.innerHTML += '<option value="' + escapeHtml(ins.id) + '">📖 ' + escapeHtml(ins.name) + '</option>';
            });
            if (instances.length === 0) {
                instSel.innerHTML += '<option value="" disabled>-- 無教材, 請按下方「➕ 新增教材」--</option>';
            }
        }
        function onMasterTypeChange() {
            // 先存上一個 type 內的編輯
            if (window.isMasterDirty) {
                extractCurrentEditorData();
            }
            window.isMasterDirty = false;
            populateMasterInstanceDropdown();
            renderMasterEditor();
        }
        function onMasterInstanceChange() {
            if (window.isMasterDirty) {
                extractCurrentEditorData();
            }
            window.isMasterDirty = false;
            renderMasterEditor();
        }
        // v1.5.2: 取得目前選的 instance 資料
        function getCurrentInstanceData() {
            var sub = el('master-subject').value;
            var typeName = el('master-type').value;
            var instId = el('master-instance').value;
            if (!sub || !typeName || !instId) return null;
            var subject = appMaster[sub];
            if (!subject || !subject.materials) return null;
            var typeObj = subject.materials[typeName];
            if (!typeObj) return null;
            var instance = (typeObj.instances || []).find(function(i) { return i.id === instId; });
            if (!instance) return null;
            return { subject: sub, typeName: typeName, instance: instance, typeObj: typeObj };
        }
        // v1.5.8 補丁: 教材科目 CRUD (v1.5.2 之後 onclick 還在但 function 沒了)
        function addMasterSubject() {
            openInputModal('➕ 新增教材科目', '', function(subName) {
                if (!subName) return;
                if (appMaster[subName]) return alert('已存在！');
                extractCurrentEditorData();
                appMaster[subName] = { materials: {} };
                populateSelect('master-subject', Object.keys(appMaster), subName);
                // v1.5.17: 直接 saveToLocal, 不依賴手動「💾 儲存教材庫變更」按鈕
                saveToLocal();
                renderMasterEditor();
            });
        }
        function renameMasterSubject() {
            var sub = el('master-subject').value;
            if (!sub) return alert('請先選擇科目！');
            openInputModal('✏️ 編輯科目名稱', sub, function(newName) {
                if (newName === sub) return;
                if (!newName) return;
                if (appMaster[newName]) return alert('已存在！');
                extractCurrentEditorData();
                appMaster[newName] = appMaster[sub];
                delete appMaster[sub];
                appLogs.forEach(l => { if (l.subject === sub) l.subject = newName; });
                populateSelect('master-subject', Object.keys(appMaster), newName);
                // v1.5.17: 直接 saveToLocal
                saveToLocal();
                renderMasterEditor();
            });
        }
        function deleteMasterSubject() {
            var sub = el('master-subject').value;
            if (!sub) return;
            // v1.5.17: 改用 custom modal (Safari 會擋 native confirm)
            openChoiceModal(
                '⚠️ 刪除科目',
                '您確定要刪除科目「' + sub + '」嗎？\n\n警告：執行此動作會導致該科目底下所有的進度規劃、單元設定與歷史關聯全部遺失，確定要繼續嗎？',
                '🗑️ 確定刪除',
                '取消',
                function() {
                    extractCurrentEditorData();
                    delete appMaster[sub];
                    populateSelect('master-subject', Object.keys(appMaster));
                    saveToLocal();
                    renderMasterEditor();
                },
                function() { /* 取消 */ }
            );
        }
        function scrollMasterVolumes(direction) {
            const container = document.getElementById('master-volumes-container');
            if (!container) return;
            const groups = Array.from(container.querySelectorAll('.vol-group'));
            if (groups.length === 0) return;
            if (direction === 'first') {
                groups[0].scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                return;
            }
            let containerCenter = container.getBoundingClientRect().left + container.clientWidth / 2;
            let closestIdx = 0;
            let minDiff = Infinity;
            
            groups.forEach((g, idx) => {
                let rect = g.getBoundingClientRect();
                let center = rect.left + rect.width / 2;
                let diff = Math.abs(center - containerCenter);
                if (diff < minDiff) { 
                    minDiff = diff; 
                    closestIdx = idx; 
                }
            });
            let targetIdx = closestIdx + direction;
            if (targetIdx < 0) targetIdx = 0;
            if (targetIdx >= groups.length) targetIdx = groups.length - 1;
            groups[targetIdx].scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
        }
        // v1.5.8: Volume CRUD (instance.type === 'volume' 才會 render vol-group)
        function addMasterVolume(afterVolName = null) {
            var data = getCurrentInstanceData();
            if (!data) return alert('請先選擇教材！');
            var instance = data.instance;
            if (instance.type !== 'volume') return alert('這個教材不是分冊類型！');
            openInputModal('➕ 新增冊次名稱', '', function(volName) {
                if (!volName) return;
                if (instance.vols[volName]) return alert('已存在！');
                extractCurrentEditorData();
                instance.vols[volName] = [];
                if (!instance.volOrder) instance.volOrder = Object.keys(instance.vols);
                if (afterVolName && typeof afterVolName === 'string') {
                    let idx = instance.volOrder.indexOf(afterVolName);
                    if (idx !== -1) instance.volOrder.splice(idx + 1, 0, volName);
                    else instance.volOrder.push(volName);
                } else {
                    instance.volOrder.push(volName);
                }
                window.isMasterDirty = true;
                renderMasterEditor();
            });
        }
        function renameMasterVolume(oldVolName) {
            var data = getCurrentInstanceData();
            if (!data) return alert('請先選擇教材！');
            var instance = data.instance;
            openInputModal('✏️ 編輯冊次', oldVolName, function(newVolName) {
                if (newVolName === oldVolName) return;
                if (!newVolName) return;
                if (instance.vols[newVolName]) return alert('已存在！');
                extractCurrentEditorData();
                instance.vols[newVolName] = instance.vols[oldVolName];
                delete instance.vols[oldVolName];
                if (instance.volOrder) {
                    var idx = instance.volOrder.indexOf(oldVolName);
                    if (idx !== -1) instance.volOrder[idx] = newVolName;
                }
                appLogs.forEach(l => { if (l.subject === data.subject && l.volume === oldVolName) l.volume = newVolName; });
                window.isMasterDirty = true;
                renderMasterEditor();
            });
        }
        function deleteMasterVolume(volName) {
            var data = getCurrentInstanceData();
            if (!data) return alert('請先選擇教材！');
            var instance = data.instance;
            if (!confirm('⚠️ 您確定要刪除冊次「' + volName + '」嗎？\n\n警告：執行此動作將會導致該冊底下所有的進度規畫與相關歷史紀錄遺失，請再三確認！')) return;
            extractCurrentEditorData();
            delete instance.vols[volName];
            if (instance.volOrder) instance.volOrder = instance.volOrder.filter(v => v !== volName);
            window.isMasterDirty = true;
            renderMasterEditor();
        }
        // v1.5.2: CRUD for Material Type
        function addMaterialType() {
            var sub = el('master-subject').value;
            if (!sub) return alert('請先選擇科目！');
            openInputModal('➕ 新增教材類型', '', function(name) {
                if (!name) return;
                var subject = appMaster[sub];
                if (!subject.materials) subject.materials = {};
                if (subject.materials[name]) return alert('已存在！');
                subject.materials[name] = { id: 'mt_' + genId(), name: name, instances: [] };
                // v1.5.17: 直接 saveToLocal
                saveToLocal();
                populateMasterTypeDropdown();
                el('master-type').value = name;
                populateMasterInstanceDropdown(name);
                renderMasterEditor();
            });
        }
        function renameMaterialType() {
            var sub = el('master-subject').value;
            var typeName = el('master-type').value;
            if (!sub) return alert('請先選擇科目！');
            if (!typeName) return alert('請先選擇教材類型！');
            openInputModal('✏️ 編輯教材類型名稱', typeName, function(newName) {
                if (newName === typeName) return;
                if (!newName) return;
                var subject = appMaster[sub];
                if (subject.materials[newName]) return alert('已存在！');
                subject.materials[newName] = subject.materials[typeName];
                subject.materials[newName].name = newName;
                delete subject.materials[typeName];
                // v1.5.17: 直接 saveToLocal
                saveToLocal();
                populateMasterTypeDropdown();
                el('master-type').value = newName;
                renderMasterEditor();
            });
        }
        function deleteMaterialType() {
            var sub = el('master-subject').value;
            var typeName = el('master-type').value;
            if (!sub) return alert('請先選擇科目！');
            if (!typeName) return alert('請先選擇教材類型！');
            var subject = appMaster[sub];
            var typeObj = subject.materials[typeName];
            if (!typeObj) return alert('找不到該類型！');
            var instCount = (typeObj.instances || []).length;
            var msg = "確定刪除教材類型「" + typeName + "」?\n";
            if (instCount > 0) msg += "底下有 " + instCount + " 個教材 instance 也會被刪掉。\n";
            // v1.5.17: 改用 custom modal
            openChoiceModal(
                '🗑️ 刪除教材類型',
                msg,
                '🗑️ 確定刪除',
                '取消',
                function() {
                    delete subject.materials[typeName];
                    // v1.6.138: 記下使用者明確刪除的 type, 避免下次啟動被自動 repair 回來
                    var usr = multiData[currentUserId];
                    if (usr) {
                        if (!usr._deletedTypes) usr._deletedTypes = {};
                        if (!usr._deletedTypes[appCurrentCat]) usr._deletedTypes[appCurrentCat] = {};
                        if (!usr._deletedTypes[appCurrentCat][sub]) usr._deletedTypes[appCurrentCat][sub] = [];
                        if (usr._deletedTypes[appCurrentCat][sub].indexOf(typeName) < 0) {
                            usr._deletedTypes[appCurrentCat][sub].push(typeName);
                        }
                    }
                    saveToLocal();
                    populateMasterTypeDropdown();
                    renderMasterEditor();
                },
                function() { /* 取消 */ }
            );
        }
        // v1.5.2: CRUD for Instance
        function addInstance() {
            var sub = el('master-subject').value;
            var typeName = el('master-type').value;
            if (!sub) return alert('請先選擇科目！');
            if (!typeName) return alert('請先選擇教材類型！');
            openInputModal('➕ 新增教材名 Instance', '', function(name) {
                if (!name) return;
                var subject = appMaster[sub];
                var typeObj = subject.materials[typeName];
                if (typeObj.instances.some(function(i) { return i.name === name; })) return alert('已存在！');
                // v1.5.17: 改用 custom modal (Safari 會擋 native confirm)
                openChoiceModal(
                    '📚 教材結構選擇',
                    '「' + name + '」需要「分冊」結構嗎？\n\n\n• 分冊 → 可以設定 第一冊 / 第二冊 ... 每冊有多個單元\n• 不分冊 → 直接設定單元 (例如 第一回 / 第二回)',
                    '📚 分冊 (volume)',
                    '📄 不分冊 (custom)',
                    function() { // 按 分冊
                        typeObj.instances.push({
                            id: 'ins_' + genId(),
                            name: name,
                            alias: name,  // v1.5.157: 預設簡稱 = 完整名
                            type: 'volume',
                            units: null,
                            vols: { '第一冊': [] },
                            volOrder: ['第一冊']
                        });
                        saveToLocal();
                        populateMasterInstanceDropdown(typeName);
                        el('master-instance').value = typeObj.instances[typeObj.instances.length - 1].id;
                        renderMasterEditor();
                    },
                    function() { // 按 不分冊
                        typeObj.instances.push({
                            id: 'ins_' + genId(),
                            name: name,
                            alias: name,  // v1.5.157: 預設簡稱 = 完整名
                            type: 'custom',
                            units: [],
                            vols: null,
                            volOrder: null
                        });
                        saveToLocal();
                        populateMasterInstanceDropdown(typeName);
                        el('master-instance').value = typeObj.instances[typeObj.instances.length - 1].id;
                        renderMasterEditor();
                    }
                );
            });
        }
        // v1.5.155: 合併 modal 改名稱 + 簡稱 (方案 A)
        function editInstance() {
            var data = getCurrentInstanceData();
            if (!data) return alert('請先選擇教材！');
            var inst = data.instance;
            openInstanceEditModal(inst, data.typeObj, data.typeName);
        }
        function openInstanceEditModal(inst, typeObj, typeName) {
            // v1.5.155: 兩個輸入框 (名稱 + 簡稱)
            var existing = el('modal-instance-edit');
            if (existing) existing.remove();
            var modal = document.createElement('div');
            modal.id = 'modal-instance-edit';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3400';
            modal.style.display = 'flex';
            modal.innerHTML = '<div class="modal-content" style="max-width: 480px;">' +
                '<div class="modal-header"><h2>✏️ 編輯教材</h2><button type="button" class="close-btn" onclick="document.getElementById(\'modal-instance-edit\').remove()">&times;</button></div>' +
                '<div style="padding: 20px;">' +
                    '<div class="form-group">' +
                        '<label>教材名稱</label>' +
                        '<input type="text" id="inst-edit-name" value="' + escapeHtml(inst.name) + '" placeholder="例：麻辣" style="width:100%; padding:8px; font-size:1.05em;">' +
                    '</div>' +
                    '<div class="form-group" style="margin-top:12px;">' +
                        '<label>簡稱 (用於月曆顯示及列印格式)</label>' +
                        '<input type="text" id="inst-edit-alias" value="' + escapeHtml(inst.alias || inst.name || '') + '" placeholder="預設=教材名稱" style="width:100%; padding:8px; font-size:1.05em;">' +
                        '<small style="color:#7f8c8d;">預設=教材名稱完整名 (可改短如「麻」「114」)</small>' +
                    '</div>' +
                '</div>' +
                '<div style="text-align: right; margin-top: 20px;">' +
                    '<button type="button" class="btn-outline" style="margin-right:10px;" onclick="document.getElementById(\'modal-instance-edit\').remove()">取消</button>' +
                    '<button type="button" class="btn-primary" onclick="saveInstanceEdit(\'' + inst.id + '\', \'' + typeName + '\')">✓ 儲存</button>' +
                '</div>' +
            '</div>';
            document.body.appendChild(modal);
            setTimeout(() => el('inst-edit-name').focus(), 100);
        }
        function saveInstanceEdit(instId, typeName) {
            var data = getCurrentInstanceData();
            if (!data) return;
            var newName = el('inst-edit-name').value.trim();
            var newAlias = el('inst-edit-alias').value.trim();
            if (!newName) return alert('教材名稱不能為空！');
            // v1.5.155: 檢查名稱重複 (排除自己)
            if (data.typeObj.instances.some(function(i) { return i.id !== instId && i.name === newName; })) {
                return alert('已存在同名教材！');
            }
            data.instance.name = newName;
            // v1.5.157: alias 改用戶輸入 (空字串 = fallback 到完整名稱)
            data.instance.alias = newAlias || newName;
            el('modal-instance-edit').remove();
            saveToLocal();
            populateMasterInstanceDropdown(typeName);
            el('master-instance').value = data.instance.id;
            renderMasterEditor();
        }
        function deleteInstance() {
            var data = getCurrentInstanceData();
            if (!data) return alert('請先選擇教材！');
            // v1.5.17: 改用 custom modal
            openChoiceModal(
                '🗑️ 刪除教材',
                '確定刪除教材「' + data.instance.name + '」?\n這個教材的單元資料會被刪掉。',
                '🗑️ 確定刪除',
                '取消',
                function() { // 確定刪除
                    data.typeObj.instances = data.typeObj.instances.filter(function(i) { return i.id !== data.instance.id; });
                    saveToLocal();
                    populateMasterInstanceDropdown(data.typeName);
                    renderMasterEditor();
                },
                function() { /* 取消, 什麼都不做 */ }
            );
        }
        function renderMasterEditor() {
            var sel = el('master-subject');
            var sub = sel ? sel.value : "";
            lastMasterSub = sub;
            window.isMasterDirty = false;
            var root = el('master-editor-root'); root.innerHTML = '';
            if(!sub) { root.innerHTML = '<div style="text-align:center; padding:20px; color:#95a5a6;">請先新增科目</div>'; return; }
            // v1.5.2: 根據 instance 決定 render 哪個資料
            var data = getCurrentInstanceData();
            if (!data) {
                root.innerHTML = '<div style="text-align:center; padding:20px; color:#95a5a6;">請選擇教材類型 + 教材名 Instance</div>';
                return;
            }
            var s = data.instance;
            // v1.5.151: 移到 if 之前 (custom 分支的 onclick 模板會用到)
            var isUB = isUnitBasedType(data.typeObj);
            if (s.type === 'custom') {
                root.innerHTML = '<div class="vol-title">✏️ 單元範圍設定 (可直接點選格子編輯)</div><div id="cfg-list-custom"></div><div style="margin-top:10px;"><button type="button" class="btn-outline" onclick="addSettingRow(\'cfg-list-custom\', null, ' + isUB + ')">➕ 新增單元</button></div>';
                if (!window._skipLoadUnits) {
                    (s.units || []).forEach(u => addSettingRow('cfg-list-custom', u, isUnitBasedType(data.typeObj)));
                } else {
                    addSettingRow('cfg-list-custom', null, isUnitBasedType(data.typeObj));
                }
            } else {
                var volsToRender = s.volOrder || Object.keys(s.vols);
                var html = '<div style="position: relative; padding-bottom: 45px;">';
                html += '<div id="master-volumes-container" class="horizontal-scroll" style="display: flex; gap: 15px; overflow-x: auto; padding-bottom: 15px; width: 100%; scroll-behavior: smooth;">';
                volsToRender.forEach(vol => {
                    var safeVol = vol.replace(/'/g, "\\'");
                    html += `<div class="vol-group" data-vol="${vol}" style="flex: 0 0 auto; min-width: 330px; margin-bottom: 0;">
                                <div class="vol-title" style="flex-wrap: wrap; gap: 8px;">
                                    <span>📚 ${vol}</span>
                                    <div style="display:flex; gap:5px; flex-wrap:wrap;">
                                        <button type="button" class="btn-outline" style="padding:4px 8px; font-size:0.85em;" onclick="addMasterVolume('${safeVol}')">➕ 往後新增</button>
                                        <button type="button" class="btn-warning" style="padding:4px 8px; font-size:0.85em;" onclick="renameMasterVolume('${safeVol}')">✏️ 編輯</button>
                                        <button type="button" class="btn-danger" style="padding:4px 8px; font-size:0.85em;" onclick="deleteMasterVolume('${safeVol}')"></button>
                                    </div>
                                </div>
                                <div id="cfg-list-${vol}"></div>
                                <div style="margin-top:10px;">
                                    <button type="button" class="btn-outline" onclick="addSettingRow('cfg-list-${safeVol}', null, ${isUB})">➕ 新增單元</button>
                                </div>
                            </div>`;
                });
                html += '</div>';
                html += `<div style="position: absolute; bottom: 5px; right: 10px; display: flex; gap: 8px; z-index: 10;">
                            <button type="button" class="btn-primary" style="border-radius: 50%; width: 40px; height: 40px; padding: 0; box-shadow: 0 3px 6px rgba(0,0,0,0.3); font-size: 1.2em; display:flex; align-items:center; justify-content:center;" onclick="scrollMasterVolumes('first')" title="回到最前一冊">⏮️</button>
                            <button type="button" class="btn-primary" style="border-radius: 50%; width: 40px; height: 40px; padding: 0; box-shadow: 0 3px 6px rgba(0,0,0,0.3); font-size: 1.2em; display:flex; align-items:center; justify-content:center;" onclick="scrollMasterVolumes(-1)" title="移動至上一冊 (置中)">⬅️</button>
                            <button type="button" class="btn-primary" style="border-radius: 50%; width: 40px; height: 40px; padding: 0; box-shadow: 0 3px 6px rgba(0,0,0,0.3); font-size: 1.2em; display:flex; align-items:center; justify-content:center;" onclick="scrollMasterVolumes(1)" title="移動至下一冊 (置中)">➡️</button>
                        </div>`;
                html += '</div>';
                if(volsToRender.length === 0) {
                    html += '<div style="text-align:center; margin-top:20px;"><button type="button" class="btn-warning" onclick="addMasterVolume()">➕ 新增第一冊</button></div>';
                }
                root.innerHTML = html;
                setTimeout(() => {
                    if (!window._skipLoadUnits) {
                        volsToRender.forEach(vol => { (s.vols[vol] || []).forEach(u => addSettingRow('cfg-list-'+vol, u, isUB)); });
                    } else {
                        volsToRender.forEach(vol => { addSettingRow('cfg-list-'+vol, null, isUB); });
                    }
                }, 0);
            }
        }
        function addSettingRow(containerId, u, isUnitBased) { 
            if (!u) { u = { id: genId(), name: '', start: 1, end: 1 }; window.isMasterDirty = true; } 
            // v1.5.150: unit-based 預設 start/end = 1 (無頁碼)
            if (isUnitBased && (!u.start || !u.end)) { u.start = 1; u.end = 1; }
            var container = document.getElementById(containerId); 
            if(!container) return; 
            var div = document.createElement('div'); 
            div.className = 'setting-unit-row'; 
            div.dataset.uid = u.id; 
            // v1.5.150: unit-based 隱藏起註頁碼輸入, 用 hidden input 保存預設值
            if (isUnitBased) {
                div.innerHTML = `✏️ <input type="text" class="cfg-name" placeholder="單元名 (例如 第1回)" value="${u.name}" oninput="window.isMasterDirty=true;">
                            <input type="hidden" class="cfg-start" value="1">
                            <input type="hidden" class="cfg-end" value="1">
                            <small style="color:#888; font-size:0.85em; margin-left:5px;">(unit-based 無頁碼)</small>
                            <button type="button" class="btn-danger" onclick="this.parentElement.remove(); window.isMasterDirty=true;"></button>`; 
            } else {
                div.innerHTML = `✏️ <input type="text" class="cfg-name" placeholder="單元名" value="${u.name}" oninput="window.isMasterDirty=true;">
                            <span>起</span><input type="number" class="cfg-start" placeholder="頁碼" value="${u.start||''}" min="1" oninput="window.isMasterDirty=true;">
                            <span>迄</span><input type="number" class="cfg-end" placeholder="頁碼" value="${u.end||''}" min="1" oninput="window.isMasterDirty=true;">
                            <button type="button" class="btn-danger" onclick="this.parentElement.remove(); window.isMasterDirty=true;"></button>`; 
            }
            container.appendChild(div); 
        }
        function onMasterSetCatChange() {
            var cat = el('master-set-cat').value;
            // v1.5.8: 切換 appMaster 到選中的 cat 的教材庫
            var user = multiData[currentUserId];
            if (cat && user && user.masters && user.masters[cat]) {
                appMaster = user.masters[cat];
                appCurrentCat = cat;
            } else {
                appMaster = {};
                appCurrentCat = cat || '';
            }
            // 更新 mission dropdown
            if(!cat || !appMissions[cat]) {
                populateSelect('master-set-mis', []);
            } else {
                populateSelect('master-set-mis', Object.keys(appMissions[cat]));
            }
            // v1.5.8: 依新 cat 更新 subject dropdown + type/instance dropdowns
            populateSelect('master-subject', Object.keys(appMaster));
            populateMasterTypeDropdown();
            renderMasterEditor();
        }
        // v1.5.13: 更新 type filter dropdown (動態 scan appMaster 的 typeName)
        function _updateMisTypeFilterDropdown() {
            var typeFilter = el('mis-type-filter');
            if (!typeFilter) return;
            var currentTypes = {};
            Object.keys(appMaster || {}).forEach(function(subName) {
                var s = appMaster[subName];
                if (s && s.materials) {
                    Object.keys(s.materials).forEach(function(t) { currentTypes[t] = true; });
                }
            });
            var availableTypes = Object.keys(currentTypes);
            var previousVal = typeFilter.value;
            typeFilter.innerHTML = '<option value="ALL">🌟 全部顯示</option>';
            if (availableTypes.length === 0) {
                typeFilter.innerHTML += '<option value="" disabled>-- 當前分類還沒有教材類型 --</option>';
            }
            availableTypes.forEach(function(t) {
                typeFilter.innerHTML += '<option value="' + escapeHtml(t) + '">📁 ' + escapeHtml(t) + '</option>';
            });
            if (previousVal && (previousVal === 'ALL' || currentTypes[previousVal])) {
                typeFilter.value = previousVal;
            } else {
                typeFilter.value = 'ALL';
            }
        }
        function onSetCatChange() {
            var cat = el('set-cat').value;
            // v1.5.8: 切換 appMaster 到選中的 cat 的教材庫
            var user = multiData[currentUserId];
            if (cat && user && user.masters && user.masters[cat]) {
                appMaster = user.masters[cat];
                appCurrentCat = cat;
            } else {
                appMaster = {};
                appCurrentCat = cat || '';
            }
            // v1.5.13: 動態更新 type filter dropdown (不會再列出不存在的 type)
            _updateMisTypeFilterDropdown();
            if(!cat || !appMissions[cat]) {
                populateSelect('set-mis', []);
                renderMissionCheckboxes();
                return;
            }
            populateSelect('set-mis', Object.keys(appMissions[cat]));
            renderMissionCheckboxes();
        }
        function addCat() {
            openInputModal('➕ 新增大分類', '', function(name) {
                if(appMissions[name]) return alert('已存在！');
                appMissions[name] = {};
                // v1.5.8: 同步在 user.masters 加空殻
                var user = multiData[currentUserId];
                if (user) {
                    if (!user.masters) user.masters = {};
                    if (!user.masters[name]) user.masters[name] = {};
                }
                syncAllCatMisDropdowns(name, null);
                if(el('pane-master').classList.contains('active')) onMasterSetCatChange(); else onSetCatChange();
                updateFilters();
            });
        }
        // v1.5.0: 新增進度分類 wizard - 同時選教材科目, 開啟後單元保持空白
        function addCatWithSubject() {
            // populate subject dropdown with existing subjects
            var sel = el('add-cat-subject');
            var subjects = Object.keys(appMaster || {});
            if (subjects.length === 0) {
                // 沒有任何科目, 自動加一個預設 (v1.5.2 materials 架構)
                appMaster = appMaster || {};
                appMaster['新科目'] = { materials: {} };
                subjects = ['新科目'];
            }
            sel.innerHTML = subjects.map(s => `<option value="${s}">${s}</option>`).join('');
            el('add-cat-name').value = '';
            // focus 到名稱輸入框
            setTimeout(() => el('add-cat-name').focus(), 100);
            openModal('modal-add-cat');
        }
        // v1.5.0: 在 wizard 內 quick 新增科目
        function quickAddSubjectFromCatModal() {
            openInputModal('➕ 新增教材科目', '', function(subName) {
                if (appMaster[subName]) return alert('已存在！');
                if (!subName.trim()) return;
                // v1.5.2: 不再問分冊, 直接用 v1.5.2 materials 架構
                appMaster[subName] = { materials: {} };
                // 更新 wizard 內的 dropdown
                var sel = el('add-cat-subject');
                sel.innerHTML += `<option value="${subName}">${subName}</option>`;
                sel.value = subName;
                window.isMasterDirty = true;
            });
        }
        // v1.5.0: 確認新增分類 + 切換到新分類 + 教材科目
        function confirmAddCatWithSubject() {
            var name = el('add-cat-name').value.trim();
            var sub = el('add-cat-subject').value;
            if (!name) return alert('請輸入分類名稱！');
            if (!sub) return alert('請選擇教材科目！');
            if (appMissions[name]) return alert('已存在！');
            // 1. 建立分類
            appMissions[name] = {};
            // v1.6.95: 同步在 user.masters 加空殻 (避免儲存後新分類消失)
            var user = multiData[currentUserId];
            if (user) {
                if (!user.masters) user.masters = {};
                if (!user.masters[name]) user.masters[name] = {};
            }
            // 2. 關閉 modal
            closeModal('modal-add-cat');
            // 3. 切換大分類 dropdown 到新分類
            var catSel = el('master-set-cat');
            if (catSel) {
                catSel.innerHTML = '';
                Object.keys(appMissions).forEach(c => {
                    catSel.innerHTML += `<option value="${c}">${c}</option>`;
                });
                catSel.value = name;
                onMasterSetCatChange();
            }
            // 4. 切換教材科目 dropdown 到選的科目 (用現有的 handler, 但先清空單元)
            // 先記錄 user 選的科目, 然後切換
            var subSel = el('master-subject');
            if (subSel) {
                subSel.innerHTML = '';
                Object.keys(appMaster).forEach(s => {
                    subSel.innerHTML += `<option value="${s}">${s}</option>`;
                });
                subSel.value = sub;
                // 5. 強制讓 renderMasterEditor 不預填既有單元 (skipDirtyCheck: wizard 流程不彈 confirm)
                handleMasterSubjectChange({ skipLoadUnits: true, skipDirtyCheck: true });
            }
            // 6. 更新 filters
            updateFilters();
            // 7. 通知使用者
            alert('✅ 已新增分類「' + name + '」, 並切換到教材科目「' + sub + '」, 單元範圍保持空白, 請填入新內容。');
        }
        
        function renCat() {
            var activeCatId = el('pane-master').classList.contains('active') ? 'master-set-cat' : 'set-cat';
            var cat = el(activeCatId).value;
            if(!cat) return;
            openInputModal('✏️ 編輯大分類', cat, function(newName) {
                if(newName === cat) return;
                if(appMissions[newName]) return alert('已存在！');
                appMissions[newName] = appMissions[cat];
                delete appMissions[cat];
                // v1.5.8: 同步 rename masters[cat]
                var user = multiData[currentUserId];
                if (user && user.masters && user.masters[cat]) {
                    user.masters[newName] = user.masters[cat];
                    delete user.masters[cat];
                    if (appCurrentCat === cat) appCurrentCat = newName;
                    if (appMaster === user.masters[newName]) {
                        // appMaster reference 還是指 user.masters[newName], 不用換
                    }
                }
                appLogs.forEach(l => { if(l.category === cat) l.category = newName; });
                syncAllCatMisDropdowns(newName, null);
                if(el('pane-master').classList.contains('active')) onMasterSetCatChange(); else onSetCatChange();
                updateFilters();
            });
        }
        function delCat() {
            var activeCatId = el('pane-master').classList.contains('active') ? 'master-set-cat' : 'set-cat';
            var cat = el(activeCatId).value;
            if(!cat) return;
            var subjCount = (multiData[currentUserId] && multiData[currentUserId].masters && multiData[currentUserId].masters[cat]) ? Object.keys(multiData[currentUserId].masters[cat]).length : 0;
            var msg = '刪除分類「' + cat + '」？';
            if (subjCount > 0) msg += '\n底下有 ' + subjCount + ' 個 subject 教材也會被刪掉。';
            if(!confirm(msg)) return;
            delete appMissions[cat];
            appLogs = appLogs.filter(l => l.category !== cat);
            // v1.5.8: 同步刪 masters[cat]
            var user = multiData[currentUserId];
            if (user && user.masters && user.masters[cat]) {
                delete user.masters[cat];
                if (appCurrentCat === cat) {
                    // 切到第一個剩下的 cat
                    var remaining = Object.keys(user.masters);
                    appCurrentCat = remaining[0] || '';
                    appMaster = user.masters[appCurrentCat] || {};
                }
            }
            syncAllCatMisDropdowns(null, null);
            if(el('pane-master').classList.contains('active')) onMasterSetCatChange(); else onSetCatChange();
            updateFilters();
        }
        
        function addMis() { 
            var activeCatId = el('pane-master').classList.contains('active') ? 'master-set-cat' : 'set-cat';
            var cat = el(activeCatId).value; 
            if(!cat) return; 
            openInputModal('➕ 新增任務', '', function(name) { 
                if(appMissions[cat][name]) return alert('已存在！'); 
                appMissions[cat][name] = []; 
                syncAllCatMisDropdowns(cat, name);
                if(!el('pane-master').classList.contains('active')) renderMissionCheckboxes(); 
                updateFilters();
            }); 
        }
        
        function renMis() { 
            var activeCatId = el('pane-master').classList.contains('active') ? 'master-set-cat' : 'set-cat';
            var activeMisId = el('pane-master').classList.contains('active') ? 'master-set-mis' : 'set-mis';
            var cat = el(activeCatId).value; 
            var mis = el(activeMisId).value; 
            if(!cat || !mis) return; 
            openInputModal('✏️ 編輯任務', mis, function(newName) { 
                if(newName === mis) return; 
                if(appMissions[cat][newName]) return alert('已存在！'); 
                appMissions[cat][newName] = appMissions[cat][mis]; 
                delete appMissions[cat][mis]; 
                appLogs.forEach(l => { if(l.category === cat && l.mission === mis) l.mission = newName; }); 
                syncAllCatMisDropdowns(cat, newName);
                if(!el('pane-master').classList.contains('active')) renderMissionCheckboxes(); 
                updateFilters();
            }); 
        }
        
        function delMis() { 
            var activeCatId = el('pane-master').classList.contains('active') ? 'master-set-cat' : 'set-cat';
            var activeMisId = el('pane-master').classList.contains('active') ? 'master-set-mis' : 'set-mis';
            var cat = el(activeCatId).value; 
            var mis = el(activeMisId).value; 
            if(!cat || !mis) return; 
            if(confirm('刪除？')) { 
                delete appMissions[cat][mis]; 
                appLogs = appLogs.filter(l => !(l.category === cat && l.mission === mis)); 
                syncAllCatMisDropdowns(cat, null);
                if(!el('pane-master').classList.contains('active')) renderMissionCheckboxes(); 
                updateFilters();
            } 
        }
        
        function scrollMissionSubjects(direction) {
            const container = document.getElementById('mission-checkbox-root');
            if (container) {
                const scrollAmount = (container.clientWidth + 15) * direction;
                container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
            }
        }
        
        function scrollMissionToStart() {
            const container = document.getElementById('mission-checkbox-root');
            if (container) {
                container.scrollTo({ left: 0, behavior: 'smooth' });
            }
        }
        function renderMissionCheckboxes() {
            var cat = el('set-cat').value;
            var mis = el('set-mis').value;
            var root = el('mission-checkbox-root');
            // v1.5.13: 即使沒有 mission 也更新 type filter (使用 onSetCatChange 出的 helper)
            _updateMisTypeFilterDropdown();
            if(!cat || !mis) { root.innerHTML = '<div style="color:#95a5a6; padding:10px;">請選擇或建立專案。</div>'; return; }
            if(Object.keys(appMaster).length === 0) { root.innerHTML = '<div style="color:#e74c3c; padding:10px;">⚠️ 基本教材庫為空，請先新增單元！</div>'; return; }
            var selectedIds = appMissions[cat][mis] || [];
            var globalTypeFilter = el('mis-type-filter') ? el('mis-type-filter').value : 'ALL';
            root.style.display = 'flex';
            root.style.gap = '15px';
            root.style.scrollSnapType = 'x mandatory';
            var html = '';
            var subKeys = Object.keys(appMaster);
            subKeys = getSortedSubjects(subKeys);
            subKeys.forEach(sub => {
                var s = appMaster[sub];
                html += `<div style="flex: 0 0 calc(50% - 7.5px); scroll-snap-align: start; border: 1px solid var(--border); border-radius: 8px; background: #fff; overflow: hidden; display: flex; flex-direction: column;">`;
                html += `<div style="background: var(--primary); color: white; padding: 10px; text-align: center; font-weight: bold; font-size: 1.1em;">📘 ${sub}</div>`;
                html += `<div class="vertical-scroll" style="max-height: 380px; overflow-y: auto; padding: 12px;">`;
                if(s.type === 'custom') {
                    html += `<label style="display:block; margin-bottom:10px; border-bottom:1px solid #e2e8f0; padding-bottom:8px; color:var(--accent); cursor:pointer;"><input type="checkbox" class="vol-master-chk" data-vol="custom" onchange="toggleVolCheck(this, '${cat}', '${mis}', '${sub}', 'custom')" style="width:auto; margin-right:5px; transform:scale(1.2);"> <b>✅ 全選 / 取消全選</b></label>`;
                    s.units.forEach(u => {
                        var isChecked = selectedIds.includes(u.id) ? 'checked' : '';
                        html += `<label style="display:block; margin-bottom:8px; font-size:0.95em; cursor:pointer;"><input type="checkbox" value="${u.id}" ${isChecked} onchange="toggleMisUnit('${u.id}', this.checked, this)" data-vol="custom" style="width:auto; margin-right:5px;"> ${u.name} (P.${u.start}~${u.end})</label>`;
                    });
                } else if (s.materials) {
                    // v1.5.5 fix: 新架構 — 從 materials[*].instances[*] 收集 units
                    // v1.5.11: 用 typeName + instanceName 當 grouping key, label = 「typeName-instanceName」
                    // v1.5.18: 區分 volume 跟 custom — volume 顯示 冊名 + instance header, custom 顯示 typeName-instanceName
                    var matUnits = _collectSubjectUnits(s);
                    // v1.5.228: key 加 instanceName 區隔 (麻辣甲 vs 大滿貫甲 同 type 同 vol 不同 instance)
                    //            原 key 已是 typeName|vol (v1.5.147), 現在升級為 typeName|instanceName|vol
                    var byVol = {};
                    matUnits.forEach(function(u) {
                        var k = (u._typeName || '_') + '|' + (u._instanceName || '_inst') + '|' + (u.vol || '_single');
                        if (!byVol[k]) byVol[k] = {
                            units: [],
                            typeName: u._typeName || '',
                            instanceName: u._instanceName || '',
                            volName: u.vol || ''
                        };
                        byVol[k].units.push(u);
                    });
                    var anyShown = false;
                    var shownInstanceHeader = {}; // v1.5.18: 記錄 instance header 已顯示
                    Object.keys(byVol).forEach(function(key) {
                        var info = byVol[key];
                        // v1.5.11: 全域 type filter (預設 ALL = 全部顯示)
                        if (globalTypeFilter !== 'ALL' && info.typeName !== globalTypeFilter) return;
                        anyShown = true;
                        // v1.5.18 + v1.5.147: 區分 volume 跟 custom — v1.5.147 key 改為 typeName|volName
                        var keyParts = key.split('|');
                        var keyTypeName = keyParts[0];
                        // v1.5.228: key 改成 typeName|instanceName|vol, parts 重排
                        var keyInstanceName = keyParts[1] || '_inst';
                        var keyVolName = keyParts[2] || '_single';
                        var label;
                        var isVolume = (keyVolName !== '_single');
                        if (isVolume) {
                            // v1.5.228: label 改為「instanceName | volName」混合形式 (Denias 要求)
                            //            沒 instanceName 就只顯示 volName
                            var instPart = (keyInstanceName && keyInstanceName !== '_inst') ? keyInstanceName : '';
                            label = instPart ? (instPart + ' | ' + keyVolName) : keyVolName;
                        } else {
                            // custom: 維持 typeName-instanceName
                            label = info.typeName + (info.instanceName ? '-' + info.instanceName : '');
                        }
                        // v1.5.18: volume 第一冊 顯示 時 加 instance header (跟 教材庫 一致)
                        var instanceHeader = '';
                        if (isVolume) {
                            var insKey = info.typeName + '|' + info.instanceName;
                            if (!shownInstanceHeader[insKey]) {
                                instanceHeader = '<div style="margin-top:10px; margin-bottom:5px; font-weight:bold; color:var(--primary); font-size:1.05em; border-bottom:1px solid var(--border); padding-bottom:5px;">📦 ' + escapeHtml(info.typeName) + ' - ' + escapeHtml(info.instanceName) + '</div>';
                                shownInstanceHeader[insKey] = true;
                            }
                        }
                        html += instanceHeader;
                        // v1.5.228: 移除 📚 icon (Denias 要求)
                        html += `<label style="display:block; margin-bottom:8px; margin-top:12px; border-bottom:1px solid #e2e8f0; padding-bottom:8px; color:var(--accent); cursor:pointer;"><input type="checkbox" class="vol-master-chk" data-vol="${escapeHtml(keyVolName)}" onchange="toggleVolCheck(this, '${cat}', '${mis}', '${sub}', '${escapeHtml(keyVolName)}')" style="width:auto; margin-right:5px; transform:scale(1.2);"> <b>${escapeHtml(keyVolName)}</b></label>`;
                        html += `<div style="padding-left:15px;">`;
                        info.units.forEach(function(u) {
                            var isChecked = selectedIds.includes(u.id) ? 'checked' : '';
                            var pRange = (u.start || u.end) ? ' (P.' + (u.start||'?') + '~' + (u.end||'?') + ')' : '';
                            html += `<label style="display:block; margin-bottom:8px; font-size:0.95em; cursor:pointer;"><input type="checkbox" value="${u.id}" ${isChecked} onchange="toggleMisUnit('${u.id}', this.checked, this)" data-vol="${escapeHtml(keyVolName)}" style="width:auto; margin-right:5px;"> ${escapeHtml(u.name)}${pRange}</label>`;
                        });
                        html += `</div>`;
                    });
                    if (!anyShown && globalTypeFilter !== 'ALL') {
                        html += `<div style="color:#95a5a6; padding:10px; text-align:center; font-size:0.9em;">（沒有「${escapeHtml(globalTypeFilter)}」類型的教材）</div>`;
                    }
                } else {
                    var volsToRender = s.volOrder || Object.keys(s.vols);
                    volsToRender.forEach(vol => {
                        html += `<label style="display:block; margin-bottom:8px; margin-top:12px; border-bottom:1px solid #e2e8f0; padding-bottom:8px; color:var(--accent); cursor:pointer;"><input type="checkbox" class="vol-master-chk" data-vol="${vol}" onchange="toggleVolCheck(this, '${cat}', '${mis}', '${sub}', '${vol}')" style="width:auto; margin-right:5px; transform:scale(1.2);"> <b>📚 ${vol}</b></label>`;
                        html += `<div style="padding-left:15px;">`;
                        s.vols[vol].forEach(u => {
                            var isChecked = selectedIds.includes(u.id) ? 'checked' : '';
                            html += `<label style="display:block; margin-bottom:8px; font-size:0.95em; cursor:pointer;"><input type="checkbox" value="${u.id}" ${isChecked} onchange="toggleMisUnit('${u.id}', this.checked, this)" data-vol="${vol}" style="width:auto; margin-right:5px;"> ${u.name} (P.${u.start}~${u.end})</label>`;
                        });
                        html += `</div>`;
                    });
                }
                html += `</div></div>`;
            });
            root.innerHTML = html; 
            setTimeout(() => {
                var masterChks = root.querySelectorAll('.vol-master-chk');
                masterChks.forEach(chk => {
                    var vol = chk.dataset.vol;
                    var container = chk.closest('.vertical-scroll');
                    if (container) {
                        var units = container.querySelectorAll(`input[type="checkbox"][data-vol="${vol}"]:not(.vol-master-chk)`);
                        if (units.length > 0) {
                            var allChecked = Array.from(units).every(u => u.checked);
                            chk.checked = allChecked;
                        } else {
                            chk.checked = false;
                        }
                    }
                });
                // v1.5.232: sync top-level select-all when all vol-master-chk are checked
                var allVolChks = root.querySelectorAll('.vol-master-chk');
                var allVolsChecked = allVolChks.length > 0 && Array.from(allVolChks).every(c => c.checked);
                var topSel = root.querySelector('.select-all-chk');
                if (topSel) topSel.checked = allVolsChecked;
            }, 0);
        }
        function toggleVolCheck(elem, cat, mis, sub, vol) {
            var isChecked = elem.checked;
            var container = elem.closest('.vertical-scroll');
            if (container) {
                var checkboxes = container.querySelectorAll('input[type="checkbox"][data-vol="'+vol+'"]:not(.vol-master-chk)');
                checkboxes.forEach(cb => { cb.checked = isChecked; });
                // v1.5.237: 直接更新 missions array，不透過 toggleMisUnit（避免 cascade）
                var cat2 = el('set-cat').value;
                var mis2 = el('set-mis').value;
                if(cat2 && mis2 && appMissions[cat2] && appMissions[cat2][mis2]) {
                    var arr = appMissions[cat2][mis2];
                    if (isChecked) {
                        checkboxes.forEach(cb => { if(!arr.includes(cb.value)) arr.push(cb.value); });
                    } else {
                        checkboxes.forEach(cb => { var i = arr.indexOf(cb.value); if(i > -1) arr.splice(i, 1); });
                    }
                }
                // v1.5.237: 統一 sync vol-master（所有 units 已更新）
                var allUnits = container.querySelectorAll('input[type="checkbox"][data-vol="'+vol+'"]:not(.vol-master-chk)');
                var allChecked = allUnits.length > 0 && Array.from(allUnits).every(function(u){return u.checked;});
                var masterChk = container.querySelector('.vol-master-chk[data-vol="'+vol+'"]');
                if (masterChk) masterChk.checked = allChecked;
                // v1.5.237: sync top-level select-all
                var rootContainer = el('mission-checkbox-root');
                if (rootContainer) {
                    var allVolChks = rootContainer.querySelectorAll('.vol-master-chk');
                    var topAllChecked = allVolChks.length > 0 && Array.from(allVolChks).every(function(c){return c.checked;});
                    var topMaster = rootContainer.querySelector('.select-all-chk');
                    if (topMaster) topMaster.checked = topAllChecked;
                }
                saveToLocal();
                // v1.5.237 DEBUG
                console.log('[DEBUG toggleVolCheck] vol='+vol+' isChecked='+isChecked+' unitCount='+checkboxes.length+' allChecked='+allChecked);
                var dbg = rootContainer ? rootContainer.querySelectorAll('.vol-master-chk') : [];
                console.log('[DEBUG] totalVolMasters='+dbg.length+' allVolsChecked='+topAllChecked);
            }
        }
        function toggleMisUnit(unitId, isChecked, elem) {
            var cat = el('set-cat').value;
            var mis = el('set-mis').value;
            if(!cat || !mis) return;
            var arr = appMissions[cat][mis];
            if (isChecked && !arr.includes(unitId)) arr.push(unitId);
            else if (!isChecked) {
                var idx = arr.indexOf(unitId);
                if (idx > -1) arr.splice(idx, 1);
                // v1.5.232: uncheck 時同步把 plans 內所有 isDone task 改回 false
                // 這樣 unit 不會因為殘留的 isDone task 而錯誤顯示為已完成
                (appPlans || []).forEach(function(plan) {
                    if (!plan.grid) return;
                    Object.keys(plan.grid).forEach(function(dStr) {
                        var tasks = plan.grid[dStr];
                        if (!tasks) return;
                        for (var i = 0; i < tasks.length; i++) {
                            var t = tasks[i];
                            if (t && t.unitId === unitId && t.isDone) {
                                t.isDone = false;
                            }
                        }
                    });
                });
            }
            // v1.5.235: vol-master sync — use mission-checkbox-root directly (not .vertical-scroll)
            if (elem) {
                var vol = elem.dataset.vol;
                var root2 = el('mission-checkbox-root');
                if (root2) {
                    var allUnits = root2.querySelectorAll('input[type="checkbox"][data-vol="'+vol+'"]:not(.vol-master-chk)');
                    var allChecked = allUnits.length > 0 && Array.from(allUnits).every(function(u){return u.checked;});
                    var masterChk = root2.querySelector('.vol-master-chk[data-vol="'+vol+'"]');
                    if (masterChk) masterChk.checked = allChecked;
                }
            }
            // v1.5.232: sync top-level select-all when any child changes
            var rootContainer = el('mission-checkbox-root');
            if (rootContainer) {
                var allVolChks = rootContainer.querySelectorAll('.vol-master-chk');
                var topAllChecked = allVolChks.length > 0 && Array.from(allVolChks).every(function(c){return c.checked;});
                var topMaster = rootContainer.querySelector('.select-all-chk');
                if (topMaster) topMaster.checked = topAllChecked;
            }
            // v1.5.20: 立即 saveToLocal, 不依賴「💾 儲存教材庫變更」按鈕
            saveToLocal();
        }
        
        // v1.5.232: top-level 全選 — 勾選時等效勾選所有 unit，實作「全部勾選 / 取消全選」
        function toggleTopSelectAll(checked) {
            var root = el('mission-checkbox-root');
            if (!root) return;
            // 找出所有 unit checkbox（排除 vol-master-chk 和 select-all-chk 本身）
            var unitChks = root.querySelectorAll('input[type="checkbox"][data-vol]');
            unitChks.forEach(function(cb) {
                if (cb.classList.contains('vol-master-chk') || cb.classList.contains('select-all-chk')) return;
                if (cb.checked !== checked) {
                    cb.checked = checked;
                    // 直接改 missions 陣列，不透過 toggleMisUnit（避免重複 splice）
                    var unitId = cb.value;
                    var cat = el('set-cat').value;
                    var mis = el('set-mis').value;
                    if (!cat || !mis) return;
                    var arr = appMissions[cat][mis];
                    if (checked && !arr.includes(unitId)) arr.push(unitId);
                    else if (!checked) {
                        var idx = arr.indexOf(unitId);
                        if (idx > -1) arr.splice(idx, 1);
                    }
                }
            });
            // 同步所有 vol-master-chk
            var masterChks = root.querySelectorAll('.vol-master-chk');
            masterChks.forEach(function(mchk) {
                var vol = mchk.dataset.vol;
                var container = mchk.closest('.vertical-scroll');
                if (!container) return;
                var units = container.querySelectorAll('input[type="checkbox"][data-vol="${vol}"]:not(.vol-master-chk)');
                if (units.length > 0) {
                    var allChecked = Array.from(units).every(u => u.checked);
                    mchk.checked = allChecked;
                }
            });
            saveToLocal();
        }
        // v1.5.182: 診斷教材庫結構 (彈出 alert 顯示 trace)
        function dedupTraceAndShow() {
            var uid = currentUserId || Object.keys(multiData)[0];
            if (!uid) return alert('❌ 找不到用戶');
            // 暫存 console.log
            var logs = [];
            var origLog = console.log;
            var origError = console.error;
            console.log = function() {
                logs.push(Array.from(arguments).join(' '));
                origLog.apply(console, arguments);
            };
            console.error = function() {
                logs.push('[ERROR] ' + Array.from(arguments).join(' '));
                origError.apply(console, arguments);
            };
            try {
                dedupTrace(uid);
            } catch (e) {
                logs.push('[THROW] ' + e.message);
            }
            console.log = origLog;
            console.error = origError;
            // 彈出結果
            var msg = logs.length > 0 ? logs.join('\n') : '✅ 沒有找到重複 unit (auto-dedup 應該跑過了)';
            if (msg.length > 1500) msg = msg.substring(0, 1500) + '\n...(太長已截斷, 完整 log 請看 DevTools console)';
            alert(msg);
            // 同時 console.log 完整版本
            origLog('=== v1.5.182 dedupTrace 完整結果 ===');
            logs.forEach(function(l) { origLog(l); });
        }
        // v1.5.184: 手動清理重複教材 + 自動重整頁面 (讓使用者立刻看到清乾淨的結果)
        function dedupeAndSave() {
            var total = 0;
            Object.keys(multiData).forEach(function(uid) {
                total += deduplicateMasterUnits(uid);
                total += deduplicateLegacyMaster(uid);
            });
            saveToLocal();  // 不論有沒有都先存
            if (total > 0) {
                alert('✅ 已清理 ' + total + ' 筆重複教材, 自動重整頁面');
                setTimeout(function() { location.reload(); }, 500);
            } else {
                alert('✅ 沒有發現重複教材 (但已 save + reload 確保顯示最新)');
                setTimeout(function() { location.reload(); }, 500);
            }
        }
        // v1.5.231: 資料健檢 — 找出幽靈單元
        // 幽靈單元 = 在 mission 清單內但沒有任何有效任務記錄（無 isDone task、無 appLog）
        window._auditSelectedUnits = [];
        window.runAudit = function() {
            var user = multiData[currentUserId];
            if (!user || !user.masters) {
                el('audit-result').innerHTML = '<div style="color:var(--danger);">⚠️ 找不到使用者資料</div>';
                return;
            }
            var ghosts = [];
            var allUnitIds = new Set();
            // 收集所有出現在 missions 裡的 unitId
            Object.values(user.masters).forEach(function(subjects) {
                Object.values(subjects || {}).forEach(function(s) {
                    if (!s || !s.missions) return;
                    Object.values(s.missions).forEach(function(arr) {
                        (arr || []).forEach(function(uid) { allUnitIds.add(uid); });
                    });
                });
            });
            // 對每個 mission unit，檢查是否有任何有效記錄
            Object.entries(user.masters).forEach(function([cat, subjects]) {
                Object.entries(subjects || {}).forEach(function([sub, s]) {
                    if (!s || !s.missions) return;
                    Object.entries(s.missions).forEach(function([mis, arr]) {
                        (arr || []).forEach(function(uid) {
                            var info = findUnitContext(uid);
                            var unitName = info ? info.unit.name : uid;
                            // 檢查 isDone tasks
                            var hasDoneTask = false;
                            (user.plans || []).forEach(function(plan) {
                                if (!plan.grid) return;
                                Object.values(plan.grid).forEach(function(tasks) {
                                    (tasks || []).forEach(function(t) {
                                        if (t && t.unitId === uid && t.isDone) hasDoneTask = true;
                                    });
                                });
                            });
                            // 檢查 appLog
                            var hasLog = (user.logs || []).some(function(l) { return l.unitId === uid; });
                            if (!hasDoneTask && !hasLog) {
                                ghosts.push({ uid: uid, name: unitName, cat: cat, sub: sub, mis: mis, info: info });
                            }
                        });
                    });
                });
            });
            // 渲染結果
            if (ghosts.length === 0) {
                el('audit-result').innerHTML = '<div style="color:var(--success); padding:15px;">✅ 沒有發現幽靈單元！所有任務內的單元都有有效記錄。</div>';
                el('btn-audit-remove').disabled = true;
                window._auditSelectedUnits = [];
                return;
            }
            var html = '<table style="width:100%; border-collapse:collapse;"><thead><tr><th style="border-bottom:2px solid var(--accent); padding:8px; text-align:left;"><input type="checkbox" id="audit-sel-all" onchange="auditToggleAll(this.checked)"></th><th style="border-bottom:2px solid var(--accent); padding:8px;">科目</th><th style="border-bottom:2px solid var(--accent); padding:8px;">單元</th><th style="border-bottom:2px solid var(--accent); padding:8px;">任務</th><th style="border-bottom:2px solid var(--accent); padding:8px;">說明</th></tr></thead><tbody>';
            ghosts.forEach(function(g, i) {
                html += '<tr>' +
                    '<td style="padding:6px;"><input type="checkbox" class="audit-cb" value="' + g.uid + '" onchange="auditUpdateSel()"></td>' +
                    '<td style="padding:6px;">' + g.sub + '</td>' +
                    '<td style="padding:6px; font-weight:bold;">' + g.name + '</td>' +
                    '<td style="padding:6px; color:var(--secondary); font-size:0.85em;">' + g.cat + ' / ' + g.mis + '</td>' +
                    '<td style="padding:6px; color:var(--danger); font-size:0.85em;">⚠ 無任務記錄</td>' +
                    '</tr>';
            });
            html += '</tbody></table>';
            html += '<div style="margin-top:10px; color:#7f8c8d; font-size:0.85em;">找到 <strong style="color:var(--danger);">' + ghosts.length + '</strong> 個幽靈單元（已選 0 個）</div>';
            el('audit-result').innerHTML = html;
            el('btn-audit-remove').disabled = true;
            window._auditSelectedUnits = [];
        };
        window.auditToggleAll = function(checked) {
            document.querySelectorAll('.audit-cb').forEach(function(cb) { cb.checked = checked; });
            window._auditSelectedUnits = checked ? window._auditAllUids || [] : [];
            el('btn-audit-remove').disabled = !checked;
        };
        window.auditUpdateSel = function() {
            var cbs = document.querySelectorAll('.audit-cb:checked');
            window._auditSelectedUnits = Array.from(cbs).map(function(cb) { return cb.value; });
            var total = document.querySelectorAll('.audit-cb').length;
            el('btn-audit-remove').disabled = window._auditSelectedUnits.length === 0;
            var countEl = el('audit-result').querySelector('div[style*="margin-top"]');
            if (countEl) countEl.innerHTML = '找到 <strong style="color:var(--danger);">' + total + '</strong> 個幽靈單元（已選 <strong>' + window._auditSelectedUnits.length + '</strong> 個）';
        };
        window.auditRemoveSelected = function() {
            var selected = window._auditSelectedUnits || [];
            if (selected.length === 0) return alert('請先勾選要移除的單元');
            if (!confirm('確定要移除選中的 ' + selected.length + ' 個幽靈單元嗎？\n從所有任務中移除後，進度將重新計算。')) return;
            var user = multiData[currentUserId];
            var removed = 0;
            selected.forEach(function(uid) {
                Object.values(user.masters).forEach(function(subjects) {
                    Object.values(subjects || {}).forEach(function(s) {
                        if (!s || !s.missions) return;
                        Object.values(s.missions).forEach(function(arr) {
                            var idx = arr.indexOf(uid);
                            if (idx !== -1) { arr.splice(idx, 1); removed++; }
                        });
                    });
                });
            });
            saveMultiData();
            alert('已移除 ' + removed + ' 個幽靈單元。請重新整理頁面。');
            setTimeout(function() { location.reload(); }, 500);
        };
                async function saveSettingsAndAlert(returnHome = false) {
            // v1.6.98: 簡化 - 直接儲存 + 顯示確認 modal
            // v1.6.96 fix: 不關閉 modal-bg (避免擋住 save-confirm)
            console.log('[v1.6.99] saveSettingsAndAlert called');
            try {
                if(el('page-settings') && el('pane-master').classList.contains('active')) {
                    extractCurrentEditorData();
                }
            } catch(e) {
                console.error('[v1.6.99] extractCurrentEditorData failed:', e.message);
                alert('❌ 儲存失敗 (extract): ' + e.message);
                return;
            }
            try {
                saveToLocal();
                updateFilters();
                window.isMasterDirty = false;
            } catch(e) {
                console.error('[v1.6.99] saveToLocal failed:', e.message);
                alert('❌ 儲存失敗 (save): ' + e.message);
                return;
            }
            if(returnHome === true) {
                returnToHome();
                return;
            }
            // v1.5.8: 跳出確認 modal + 兩個按鈕 (繼續編輯 / 結束編輯)
            openSaveConfirmModal();
        }
        function openSaveConfirmModal() {
            // 動態創建 modal (避免跟其他 modal 混淆)
            var existing = el('modal-save-confirm');
            if (existing) existing.remove();
            var modal = document.createElement('div');
            modal.id = 'modal-save-confirm';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3500';
            modal.style.display = 'flex';
            modal.innerHTML = '<div class="modal-content" style="max-width: 440px;">' +
                '<div class="modal-header">' +
                    '<h2 style="color:var(--success);">✅ 儲存成功！</h2>' +
                '</div>' +
                '<div style="padding: 20px 0; text-align: center; color: var(--secondary);">' +
                    '<p style="margin: 0 0 8px 0; font-size: 1.05em;">教材庫變更已儲存完成。</p>' +
                    '<p style="margin: 0; font-size: 1.1em; font-weight: bold;">請選擇下一步：</p>' +
                '</div>' +
                '<div style="display: flex; gap: 12px; justify-content: center; margin-top: 15px;">' +
                    '<button type="button" class="btn-primary" onclick="onSaveConfirmContinue()" style="padding: 10px 20px;">✏️ 繼續編輯</button>' +
                    '<button type="button" class="btn-success" onclick="onSaveConfirmFinish()" style="padding: 10px 20px;">🏠 結束編輯</button>' +
                '</div>' +
            '</div>';
            document.body.appendChild(modal);
        }
        function closeSaveConfirmModal() {
            var modal = el('modal-save-confirm');
            if (modal) modal.remove();
        }
        // v1.5.17: 兩鍵選擇 modal, 取代 native confirm() (Safari 會擋)
        function openChoiceModal(title, message, optA, optB, onA, onB) {
            var existing = el('modal-choice');
            if (existing) existing.remove();
            var modal = document.createElement('div');
            modal.id = 'modal-choice';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3500';
            modal.style.display = 'flex';
            modal.innerHTML = '<div class="modal-content" style="max-width: 440px;">' +
                '<div class="modal-header"><h2 style="color:var(--accent);">' + escapeHtml(title) + '</h2></div>' +
                '<div style="padding: 15px 0; text-align: center; color: var(--secondary); white-space: pre-line;">' + escapeHtml(message) + '</div>' +
                '<div style="display: flex; gap: 12px; justify-content: center; margin-top: 15px;">' +
                    '<button type="button" class="btn-primary" id="modal-choice-a" style="padding: 10px 20px;">' + escapeHtml(optA) + '</button>' +
                    '<button type="button" class="btn-outline" id="modal-choice-b" style="padding: 10px 20px;">' + escapeHtml(optB) + '</button>' +
                '</div>' +
            '</div>';
            document.body.appendChild(modal);
            el('modal-choice-a').onclick = function() { modal.remove(); if (onA) onA(); };
            el('modal-choice-b').onclick = function() { modal.remove(); if (onB) onB(); };
        }
        // v1.5.95: 3 選項 modal (強制/延長/取消)
        function openThreeChoiceModal(title, message, optA, optB, optC, onA, onB, onC) {
            var existing = el('modal-three-choice');
            if (existing) existing.remove();
            var modal = document.createElement('div');
            modal.id = 'modal-three-choice';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3500';
            modal.style.display = 'flex';
            modal.innerHTML = '<div class="modal-content" style="max-width: 500px;">' +
                '<div class="modal-header"><h2 style="color:var(--accent);">' + escapeHtml(title) + '</h2></div>' +
                '<div style="padding: 15px 0; text-align: center; color: var(--secondary); white-space: pre-line;">' + escapeHtml(message) + '</div>' +
                '<div style="display: flex; gap: 10px; justify-content: center; margin-top: 15px; flex-wrap: wrap;">' +
                    '<button type="button" class="btn-primary" id="modal-three-a" style="padding: 10px 18px;">' + escapeHtml(optA) + '</button>' +
                    '<button type="button" class="btn-primary" id="modal-three-b" style="padding: 10px 18px;">' + escapeHtml(optB) + '</button>' +
                    '<button type="button" class="btn-outline" id="modal-three-c" style="padding: 10px 18px;">' + escapeHtml(optC) + '</button>' +
                '</div>' +
            '</div>';
            document.body.appendChild(modal);
            el('modal-three-a').onclick = function() { modal.remove(); if (onA) onA(); };
            el('modal-three-b').onclick = function() { modal.remove(); if (onB) onB(); };
            el('modal-three-c').onclick = function() { modal.remove(); if (onC) onC(); };
        }
        // v1.5.95: 延長完成日期子對話框
        function openExtendDateDialog(currentEndDate, minDays, maxDays, onConfirm) {
            var existing = el('modal-extend-date');
            if (existing) existing.remove();
            var modal = document.createElement('div');
            modal.id = 'modal-extend-date';
            modal.className = 'modal-bg';
            modal.style.zIndex = '3600';
            modal.style.display = 'flex';
            
            var minDate = new Date(currentEndDate);
            minDate.setDate(minDate.getDate() + 1);
            var minDateStr = getLocalDateString(minDate);
            var defaultDate = new Date(currentEndDate);
            defaultDate.setDate(defaultDate.getDate() + minDays);
            var defaultDateStr = getLocalDateString(defaultDate);
            
            modal.innerHTML = '<div class="modal-content" style="max-width: 460px;">' +
                '<div class="modal-header"><h2 style="color:var(--accent);">⏰ 延長計畫完成日期</h2></div>' +
                '<div style="padding: 15px;">' +
                    '<div style="margin-bottom: 12px; padding: 8px; background: #f8fafc; border-radius: 6px;">' +
                        '<div>目前完成日期: <strong>' + escapeHtml(currentEndDate) + '</strong></div>' +
                        '<div>至少需延長: <strong>' + minDays + ' 天 (到 ' + escapeHtml(minDateStr) + ' 或之後)</strong></div>' +
                    '</div>' +
                    '<div style="margin-bottom: 8px;">要延長幾天: <input type="number" id="modal-extend-days" min="' + minDays + '" max="' + maxDays + '" value="' + minDays + '" style="padding: 8px; width: 80px; font-size: 1.1em; margin-left: 8px;"> 天</div>' +
                    '<div style="font-size: 0.85em; color: #7f8c8d;">範圍: ' + minDays + ' 到 ' + maxDays + ' 天 (輸入 0 = 完全取消)</div>' +
                '</div>' +
                '<div style="display: flex; gap: 12px; justify-content: flex-end; padding: 0 15px 15px;">' +
                    '<button type="button" class="btn-primary" id="modal-extend-ok" style="padding: 8px 20px;">確定延長</button>' +
                    '<button type="button" class="btn-outline" id="modal-extend-cancel" style="padding: 8px 20px;">取消</button>' +
                '</div>' +
            '</div>';
            document.body.appendChild(modal);
            el('modal-extend-ok').onclick = function() {
                var days = parseInt(el('modal-extend-days').value);
                if (isNaN(days) || days < minDays || days > maxDays) {
                    alert('請輸入 ' + minDays + ' 到 ' + maxDays + ' 之間的天數');
                    return;
                }
                modal.remove();
                if (onConfirm) onConfirm(days);
            };
            el('modal-extend-cancel').onclick = function() { modal.remove(); };
        }
        function onSaveConfirmContinue() {
            closeSaveConfirmModal();
        }
        function onSaveConfirmFinish() {
            closeSaveConfirmModal();
            returnToHome();
        }
        
        function updateFilters() { var fCatSel = el('filter-category'); var fMisSel = el('filter-mission'); if(!fCatSel || !fMisSel) return; var prevCat = fCatSel.value; var prevMis = fMisSel.value; var cats = Object.keys(appMissions); var catOpts = '<option value="ALL">🌟 全部顯示</option>'; cats.forEach(c => catOpts += `<option value="${c}">${c}</option>`); fCatSel.innerHTML = catOpts; if (cats.includes(prevCat)) fCatSel.value = prevCat; else fCatSel.value = 'ALL'; onFilterCategoryChange(prevMis); }
        function onFilterCategoryChange(preserveMis) { var cat = el('filter-category').value; var fMisSel = el('filter-mission'); if(!fMisSel) return; var misOpts = '<option value="ALL">🌟 全部任務</option>'; if (cat !== 'ALL' && appMissions[cat]) Object.keys(appMissions[cat]).forEach(m => misOpts += `<option value="${m}">${m}</option>`); fMisSel.innerHTML = misOpts; if (preserveMis && typeof preserveMis === 'string') { var options = Array.from(fMisSel.options).map(o => o.value); if (options.includes(preserveMis)) fMisSel.value = preserveMis; } renderDashboard(); renderTreeView(); renderMonthlyAnalysis(); }
        
        window._dashDataStore = {};
        function findUnitScheduledDate(unitId) {
            // 從所有 plan 的 grid 找 unitId 對應的未完成 task,取最後一個排程日 (過去或未來都算)
            if (!appPlans || appPlans.length === 0) return null;
            var latestDate = null;
            appPlans.forEach(plan => {
                if (!plan.grid) return;
                Object.keys(plan.grid).forEach(dateStr => {
                    var tasks = plan.grid[dateStr];
                    if (!Array.isArray(tasks)) return;
                    tasks.forEach(t => {
                        // 過濾掉已勾選完成的 task
                        if (t && t.unitId === unitId && !t.isDone) {
                            if (!latestDate || dateStr > latestDate) latestDate = dateStr;
                        }
                    });
                });
            });
            return latestDate;
        }
        function getUnitOpenTaskCount(unitId) {
            // 統計這個 unit 在月曆上有幾個未勾選的 task
            var count = 0;
            if (!appPlans || appPlans.length === 0) return 0;
            appPlans.forEach(plan => {
                if (!plan.grid) return;
                Object.keys(plan.grid).forEach(dateStr => {
                    var tasks = plan.grid[dateStr];
                    if (!Array.isArray(tasks)) return;
                    tasks.forEach(t => {
                        if (t && t.unitId === unitId && !t.isDone) count++;
                    });
                });
            });
            return count;
        }
        function renderDashSummary() {
            // v1.6.67: 強制 refresh (避免 stale appPlans / cache)
            if (multiData && multiData[currentUserId]) {
                appPlans = multiData[currentUserId].plans || [];
            }
            if (typeof _collectSubjectUnitsCache !== 'undefined') {
                _collectSubjectUnitsCache = new WeakMap();
            }
            // v1.1: 統計 + 7-day bar chart
            var studentCount = Object.keys(multiData || {}).length;
            var studentNames = Object.keys(multiData || {}).map(uid => multiData[uid].name).filter(Boolean);
            
            var missionCount = 0, catCount = Object.keys(appMissions).length;
            Object.keys(appMissions).forEach(cat => {
                missionCount += Object.keys(appMissions[cat]).length;
            });
            
            // 學習活動統計
            var totalLogs = appLogs.filter(l => l.category !== '🔄 系統重排' && l.category !== '🗓️ 計畫管理').length;
            
            // 本週 / 本月學習頁數
            var now = new Date();
            var weekStart = new Date(now); weekStart.setDate(now.getDate() - 6);
            var weekStartStr = getLocalDateString(weekStart);
            var monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
            var monthStartStr = getLocalDateString(monthStart);
            
            var weekPages = 0, monthPages = 0, dailyPages = {};
            appLogs.forEach(l => {
                if (!l.pages || l.pages <= 0) return;
                // v1.3.6 bug fix: 排除系統重排 + 計畫管理 log (這些是順延/排程, 不是真正的學習)
                if (l.category === '🔄 系統重排' || l.category === '🗓️ 計畫管理') return;
                if (l.date >= weekStartStr) {
                    weekPages += l.pages;
                    dailyPages[l.date] = (dailyPages[l.date] || 0) + l.pages;
                }
                if (l.date >= monthStartStr) monthPages += l.pages;
            });
            
            // 7-day bars (v1.4.0: 加日期 + 平均線 + 總計)
            var days = [];
            for (var i = 6; i >= 0; i--) {
                var d = new Date(now); d.setDate(now.getDate() - i);
                var ds = getLocalDateString(d);
                var dayLabel = ['日','一','二','三','四','五','六'][d.getDay()];
                // 月/日 (短格式)
                var m = d.getMonth() + 1;
                var dd = d.getDate();
                days.push({ date: ds, label: dayLabel, md: m + '/' + dd, pages: dailyPages[ds] || 0 });
            }
            var maxPages = Math.max.apply(null, days.map(d => d.pages).concat([1]));
            // 平均 (基於 7 日總和)
            var avgPages = Math.round(weekPages / 7);
            
            var weekBarsHtml = days.map(d => {
                var h = Math.max(2, (d.pages / maxPages) * 90);
                // 平均線位置 (% 高度)
                var avgPct = maxPages > 0 ? (avgPages / maxPages * 100) : 0;
                return '<div class="dash-week-bar-wrap">' +
                    '<div class="dash-week-bar-area">' +
                        '<div class="dash-week-bar" style="height:' + h + 'px;" title="' + d.date + ': ' + d.pages + ' 頁">' +
                            (h > 15 ? '<div class="dash-week-pages-inside">' + d.pages + '</div>' : '') +
                        '</div>' +
                        (avgPages > 0 ? '<div class="dash-week-avg-line" style="bottom:' + avgPct + '%;" title="7 日平均 ' + avgPages + ' 頁"></div>' : '') +
                    '</div>' +
                    '<div class="dash-week-label">' + d.label + '</div>' +
                    '<div class="dash-week-date">' + d.md + '</div>' +
                '</div>';
            }).join('');
            
            var studentsLine = studentNames.length > 0 ? studentNames.join('、') : '尚未建立';
            if (studentsLine.length > 30) studentsLine = studentsLine.substring(0, 30) + '…';
            
            return '<div class="dash-summary">' +
                '<div class="dash-stat-card accent">' +
                    '<div class="stat-label">👥 學生人數</div>' +
                    '<div class="stat-value">' + studentCount + '</div>' +
                    '<div class="stat-sub">' + studentsLine + '</div>' +
                '</div>' +
                '<div class="dash-stat-card purple">' +
                    '<div class="stat-label">🎯 任務總數</div>' +
                    '<div class="stat-value">' + missionCount + '</div>' +
                    '<div class="stat-sub">' + catCount + ' 個分類</div>' +
                '</div>' +
                '<div class="dash-stat-card success">' +
                    '<div class="stat-label">📚 學習活動</div>' +
                    '<div class="stat-value">' + totalLogs + '</div>' +
                    '<div class="stat-sub">歷史紀錄筆數</div>' +
                '</div>' +
                '<div class="dash-stat-card warning">' +
                    '<div class="stat-label">📅 本週學習</div>' +
                    '<div class="stat-value">' + weekPages + '</div>' +
                    '<div class="stat-sub">本月 ' + monthPages + ' 頁</div>' +
                '</div>' +
            '</div>' +
            '<div class="dash-weekly-chart">' +
                '<div class="dash-week-header">' +
                    '<h3>📊 近 7 日學習量 <span class="dash-week-unit">（頁）</span></h3>' +
                    '<div class="dash-week-total">' +
                        '<span class="dash-week-total-label">總計</span>' +
                        '<span class="dash-week-total-value">' + weekPages + '</span>' +
                        '<span class="dash-week-total-unit">頁</span>' +
                    '</div>' +
                '</div>' +
                '<div class="dash-week-avg-row">7 日平均 <span class="avg-num">' + avgPages + '</span> 頁/天</div>' +
                '<div class="dash-week-bars">' + weekBarsHtml + '</div>' +
            '</div>';
        }
        function escapeHtml(s) {
            if (s === null || s === undefined) return '';
            return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        }
        function switchDashView(view) {
            document.querySelectorAll('.dash-view').forEach(v => v.classList.remove('active'));
            document.querySelectorAll('.dash-tab').forEach(b => b.classList.remove('active'));
            var root = el('dash-view-target') || (view === 'starmap' ? el('starmap-root') : el('dashboard-root'));
            // simpler approach: 直接操作兩個 root
            if (view === 'starmap') {
                el('starmap-root').classList.add('active');
                el('dashboard-root').classList.remove('active');
                renderTreeView();
            } else {
                el('dashboard-root').classList.add('active');
                el('starmap-root').classList.remove('active');
            }
            document.querySelectorAll('.dash-tab').forEach(b => {
                if (b.getAttribute('data-view') === view) b.classList.add('active');
            });
        }
        // v1.6.69: 搬到全域 (原本在 renderTreeView 內, 造成首頁重整後 mission tree 顯示白色)
        window.refreshTreeScheduledUnits = function() {
            window._treeScheduledUnits = {};
            if (Array.isArray(appPlans)) {
                appPlans.forEach(function(plan) {
                    if (!plan.grid) return;
                    Object.keys(plan.grid).forEach(function(dStr) {
                        var tasks = plan.grid[dStr];
                        if (!Array.isArray(tasks)) return;
                        tasks.forEach(function(t) {
                            if (!t || !t.unitId || !t.startPage || !t.endPage || !t.cat) return;
                            if (!window._treeScheduledUnits[t.unitId]) {
                                window._treeScheduledUnits[t.unitId] = {
                                    covered: 0, donePages: 0, totalTasks: 0, doneTasks: 0,
                                    firstCat: t.cat, firstMis: t.mis || plan.name || '',
                                    firstPlanId: plan.id
                                };
                            }
                            var pages = t.endPage - t.startPage + 1;
                            window._treeScheduledUnits[t.unitId].covered += pages;
                            window._treeScheduledUnits[t.unitId].totalTasks += 1;
                            if (t.isDone) {
                                window._treeScheduledUnits[t.unitId].doneTasks += 1;
                            }
                        });
                    });
                });
            }
            // v1.6.55: 同時算 filtered + unfiltered overlap
            // filtered (respects current mission filter) -> donePages
            var overlapFiltered = getUnitDonePagesByOverlap();
            Object.keys(overlapFiltered).forEach(function(uid) {
                if (!window._treeScheduledUnits[uid]) {
                    window._treeScheduledUnits[uid] = {
                        covered: 0, donePages: 0, totalTasks: 0, doneTasks: 0,
                        firstCat: '', firstMis: '', firstPlanId: null
                    };
                }
                window._treeScheduledUnits[uid].donePages += overlapFiltered[uid] || 0;
            });
            // unfiltered (ALL missions) -> totalDonePages (for display only)
            var overlapUnfiltered = getUnitDonePagesByOverlap('ALL', 'ALL');
            Object.keys(overlapUnfiltered).forEach(function(uid) {
                if (!window._treeScheduledUnits[uid]) {
                    window._treeScheduledUnits[uid] = {
                        covered: 0, donePages: 0, totalTasks: 0, doneTasks: 0,
                        firstCat: '', firstMis: '', firstPlanId: null
                    };
                }
                window._treeScheduledUnits[uid].totalDonePages = overlapUnfiltered[uid] || 0;
            });
        };
        function renderTreeView() {
            var root = el('starmap-root');
            if (!root) return;
            root.innerHTML = '';
            // v1.5.176: 拿掉 tree-cat-filter (跟看板篩選重複), 只剩 科目/教材類別/冊別 dropdowns
            var user = multiData[currentUserId];
            // 收集所有 subjects (不限 cat — 用戶已從看板選好 cat)
            var treeSubjects = {};
            if (user && user.masters) {
                Object.keys(user.masters).forEach(function(c) {
                    Object.keys(user.masters[c] || {}).forEach(function(sub) {
                        treeSubjects[sub + '|||' + c] = { name: sub, cat: c, subj: user.masters[c][sub] };
                    });
                });
            }
            // v1.5.175: 樹狀圖 3 個 dropdowns (科目/教材類別/冊別) — default 依科目別收起
            var treeSubjectSel = el('tree-subject-filter');
            var treeTypeSel = el('tree-type-filter');
            var treeVolSel = el('tree-vol-filter');
            // treeSubjects 已在 init 時收集 (不限 cat)
            if (Object.keys(treeSubjects).length === 0) {
                root.innerHTML = '<div class="tree-empty">🌳 尚未建立教材庫<br><br><span style="font-size:0.85em;">先去「教材庫與備份」建立科目與單元,樹狀圖就會長出來 ✨</span></div>';
                if (treeTypeSel) treeTypeSel.innerHTML = '<option value="ALL">全部</option>';
                if (treeVolSel) treeVolSel.innerHTML = '<option value="ALL">全部</option>';
                return;
            }
            // v1.5.175: populate 科目 dropdown (所有科目, 不限 cat)
            if (treeSubjectSel) {
                var prevSubj = treeSubjectSel.value;
                var subjectOpts = '<option value="ALL">🌟 全部科目 (' + Object.keys(treeSubjects).length + ')</option>';
                Object.keys(treeSubjects).forEach(function(key) {
                    var subjName = treeSubjects[key].name;
                    subjectOpts += '<option value="' + key + '">' + subjName + '</option>';
                });
                treeSubjectSel.innerHTML = subjectOpts;
                if (prevSubj && treeSubjects[prevSubj]) {
                    treeSubjectSel.value = prevSubj;
                } else {
                    treeSubjectSel.value = 'ALL';  // default 依科目別收起
                }
            }
            var treeSubjectKey = treeSubjectSel ? treeSubjectSel.value : 'ALL';
            // v1.5.175: populate 教材類別 dropdown (依選定科目)
            if (treeTypeSel) {
                var prevType = treeTypeSel.value;
                var typeOpts = '<option value="ALL">全部</option>';
                var selectedSubj = treeSubjectKey !== 'ALL' ? treeSubjects[treeSubjectKey] : null;
                if (selectedSubj) {
                    var types = selectedSubj.subj.materials ? Object.keys(selectedSubj.subj.materials) : [];
                    types.forEach(function(t) {
                        var cnt = selectedSubj.subj.materials[t] && selectedSubj.subj.materials[t].instances ? selectedSubj.subj.materials[t].instances.length : 0;
                        typeOpts += '<option value="' + t + '">' + t + ' (' + cnt + ')</option>';
                    });
                    treeTypeSel.disabled = false;
                } else {
                    treeTypeSel.disabled = true;
                }
                treeTypeSel.innerHTML = typeOpts;
                if (prevType && typeOpts.indexOf('value="' + prevType + '"') > -1) {
                    treeTypeSel.value = prevType;
                } else {
                    treeTypeSel.value = 'ALL';
                }
            }
            var treeType = treeTypeSel ? treeTypeSel.value : 'ALL';
            // v1.5.175: populate 冊別 dropdown (依選定教材類別)
            if (treeVolSel) {
                var prevVol = treeVolSel.value;
                var volOpts = '<option value="ALL">全部</option>';
                var typeObjForVol = (selectedSubj && treeType !== 'ALL') ? selectedSubj.subj.materials[treeType] : null;
                if (typeObjForVol && typeObjForVol.instances) {
                    typeObjForVol.instances.forEach(function(inst) {
                        if (inst.vols) {
                            Object.keys(inst.vols).forEach(function(volName) {
                                var cnt = (inst.vols[volName] || []).length;
                                volOpts += '<option value="' + inst.name + '|||' + volName + '">' + inst.name + ' / ' + volName + ' (' + cnt + ' 單元)</option>';
                            });
                        }
                    });
                    treeVolSel.disabled = false;
                } else {
                    treeVolSel.disabled = true;
                }
                treeVolSel.innerHTML = volOpts;
                if (prevVol && volOpts.indexOf('value="' + prevVol + '"') > -1) {
                    treeVolSel.value = prevVol;
                } else {
                    treeVolSel.value = 'ALL';
                }
            }
            var treeVol = treeVolSel ? treeVolSel.value : 'ALL';
            // v1.5.176: filter 邏輯 — 依 dropdown 選擇只顯示對應範圍
            // - 沒選科目 (ALL): 顯示科目 summary cards (default 收起)
            // - 選了科目: 只渲染該科目的樹, 教材類別/冊別進一步 filter
            if (treeSubjectKey === 'ALL') {
                renderTreeSubjectSummary(root, treeSubjects);
                return;
            }
            // 選了科目 → 把 treeSubjects 縮成單一科目 (後續 render 邏輯只 render 這個)
            var singleSubject = {};
            var singleEntry = Object.assign({}, treeSubjects[treeSubjectKey]);
            singleSubject[treeSubjectKey] = singleEntry;
            treeSubjects = singleSubject;
            // v1.5.176: 套用 教材類別/冊別 filter — 修改 entry.subj 讓 render 只 iterate 選到的範圍
            if (singleEntry && singleEntry.subj) {
                if (treeType !== 'ALL' && singleEntry.subj.materials && singleEntry.subj.materials[treeType]) {
                    var filteredMaterials = {};
                    var typeObjOrig = singleEntry.subj.materials[treeType];
                    if (treeVol !== 'ALL') {
                        // 冊別也選了 — 只留該 instance 的該冊
                        var filteredInstances = (typeObjOrig.instances || []).map(function(inst) {
                            if (inst.vols && inst.vols[treeVol]) {
                                return Object.assign({}, inst, { vols: (function() {
                                    var v = {};
                                    v[treeVol] = inst.vols[treeVol];
                                    return v;
                                })() });
                            }
                            return null;
                        }).filter(Boolean);
                        filteredMaterials[treeType] = Object.assign({}, typeObjOrig, { instances: filteredInstances });
                    } else {
                        filteredMaterials[treeType] = typeObjOrig;
                    }
                    singleEntry.subj = Object.assign({}, singleEntry.subj, { materials: filteredMaterials });
                } else if (treeType !== 'ALL' && (!singleEntry.subj.materials || !singleEntry.subj.materials[treeType])) {
                    // 選了 type 但該科目沒有 — 顯示空
                    singleEntry.subj = Object.assign({}, singleEntry.subj, { materials: {} });
                }
            }
            // v1.4.8: 套用看板篩選 — 不論 cat 是否 ALL, 只要 mis 不是 ALL 就用 mis 的 unitIds
            var filterCat = el('filter-category') ? el('filter-category').value : 'ALL';
            var filterMis = el('filter-mission') ? el('filter-mission').value : 'ALL';
            var allowedUnitIds = null;  // null = 全部, Set = 過濾
            if (filterMis !== 'ALL') {
                // 找 mis 實際所在的 cat (用搜尋方式, 因為 mis 在 onFilterCategoryChange 會被清掉)
                var foundCat = null;
                if (filterCat !== 'ALL' && appMissions[filterCat] && appMissions[filterCat][filterMis]) {
                    foundCat = filterCat;
                } else {
                    Object.keys(appMissions).forEach(function(c) {
                        if (appMissions[c] && appMissions[c][filterMis]) foundCat = c;
                    });
                }
                if (foundCat && appMissions[foundCat][filterMis]) {
                    allowedUnitIds = new Set(appMissions[foundCat][filterMis]);
                }
            } else if (filterCat !== 'ALL' && appMissions[filterCat]) {
                // 只選 category, 收集底下所有 mis 的 unitIds
                allowedUnitIds = new Set();
                Object.keys(appMissions[filterCat]).forEach(function(m) {
                    (appMissions[filterCat][m] || []).forEach(function(uid) {
                        allowedUnitIds.add(uid);
                    });
                });
            }
            // 計算每個 unit 的完成度
            var logData = {};
            if (Array.isArray(appLogs)) {
                appLogs.forEach(l => {
                    if (!l || !l.unitId) return;
                    if (l.category === '🔄 系統重排' || l.category === '🗓️ 計畫管理') return;
                    if (!logData[l.unitId]) logData[l.unitId] = { pages: 0 };
                    logData[l.unitId].pages += (l.pages || 0);
                });
            }
            function getStatus(unitId, total) {
                // v1.5.87: 改用 window._treeScheduledUnits (doneTasks 反映 checkbox 勾選)
                var suInfo = window._treeScheduledUnits && window._treeScheduledUnits[unitId];
                var done = suInfo ? suInfo.doneTasks : 0;
                if (done >= total) return 'done';
                if (done > 0) return 'progress';
                return 'todo';
            }
            // v1.6.53: 一開始就計算一次（頁面載入時）
            window.refreshTreeScheduledUnits();
            function totalOf(u) {
                var t = ((u.end || 0) - (u.start || 0) + 1);
                return (t > 0) ? t : 1;
            }
            // v1.6.53: 每次renderTreeView都重新從appPlans計算，確保包含手動新增的任務
            window.refreshTreeScheduledUnits();
            var html = '<div class="tree-container">';
            Object.keys(treeSubjects).forEach(function(key) {
                var entry = treeSubjects[key];
                var sub = entry.name;
                var catLabel = ' <small style="color:var(--secondary);font-size:0.7em;">[' + entry.cat + ']</small>';
                var s = entry.subj;
                if (!s) return;
                var doneCount = 0, totalCount = 0;
                var isUnitBasedTree = false;  // v1.5.146: subject 為 unit-based
                // 先算總數 (v1.6.33: 移除 allowedUnitIds 過濾, 讓 tree view 和 dashboard 算出一樣的數字)
                function countUnits(arr) {
                    arr.forEach(u => {
                        var ctx = findUnitContext(u.id);
                        var typeObj = ctx ? ctx.typeObj : null;
                        var total = getUnitTotalCount(u, typeObj);
                        var done = getUnitDoneCount(u, typeObj, null, null);
                        totalCount += total;
                        doneCount += done;
                        if (typeObj && isUnitBasedType(typeObj)) isUnitBasedTree = true;
                    });
                }
                var overlapDone = getUnitDonePagesByOverlap();
                if (s.type === 'custom' && Array.isArray(s.units)) {
                    countUnits(s.units);
                } else if (s.vols) {
                    Object.keys(s.vols).forEach(v => {
                        if (Array.isArray(s.vols[v])) countUnits(s.vols[v]);
                    });
                } else if (s.materials) {
                    // v1.5.5 fix: 讀新架構
                    countUnits(_collectSubjectUnits(s));
                }
                html += '<div class="tree-subject">';
                html += '<h2>' + escapeHtml(sub) + catLabel + '<span class="tree-progress">' + doneCount + ' / ' + totalCount + (isUnitBasedTree ? ' units' : ' 頁') + '</span></h2>';
                if (s.type === 'custom' && Array.isArray(s.units)) {
                    // v1.5.192: legacy 自訂範圍結構, 用 instance header 包起來 (跟教材庫一致)
                    var instLabel = escapeHtml(sub) + ' - 自訂範圍';
                    html += '<ul class="tree-instance"><li class="tree-instance-label" style="font-weight:bold; color:var(--primary); margin-top:8px;">📖 ' + instLabel + '</li>';
                    html += '<ul class="tree-vol"><li class="tree-vol-label">📖 自訂範圍</li>';
                    // v1.5.207: sticky 標題列 (用 display:flex)
                    html += '<li class="tree-units-header" style="display:grid; grid-template-columns: 1fr 100px 110px 150px 90px; gap:24px; align-items:center; padding:6px 24px; color:var(--primary); font-size:0.85em; font-weight:bold; position:sticky; top:0; z-index:20; list-style:none;">';
                    html += '<span>單元名稱</span>';
                    html += '<span style="text-align:center;">頁碼</span>';
                    html += '<span style="text-align:center;">答對率</span>';
                    html += '<span style="text-align:center;">完成度</span>';
                    html += '<span style="text-align:center;">排程天數</span>';
                    html += '</li>';
                    html += '<ul class="tree-units">';
                    s.units.forEach(u => {
                        var t = totalOf(u);
                        var st = getStatus(u.id, t);
                        var dotClass = 'dot-' + st;
                        var range = (u.start && u.end) ? 'P.' + u.start + (u.start !== u.end ? '~' + u.end : '') : '';
                        html += '<li class="tree-unit">';
                        html += '<span class="tree-dot ' + dotClass + '" title="' + escapeHtml(sub) + ' / ' + escapeHtml(u.name) + '"></span>';
                        html += '<span class="tree-unit-name">' + escapeHtml(u.name) + '</span>';
                        if (range) html += '<span class="tree-unit-range">' + escapeHtml(range) + '</span>';
                        html += '</li>';
                    });
                    html += '</ul></ul>';
                    html += '</ul>';
                } else if (s.vols) {
                    var volOrder = s.volOrder || Object.keys(s.vols);
                    volOrder.forEach(volName => {
                        var arr = s.vols[volName];
                        if (!Array.isArray(arr) || arr.length === 0) return;
                        // v1.5.177: 拿掉 mission filter
                        html += '<ul class="tree-vol"><li class="tree-vol-label">📖 ' + escapeHtml(volName) + '</li>';
                        html += '<ul class="tree-units">';
                        arr.forEach(u => {
                            var t = totalOf(u);
                            var st = getStatus(u.id, t);
                            var dotClass = 'dot-' + st;
                            var range = (u.start && u.end) ? 'P.' + u.start + (u.start !== u.end ? '~' + u.end : '') : '';
                            // v1.5.146: 根據 unit-based 計算進度
                            var ctx = findUnitContext(u.id);
                            var typeObj = ctx ? ctx.typeObj : null;
                            var isUnitBased = isUnitBasedType(typeObj);
                            var totalU = getUnitTotalCount(u, typeObj);
                            var doneU = getUnitDoneCount(u, typeObj, null, null);
                            var pct = totalU > 0 ? Math.min(100, Math.round(doneU / totalU * 100)) : 0;
                            var unitLabel2 = isUnitBased ? 'units' : '頁';
                            var barColor = isDoneForTree ? '#27ae60' : (pct >= 50 ? '#f39c12' : (pct > 0 ? '#e67e22' : '#95a5a6'));
                            var barFilled = Math.round(pct / 10);
                            var barEmpty = 10 - barFilled;
                            var barStr = '█'.repeat(barFilled) + '░'.repeat(barEmpty);
                            var suInfo = window._treeScheduledUnits[u.id];
                            var cat4jump = suInfo ? suInfo.firstCat : '';
                            var mis4jump = suInfo ? suInfo.firstMis : (entry.cat || '');
                            html += '<li class="tree-unit" onclick="jumpToUnitCalendar(\'' + u.id + '\', \'' + escapeHtml(cat4jump) + '\', \'' + escapeHtml(mis4jump) + '\')" style="cursor:pointer;" title="點擊跳到月曆檢視">';
                            html += '<span class="tree-dot ' + dotClass + '" title="' + escapeHtml(sub) + ' / ' + escapeHtml(u.name) + '"></span>';
                            html += '<span class="tree-unit-name">' + escapeHtml(u.name) + '</span>';
                            if (range) html += '<span class="tree-unit-range">' + escapeHtml(range) + '</span>';
                            // 進度條
                            html += '<span class="tree-unit-progress" style="font-family:monospace; font-size:0.75em; color:' + barColor + '; margin-left:8px; white-space:nowrap;">';
                            html += barStr + ' ' + doneU + '/' + totalU + ' ' + unitLabel2 + ' (' + pct + '%)';
                            html += '</span>';
                            if (suInfo && suInfo.totalTasks > 0) {
                                html += '<span class="tree-unit-clock" title="已排 ' + suInfo.totalTasks + ' 個任務">⏰×' + suInfo.totalTasks + '</span>';
                            }
                            html += '</li>';
                        });
                        html += '</ul></ul>';
                    });
                } else if (s.materials) {
                    // v1.5.5 fix: 新架構 — 從 materials[*].instances[*] 收集 units
                    var allUnits = _collectSubjectUnits(s);
                    // v1.5.177: 拿掉 mission filter - 顯示所有教材庫 units
                    // v1.5.190: 改用 byInstance 三層分組 (instance → vol → unit), 避免同 instance 多 vol 重複顯示教材名稱
                    var byInstance = {};
                    allUnits.forEach(function(u) {
                        var typeName = u._typeName || '';
                        var instanceName = u._instanceName || '';
                        var volName = u.vol || 'custom';
                        // v1.5.190: volName 是「typeName|ins.name」這種 legacy 格式 (來自 ins.units 分支), 不算真正 vol, 標記成空
                        // v1.5.191: volName = 'custom' 也視為 noVol (代表 instance 沒明確分冊)
                        var realVolName = volName;
                        if (volName === typeName + '|' + instanceName || volName === 'custom') {
                            realVolName = '';
                        }
                        var ik = typeName + '|' + instanceName;
                        if (!byInstance[ik]) byInstance[ik] = { typeName: typeName, instanceName: instanceName, vols: {} };
                        var vk = realVolName || '__no_vol__';
                        if (!byInstance[ik].vols[vk]) byInstance[ik].vols[vk] = { volName: realVolName, units: [] };
                        byInstance[ik].vols[vk].units.push(u);
                    });
                    function makeInstanceLabel(typeName, instanceName) {
                        // v1.5.206: 移除「-」分隔, 改為空格連接
                        var parts = [];
                        var instName = instanceName;
                        if (instName === '(原主教材)') instName = '';
                        if (typeName) parts.push(escapeHtml(typeName));
                        if (instName) parts.push(escapeHtml(instName));
                        return parts.length > 0 ? parts.join(' ') : '(未命名教材)';
                    }
                    function makeVolLabel(volName) {
                        if (!volName) return null;
                        return '📖 ' + escapeHtml(volName);
                    }
                    function renderUnitRow(u, optCtx) {
                        // v1.5.228: optCtx = {sub, typeName, instanceName} 由 caller 傳入，避免 cross-instance 汙染
                        var t = totalOf(u);
                        var st = getStatus(u.id, t);
                        var dotClass = 'dot-' + st;
                        var range = (u.start && u.end) ? 'P.' + u.start + (u.start !== u.end ? '~' + u.end : '') : '';
                        var totalPages = u.end - u.start + 1;
                        var suInfo = window._treeScheduledUnits[u.id];
                        // v1.6.55: use totalDonePages (unfiltered ALL missions) for display
                        var coveredPages = suInfo ? (suInfo.totalDonePages || suInfo.donePages) : 0;
                        var isDoneForTree = getUnitLastDoneDate(u.id) !== null;
                        var pct = (!isDoneForTree || totalPages === 0) ? 0 : Math.min(100, Math.round(coveredPages / totalPages * 100));
                        var barColor = pct === 100 ? '#27ae60' : (pct >= 50 ? '#f39c12' : (pct > 0 ? '#e67e22' : '#95a5a6'));
                        var barFilled = Math.round(pct / 10);
                        var barEmpty = 10 - barFilled;
                        var barStr = '█'.repeat(barFilled) + '░'.repeat(barEmpty);
                        var cat4jump = suInfo ? suInfo.firstCat : '';
                        var mis4jump = suInfo ? suInfo.firstMis : (entry.cat || '');
                        var scheduledDays = getUnitScheduledDays(u.id);
                        // v1.5.228: 傳入當前 unit 的 sub/typeName/instanceName 給 getUnitAccuracyRate filter
                        // v1.6.162: 加第 5 參數 vol — 雙軌制, 避免跨 vol 污染
                        var accuracyRate = getUnitAccuracyRate(u.name, optCtx && optCtx.sub, optCtx && optCtx.typeName, optCtx && optCtx.instanceName, optCtx && optCtx.vol);
                        var accuracyBarHtml = '';
                        if (accuracyRate !== null) {
                            var accPct = Math.round(accuracyRate * 100);
                            var accColor = accPct >= 96 ? '#27ae60' : (accPct >= 90 ? '#f59e0b' : '#ef4444');
                            var accFilled = Math.round(accPct / 10);
                            var accEmpty = 10 - accFilled;
                            var accStr = '█'.repeat(accFilled) + '░'.repeat(accEmpty);
                            accuracyBarHtml = '<span class="tree-unit-accuracy" onclick="event.stopPropagation(); jumpToAccuracyForUnitHighlight(\x27' + u.id + '\x27, \x27' + escapeHtml(u.name) + '\x27)" style="cursor:pointer; font-family:monospace; font-size:0.75em; color:' + accColor + '; white-space:nowrap;" title="點擊跳到答對率記錄並高亮此單元">' + accStr + ' ' + accPct + '%</span>';
                        }
                        // v1.5.212: grid 5 欄對齊 header
                        var rowHtml = '<li class="tree-unit" onclick="jumpToUnitCalendar(\'' + u.id + '\', \'' + escapeHtml(cat4jump) + '\', \'' + escapeHtml(mis4jump) + '\')"  style="display:grid; grid-template-columns: 1fr 100px 110px 150px 90px; gap:24px; align-items:center; padding:4px 24px; cursor:pointer; border-bottom:1px dashed #e2e8f0;">';
                        rowHtml += '<span class="tree-unit-name" onclick="event.stopPropagation(); jumpToAccuracyForUnit(\x27' + u.id + '\x27, \x27' + escapeHtml(u.name) + '\x27);" style="cursor:pointer; color:var(--accent); text-decoration:underline;" title="點擊跳到答對率記錄">';
                        rowHtml += '<span class="tree-dot ' + dotClass + '" style="display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:6px; vertical-align:middle; background:' + (st === 'done' ? '#27ae60' : (st === 'progress' ? '#f39c12' : '#e5e7eb')) + ';"></span>';
                        rowHtml += escapeHtml(u.name);
                        rowHtml += '</span>';
                        rowHtml += '<span class="tree-unit-range" style="font-family:monospace; font-size:0.85em; color:var(--secondary);">' + escapeHtml(range || '-') + '</span>';
                        rowHtml += '<span style="font-size:0.85em;">' + accuracyBarHtml + '</span>';
                        var progressTxt = isDoneForTree ? (coveredPages + '/' + totalPages + ' (' + pct + '%)') : '—';
                        rowHtml += '<span class="tree-unit-progress" onclick="jumpToUnitCalendar(\x27' + u.id + '\x27, \x27' + escapeHtml(cat4jump) + '\x27, \x27' + escapeHtml(mis4jump) + '\x27)" style="font-family:monospace; font-size:0.75em; color:' + barColor + '; white-space:nowrap; cursor:pointer;" title="點擊跳到月曆檢視">' + barStr + ' ' + progressTxt + '</span>';
                        rowHtml += '<span style="font-size:0.85em;">';
                        if (scheduledDays > 0) {
                            rowHtml += '<span class="tree-unit-clock" onclick="event.stopPropagation(); jumpToUnitCalendar(\x27' + u.id + '\x27, \x27' + escapeHtml(cat4jump) + '\x27, \x27' + escapeHtml(mis4jump) + '\x27)" style="cursor:pointer; font-size:0.85em; white-space:nowrap;" title="已排 ' + scheduledDays + ' 天, 點擊跳到月曆">📅 ' + scheduledDays + '天</span>';
                        }
                        rowHtml += '</span>';
                        rowHtml += '</li>';
                        return rowHtml;
                    }
                    Object.keys(byInstance).forEach(function(ik) {
                        var inst = byInstance[ik];
                        var volKeys = Object.keys(inst.vols);
                        if (volKeys.length === 0) return;
                        // v1.5.191: 永遠輸出 instance header (讓教材名稱清楚顯示)
                        var hasNoVol = volKeys.length === 1 && volKeys[0] === '__no_vol__';
                        var instLabel = makeInstanceLabel(inst.typeName, inst.instanceName);
                        html += '<ul class="tree-instance"><li class="tree-instance-label" style="font-weight:bold; color:var(--primary); margin-top:8px;">📖 ' + instLabel + '</li>';
                        // v1.5.191: 沒 vol 時, units 直接列在 instance 內 (不縮排 vol)
                        if (hasNoVol) {
                            // v1.5.222: 沒 vol 也加 tree-units-header (統一每個 instance 都有 header)
                            html += '<ul class="tree-units-header-wrapper" style="list-style:none; padding:0;"><li class="tree-units-header" style="display:grid; grid-template-columns: 1fr 100px 110px 150px 90px; gap:24px; align-items:center; padding:6px 24px; color:var(--primary); font-size:0.85em; font-weight:bold; list-style:none;">';
                            html += '<span>單元名稱</span>';
                            html += '<span style="text-align:center;">頁碼</span>';
                            html += '<span style="text-align:center;">答對率</span>';
                            html += '<span style="text-align:center;">完成度</span>';
                            html += '<span style="text-align:center;">排程天數</span>';
                            html += '</li>';
                            html += '<ul class="tree-units">';
                        }
                        volKeys.forEach(function(vk) {
                            var vol = inst.vols[vk];
                            if (vol.units.length === 0) return;
                            var volLabel = makeVolLabel(vol.volName);
                            if (volLabel) {
                                html += '<ul class="tree-vol"><li class="tree-vol-label">' + volLabel + '</li>';
                                // v1.5.207: sticky 標題列 (用 display:flex 而非 grid, sticky 更穩)
                                html += '<li class="tree-units-header" style="display:grid; grid-template-columns: 1fr 100px 110px 150px 90px; gap:24px; align-items:center; padding:6px 24px; color:var(--primary); font-size:0.85em; font-weight:bold; position:sticky; top:0; z-index:20; list-style:none;">';
                                html += '<span>單元名稱</span>';
                                html += '<span style="text-align:center;">頁碼</span>';
                                html += '<span style="text-align:center;">答對率</span>';
                                html += '<span style="text-align:center;">完成度</span>';
                                html += '<span style="text-align:center;">排程天數</span>';
                                html += '</li>';
                                html += '<ul class="tree-units">';
                            }
                            vol.units.forEach(function(u) {
                                // v1.6.162: 加 vol.volName 給 renderUnitRow 用於雙軌制過濾
                                html += renderUnitRow(u, { sub: sub, typeName: inst.typeName, instanceName: inst.instanceName, vol: vol.volName });
                            });
                            if (volLabel) html += '</ul></ul>';
                        });
                        if (hasNoVol) html += '</ul></ul>';
                        html += '</ul>';
                    });
                }
                html += '</div>';
            });
            html += '</div>';
            // Legend
            html += '<div class="tree-legend">';
            html += '<div class="tree-legend-item"><span class="tree-legend-dot done"></span><span>已完成 (100%)</span></div>';
            html += '<div class="tree-legend-item"><span class="tree-legend-dot progress"></span><span>進行中 (1-99%)</span></div>';
            html += '<div class="tree-legend-item"><span class="tree-legend-dot todo"></span><span>未開始 (0%)</span></div>';
            html += '<div class="tree-legend-item"><span style="font-size:1em;">⏰</span><span>有排程</span></div>';
            html += '</div>';
            root.innerHTML = html;
        }
        // === v1.4.0: 月份分析 (月→週 bar chart) ===
        function renderMonthlyAnalysis() {
            var root = el('monthly-root');
            if (!root) return;
            root.innerHTML = '';
            if (!Array.isArray(appLogs) || appLogs.length === 0) {
                root.innerHTML = '<div class="monthly-empty">📅 尚無學習紀錄, 無法分析</div>';
                return;
            }
            // 收集 log: 按月份 → 週次 (該月內) → 頁數
            function getMonthWeek(dateStr) {
                // v1.4.19: 改用 Denias 的週次定義
                // W1 = 月初到本月第一個週日 (含週日, 不一定 7 天)
                // W2+ = 第一個週一開始每 7 天
                // 例: 7 月 (7/1=三): W1=7/1~7/5 (5天), W2=7/6~7/12, W3=7/13~7/19, W4=7/20~7/26, W5=7/27~7/31
                var d = new Date(dateStr + 'T00:00:00');
                var year = d.getFullYear();
                var month = d.getMonth() + 1;
                var firstOfMonth = new Date(year, month - 1, 1);
                var dayOfWeek = firstOfMonth.getDay(); // 0=日, 1=一, ..., 6=六
                // 找本月第一個週日 (= 月初 + (7-dayOfWeek) mod 7 天)
                var firstSunday = new Date(firstOfMonth);
                var sunOffset = dayOfWeek === 0 ? 0 : (7 - dayOfWeek);
                firstSunday.setDate(firstOfMonth.getDate() + sunOffset);
                // 找本月第一個週一
                var firstMonday = new Date(firstOfMonth);
                var monOffset = dayOfWeek === 0 ? 1 : (8 - dayOfWeek);
                if (dayOfWeek === 1) monOffset = 0;
                firstMonday.setDate(firstOfMonth.getDate() + monOffset);
                // v1.5.202: 算本月最後一天 (lastOfMonth)
                var lastOfMonth = new Date(year, month, 0);  // 下月第 0 天 = 本月最後一天
                // var lastOfMonthDay = lastOfMonth.getDate();
                // 判斷日期落在哪一週
                if (d <= firstSunday) {
                    return { year: year, month: month, week: 1 };
                }
                // 在週一之後, 算 daysDiff
                var daysDiff = Math.floor((d - firstMonday) / (24 * 60 * 60 * 1000));
                if (daysDiff < 0) {
                    return { year: year, month: month, week: 1 };
                }
                var week = Math.floor(daysDiff / 7) + 2;
                // v1.5.202: 該週的結束日不能超過本月最後一天
                // 例: 8月 W6 = 8/24~8/30 (不跨到 9月), 因為 8/31 = firstMonday + 28, W6 = (28/7)+2 = 6, 結束日 = 8/24+6 = 8/30
                // 但若該週範圍會跨月, 縮短到 lastOfMonth
                var weekStart = new Date(firstMonday);
                weekStart.setDate(firstMonday.getDate() + (week - 2) * 7);
                var weekEnd = new Date(weekStart);
                weekEnd.setDate(weekStart.getDate() + 6);
                // 如果 weekEnd 跨月, 只算到 lastOfMonth
                if (weekEnd > lastOfMonth) {
                    // 但 d 還在本月內, 所以一定會算進當月某週
                    // 改邏輯: 若 d 在月底那一週, 仍算一週 (week 6 或更高)
                }
                return { year: year, month: month, week: week };
            }
            // v1.4.27: filter 邏輯改進 - category 直接比對, mission 才用 unitId
            var filterCatM = el('filter-category') ? el('filter-category').value : 'ALL';
            var filterMisM = el('filter-mission') ? el('filter-mission').value : 'ALL';
            var allowedUnitIdsM = null;
            // mission-level filter (specific mission)
            if (filterMisM !== 'ALL') {
                var foundCatM = null;
                if (filterCatM !== 'ALL' && appMissions[filterCatM] && appMissions[filterCatM][filterMisM]) {
                    foundCatM = filterCatM;
                } else {
                    Object.keys(appMissions).forEach(function(c) {
                        if (appMissions[c] && appMissions[c][filterMisM]) foundCatM = c;
                    });
                }
                if (foundCatM && appMissions[foundCatM][filterMisM]) {
                    allowedUnitIdsM = new Set(appMissions[foundCatM][filterMisM]);
                }
            } else if (filterCatM !== 'ALL' && appMissions[filterCatM]) {
                // category-level: 用 unitId 但 fallback 用 category 直接比對 (含 orphan unitIds)
                allowedUnitIdsM = new Set();
                Object.keys(appMissions[filterCatM]).forEach(function(m) {
                    (appMissions[filterCatM][m] || []).forEach(function(uid) {
                        allowedUnitIdsM.add(uid);
                    });
                });
            }
            // v1.4.11: 去重 - 同 (subject+unitName+start+end+date) 只算一次
            // 原因: 系統算 340 但 Denias 實際加總只有 168, 表示重複
            // 用 subject+unitName+page range+date 組合 key, 對 plan 自動重複 task 有效
            var seenLogs = {};
            var byMonth = {};  // v1.4.14 補回 (v1.4.10 不小心刪掉, 導致 Can't find variable: byMonth)
            appLogs.forEach(l => {
                if (!l.date || !l.pages || l.pages <= 0) return;
                if (l.category === '🔄 系統重排' || l.category === '🗓️ 計畫管理') return;
                // v1.4.29: filter 改進
                // - category-level: 嚴格 category match (含 orphan unitIds)
                // - mission-level: unitId match OR mission string match (含 orphan unitIds)
                if (filterCatM !== 'ALL' && l.category !== filterCatM) return;
                if (filterMisM !== 'ALL' && allowedUnitIdsM) {
                    var inByUid = l.unitId && allowedUnitIdsM.has(l.unitId);
                    var inByStr = l.mission === filterMisM;
                    if (!inByUid && !inByStr) return;
                }
                // 多欄位 dedup key (subject+date+pages) — 激進去重
                // v1.4.15: 同一天同樣科目同樣頁數只算一次 (不該同天讀兩次同樣頁數)
                var dedupKey = (l.subject || '') + '|' + l.date + '|' + l.pages;
                if (seenLogs[dedupKey] !== undefined) return;
                // v1.4.30: 跨科目 (date+pages) 只在 subject 相似時 dedup
                // 不相似 = 真的讀了多個 5 頁 (7/3 那種 case)
                var datePagesKey = l.date + '|' + l.pages;
                var existingSimilar = seenLogs['DP_' + datePagesKey];
                if (existingSimilar) {
                    // 比較 subject 是否相似 (有包含關係)
                    var subj = (l.subject || '').replace(/\s/g, '');
                    if (existingSimilar.indexOf(subj) >= 0 || subj.indexOf(existingSimilar.replace(/\s/g, '')) >= 0) {
                        return; // subject 相似 → dedup
                    }
                    // 不相似: 用新 subject 記錄 (但保留舊的, 不要覆蓋)
                    seenLogs['DP_' + datePagesKey + '_' + subj] = true;
                } else {
                    seenLogs['DP_' + datePagesKey] = (l.subject || '').replace(/\s/g, '');
                }
                seenLogs[dedupKey] = l.pages;
                var mw = getMonthWeek(l.date);
                var key = mw.year + '-' + String(mw.month).padStart(2, '0');
                if (!byMonth[key]) byMonth[key] = { year: mw.year, month: mw.month, weeks: {} };
                if (!byMonth[key].weeks[mw.week]) byMonth[key].weeks[mw.week] = 0;
                byMonth[key].weeks[mw.week] += l.pages;
                // v1.4.16: debug 用, 收集 logs by week
                if (!byMonth[key].weekLogs) byMonth[key].weekLogs = {};
                if (!byMonth[key].weekLogs[mw.week]) byMonth[key].weekLogs[mw.week] = [];
                byMonth[key].weekLogs[mw.week].push({
                    date: l.date,
                    subject: l.subject,
                    unitName: l.unitName,
                    start: l.start,
                    end: l.end,
                    pages: l.pages,
                    id: l.id,
                    category: l.category,
                    mission: l.mission || '?'
                });
            });
            window._byMonthData = byMonth;  // v1.4.16: debug 用
            var monthKeys = Object.keys(byMonth).sort();
            if (monthKeys.length === 0) {
                root.innerHTML = '<div class="monthly-empty">📅 尚無學習紀錄, 無法分析</div>';
                return;
            }
            var html = '<div class="monthly-container">';
            monthKeys.forEach(mkey => {
                var m = byMonth[mkey];
                var monthLabel = m.year + ' 年 ' + m.month + ' 月';
                var totalPages = Object.values(m.weeks).reduce(function(a, b) { return a + b; }, 0);
                var maxWeekPages = Math.max.apply(null, Object.values(m.weeks).concat([1]));
                html += '<div class="monthly-block">';
                html += '<div class="monthly-block-header">';
                html += '<h3>' + monthLabel + '</h3>';
                html += '<div class="monthly-total">總計 <b>' + totalPages + '</b> 頁</div>';
                html += '</div>';
                // v1.4.24: dump 到 console 給 user 用 F12 查
        // v1.5.201: 展開/折疊月份分析的詳細記錄
        window.toggleMonthlyDetail = function(mkey) {
            var panel = document.querySelector('.monthly-detail-panel[data-mkey="' + mkey + '"]');
            var btn = document.querySelector('button[data-mkey="' + mkey + '"][onclick*="toggleMonthlyDetail"]');
            if (panel && btn) {
                if (panel.style.display === 'none') {
                    panel.style.display = 'block';
                    btn.innerHTML = '📂 折疊詳細記錄';
                    btn.style.background = '#10b981';
                } else {
                    panel.style.display = 'none';
                    btn.innerHTML = '📂 展開詳細記錄';
                    btn.style.background = '#3b82f6';
                }
            }
        };
        window.dumpMonthLogs = function(mkey) {
            // v1.5.204: dump 到 textarea (預設隱藏, 但可在展開詳細記錄 panel 內看到)
            try {
                var data = window._byMonthData ? window._byMonthData[mkey] : null;
                if (!data) {
                    console.log('No data: _byMonthData[' + mkey + '] 不存在');
                    return;
                }
                var logs = [];
                appLogs.forEach(function(l) {
                    if (!l.date || !l.pages || l.pages <= 0) return;
                    var mw = getMonthWeek(l.date);
                    if (mw.year === data.year && mw.month === data.month) {
                        logs.push(l);
                    }
                });
                var json = JSON.stringify(logs, null, 2);
                // 顯示到 textarea (在 panel 內)
                var ta = document.getElementById('dump-textarea-' + mkey);
                if (ta) {
                    ta.style.display = 'block';
                    ta.value = json;
                }
                // 同時 console
                if (typeof console !== 'undefined' && console.log) {
                    console.log('=== Month ' + data.year + '-' + data.month + ' All Logs ===');
                    console.log('Total: ' + logs.length + ' logs');
                    console.log(json);
                }
            } catch (e) {
                console.error('Dump 錯誤:', e.message);
            }
        };
        // v1.4.23: 完整 dump 模式 - 顯示所有月內 logs + 每筆排除原因
                // v1.4.25 緊急 fix: 加回 var allMonthLogs 宣告 (v1.4.23 patch 意外刪掉)
                var allMonthLogs = [];
                appLogs.forEach(function(l) {
                    if (!l.date || !l.pages || l.pages <= 0) return;
                    var mw = getMonthWeek(l.date);
                    if (mw.year === m.year && mw.month === m.month) {
                        allMonthLogs.push(Object.assign({}, l, { _week: mw.week }));
                    }
                });
                var filterLabel = 'Filter: cat=' + filterCatM + ' / mis=' + filterMisM + ' / allowedUnitIds=' + (allowedUnitIdsM ? allowedUnitIdsM.size + ' 個' : 'ALL');
                // v1.5.206: dump button 完全隱藏 (debug 工具只在 console, window.dumpMonthLogs function 保留)
                // 不輸出任何按鈕, panel 也保持隱藏 (debug 功能存在但不顯示 UI)
                html += '<div style="display:none;" data-debug-tools-for="' + mkey + '"></div>';
                // panel 預設隱藏, 點按鈕展開
                html += '<div class="monthly-debug-panel monthly-detail-panel" data-mkey="' + mkey + '" style="display:none; padding:10px; background:#fef9e7; border:1px solid #f39c12; border-radius:6px; margin-bottom:10px; max-height:500px; overflow-y:auto; font-size:0.75em;">';
                html += '<textarea id="dump-textarea-' + mkey + '" style="display:none; width:100%; height:200px; margin-top:8px; font-family:monospace; font-size:0.75em; padding:6px; border:1px solid #ccc; border-radius:4px;" readonly></textarea>';
                var dumpWeekGrouped = {};
                allMonthLogs.forEach(function(l) {
                    var key = 'W' + l._week;
                    if (!dumpWeekGrouped[key]) dumpWeekGrouped[key] = [];
                    dumpWeekGrouped[key].push(l);
                });
                Object.keys(dumpWeekGrouped).sort(function(a, b) { return parseInt(a.slice(1)) - parseInt(b.slice(1)); }).forEach(function(wk) {
                    var logs = dumpWeekGrouped[wk];
                    var totalW = logs.reduce(function(s, l) { return s + l.pages; }, 0);
                    // v1.4.31: 先 trace 一遍 reason, 計算 ✓ 頁數 = bar 實際計入的
                    var keptPages = 0;
                    logs.forEach(function(l) {
                        var reason = '?';
                        var cat = l.category || '?';
                        if (cat === '🔄 系統重排' || cat === '🗓️ 計畫管理') {
                            reason = '✗cat=' + cat;
                        } else if (filterCatM !== 'ALL' && cat !== filterCatM) {
                            reason = '✗cat不符(' + cat + '≠' + filterCatM + ')';
                        } else if (filterMisM !== 'ALL' && allowedUnitIdsM && l.unitId && !allowedUnitIdsM.has(l.unitId) && l.mission !== filterMisM) {
                            reason = '✗mis不符(uid不在mission 且 mission字串≠' + filterMisM + ')';
                        } else {
                            reason = '✓';
                            keptPages += l.pages;
                        }
                    });
                    html += '<b>' + wk + ':</b> 全部 <span style="color:#e74c3c;">' + totalW + ' 頁</span> (' + logs.length + ' 筆) → bar計入 <span style="color:green;">' + keptPages + ' 頁</span><br>';
                    logs.forEach(function(l, i) {
                        var reason = '?';
                        var cat = l.category || '?';
                        if (cat === '🔄 系統重排' || cat === '🗓️ 計畫管理') {
                            reason = '✗cat=' + cat;
                        } else if (filterCatM !== 'ALL' && cat !== filterCatM) {
                            reason = '✗cat不符(' + cat + '≠' + filterCatM + ')';
                        } else if (filterMisM !== 'ALL' && allowedUnitIdsM && l.unitId && !allowedUnitIdsM.has(l.unitId) && l.mission !== filterMisM) {
                            reason = '✗mis不符(uid不在mission 且 mission字串≠' + filterMisM + ')';
                        } else {
                            reason = '✓';
                        }
                        html += '<span style="font-family:monospace; display:block; padding-left:15px; font-size:1.05em;">&nbsp;&nbsp;' + (i+1) + '. ' + l.date + ' | ' + reason + ' | [' + cat + ' / ' + (l.mission||'?') + '] | ' + (l.subject||'?') + ' | ' + (l.unitName||'?') + ' | P.' + (l.start||0) + '~' + (l.end||0) + ' | ' + l.pages + '頁 | uid=' + (l.unitId||'-') + ' | id=' + (l.id||'?') + '</span>';
                    });
                    html += '<br>';
                });
                html += '</div>';
                var weekKeys = Object.keys(m.weeks).sort(function(a, b) { return parseInt(a) - parseInt(b); });
                html += '<div class="monthly-chart-area">';
                // Y 軸刻度 (頁數) - 5 等分
                html += '<div class="monthly-yaxis-wrap">';
                html += '<div class="monthly-yaxis-title">頁數</div>';
                html += '<div class="monthly-yaxis">';
                for (var yi = 0; yi <= 4; yi++) {
                    var yv = Math.round(maxWeekPages * yi / 4);
                    html += '<div class="monthly-yaxis-label">' + yv + '</div>';
                }
                html += '</div>';
                html += '</div>';
                html += '<div class="monthly-weeks">';
                // v1.4.19: 同步用 Denias 的週次定義 (W1 = 月初~首週日, W2+ = 首週一~每7天)
                var firstOfMonth = new Date(m.year, m.month - 1, 1);
                var dayOfWeek = firstOfMonth.getDay();
                var firstSunday = new Date(firstOfMonth);
                var sunOffset = dayOfWeek === 0 ? 0 : (7 - dayOfWeek);
                firstSunday.setDate(firstOfMonth.getDate() + sunOffset);
                var firstMonday = new Date(firstOfMonth);
                var monOffset = dayOfWeek === 0 ? 1 : (8 - dayOfWeek);
                if (dayOfWeek === 1) monOffset = 0;
                firstMonday.setDate(firstOfMonth.getDate() + monOffset);
                // v1.5.202: 算本月 lastOfMonth (最後一天), wkEnd 不超過 lastOfMonth
                var lastOfMonthChart = new Date(m.year, m.month, 0);
                weekKeys.forEach(function(wk) {
                    var pages = m.weeks[wk];
                    var h = Math.max(2, (pages / maxWeekPages) * 180);
                    var wkStart, wkEnd;
                    if (parseInt(wk) === 1) {
                        // W1 = 月初 ~ 首週日
                        wkStart = new Date(firstOfMonth);
                        wkEnd = new Date(firstSunday);
                    } else {
                        // W2+ = 首週一 + (wk-2)*7 ~ +6 天, 但不超過本月 lastOfMonth
                        wkStart = new Date(firstMonday);
                        wkStart.setDate(firstMonday.getDate() + (parseInt(wk) - 2) * 7);
                        wkEnd = new Date(wkStart);
                        wkEnd.setDate(wkStart.getDate() + 6);
                        // v1.5.202: 限制 wkEnd 不超過本月最後一天, 避免跨月
                        if (wkEnd > lastOfMonthChart) {
                            wkEnd = new Date(lastOfMonthChart);
                        }
                    }
                    var startStr = (wkStart.getMonth() + 1) + '/' + wkStart.getDate();
                    var endStr = (wkEnd.getMonth() + 1) + '/' + wkEnd.getDate();
                    html += '<div class="monthly-week-bar-wrap">' +
                        '<div class="monthly-week-pages">' + pages + '</div>' +
                        '<div class="monthly-week-bar-area" style="height:180px"><div class="monthly-week-bar" style="height:' + h + 'px;" title="W' + wk + ' (' + startStr + '~' + endStr + '): ' + pages + ' 頁"></div></div>' +
                        '<div class="monthly-week-label">W' + wk + '</div>' +
                        '<div class="monthly-week-range">' + startStr + '~' + endStr + '</div>' +
                    '</div>';
                });
                html += '</div>';  // .monthly-weeks
                html += '<div class="monthly-axis-caption">週次 · 日期範圍</div>';
                html += '</div>';  // .monthly-chart-area
                html += '</div>';  // .monthly-block
            });
            html += '</div>';
            root.innerHTML = html;
        }
                    function switchUnitCoverageView(cat, mis) {
            jumpToUnitCalendar(null, cat, mis);
        }
        
        function jumpToUnitCalendar(unitId, cat, mis) {
            // v1.5.86: 簡化 - 點單元 → 切月曆 + 設 highlight (不清掉其他任務)
            var suInfo = window._treeScheduledUnits && window._treeScheduledUnits[unitId];
            
            // v1.5.186: 若此單元沒有任何排程任務, 提示「進度待安排」, 不跳月曆
            if (!suInfo || suInfo.totalTasks === 0 && suInfo.donePages === 0) {
                alert('📌 此單元尚未排程\n請先到「🪄 建立智慧排程」新增任務');
                return;
            }
            
            // 1. 找 plan
            var targetPlanId = null;
            if (suInfo && suInfo.firstPlanId) targetPlanId = suInfo.firstPlanId;
            if (!targetPlanId && cat && mis) {
                var p = appPlans.find(p => p.cat === cat && p.name === mis);
                if (p) targetPlanId = p.id;
            }
            if (!targetPlanId && cat) {
                var p = appPlans.find(p => p.cat === cat);
                if (p) targetPlanId = p.id;
            }
            if (!targetPlanId && appPlans.length > 0) targetPlanId = appPlans[0].id;
            
            if (!targetPlanId) {
                console.log('[jumpToUnitCalendar] 找不到任何 plan');
                return;
            }
            
            // 2. openPlanner() 確保 dropdown populate
            openPlanner();
            
            // 3. 設定 planner-selector
            var plannerSel = el('planner-selector');
            if (plannerSel) plannerSel.value = targetPlanId;
            
            // 4. cat = plan 的 cat, mis = ALL (全部顯示)
            var targetPlan = appPlans.find(p => p.id === targetPlanId);
            var filterCat = targetPlan ? targetPlan.cat : (cat || 'ALL');
            var catFilter = el('planner-cat-filter');
            if (catFilter) {
                catFilter.value = filterCat;
                onPlannerCatChange();
            }
            var misFilter = el('planner-mis-filter');
            if (misFilter) misFilter.value = 'ALL';
            
            // 5. 切到該單元第一個 task 的月份
            var targetMonth = null;
            if (targetPlan && targetPlan.grid) {
                Object.keys(targetPlan.grid).forEach(dStr => {
                    var tasks = targetPlan.grid[dStr] || [];
                    for (var i = 0; i < tasks.length; i++) {
                        if (tasks[i].unitId === unitId && !targetMonth) {
                            targetMonth = dStr.substring(0, 7);
                        }
                    }
                });
            }
            if (targetMonth && typeof currentViewDate !== 'undefined') {
                var parts = targetMonth.split('-');
                currentViewDate = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, 1);
            }
            
            // 6. 設 highlight (不清掉其他任務,所有任務都顯示)
            window._highlightUnitId = unitId;
            window._filteredGrid = null;
            
            // 7. render
            renderCalendar();
        }
        
        function returnToTreeView() {
            // v1.5.86: 從月曆返回樹狀圖
            openStats();
            // switchStatsView('tree') - 在 openStats 裡已處理
        }
        
        function renderDashboard() { 
            // v1.6.67: 強制 sync appPlans 跟清 cache
            if (multiData && multiData[currentUserId]) {
                appPlans = multiData[currentUserId].plans || [];
            }
            if (typeof _collectSubjectUnitsCache !== 'undefined') {
                _collectSubjectUnitsCache = new WeakMap();
            }
            // v1.6.69: refresh _treeScheduledUnits 讓 mission tree 立刻有正確資料
            // 修首頁重整後 mission tree 全白的 bug
            if (typeof window.refreshTreeScheduledUnits === 'function') {
                window.refreshTreeScheduledUnits();
            }
            var root = el('dashboard-root'); root.innerHTML = ''; 
            root.innerHTML += renderDashSummary();
            // v1.5.77: 單元進度總覽已整合到樹狀圖 (renderTreeView),不再單獨顯示
            
            var filterCat = el('filter-category') ? el('filter-category').value : 'ALL'; 
            var filterMis = el('filter-mission') ? el('filter-mission').value : 'ALL'; 
            
            var totalRendered = 0; 
            window._dashDataStore = {}; 
            
            // v1.5.163: 簡單對應算法 (task.unitId 對應 unit), 不用 overlap 跨單元分布
            var simpleDone = getUnitDonePagesByUnitIdMatch(filterCat, filterMis);
            // v1.6.65: 不過濾 mission 的 done 計算 (mission 只決定 unit 範圍,不限制哪些 mission 的 task 算 done)
            var simpleDoneAllMissions = getUnitDonePagesByUnitIdMatch(null, null);
            var logData = {};
            appLogs.forEach(l => {
                if(l.category === '🔄 系統重排' || l.category === '🗓️ 計畫管理') return;
                if(!logData[l.unitId]) logData[l.unitId] = { dates: new Set(), lastDate: '', totalDonePages: 0 };
                logData[l.unitId].dates.add(l.date);
                if (l.date > logData[l.unitId].lastDate) logData[l.unitId].lastDate = l.date;
                logData[l.unitId].totalDonePages += l.pages;
            });
            // v1.5.149: 不再用 overlap algorithm (task.isDone=true 但實際沒寫過的 unit 會被誤算)
// 原 v1.5.109 覆蓋逻辑錯誤: 漠南非洲 example 有 task.isDone=true 但 dates=0,
// 被 overlap 覆盖後 totalDonePages = 全 unit pages, 結果被當 doneUnits (但實際沒寫過)
// v1.5.149: 只用 log 統計總 pages,不用 overlap
            // Object.keys(overlapData).forEach(...)  -- 已停用
            var targetOrder = ['國文', '數學', '英文', '歷史', '地理', '公民', '理化', '生物'];
            Object.keys(appMissions).forEach(cat => { 
                if (filterCat !== 'ALL' && filterCat !== cat) return; 
                if(Object.keys(appMissions[cat]).length === 0) return; 
                var catHtml = `<div class="category-title">${cat}</div>`; 
                var catHasContent = false; 
                
                Object.keys(appMissions[cat]).forEach(mis => { 
                    if (filterCat !== 'ALL' && filterMis !== 'ALL' && filterMis !== mis) return; 
                    var mTree = buildMissionTree(cat, mis); 
                    if(Object.keys(mTree).length === 0) return; 
                    
                                            var cardSimpleDone = getUnitDonePagesByUnitIdMatch(cat, mis);
var misHtml = `<div class="mission-section"><div class="mission-title">${mis}</div><div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">`; 
                    
                    var subjectsInMission = Object.keys(mTree);
                    subjectsInMission.sort((a, b) => {
                        var idxA = targetOrder.indexOf(a);
                        var idxB = targetOrder.indexOf(b);
                        if(idxA === -1) idxA = 999;
                        if(idxB === -1) idxB = 999;
                        return idxA - idxB;
                    });
                    subjectsInMission.forEach(sub => { 
                        var sTree = mTree[sub]; 
                        
                        var totalPages = 0;
                        var donePages = 0;
                        var doneUnits = [];
                        var todoUnits = [];
                        
                        function processUnit(u) {
                            // v1.5.148 + v1.5.149: 改用 helper, 根據 unit-based 或 page-based 計算進度
                            var ctx = findUnitContext(u.id);
                            var typeObj = ctx ? ctx.typeObj : null;
                            var pTotal = getUnitTotalCount(u, typeObj);
                            // v1.5.159: page-based 改用 overlapData 算 done pages (跨單元任務會按 overlap 分布到每個 unit)
                            // unit-based 用 getUnitDoneCount (scan task.isDone)
                            // v1.6.65: done 從所有 mission 算 (不限 dropdown mission), 避免一模 done 在二模 view 看不到
                            var pDone = isUnitBasedType(typeObj) ? getUnitDoneCount(u, typeObj, null, null) : (simpleDoneAllMissions[u.id] || 0);
                            if (pDone > pTotal) pDone = pTotal;
                            // v1.5.162: page-based 改用 overlapData 判斷 done (v1.5.159 後 overlapData 已是權威來源)
                            // 不再用 logData dates (跨單元任務的 log 只記到 1 個 unit, 其他 unit dates=0 但其實已 done)
                            var isActuallyDone = false;
                            if (pDone >= pTotal) {
                                if (isUnitBasedType(typeObj)) {
                                    isActuallyDone = pDone === 1 && getUnitLastDoneDate(u.id) !== null;
                                } else {
                                    isActuallyDone = getUnitLastDoneDate(u.id) !== null;  // 必須月曆有勾完成才算 算出的 pDone
                                }
                            }
                            // v1.5.149: donePages + totalPages 始終累加 (partial done 也算)
                            totalPages += pTotal;
                            donePages += pDone;
                            
                            if (isActuallyDone) {
                                doneUnits.push({
                                    id: u.id,
                                    name: u.name,
                                    days: (function() {
                                        var days = new Set();
                                        if (Array.isArray(appPlans)) {
                                            appPlans.forEach(function(p) {
                                                if (!p.grid) return;
                                                Object.keys(p.grid).forEach(function(d) {
                                                    (p.grid[d] || []).forEach(function(t) {
                                                        if (t && t.isDone && t.unitId === u.id) days.add(d);
                                                    });
                                                });
                                            });
                                        }
                                        return days.size > 0 ? days.size : 1;
                                    })(),
                                    finishDate: getUnitLastDoneDate(u.id) || '未知' 
                                });
                            } else {
                                // v1.5.149: 如果是 unit-based 但 task 實際沒 isDone, 重設 pDone
                                if (isUnitBasedType(typeObj) && pDone > 0) pDone = 0;
                                todoUnits.push({
                                    id: u.id,
                                    name: u.name,
                                    pagesLeft: Math.max(0, pTotal - pDone),
                                    totalPages: pTotal,
                                    range: isUnitBasedType(typeObj) ? u.name : ('P.' + u.start + '~' + u.end),
                                    expected: findUnitScheduledDate(u.id),
                                    openTaskCount: getUnitOpenTaskCount(u.id)
                                });
                            }
                        }
                        if (sTree.type === 'custom') { 
                            sTree.items['custom'].forEach(processUnit); 
                        } else { 
                            var volsToRender = Object.keys(sTree.items); // v1.6.136: 包含 instance-prefixed vol 
                            volsToRender.forEach(vol => { 
                                sTree.items[vol].forEach(processUnit); 
                            }); 
                        }
                        
                        var pct = totalPages > 0 ? Math.round((donePages / totalPages) * 100) : 0;
                        var pctRemain = 100 - pct;
                        
                        // v1.5.149: 判斷 subject 為純 unit-based (全部 units 都 unit-based)
                        // 否則顯示 頁
                        var allUnitBased = true;
                        var anyUnit = false;
                        Object.keys(sTree.items).forEach(function(volKey) {
                            (sTree.items[volKey] || []).forEach(function(u) {
                                anyUnit = true;
                                var ctxCheck = findUnitContext(u.id);
                                if (!ctxCheck || !isUnitBasedType(ctxCheck.typeObj)) allUnitBased = false;
                            });
                        });
                        if (!anyUnit) allUnitBased = false;
                        var unitLabelText = allUnitBased ? 'units' : '頁';
                        
                        var dataKey = 'key_' + genId();
                        window._dashDataStore[dataKey] = { done: doneUnits, todo: todoUnits };
                        var barHtml = `
                            <div class="card" style="padding: 15px;">
                                <div class="subject-name" style="margin-bottom: 10px; border:none; padding:0;">📌 ${sub} <span style="font-size:0.8em; color:#7f8c8d; font-weight:normal;">(${donePages}/${totalPages} ${unitLabelText})</span></div>
                                <div style="display: flex; height: 35px; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; background: #fff; box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);">
                                    <div style="width: ${pct}%; background: repeating-linear-gradient(45deg, #a7f3d0, #a7f3d0 10px, #34d399 10px, #34d399 20px); display: flex; align-items: center; justify-content: center; color: #064e3b; font-weight: bold; cursor: pointer; font-size: 1.1em; text-shadow: 0 0 3px rgba(255,255,255,0.8);" title="點擊查看已完成詳細資訊" onclick="showDashDetail('done', '${sub}', '${dataKey}')">
                                        ${pct > 4 ? pct + '%' : ''}
                                    </div>
                                    <div style="width: ${pctRemain}%; background: #fff; display: flex; align-items: center; justify-content: center; color: #94a3b8; font-weight: bold; cursor: pointer;" title="未完成: ${pctRemain}%。點擊查看待完成詳細資訊" onclick="showDashDetail('todo', '${sub}', '${dataKey}')">
                                        ${pctRemain > 8 ? pctRemain + '%' : ''}
                                    </div>
                                </div>
                            </div>
                        `;
                        misHtml += barHtml;
                    }); 
                    misHtml += `</div></div>`; 
                    catHtml += misHtml; 
                    catHasContent = true; 
                    totalRendered++; 
                }); 
                if (catHasContent) root.innerHTML += catHtml; 
            }); 
            if (totalRendered === 0) root.innerHTML = '<div style="text-align:center; color:#94a3b8; margin-top: 50px; font-size: 1.2em;"><h3>📭 目前篩選的範圍內沒有內容</h3></div>'; 
        }
        window.showDashDetail = function(type, subject, dataKey) {
            var dataInfo = window._dashDataStore[dataKey];
            if (!dataInfo) return;
            var html = '';
            
            if (type === 'done') {
                var data = dataInfo.done;
                el('dd-title').innerHTML = `✅ ${subject} - 已完成單元`;
                if(data.length === 0) html = '<div style="color:#7f8c8d;">目前無已完成的單元。</div>';
                else {
                    html += '<table style="width:100%; border-collapse:collapse; text-align:left;"><tr><th style="border-bottom:2px solid #ccc; padding:10px;">單元名稱</th><th style="border-bottom:2px solid #ccc; padding:10px; text-align:center;">花費天數</th><th style="border-bottom:2px solid #ccc; padding:10px; text-align:center;">完成日期</th></tr>';
                    data.forEach(d => {
                        html += `<tr><td style="border-bottom:1px solid #eee; padding:10px; font-weight:bold; color:var(--primary);">${d.name}</td><td style="border-bottom:1px solid #eee; padding:10px; text-align:center; color:var(--accent);">${d.days} 天</td><td style="border-bottom:1px solid #eee; padding:10px; text-align:center; color:var(--secondary);">${d.finishDate}</td></tr>`;
                    });
                    html += '</table>';
                }
            } else {
                var data = dataInfo.todo;
                var totalPagesSum = data.reduce((s, d) => s + (d.totalPages || 0), 0);
                var totalLeftSum = data.reduce((s, d) => s + d.pagesLeft, 0);
                var totalDoneSum = totalPagesSum - totalLeftSum;
                var summaryLine = (totalPagesSum > 0)
                    ? ' <span style="font-size:0.75em;color:var(--secondary);font-weight:normal;">(未完成單元 ' + totalPagesSum + ' 頁 / 已完成部分 ' + totalDoneSum + ' / 剩餘 ' + totalLeftSum + ')</span>'
                    : '';
                el('dd-title').innerHTML = '⏳ ' + subject + ' - 未完成單元' + summaryLine;
                if(data.length === 0) html = '<div style="color:#7f8c8d;">🎉 太棒了！所有單元均已完成。</div>';
                else {
                    html += '<table style="width:100%; border-collapse:collapse; text-align:left;"><tr><th style="border-bottom:2px solid #ccc; padding:10px;">單元名稱</th><th style="border-bottom:2px solid #ccc; padding:10px; text-align:center;">剩餘頁數</th><th style="border-bottom:2px solid #ccc; padding:10px; text-align:center;">狀態</th></tr>';
                    data.forEach(d => {
                        var statusHtml;
                        if (d.expected) {
                            var parts = d.expected.split('-');
                            var mm = parseInt(parts[1], 10);
                            var dd = parseInt(parts[2], 10);
                            var todayStr = getLocalDateString(new Date());
                            if (d.expected < todayStr) {
                                statusHtml = '<span style="color:var(--warning); font-weight:bold;">原排 ' + mm + '/' + dd + '（逾期）</span>';
                            } else if (d.expected === todayStr) {
                                statusHtml = '<span style="color:var(--accent); font-weight:bold;">今天 ' + mm + '/' + dd + ' 完成</span>';
                            } else {
                                statusHtml = '<span style="color:var(--accent); font-weight:bold;">預定 ' + mm + '/' + dd + ' 完成</span>';
                            }
                        } else {
                            statusHtml = '<span style="color:#7f8c8d;">待安排</span>';
                        }
                        var rangeTag = d.range ? ' <span style="font-size:0.7em;color:#7f8c8d;font-weight:normal;">(' + d.range + ')</span>' : '';
                        var openTag = (d.openTaskCount && d.openTaskCount > 0) ? ' <span style="font-size:0.7em;color:var(--danger);font-weight:normal;" title="在月曆排程中還有 ' + d.openTaskCount + ' 個未勾選的 task">⚠ ' + d.openTaskCount + ' 未勾</span>' : '';
                        html += '<tr><td style="border-bottom:1px solid #eee; padding:10px; font-weight:bold; color:var(--primary);">' + d.name + rangeTag + openTag + '</td><td style="border-bottom:1px solid #eee; padding:10px; text-align:center; color:var(--danger); font-weight:bold;">' + d.pagesLeft + ' 頁</td><td style="border-bottom:1px solid #eee; padding:10px; text-align:center; font-size:0.9em;">' + statusHtml + '</td></tr>';
                    });
                    html += '</table>';
                }
            }
            el('dd-content').innerHTML = html;
            openModal('modal-dash-detail');
        }
        
        function renderUserManageList() { 
            el('user-manage-list').innerHTML = Object.keys(multiData).map(uid => {
                let avSrc = multiData[uid].avatar || DEFAULT_AVATAR;
                return `
                <div class="user-list-item" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; background:white; padding:10px; border-radius:8px; border:1px solid var(--border);">
                    <div style="display:flex; align-items:center; gap:12px;">
                        <img src="${avSrc}" style="width:45px; height:45px; border-radius:50%; object-fit:cover; cursor:pointer; border:2px solid var(--accent); transition:0.2s;" title="點擊自訂頭貼" onclick="openAvatarModal('${uid}')" onmouseover="this.style.opacity=0.8; this.style.transform='scale(1.1)';" onmouseout="this.style.opacity=1; this.style.transform='scale(1)';">
                        <span style="font-weight:bold; font-size:1.1em; ${uid===currentUserId?'color:var(--accent);':''}">${multiData[uid].name} ${uid===currentUserId?' (目前)':''}</span>
                    </div>
                    <div>
                        <button class="btn-warning" style="padding:4px 8px;" onclick="renameUser('${uid}')">✏️ 名稱</button>
                        <button class="btn-danger" style="padding:4px 8px;" onclick="deleteUser('${uid}')" ${Object.keys(multiData).length===1?'disabled':''}></button>
                    </div>
                </div>
                `;
            }).join(''); 
        }
        function openAvatarModal(uid) {
            el('avatar-edit-uid').value = uid;
            el('avatar-upload').value = ''; 
            openModal('modal-avatar');
        }
        function handleAvatarUpload(input) {
            let uid = el('avatar-edit-uid').value;
            if (!uid || !input.files || !input.files[0]) return;
            
            let file = input.files[0];
            let reader = new FileReader();
            
            reader.onload = function(e) {
                let img = new Image();
                img.onload = function() {
                    let canvas = document.createElement('canvas');
                    let ctx = canvas.getContext('2d');
                    
                    let size = Math.min(img.width, img.height);
                    let sx = (img.width - size) / 2;
                    let sy = (img.height - size) / 2;
                    
                    canvas.width = 150;
                    canvas.height = 150;
                    ctx.drawImage(img, sx, sy, size, size, 0, 0, 150, 150);
                    
                    multiData[uid].avatar = canvas.toDataURL('image/jpeg', 0.8);
                    
                    saveToLocal();
                    renderUserManageList();
                    if (uid === currentUserId) switchUser();
                    closeModal('modal-avatar');
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
        function setEmojiAvatar(emoji) {
            let uid = el('avatar-edit-uid').value;
            if(!uid) return;
            
            let canvas = document.createElement('canvas');
            canvas.width = 150;
            canvas.height = 150;
            let ctx = canvas.getContext('2d');
            
            ctx.fillStyle = '#f1f5f9';
            ctx.fillRect(0, 0, 150, 150);
            
            ctx.font = '80px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(emoji, 75, 80);
            
            multiData[uid].avatar = canvas.toDataURL('image/png');
            
            saveToLocal();
            renderUserManageList();
            if (uid === currentUserId) switchUser();
            closeModal('modal-avatar');
        }
        function addNewUser() { openInputModal('➕ 建立新學生', '', function(name) { var newId = genId(); multiData[newId] = { name: name, master: {}, missions: {}, logs: [], plans: [], avatar: '' }; saveToLocal(); el('user-selector').innerHTML += `<option value="${newId}">${name}</option>`; renderUserManageList(); }); }
        function renameUser(uid) { openInputModal('✏️ 修改學生名稱', multiData[uid].name, function(newName) { if (newName !== multiData[uid].name) { multiData[uid].name = newName; saveToLocal(); initUsers(); renderUserManageList(); } }); }
        function deleteUser(uid) { if (Object.keys(multiData).length <= 1) return; if (confirm('確定刪除此學生的所有資料？')) { delete multiData[uid]; if (currentUserId === uid) currentUserId = Object.keys(multiData)[0]; saveToLocal(); initUsers(); renderUserManageList(); } }
        async function exportDataToFile() {
            // v1.5.226: 全機備份改寫 — 抓所有 StudyMap_ 前綴的 localStorage 資料
            if (el('page-settings') && el('pane-master').classList.contains('active')) extractCurrentEditorData();
            try { saveToLocal(); } catch(e) { console.warn('saveToLocal 失敗:', e); }
            var snapshot = {
                _meta: {
                    app: 'StudyMap',
                    schema: 'full-v1',  // v1.5.226 之後的備份格式
                    exportedAt: new Date().toISOString(),
                    note: '全機備份: 教材庫 + 答對率 + PlanEvents + 看板 + 主題 + 偏好 + 安全備份/快照'
                },
                keys: {}
            };
            // 抓所有 StudyMap_ 前綴的 key (含 dynamic 命名的 PlanEvents)
            for (var i = 0; i < localStorage.length; i++) {
                var key = localStorage.key(i);
                if (key && key.indexOf('StudyMap_') === 0 && key !== STORAGE_KEY_LAST_EXPORT) {
                    var raw = localStorage.getItem(key);
                    try {
                        snapshot.keys[key] = JSON.parse(raw);
                    } catch(e) {
                        // 非 JSON (理論上不會, 但保險存字串)
                        snapshot.keys[key] = raw;
                    }
                }
            }
            snapshot._meta.keyCount = Object.keys(snapshot.keys).length;
            var dataStr = JSON.stringify(snapshot, null, 2);
            var defaultFilename = "StudyMap_Backup_" + getLocalDateString(new Date()) + ".json";
            try {
                if (window.showSaveFilePicker) {
                    const opts = {
                        suggestedName: defaultFilename,
                        types: [{ description: 'JSON 備份檔案', accept: {'application/json': ['.json']} }]
                    };
                    const handle = await window.showSaveFilePicker(opts);
                    const writable = await handle.createWritable();
                    await writable.write(dataStr);
                    await writable.close();
                    // 標記已備份
                    try { localStorage.setItem(STORAGE_KEY_LAST_EXPORT, new Date().toISOString()); } catch(e) {}
                    clearDirty('export-success');
                    updateBackupIndicator();
                    if (confirm("✅ JSON 備份匯出成功！\n\n(已備份 " + snapshot._meta.keyCount + " 個資料區段)\n\n請問是否要關閉教材庫設定與系統備份畫面？")) {
                        returnToHome();
                    }
                } else {
                    var blob = new Blob([dataStr], { type: "application/json" });
                    var url = URL.createObjectURL(blob);
                    var link = document.createElement("a");
                    link.href = url;
                    link.download = defaultFilename;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    URL.revokeObjectURL(url);
                    setTimeout(function() {
                        // 標記已備份 (在下載視窗跑完後更新)
                        try { localStorage.setItem(STORAGE_KEY_LAST_EXPORT, new Date().toISOString()); } catch(e) {}
                        clearDirty('export-success');
                        updateBackupIndicator();
                        if (confirm("✅ JSON 備份匯出成功！\n\n(已備份 " + snapshot._meta.keyCount + " 個資料區段)\n\n請問是否要關閉設定畫面？")) {
                            returnToHome();
                        }
                    }, 500);
                }
            } catch(err) {
                if (err.name !== 'AbortError') {
                    console.error(err);
                    alert("檔案儲存失敗！" + (err.message || ''));
                }
            }
        }
        // v1.5.16: 專門補數學的「複習講義」instance (Denias 22:19 指定名稱為「複習講義」)
        // 從 v1.5.3 硬編碼備份 (window._v153_BACKUP_MASTER_STR) 取出數學的 7 冊內容 merge 進去
        // 不會動其他科目 (英文/理化/歷史/地理/公民/生物 都不用改)
        // v1.5.16 修正: 先找現有 volume type instance (例如 Denias 的「大滿貫」), 改名成「複習講義」+ 補 volOrder
        //              如果完全沒有 volume instance 才 push 新 instance
        function restoreMathLecture() {
            var user = multiData[currentUserId];
            if (!user || !user.masters || !user.masters['會考複習']) {
                return alert('找不到 user.masters["會考複習"]');
            }
            var mathSub = user.masters['會考複習']['數學'];
            if (!mathSub) return alert('找不到「數學」subject');
            if (!mathSub.materials) mathSub.materials = {};
            // 確保「複習講義」type 存在
            if (!mathSub.materials['複習講義']) {
                mathSub.materials['複習講義'] = { id: 'mt_' + genId(), name: '複習講義', instances: [] };
            }
            var lectureType = mathSub.materials['複習講義'];
            // 步驟 1: 找現有的「複習講義」instance (name 完全匹配), 跳過
            var exactMatch = lectureType.instances.find(function(i) { return i.name === '複習講義'; });
            if (exactMatch) {
                var totalUnits = 0;
                Object.keys(exactMatch.vols || {}).forEach(function(v) {
                    totalUnits += (exactMatch.vols[v] || []).length;
                });
                return alert('「數學 / 複習講義」instance 已存在, 跳過 (不重複加)\n\nvol 數: ' + Object.keys(exactMatch.vols || {}).length + '\nunit 總數: ' + totalUnits);
            }
            // 步驟 2 (v1.5.16): 找現有 volume type instance (例如「大滿貫」), 改名成「複習講義」+ 補 volOrder
            var existingVol = lectureType.instances.find(function(i) { return i.type === 'volume' && i.vols; });
            if (existingVol) {
                var oldName = existingVol.name;
                existingVol.name = '複習講義';
                if (!existingVol.volOrder) existingVol.volOrder = Object.keys(existingVol.vols);
                saveToLocal();
                var totalUnits = 0;
                Object.keys(existingVol.vols).forEach(function(v) {
                    totalUnits += (existingVol.vols[v] || []).length;
                });
                console.log('v1.5.16: ✅ 把數學「' + oldName + '」instance 改名為「複習講義」', { volCount: Object.keys(existingVol.vols).length, unitCount: totalUnits, volOrder: existingVol.volOrder });
                alert('✅ 數學「複習講義」已合併!\n\n把舊 instance「' + oldName + '」改名 + 補上 volOrder\n\nvol 數: ' + Object.keys(existingVol.vols).length + '\nunit 總數: ' + totalUnits + '\nvol 名稱: ' + Object.keys(existingVol.vols).join(', '));
                return;
            }
            // 步驟 3: 沒有任何 volume instance, 從 v1.5.3 硬編碼備份 parse 數學的 7 冊建立新 instance
            if (!window._v153_BACKUP_MASTER_STR) return alert('找不到 v1.5.3 硬編碼備份');
            var backup;
            try {
                var all = JSON.parse(window._v153_BACKUP_MASTER_STR);
                backup = all['數學'];
            } catch(e) {
                return alert('Parse 備份失敗: ' + e.message);
            }
            if (!backup || !backup.vols) return alert('備份裡沒有數學的 vols 資料');
            // 建立「複習講義」instance (instance name = 「複習講義」)
            lectureType.instances.push({
                id: 'ins_' + genId(),
                name: '複習講義',
                type: 'volume',
                units: null,
                vols: backup.vols,
                volOrder: backup.volOrder || Object.keys(backup.vols)
            });
            saveToLocal();
            var mainUnits = [];
            Object.keys(backup.vols).forEach(function(volName) {
                mainUnits = mainUnits.concat(backup.vols[volName]);
            });
            alert('✅ 數學「複習講義」instance 已建立!\n\nvol 數: ' + Object.keys(backup.vols).length + '\nunit 總數: ' + mainUnits.length + '\nvol 名稱: ' + Object.keys(backup.vols).join(', '));
            console.log('v1.5.16: ✅ 數學複習講義 (新 instance) 已 merge', { volCount: Object.keys(backup.vols).length, unitCount: mainUnits.length, volOrder: backup.volOrder });
        }
        // v1.5.16: 清掉段考複習的 5 個會考 type (v1.5.13 repair 邏輯遺留的污染)
        // Denias 23:13: 段考複習的教材類型不預設, 自己手動加
        // 這按鈕讓 Denias 一鍵清掉 v1.5.13 自動補的會考 type
        function cleanupSegmentExamTypes() {
            var user = multiData[currentUserId];
            if (!user || !user.masters || !user.masters['段考複習']) return alert('找不到 user.masters["段考複習"]');
            var defaultTypes = ['複習講義','複習卷','數字題本','模擬題本','考古題'];
            var removed = 0;
            var detail = [];
            Object.keys(user.masters['段考複習']).forEach(function(subName) {
                var subj = user.masters['段考複習'][subName];
                if (subj && subj.materials) {
                    defaultTypes.forEach(function(t) {
                        if (subj.materials[t]) {
                            delete subj.materials[t];
                            removed++;
                            detail.push(subName + '/' + t);
                        }
                    });
                }
            });
            saveToLocal();
            console.log('v1.5.16: ✅ 清掉段考複習 ' + removed + ' 個會考 type', detail);
            alert('✅ 從段考複習移除了 ' + removed + ' 個會考 type\n\n(複習講義/複習卷/數字題本/模擬題本/考古題)\n\n現在可以自己手動加段考專用的 type 了！\n\n詳細:\n' + detail.slice(0, 20).join('\n') + (detail.length > 20 ? '\n... 還有 ' + (detail.length - 20) + ' 個' : ''));
        }
// v1.5.14: 從舊備份 (v1.5.1 之前的 config.master 格式) merge 進來
        // 那些 subj.materials 存在但缺「複習講義」type (原本 v1.5.2 migrate 應該建但被跳過)
        function restoreFromOldBackup() {
            openInputModal('📦 請貼上舊備份的 config.master JSON', '', function(text) {
                if (!text) return;
                var backupMaster;
                try {
                    backupMaster = JSON.parse(text);
                } catch (e) {
                    return alert('JSON parse 失敗: ' + e.message + '\n\n請貼上備份檔裡的 "master" 物件內容 (以 { 開頭 以 } 結尾)');
                }
                var user = multiData[currentUserId];
                if (!user || !user.masters) return alert('找不到 user data');
                if (!user.masters['會考複習']) user.masters['會考複習'] = {};
                var restored = [];
                var skipped = [];
                Object.keys(backupMaster).forEach(function(subName) {
                    var backupSub = backupMaster[subName];
                    var currentSub = user.masters['會考複習'][subName];
                    if (!currentSub) {
                        skipped.push(subName + ' (現在沒有此科目)');
                        return;
                    }
                    if (!currentSub.materials) currentSub.materials = {};
                    // 確保「複習講義」type 存在
                    if (!currentSub.materials['複習講義']) {
                        currentSub.materials['複習講義'] = { id: 'mt_' + genId(), name: '複習講義', instances: [] };
                    }
                    var lectureType = currentSub.materials['複習講義'];
                    // 檢查是否已經有「(原主教材)」instance
                    var hasMain = lectureType.instances.some(function(i) { return i.name === '(原主教材)'; });
                    if (hasMain) {
                        skipped.push(subName + ' (已經有原主教材)');
                        return;
                    }
                    if (backupSub.type === 'custom') {
                        lectureType.instances.push({
                            id: 'ins_' + genId(),
                            name: '(原主教材)',
                            type: 'custom',
                            units: backupSub.units || [],
                            vols: null,
                            volOrder: null
                        });
                        restored.push(subName + ' (custom, ' + (backupSub.units || []).length + ' 個 unit)');
                    } else if (backupSub.type === 'volume') {
                        var mainUnits = [];
                        Object.keys(backupSub.vols || {}).forEach(function(volName) {
                            (backupSub.vols[volName] || []).forEach(function(u) {
                                mainUnits.push(Object.assign({}, u, { vol: volName }));
                            });
                        });
                        lectureType.instances.push({
                            id: 'ins_' + genId(),
                            name: '(原主教材)',
                            type: 'volume',
                            units: null,
                            vols: backupSub.vols || {},
                            volOrder: backupSub.volOrder || Object.keys(backupSub.vols || {})
                        });
                        restored.push(subName + ' (volume, ' + mainUnits.length + ' 個 unit, ' + Object.keys(backupSub.vols || {}).length + ' 冊)');
                    } else {
                        skipped.push(subName + ' (type=' + backupSub.type + ' 不明)');
                    }
                });
                saveToLocal();
                var msg = '備份還原完成!\n\n✅ 已恢復:\n' + restored.join('\n') + '\n\n⏭️ 跳過:\n' + (skipped.length ? skipped.join('\n') : '(無)') + '\n\n請強制重整 ⌘+Shift+R 後檢查教材庫 tab 1。';
                alert(msg);
                console.log('v1.5.14 restoreFromOldBackup:\n✅ Restored:', restored, '\n⏭️ Skipped:', skipped);
            });
        }
// v1.5.226: import handler 改寫 — 接受全機備份新格式 + 舊單 key 格式向後相容
document.getElementById('import-file').addEventListener('change', function(e) {
    var file = e.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(ev) {
        try {
            var data = JSON.parse(ev.target.result);
            if (!data || typeof data !== 'object') throw new Error('頂層不是 object');
            var keysToWrite = {};
            // 偵測新格式 (v1.5.226 全機備份): 有 _meta.app === 'StudyMap' + keys 物件
            if (data._meta && data._meta.app === 'StudyMap' && data.keys && typeof data.keys === 'object') {
                keysToWrite = data.keys;
                var keyCount = Object.keys(keysToWrite).length;
                var backupTime = data._meta.exportedAt || '未知時間';
                if (!confirm('⚠️ 偵測到「全機備份」格式\n\n' +
                        '備份時間: ' + backupTime + '\n' +
                        '資料區段數: ' + keyCount + '\n\n' +
                        '即將覆蓋目前瀏覽器內所有 StudyMap 資料！\n' +
                        '(強烈建議先做一次匯出, 保留現有版本再還原)\n\n' +
                        '確定要還原嗎?')) return;
            }
            // 舊格式向後相容 (只備份 STORAGE_KEY_FAMILY): 一個大 object 直接當 multiData 用
            else if (Object.keys(data).length > 0 && data[Object.keys(data)[0]] &&
                     typeof data[Object.keys(data)[0]].masters !== 'undefined') {
                keysToWrite[STORAGE_KEY_FAMILY] = data;
                if (!confirm('⚠️ 偵測到「舊版單一備份」格式 (只含教材庫資料)\n\n' +
                        '注意: 此格式不包含 答對率 / PlanEvents / 看板外觀 等資料\n' +
                        '建議改用 v1.5.226 之後的「全機備份」重做一次\n\n' +
                        '確定要還原嗎?')) return;
            }
            else {
                throw new Error('無法辨識的備份檔格式 (既非全機備份也非舊版教材庫備份)');
            }
            var written = 0, failed = 0;
            var kArr = Object.keys(keysToWrite);
            for (var i = 0; i < kArr.length; i++) {
                var k = kArr[i];
                if (typeof k !== 'string' || k.indexOf('StudyMap_') !== 0) continue;  // 安全過濾
                try {
                    localStorage.setItem(k, JSON.stringify(keysToWrite[k]));
                    written++;
                } catch(e2) {
                    console.error('匯入失敗 ' + k + ':', e2);
                    failed++;
                }
            }
            if (failed > 0) {
                alert('匯入部分完成: ' + written + ' 成功, ' + failed + ' 失敗\n' +
                      '請檢查 console 查看失敗的 key');
            }
            alert('🎉 還原完成! (' + written + ' 個資料區段)\n系統即將重新載入。');
            window.location.reload();
        } catch(err) {
            alert('匯入失敗: ' + (err.message || '檔案格式錯誤或無法解析'));
        }
    };
    reader.onerror = function() { alert('讀檔失敗'); };
    reader.readAsText(file);
    e.target.value = '';
});
        // ============================================================
        // v1.5.226: 全機備份 / 離開提醒模組
        // ============================================================
        var STORAGE_KEY_LAST_EXPORT = 'StudyMap_LastExportAt_V226';
        var STORAGE_KEY_DISMISS_AT = 'StudyMap_DirtyDismissAt_V226';
        var BACKUP_WARN_DAYS = 3;  // B3: 3 天閾值 (Denias 指定)
        var _dirtyState = { active: false, since: null, dismissedAt: null };
        try { _dirtyState.dismissedAt = localStorage.getItem(STORAGE_KEY_DISMISS_AT); } catch(e) {}
        function markDirty() {
            if (_dirtyState.active) return;  // 已經標記過了
            _dirtyState.active = true;
            _dirtyState.since = new Date();
            renderDirtyBanner();
        }
        function clearDirty(reason) {
            _dirtyState.active = false;
            _dirtyState.since = null;
            _dirtyState.dismissedAt = null;
            try { localStorage.removeItem(STORAGE_KEY_DISMISS_AT); } catch(e) {}
            renderDirtyBanner();
        }
        function dismissDirtyBanner() {
            _dirtyState.dismissedAt = new Date().toISOString();
            try { localStorage.setItem(STORAGE_KEY_DISMISS_AT, _dirtyState.dismissedAt); } catch(e) {}
            renderDirtyBanner();
        }
        function renderDirtyBanner() {
            var banner = el('dirty-banner');
            if (!banner) return;
            // 若使用者明確 dismiss 過，且沒新變動，就維持關閉
            if (!_dirtyState.active) { banner.classList.remove('show'); return; }
            var t = _dirtyState.since;
            var hh = t ? String(t.getHours()).padStart(2, '0') : '--';
            var mm = t ? String(t.getMinutes()).padStart(2, '0') : '--';
            var tsEl = el('dirty-since-time');
            if (tsEl) tsEl.textContent = hh + ':' + mm;
            banner.classList.add('show');
        }
        // 攔截 localStorage.setItem, 任何 StudyMap_ 寫入都視為 dirty
        // 注意: STORAGE_KEY_LAST_EXPORT 本身不算 dirty (它記錄的是「已備份過」)
        (function() {
            var KEEP_OUT = [STORAGE_KEY_LAST_EXPORT, STORAGE_KEY_DISMISS_AT];
            try {
                var origSet = Storage.prototype.setItem;
                Storage.prototype.setItem = function(key, value) {
                    origSet.call(this, key, value);
                    if (typeof key === 'string' && key.indexOf('StudyMap_') === 0 &&
                        KEEP_OUT.indexOf(key) === -1) {
                        try { if (typeof window.markDirty === 'function') window.markDirty(); }
                        catch(e) { console.error('markDirty 失敗:', e); }
                    }
                };
            } catch(e) {
                console.warn('v1.5.226: setItem 攔截失敗 (Safari 私有模式?) — dirty 追蹤會少幾個', e);
            }
        })();
        // B2: 離開頁面提醒
        window.addEventListener('beforeunload', function(e) {
            if (_dirtyState.active) {
                e.preventDefault();
                e.returnValue = '你有未匯出的資料異動, 真的要離開嗎?';
                return '你有未匯出的資料異動, 真的要離開嗎?';
            }
        });
        // iOS Safari 用 pagehide
        window.addEventListener('pagehide', function() {
            if (_dirtyState.active) {
                // 不能彈 modal, 留 console 提示 + dirty flag 留待下次進入時 banner 仍在
                console.warn('v1.5.226: 離開時有 dirty 資料未匯出');
            }
        });
        // B1: 備份狀態指示 (3 天閾值)
        function getLastExportTime() {
            try {
                var t = localStorage.getItem(STORAGE_KEY_LAST_EXPORT);
                if (!t) return null;
                var d = new Date(t);
                if (isNaN(d.getTime())) return null;
                return d;
            } catch(e) { return null; }
        }
        function getBackupStatusInfo() {
            var last = getLastExportTime();
            if (!last) return { cls: 'never', label: '⚠️ 從未備份過', lastIso: null, days: null };
            var days = Math.floor((Date.now() - last.getTime()) / 86400000);
            if (days >= BACKUP_WARN_DAYS) {
                return { cls: 'warn', label: '⚠️ ' + days + ' 天沒備份', lastIso: last.toISOString(), days: days };
            }
            var dayLabel = days === 0 ? '今天' : days + ' 天前';
            return { cls: 'ok', label: '✅ ' + dayLabel + '已備份', lastIso: last.toISOString(), days: days };
        }
        function updateBackupIndicator() {
            // v1.6.70.1: backup-status-bar/icon/text 已移除 (改為獨立按鈕)
            // 保留函式但 no-op, 避免其他呼叫 crash
        }
        // 每分鐘重新計算備份狀態 (跨日或時間流逝時刷新指示器)
        setInterval(updateBackupIndicator, 60000);
        // ============================================================
        // v1.5.226: end of module
        // ============================================================
        initUsers();
        updateBackupIndicator();  // v1.5.226: 啟動時更新備份狀態
        loadTheme();
        renderAppPrefsCatHours();  // v1.5.112: 初始化任務預設時數 UI
        // v1.5.227: clearDirty 到 init 完成後才觸發 (避免 init 內部 setItem 誤觸)
        // switchUser 在 initUsers 內部會 setItem( FAMILY) re-write, 不代表 user 改過資料
        setTimeout(function() { clearDirty('init-settled'); }, 2000);
    
// ============================================================
// Phase 1: Crop/Erase Modal System + Old Wrong-Note DB Functions
// ============================================================
// --- Phase 1: handleFilesForCrop (entry point for crop flow) ---
var manualBoxes = [];
var batchCounter = 0;
async function handleFilesForCrop(files) {
    if (!files || files.length === 0) return;
    var workspace = document.getElementById('wn-crop-workspace');
    if (!workspace) { console.error('[Phase1] wn-crop-workspace not found'); return; }
    workspace.innerHTML = '';
    workspace.classList.add('crop-mode');
    var modal = document.getElementById('crop-modal');
    if (modal) {
        modal.style.display = 'flex';
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
    }
    var statsWN = document.getElementById('stats-wrongnotes');
    if (statsWN) { statsWN.style.display = 'block'; statsWN.classList.add('active'); }
    // v1.6.67: wrongnotes-root removed (replaced with iframe); wnRoot no-op
    var wnImport = document.getElementById('wn-import');
    if (wnImport) {
        document.querySelectorAll('.wn-tab').forEach(function(t){ t.classList.remove('active'); });
        document.querySelectorAll('.wn-page').forEach(function(p){ p.classList.remove('active'); });
        var tBtn = document.querySelector('.wn-tab[data-wntab="import"]');
        if (tBtn) tBtn.classList.add('active');
        wnImport.classList.add('active');
    }
    batchCounter++;
    manualBoxes = [];
    for (var i = 0; i < files.length; i++) {
        var file = files[i];
        if (file.type === "application/pdf") {
            await renderPDF(file, workspace);
        } else if (file.type.startsWith("image/")) {
            await renderImage(file, workspace);
        }
    }
}
async function renderImage(file, workspace) {
    return new Promise(function(resolve) {
        var reader = new FileReader();
        reader.onload = function(e) {
            var img = document.createElement('img');
            img.src = e.target.result;
            img.alt = file.name || '';
            img.style.width = '100%';
            img.style.display = 'block';
            img.onload = function() {
                createPageContainer(img, workspace);
                resolve();
            };
        };
        reader.readAsDataURL(file);
    });
}
async function renderPDF(file, workspace) {
    var card = document.createElement('div');
    card.className = 'file-card';
    card.innerHTML = '<div style="text-align:center;padding:20px;color:#e74c3c;">📄 PDF: ' + escapeHtml(file.name) + '<br><small>PDF 功能施工中</small></div>';
    workspace.appendChild(card);
}
// Old version approach: image directly in .page-container
// Click on container fires createNewManualBox at click position (percentage-based)
function createPageContainer(mediaEl, workspace) {
    var container = document.createElement('div');
    container.className = 'page-container';
    container.appendChild(mediaEl);
    // Listen on container (not workspace) so e.offsetX/Y is relative to image area
    container.addEventListener('mousedown', function(e) {
        if (!window._isManualAdding) return;
        if (e.target.tagName === 'BUTTON') return;
        e.preventDefault();
        e.stopPropagation();
        // Use e.offsetX/Y (relative to container) → convert to percentage
        var rect = container.getBoundingClientRect();
        var xPerc = (e.offsetX / rect.width) * 100;
        var yPerc = (e.offsetY / rect.height) * 100;
        var newBox = {
            id: 'box_' + Date.now(),
            x: 0,       // always start from left edge, matching image width
            y: yPerc,   // click Y position (top)
            w: 100,     // image box width (100%)
            h: 12,      // height 12% of image
            targetPageIndex: container.dataset.pageIndex ? parseInt(container.dataset.pageIndex) : 0
        };
        if (!container.dataset.pageIndex) {
            var pcs = workspace.querySelectorAll('.page-container');
            for (var pi = 0; pi < pcs.length; pi++) {
                if (pcs[pi] === container) { container.dataset.pageIndex = pi; break; }
            }
        }
        manualBoxes.push(newBox);
        renderManualBoxes();
        window._isManualAdding = false;
        var tip = document.getElementById('manual-tip');
        if (tip) tip.textContent = '✅ 已新增，可拖曳調整或繼續新增';
    });
    workspace.appendChild(container);
}
function addImageCardToWorkspace(dataUrl, fileName, workspace) {
    var img = document.createElement('img');
    img.src = dataUrl;
    img.alt = fileName || '';
    img.style.width = '100%';
    img.style.display = 'block';
    img.onload = function() {
        createPageContainer(img, workspace);
    };
}
function onSourceChange(selectEl) {
    var input = selectEl.closest('.file-card').querySelector('.custom-source[type="text"]');
    if (input) input.style.display = (selectEl.value === '其他') ? 'block' : 'none';
}
function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
// enableManualCrop removed - buttons always visible
function startManualBox() {
    window._isManualAdding = true;
    var tip = document.getElementById('manual-tip');
    if (tip) tip.textContent = '👉 請在圖片上點擊以新增題框';
}
function undoManualBox() {
    if (manualBoxes.length > 0) { manualBoxes.pop(); renderManualBoxes(); }
}
function renderManualBoxes() {
    var workspace = document.getElementById('wn-crop-workspace');
    if (!workspace) return;
    workspace.querySelectorAll('.page-container .mock-crop-box').forEach(function(b){ b.remove(); });
    manualBoxes.forEach(function(box) {
        var div = document.createElement('div');
        div.className = 'mock-crop-box';
        div.style.left = box.x + '%';
        div.style.top = box.y + '%';
        div.style.width = box.w + '%';
        div.style.height = box.h + '%';
        div.innerHTML = '<button class="delete-box-btn" onclick="deleteManualBox(this.dataset.boxid)" data-boxid="' + box.id + '">✕</button><div class="add-crop-btn" onclick="toggleCroppedQuestion(this)" data-boxid="' + box.id + '">+</div><div class="resize-handle tl" data-corner="tl"></div><div class="resize-handle tr" data-corner="tr"></div><div class="resize-handle br" data-corner="br"></div><div class="resize-handle bl" data-corner="bl"></div>';
        div.onmousedown = function(e) {
            if (e.target.classList.contains('delete-box-btn')) return;
            e.preventDefault();
            e.stopPropagation();
            var startX = e.clientX, startY = e.clientY;
            var origX = box.x, origY = box.y, origW = box.w, origH = box.h;
            var container = div.parentElement; // box is now appended to page-container
            var cW = container ? container.offsetWidth : 800;
            var cH = container ? container.offsetHeight : 600;
            // Detect if click is on a resize handle
            var corner = e.target.dataset && e.target.dataset.corner;
            var isResize = !!corner;
            function onMove(me) {
                var dx = ((me.clientX - startX) / cW) * 100;
                var dy = ((me.clientY - startY) / cH) * 100;
                if (isResize) {
                    // Resize from corner
                    if (corner === 'br') {
                        // Bottom-right: increase width and height
                        box.w = Math.max(5, origW + dx);
                        box.h = Math.max(5, origH + dy);
                    } else if (corner === 'tr') {
                        // Top-right: increase width, decrease height from top
                        box.w = Math.max(5, origW + dx);
                        box.h = Math.max(5, origH - dy);
                        box.y = origY + dy;
                        div.style.top = box.y + '%';
                    } else if (corner === 'bl') {
                        // Bottom-left: decrease width, increase height
                        box.w = Math.max(5, origW - dx);
                        box.h = Math.max(5, origH + dy);
                        box.x = origX + dx;
                        div.style.left = box.x + '%';
                    } else if (corner === 'tl') {
                        // Top-left: decrease width and height from top
                        box.w = Math.max(5, origW - dx);
                        box.h = Math.max(5, origH - dy);
                        box.x = origX + dx;
                        box.y = origY + dy;
                        div.style.left = box.x + '%';
                        div.style.top = box.y + '%';
                    }
                    div.style.width = box.w + '%';
                    div.style.height = box.h + '%';
                } else {
                    // Drag (move)
                    box.x = origX + dx;
                    box.y = origY + dy;
                    div.style.left = box.x + '%';
                    div.style.top = box.y + '%';
                }
            }
            function onUp() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        };
        // Find the page-container that matches this box's targetPageIndex
        var container = workspace.querySelectorAll('.page-container')[box.targetPageIndex || 0];
        if (container) {
            container.appendChild(div);
        } else {
            workspace.appendChild(div);
        }
    });
}
function deleteManualBox(boxId) {
    manualBoxes = manualBoxes.filter(function(b){ return b.id !== boxId; });
    renderManualBoxes();
}
function toggleCroppedQuestion(btn) {
    if (btn.classList.contains('selected')) {
        btn.classList.remove('selected');
        btn.innerText = '+';
        btn.style.background = '#007aff';
    } else {
        btn.classList.add('selected');
        btn.innerText = '✓';
        btn.style.background = '#34c759';
    }
}
function triggerAutoCrop() {
    var workspace = document.getElementById('wn-crop-workspace');
    if (!workspace) return;
    var img = workspace.querySelector('img');
    if (!img) return;
    var newBox = { id: 'box_' + Date.now(), x: 50, y: 50, w: 200, h: 100 };
    manualBoxes.push(newBox);
    renderManualBoxes();
}
function cancelCropping() {
    var modal = document.getElementById('crop-modal');
    if (modal) modal.style.display = 'none';
    var workspace = document.getElementById('wn-crop-workspace');
    if (workspace) { workspace.innerHTML = ''; workspace.classList.remove('crop-mode'); }
    manualBoxes = [];
}
function finishCropping() {
    var modal = document.getElementById('crop-modal');
    if (modal) modal.style.display = 'none';
    var workspace = document.getElementById('wn-crop-workspace');
    if (workspace) workspace.classList.remove('crop-mode');
    var settingsContainer = document.getElementById('settings-container');
    var slider = document.getElementById('cards-slider');
    if (settingsContainer && slider && (slider.children.length > 0 || manualBoxes.length > 0)) {
        settingsContainer.style.display = 'block';
    }
}
// ============================================================
// Old Wrong-Note DB Crop/Box Functions
// ============================================================
function WN_cancelImage() {
    WN_STATE.importedImage = null;
    WN_STATE.importedFileName = null;
    WN_STATE.cropBoxes = [];
    WN_STATE.eraseBoxes = [];
    WN_renderBoxes();
    document.getElementById('wn-file-input').value = '';
    var cropArea = document.getElementById('wn-crop-area');
    var modeBar = document.getElementById('wn-mode-bar');
    var dropZone = document.getElementById('wn-drop-zone');
    if (cropArea) cropArea.style.display = 'none';
    if (modeBar) modeBar.style.display = 'none';
    if (dropZone) dropZone.style.display = 'block';
}
function WN_setMode(mode) {
    WN_STATE.mode = mode;
    document.querySelectorAll('.wn-mode-btn').forEach(function(b){ b.classList.remove('active'); });
    var btn = document.getElementById('wn-mode-' + mode);
    if (btn) btn.classList.add('active');
}
function WN_updateModeButtons() {
    document.querySelectorAll('.wn-mode-btn').forEach(function(b){ b.classList.remove('active'); });
    var activeBtn = document.getElementById('wn-mode-' + WN_STATE.mode);
    if (activeBtn) activeBtn.classList.add('active');
}
function WN_handleFileInput(input) {
    if (!input.files || !input.files.length) return;
    var file = input.files[0];
    WN_STATE.importedFileName = file.name;
    var reader = new FileReader();
    reader.onload = function(e) {
        WN_STATE.importedImage = e.target.result;
        WN_showCropImage(e.target.result);
    };
    reader.readAsDataURL(file);
}
function WN_renderBoxes() {
    var cropArea = document.getElementById('wn-crop-area');
    if (!cropArea) return;
    cropArea.querySelectorAll('.wn-crop-box, .wn-erase-box').forEach(function(b){ b.remove(); });
    var img = document.getElementById('wn-crop-img');
    if (!img) return;
    var rect = cropArea.getBoundingClientRect();
    if (rect.width === 0) return;
    var scaleX = rect.width / img.naturalWidth;
    var scaleY = rect.height / img.naturalHeight;
    WN_STATE.cropBoxes.forEach(function(box, i) {
        var div = document.createElement('div');
        div.className = 'wn-crop-box';
        div.style.left = (box.x * scaleX) + 'px';
        div.style.top = (box.y * scaleY) + 'px';
        div.style.width = (box.w * scaleX) + 'px';
        div.style.height = (box.h * scaleY) + 'px';
        div.innerHTML = '<span class="wn-box-num">' + (i+1) + '</span><button class="wn-box-delete" onclick="WN_deleteBox(event,' + box.id + ')">✕</button>';
        div.onmousedown = function(ev) {
            ev.stopPropagation();
            if (ev.target.classList.contains('wn-box-delete')) return;
            ev.preventDefault();
            var startX = ev.clientX, startY = ev.clientY;
            var origX = box.x, origY = box.y;
            function onMove(e) {
                box.x = Math.max(0, origX + (e.clientX - startX) / scaleX);
                box.y = Math.max(0, origY + (e.clientY - startY) / scaleY);
                div.style.left = (box.x * scaleX) + 'px';
                div.style.top = (box.y * scaleY) + 'px';
            }
            function onUp() { document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        };
        cropArea.appendChild(div);
    });
    WN_STATE.eraseBoxes.forEach(function(box, i) {
        var div = document.createElement('div');
        div.className = 'wn-erase-box';
        div.style.left = (box.x * scaleX) + 'px';
        div.style.top = (box.y * scaleY) + 'px';
        div.style.width = (box.w * scaleX) + 'px';
        div.style.height = (box.h * scaleY) + 'px';
        div.innerHTML = '<button class="wn-erase-del" onclick="WN_deleteEraseBox(event,' + box.id + ')">✕</button>';
        div.onmousedown = function(ev) {
            ev.stopPropagation();
            if (ev.target.classList.contains('wn-erase-del')) return;
            ev.preventDefault();
            var startX = ev.clientX, startY = ev.clientY;
            var origX = box.x, origY = box.y;
            function onMove(e) {
                box.x = Math.max(0, origX + (e.clientX - startX) / scaleX);
                box.y = Math.max(0, origY + (e.clientY - startY) / scaleY);
                div.style.left = (box.x * scaleX) + 'px';
                div.style.top = (box.y * scaleY) + 'px';
            }
            function onUp() { document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        };
        cropArea.appendChild(div);
    });
}
function WN_deleteEraseBox(event, boxId) {
    event.stopPropagation();
    event.preventDefault();
    WN_STATE.eraseBoxes = WN_STATE.eraseBoxes.filter(function(b){ return b.id !== boxId; });
    WN_applyErase();
}
function WN_handleCleanImage(input) {
    if (!input.files || !input.files.length) return;
    WN_STATE.cleanImage = null;
    var reader = new FileReader();
    reader.onload = function(e) {
        WN_STATE.cleanImage = e.target.result;
        var cleanUpload = document.getElementById('wn-clean-upload');
        if (cleanUpload) cleanUpload.style.display = 'none';
        var cleanImg = document.getElementById('wn-clean-img');
        if (cleanImg) { cleanImg.src = e.target.result; cleanImg.style.display = 'block'; }
    };
    reader.readAsDataURL(input.files[0]);
}
// Old WN drag/drop (redirect to new handleFilesForCrop)
function WN_onDragOver(e) { e.preventDefault(); e.stopPropagation(); }
function WN_onDrop(e) {
    e.preventDefault(); e.stopPropagation();
    var files = e.dataTransfer.files;
    if (files && files.length > 0) {
        var dt = new DataTransfer();
        for (var i = 0; i < files.length; i++) dt.items.add(files[i]);
        var fileInput = document.getElementById('wn-file-input');
        if (fileInput) {
            fileInput.value = '';  // Clear value first to ensure onchange fires
            fileInput.files = dt.files;
        }
        // Don't call handleFilesForCrop directly - the onchange will fire and call it once
    }
}
// Phase 1 stub note functions
function generateNote() {
    // v1.6.66: redirect to real WN_generateNote
    if (typeof WN_generateNote === 'function') {
        WN_generateNote();
        return;
    }
    alert('[v1.6.66] 請透過完整 flow');
}
function saveNotes() {
    // v1.6.66: call real save
    if (typeof WN_saveFinalNote === 'function') {
        WN_saveFinalNote();
        return;
    }
    alert('[v1.6.66] 儲存功能已改用 WN_saveFinalNote()');
}
function renderViewPage() {
    var container = document.getElementById('view-slots-container');
    if (container) container.innerHTML = '<div class="placeholder-text">📖 錯題筆記檢視功能施工中</div>';
}
(function() {
  console.log('[智慧排程模式] 初始化互動功能');
  let activeExpandedDesc = null;
  
  // 建立狀態列
  if (!document.getElementById('wz-status-line')) {
    const statusLine = document.createElement('div');
    statusLine.id = 'wz-status-line';
    statusLine.style.cssText = 'position: fixed; bottom: 15px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.9); color: white; padding: 8px 16px; border-radius: 20px; font-size: 14px; max-width: 90%; text-align: center; z-index: 99999; box-shadow: 0 4px 12px rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.2); display: none; transition: opacity 0.3s ease;';
    document.body.appendChild(statusLine);
    console.log('[智慧排程模式] 狀態列建立完成');
  }
  
  const statusLine = document.getElementById('wz-status-line');
  
  // 初始化按鈕互動
  function initButtonInteractions() {
    const descTexts = document.querySelectorAll('.wz-desc-text');
    console.log('[智慧排程模式] 找到描述元素:', descTexts.length);
    
    descTexts.forEach(span => {
      // v1.6.143: 直接設置樣式（繞過 CSS 選擇器問題）
      span.style.cssText = 'flex: 1 1 0 !important;min-width: 0 !important;max-width: 280px !important;white-space: nowrap !important;overflow: hidden !important;text-overflow: ellipsis !important;display: block !important;width: 100% !important;line-height: 1.4 !important;';
      console.log('[智慧排程模式] 直接設置樣式:', span.textContent.substring(0, 15) + '...');
      // 清除舊的事件監聽器
      const newSpan = span.cloneNode(true);
      span.parentNode.replaceChild(newSpan, span);
      
      // 新增新的監聽器
      newSpan.addEventListener('click', function(e) {
        e.stopPropagation();
        console.log('[智慧排程模式] 點擊:', this.dataset.full?.substring(0, 30) + '...');
        
        // 收合前一個展開的元素
        if (activeExpandedDesc && activeExpandedDesc !== this) {
          activeExpandedDesc.classList.remove('expanded');
          console.log('[智慧排程模式] 收合前一個元素');
        }
        
        // 切換當前元素
        if (this.classList.contains('expanded')) {
          this.classList.remove('expanded');
          activeExpandedDesc = null;
          statusLine.style.display = 'none';
          console.log('[智慧排程模式] 收合當前元素');
        } else {
          this.classList.add('expanded');
          activeExpandedDesc = this;
          
          // 顯示狀態列
          statusLine.textContent = this.dataset.full || this.innerText;
          statusLine.style.display = 'block';
          statusLine.style.opacity = '1';
          console.log('[智慧排程模式] 展開當前元素，狀態列更新');
          
          // 自動隱藏計時器
          setTimeout(() => {
            if (activeExpandedDesc === this) {
              statusLine.style.opacity = '0';
              setTimeout(() => {
                if (activeExpandedDesc === this) {
                  statusLine.style.display = 'none';
                  console.log('[智慧排程模式] 狀態列自動隱藏');
                }
              }, 300);
            }
          }, 4000);
        }
      });
      
      // 懸停顯示完整文字
      newSpan.addEventListener('mouseenter', function() {
        if (!activeExpandedDesc) {
          statusLine.textContent = this.dataset.full || this.innerText;
          statusLine.style.display = 'block';
          statusLine.style.opacity = '1';
        }
      });
      
      newSpan.addEventListener('mouseleave', function() {
        if (!activeExpandedDesc) {
          statusLine.style.opacity = '0';
          setTimeout(() => {
            if (!activeExpandedDesc) {
              statusLine.style.display = 'none';
            }
          }, 300);
        }
      });
    });
    
    console.log('[智慧排程模式] 互動功能初始化完成');
  }
  
  // 全域點擊收合
  document.addEventListener('click', function(e) {
    if (activeExpandedDesc && !activeExpandedDesc.contains(e.target)) {
      activeExpandedDesc.classList.remove('expanded');
      activeExpandedDesc = null;
      statusLine.style.display = 'none';
      console.log('[智慧排程模式] 點擊頁面其他區域，收合所有元素');
    }
  });
  
  // 延遲初始化以確保 DOM 準備好
  setTimeout(initButtonInteractions, 100);
})();
