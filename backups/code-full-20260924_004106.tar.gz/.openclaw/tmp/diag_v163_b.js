// v1.6.163 診斷 B — 全 localStorage 找 "英文" 字串 + "龐辣甲"
(function(){
  var keys = [];
  for (var i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i));
  
  console.log('=== grep 英文 + 龐辣甲 in all keys ===');
  keys.forEach(function(k){
    var v = localStorage.getItem(k);
    if (!v) return;
    if (v.indexOf('龐辣甲') >= 0 || v.indexOf('L1~L3') >= 0 || v.indexOf('大滿貫甲') >= 0) {
      console.log('  HIT in KEY: '***');
      console.log('    length: '+v.length);
      console.log('    preview around 龐辣甲:');
      var idx = v.indexOf('龐辣甲');
      if (idx > 0) console.log('    '+v.substring(Math.max(0,idx-50), idx+200));
    }
  });
  
  console.log('=== appPlans / SafetyBackup ===');
  ['appPlans','StudyMap_SafetyBackup_V106','StudyMap_Family_Data_V20'].forEach(function(k){
    var v = localStorage.getItem(k);
    console.log(k+': length='+(v? v.length: 0));
    if (v) {
      try {
        var d = JSON.parse(v);
        if (Array.isArray(d)) console.log('  array length='+d.length);
        else if (typeof d === 'object') {
          var ks = Object.keys(d);
          console.log('  object keys='+ks.slice(0,5).join(','));
        }
      } catch(e) { console.log('  JSON parse fail'); }
    }
  });
})();
